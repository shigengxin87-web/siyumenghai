(() => {
  "use strict";

  const CHANNEL = "hongshuskill-page";
  const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
  const NOTE_INACCESSIBLE_MARKERS = [
    "当前笔记暂时无法浏览",
    "用户不存在",
    "账号已注销",
    "该用户已注销",
    "私密笔记",
    "仅作者可见",
    "因用户设置，你无法查看",
    "该内容因违规已被删除",
    "因违规无法查看",
    "该笔记已被删除",
    "笔记不存在",
    "内容不存在",
    "已失效",
    "isn't available",
  ];
  const NOTE_VERIFICATION_MARKERS = [
    "扫码查看",
    "打开小红书App扫码",
    "请使用小红书App扫码",
    "安全验证",
  ];

  function safeLocationUrl() {
    try {
      const url = new URL(location.href);
      return `${url.origin}${url.pathname}`;
    } catch {
      return "";
    }
  }

  function isVisible(element) {
    if (!(element instanceof Element)) return false;
    const rect = element.getBoundingClientRect();
    const style = getComputedStyle(element);
    const opacity = Number.parseFloat(style.opacity || "1");
    const isTrap = element.closest("[data-hp-kind],[button-hp-installed]");
    return rect.width > 0
      && rect.height > 0
      && rect.left > -1000
      && rect.top > -1000
      && style.display !== "none"
      && style.visibility !== "hidden"
      && opacity > 0.01
      && !isTrap;
  }

  function firstVisible(selectors, root = document) {
    for (const selector of selectors) {
      const match = Array.from(root.querySelectorAll(selector)).find(isVisible);
      if (match) return match;
    }
    return null;
  }

  function exactText(text, selectors = "button,[role='button'],a,div,span") {
    return Array.from(document.querySelectorAll(selectors)).find(
      (element) => isVisible(element) && element.textContent.trim() === text,
    );
  }

  async function waitFor(getter, timeoutMs = 15000, intervalMs = 150) {
    const deadline = Date.now() + timeoutMs;
    while (Date.now() < deadline) {
      const result = getter();
      if (result) return result;
      await sleep(intervalMs);
    }
    return null;
  }

  function clickElement(element) {
    if (!element) throw new Error("找不到可点击元素");
    element.scrollIntoView({ block: "center", inline: "nearest" });
    element.focus?.();
    element.click();
  }

  function pointerClick(element) {
    if (!element) throw new Error("找不到可点击元素");
    element.scrollIntoView({ block: "center", inline: "nearest" });
    element.focus?.();
    const eventInit = { bubbles: true, cancelable: true, composed: true, view: window };
    if (typeof PointerEvent === "function") {
      element.dispatchEvent(new PointerEvent("pointerdown", { ...eventInit, pointerId: 1, pointerType: "mouse", isPrimary: true, buttons: 1 }));
    }
    element.dispatchEvent(new MouseEvent("mousedown", { ...eventInit, buttons: 1 }));
    if (typeof PointerEvent === "function") {
      element.dispatchEvent(new PointerEvent("pointerup", { ...eventInit, pointerId: 1, pointerType: "mouse", isPrimary: true }));
    }
    element.dispatchEvent(new MouseEvent("mouseup", eventInit));
    element.dispatchEvent(new MouseEvent("click", eventInit));
  }

  function switchIsChecked(element) {
    if (!element) return false;
    return element.getAttribute("aria-checked") === "true"
      || /(?:^|\s)(?:active|checked)(?:\s|$)/.test(element.className)
      || Boolean(element.querySelector("[aria-checked='true'],.checked,.active"));
  }

  function setNativeValue(element, value) {
    if (!element) throw new Error("找不到输入框");
    const prototype = element instanceof HTMLTextAreaElement
      ? HTMLTextAreaElement.prototype
      : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(prototype, "value")?.set;
    element.focus();
    if (setter) setter.call(element, value);
    else element.value = value;
    element.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: value }));
    element.dispatchEvent(new Event("change", { bubbles: true }));
  }

  function fillEditable(element, value) {
    if (!element) throw new Error("找不到正文编辑器");
    element.focus();
    const selection = window.getSelection();
    const range = document.createRange();
    range.selectNodeContents(element);
    selection.removeAllRanges();
    selection.addRange(range);
    document.execCommand("insertText", false, value);
    element.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: value }));
    element.dispatchEvent(new Event("change", { bubbles: true }));
  }

  function appendEditable(element, value) {
    element.focus();
    const selection = window.getSelection();
    const range = document.createRange();
    range.selectNodeContents(element);
    range.collapse(false);
    selection.removeAllRanges();
    selection.addRange(range);
    document.execCommand("insertText", false, value);
    element.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: value }));
  }

  function cleanText(element) {
    return element?.textContent?.replace(/\s+/g, " ").trim() || "";
  }

  const FEEDBACK_SELECTORS = [
    "[role='alert']",
    "[role='dialog']",
    ".d-toast",
    ".toast",
    ".toast-error",
    ".toast-success",
    ".el-message",
    ".notification",
    "[class*='error-message']",
    "[class*='verify-modal']",
    "[class*='risk-block']",
    "[class*='forbidden-page']",
    ".access-wrapper",
    ".error-wrapper",
    ".blocked-wrapper",
    ".not-found-wrapper",
  ].join(",");

  const FEEDBACK_EXCLUDE_SELECTOR = [
    "#detail-title",
    "#detail-desc",
    ".note-content",
    ".comments-container",
    ".comment-item",
    ".parent-comment",
    "[contenteditable='true']",
    "textarea",
    "input",
  ].join(",");

  function scopedFeedbackElements() {
    return Array.from(document.querySelectorAll(FEEDBACK_SELECTORS)).filter((element) => {
      if (!isVisible(element)) return false;
      if (element.closest?.(FEEDBACK_EXCLUDE_SELECTOR)) return false;
      return true;
    });
  }

  function scopedFeedbackText() {
    return [...new Set(scopedFeedbackElements().map(cleanText).filter(Boolean))].join("\n");
  }

  function scopedFeedbackMatch(pattern) {
    return scopedFeedbackText().match(pattern);
  }

  function parseLink(href) {
    if (!href) return { feed_id: "", xsec_token: "", xsec_source: "" };
    try {
      const url = new URL(href, location.origin);
      const match = url.pathname.match(/\/explore\/([^/?]+)/)
        || url.pathname.match(/\/search_result\/([^/?]+)/)
        || url.pathname.match(/\/user\/profile\/[^/?]+\/([^/?]+)/);
      return {
        feed_id: match?.[1] || "",
        xsec_token: url.searchParams.get("xsec_token") || "",
        xsec_source: url.searchParams.get("xsec_source") || "",
      };
    } catch {
      return { feed_id: "", xsec_token: "", xsec_source: "" };
    }
  }

  function feedFromCard(card, index, defaultSource = "pc_feed") {
    const link = card.querySelector([
      "a.cover[href*='xsec_token']",
      "a.title[href*='xsec_token']",
      "a[href*='/explore/'][href*='xsec_token']",
      "a[href*='/search_result/'][href*='xsec_token']",
    ].join(","));
    const parsed = parseLink(link?.href);
    const authorLink = card.querySelector(".author-wrapper a[href*='/user/profile/'],a.author[href*='/user/profile/']");
    let authorUrl = null;
    try {
      authorUrl = authorLink ? new URL(authorLink.href || authorLink.getAttribute("href"), location.origin) : null;
    } catch {
      authorUrl = null;
    }
    const userMatch = authorUrl?.pathname.match(/\/user\/profile\/([^/?]+)/);
    const image = card.querySelector("a.cover img,img[data-xhs-img],img");
    const like = firstVisible([".like-wrapper .count", ".like-wrapper span:last-child", ".footer .count"], card);
    return {
      feed_id: parsed.feed_id || card.dataset.noteId || "",
      xsec_token: parsed.xsec_token || link?.dataset.xsecToken || "",
      xsec_source: parsed.xsec_source || defaultSource,
      title: cleanText(card.querySelector("a.title,.title")),
      note_type: card.querySelector(".play-icon,.video-icon,[class*='play']") ? "video" : "normal",
      author: {
        user_id: userMatch?.[1] || authorLink?.dataset.userId || "",
        nickname: cleanText(card.querySelector(".author-wrapper .name,.author-wrapper .username,.author .name")),
        xsec_token: authorUrl?.searchParams.get("xsec_token") || "",
        xsec_source: authorUrl?.searchParams.get("xsec_source") || defaultSource,
      },
      metrics: { likes: cleanText(like) },
      cover_url: image?.currentSrc || image?.src || "",
      index,
    };
  }

  function commentFromNode(node) {
    const own = node.matches(".comment-item") ? node : node.querySelector(":scope > .comment-item,.comment-item");
    if (!own) return null;
    const id = own.id?.replace(/^comment-/, "") || own.dataset.commentId || "";
    const author = own.querySelector(".author .name,.author-wrapper .name,a[data-user-id]");
    const content = own.querySelector(":scope .content .note-text,:scope .content");
    const userId = author?.dataset.userId || author?.getAttribute("href")?.match(/\/user\/profile\/([^/?]+)/)?.[1] || "";
    const subNodes = Array.from(node.querySelectorAll([
      ":scope > .comment-item-sub",
      ".reply-container .comment-item-sub",
      ".sub-comment .comment-item",
    ].join(",")));
    return {
      comment_id: id,
      content: cleanText(content),
      author: { user_id: userId, nickname: cleanText(author) },
      likes: cleanText(own.querySelector(".like .count,.like-wrapper .count")),
      date: cleanText(own.querySelector(".date")),
      replies: subNodes.map(commentFromNode).filter(Boolean),
    };
  }

  async function checkLogin() {
    const outcome = await waitFor(() => {
      const loginBox = firstVisible([".login-container", "[class*='login-container']"]);
      const qrCode = firstVisible(["img.qrcode-img", ".qrcode-img img"]);
      const profileLink = firstVisible([
        ".main-container .user a[href*='/user/profile/']",
        ".main-container .user .link-wrapper .channel",
        "a[href*='/user/profile/'] .channel",
        "li.user a[href*='/user/profile/']",
      ]);
      if (!loginBox && !qrCode && !profileLink) return null;
      const profileAnchor = profileLink?.matches?.("a[href*='/user/profile/']")
        ? profileLink
        : profileLink?.closest?.("a[href*='/user/profile/']");
      const profileHref = profileAnchor?.getAttribute?.("href") || "";
      const userId = profileHref.match(/\/user\/profile\/([^/?]+)/)?.[1] || "";
      return {
        logged_in: Boolean(profileLink) && !loginBox,
        login_visible: Boolean(loginBox || qrCode),
        nickname: cleanText(profileLink),
        user_id: userId,
        url: safeLocationUrl(),
      };
    }, 10000, 200);
    return outcome || {
      logged_in: false,
      login_visible: false,
      inconclusive: true,
      url: safeLocationUrl(),
    };
  }

  async function noteAccess() {
    const outcome = await waitFor(() => {
      const feedback = scopedFeedbackText();
      const verification = NOTE_VERIFICATION_MARKERS.find((marker) => feedback.includes(marker));
      if (verification) {
        return {
          accessible: false,
          verification_required: true,
          reason: verification,
          url: safeLocationUrl(),
        };
      }
      const inaccessible = NOTE_INACCESSIBLE_MARKERS.find(
        (marker) => feedback.toLowerCase().includes(marker.toLowerCase()),
      );
      if (inaccessible) {
        return {
          accessible: false,
          verification_required: false,
          reason: inaccessible,
          url: safeLocationUrl(),
        };
      }
      const note = firstVisible([
        "#detail-title",
        "#detail-desc",
        ".note-content",
        ".interaction-container",
        ".note-detail-mask",
      ]);
      return note ? { accessible: true, verification_required: false, url: safeLocationUrl() } : null;
    }, 12000, 200);
    return outcome || {
      accessible: false,
      verification_required: false,
      reason: "笔记内容加载超时",
      url: safeLocationUrl(),
    };
  }

  async function qrImageDataUrl(image) {
    if (/^data:image\/png;base64,/i.test(image.src || "")) return image.src;
    try {
      await image.decode?.();
      const canvas = document.createElement("canvas");
      canvas.width = image.naturalWidth || image.width;
      canvas.height = image.naturalHeight || image.height;
      const context = canvas.getContext("2d");
      if (!context || !canvas.width || !canvas.height) throw new Error("empty canvas");
      context.drawImage(image, 0, 0, canvas.width, canvas.height);
      return canvas.toDataURL("image/png");
    } catch {
      throw new Error("登录二维码无法转换为本地 PNG，请刷新登录框后重试");
    }
  }

  async function getQrCode() {
    const status = await checkLogin();
    if (status.logged_in) return status;
    let refreshed = false;
    let image = await waitFor(() => firstVisible(["img.qrcode-img", ".qrcode-img img"]), 15000);
    if (!image) throw new Error("登录二维码未出现");
    const loginRoot = image.closest?.(".login-container,[class*='login-container'],[role='dialog']")
      || firstVisible([".login-container", "[class*='login-container']"]);
    const expired = () => /二维码.{0,8}(?:已过期|过期|已失效|失效)/.test(cleanText(loginRoot));
    if (expired()) {
      const previousSource = image.currentSrc || image.src || "";
      const refresh = firstVisible([
        "button[class*='refresh']",
        "[class*='qrcode'] [class*='refresh']",
        "[class*='qr'] [class*='refresh']",
      ], loginRoot || document) || Array.from(
        (loginRoot || document).querySelectorAll("button,[role='button'],a,span"),
      ).find((item) => isVisible(item) && /刷新二维码|点击刷新|重新获取/.test(cleanText(item)));
      if (!refresh) throw new Error("登录二维码已过期，且找不到可靠的刷新控件");
      clickElement(refresh);
      refreshed = true;
      image = await waitFor(() => {
        const candidate = firstVisible(["img.qrcode-img", ".qrcode-img img"]);
        if (!candidate) return null;
        const source = candidate.currentSrc || candidate.src || "";
        return (!expired() && source && (source !== previousSource || candidate !== image))
          ? candidate
          : null;
      }, 10000, 200);
      if (!image) throw new Error("登录二维码已过期，刷新后未出现新二维码");
    }
    const dataUrl = await qrImageDataUrl(image);
    return {
      logged_in: false,
      status: "qrcode_ready",
      refreshed,
      data_url: dataUrl,
      url: safeLocationUrl(),
    };
  }

  async function preparePhone({ phone }) {
    const status = await checkLogin();
    if (status.logged_in) return { ...status, message: "已登录，无需重新登录" };
    const input = await waitFor(() => firstVisible(["label.phone input", "input[placeholder*='手机号']"]));
    if (!input) throw new Error("找不到手机号输入框");
    setNativeValue(input, phone);
    const container = input.closest(".login-container,[class*='login-container']");
    if (!container) throw new Error("登录表单结构异常，无法安全定位用户协议");
    const agreed = container.querySelector(".agree-icon .agreed,.agree-icon .icon-wrapper.agreed,input[type='checkbox']:checked");
    if (agreed) return { logged_in: false, agreement_ready: true, skip: true };
    const agreement = firstVisible([".agree-icon .icon-wrapper", ".agree-icon", "input[type='checkbox']"], container);
    return {
      logged_in: false,
      ...elementTarget(agreement, "登录协议复选框", "login-agreement"),
    };
  }

  async function sendCodeTarget() {
    const status = await checkLogin();
    if (status.logged_in) return { ...status, skip: true };
    const button = firstVisible(["span.code-button", "button[class*='code']"]);
    return {
      logged_in: false,
      ...elementTarget(button, "发送验证码按钮", "login-send-code"),
    };
  }

  async function waitCodeSent({ phone }) {
    const outcome = await waitFor(() => {
      const risk = scopedFeedbackMatch(/访问频繁|操作频繁|账号异常|安全验证|发送受限/);
      if (risk) return { risk: risk[0] };
      const button = firstVisible(["span.code-button", "button[class*='code']"]);
      return /\d/.test(cleanText(button)) ? { countdown: button } : null;
    }, 6000, 200);
    if (outcome?.risk) {
      const error = new Error(outcome.risk);
      error.code = "risk_control_active";
      throw error;
    }
    if (!outcome?.countdown) throw new Error("验证码未进入倒计时，可能触发了频率限制");
    return { status: "code_sent", phone_masked: `${phone.slice(0, 3)}****${phone.slice(-4)}` };
  }

  async function prepareVerifyCode({ code }) {
    const input = await waitFor(() => firstVisible(["label.auth-code input", "input[placeholder*='验证码']"]));
    if (!input) throw new Error("找不到验证码输入框");
    setNativeValue(input, code);
    const submit = firstVisible([".input-container button.submit", "button[type='submit']"]);
    return {
      skip: false,
      ...elementTarget(submit, "验证码提交按钮", "login-verify"),
    };
  }

  async function waitVerifyCode() {
    const outcome = await waitFor(() => {
      const error = cleanText(firstVisible([".err-msg", "[class*='error-msg']"]));
      if (error) return { logged_in: false, message: error };
      const profile = firstVisible([".main-container .user a[href*='/user/profile/']", "li.user a[href*='/user/profile/']"]);
      return profile ? { logged_in: true, message: "登录成功" } : null;
    }, 30000, 300);
    return outcome || { logged_in: false, message: "等待登录结果超时" };
  }

  async function applyFilters({ filters }) {
    const requested = Object.entries(filters || {}).filter(([, value]) => value && value !== "不限");
    if (!requested.length) return { applied: [] };
    const filterButton = firstVisible(["div.filter", "[class*='filter']"]);
    if (!filterButton) throw new Error("找不到筛选按钮");
    if (!firstVisible([".filters-wrapper"])) clickElement(filterButton);
    const wrapper = await waitFor(() => firstVisible([".filters-wrapper"]));
    if (!wrapper) throw new Error("筛选面板未打开");
    const labels = {
      sort_by: "排序依据",
      note_type: "笔记类型",
      publish_time: "发布时间",
      search_scope: "搜索范围",
      location: "位置距离",
    };
    const groups = Array.from(wrapper.querySelectorAll(":scope > .filters,.filters"));
    const applied = [];
    for (const [key, value] of requested) {
      const group = groups.find((item) => cleanText(item).startsWith(labels[key] || ""));
      const option = group && Array.from(group.querySelectorAll(".tags,button,span")).find(
        (item) => cleanText(item) === value && isVisible(item),
      );
      if (!option) throw new Error(`找不到筛选项：${labels[key] || key} / ${value}`);
      clickElement(option.closest(".tags,button") || option);
      applied.push({ key, value });
      await sleep(350);
    }
    await sleep(900);
    return { applied };
  }

  async function domFeeds({ limit = 40, xsec_source: xsecSource = "pc_feed" } = {}) {
    await waitFor(() => document.querySelector("section.note-item,.note-item"), 15000);
    const cards = Array.from(document.querySelectorAll("section.note-item,.note-item"))
      .filter(isVisible)
      .slice(0, Math.max(1, limit));
    const feeds = cards
      .map((card, index) => feedFromCard(card, index, xsecSource))
      .filter((item) => item.feed_id);
    return { feeds, count: feeds.length, source: "dom" };
  }

  function domNoteContent() {
    const root = document.querySelector("#detail-desc,.note-content .desc");
    if (!root) return { body: "", tags: [] };
    const tags = Array.from(root.querySelectorAll("a.tag"))
      .map((item) => cleanText(item))
      .filter(Boolean);
    const clone = root.cloneNode(true);
    clone.querySelectorAll("a.tag").forEach((item) => item.remove());
    const body = (clone.textContent || "").replace(/\n{3,}/g, "\n\n").trim();
    return { body, tags };
  }

  async function loadComments(params) {
    if (!params.load_all_comments) return { loaded: false };
    const commentsRoot = firstVisible([".comments-container", ".interaction-container"]);
    if (!commentsRoot) return { loaded: false, reason: "comments_not_visible" };
    commentsRoot.scrollIntoView({ block: "start", inline: "nearest" });
    const candidates = [
      firstVisible([".note-scroller"]),
      commentsRoot,
      document.scrollingElement,
      document.documentElement,
    ].filter(Boolean);
    const scroller = candidates.find((item) => (
      Number(item.scrollHeight || 0) > Number(item.clientHeight || 0) + 20
    )) || document.scrollingElement || document.documentElement;
    const maxItems = Number(params.max_comment_items || 0);
    const delays = { slow: 850, normal: 500, fast: 280 };
    const threshold = Number(params.max_replies_threshold ?? 10);
    const maxRounds = maxItems > 0 ? Math.min(120, Math.max(20, maxItems * 3)) : 120;
    let stableRounds = 0;
    let previous = -1;
    let rounds = 0;
    let previousScrollTop = -1;
    let expandedReplies = 0;
    let skippedReplies = 0;
    let reachedEnd = false;
    while (rounds++ < maxRounds) {
      const parents = Array.from(document.querySelectorAll(".parent-comment"));
      if (maxItems > 0 && parents.length >= maxItems) break;
      const noComments = firstVisible([".no-comments-text"]);
      const end = firstVisible([".end-container"]);
      if (noComments || (end && /THE\s*END/i.test(cleanText(end)))) {
        reachedEnd = true;
        break;
      }
      if (params.click_more_replies && rounds % 3 === 1) {
        let clickedThisRound = 0;
        for (const button of Array.from(document.querySelectorAll(".show-more")).filter(isVisible)) {
          if (clickedThisRound >= 8) break;
          const count = Number((cleanText(button).match(/\d+/) || ["0"])[0]);
          if (threshold > 0 && count > threshold) {
            skippedReplies += 1;
            continue;
          }
          button.scrollIntoView({ block: "center", inline: "nearest" });
          button.click();
          clickedThisRound += 1;
          expandedReplies += 1;
        }
      }
      const count = parents.length;
      stableRounds = count === previous ? stableRounds + 1 : 0;
      previous = count;
      const largeStep = stableRounds >= 8;
      const viewport = Number(scroller.clientHeight || window.innerHeight || 768);
      const step = Math.round(viewport * (largeStep ? 2.1 : 0.9) * (0.9 + Math.random() * 0.2));
      if (scroller === document.scrollingElement || scroller === document.documentElement) {
        window.scrollBy(0, Math.max(step, 500));
      } else {
        scroller.scrollTop = Math.min(
          Number(scroller.scrollHeight || 0),
          Number(scroller.scrollTop || 0) + Math.max(step, 350),
        );
        scroller.dispatchEvent(new Event("scroll", { bubbles: true }));
      }
      const currentScrollTop = scroller === document.scrollingElement || scroller === document.documentElement
        ? Number(window.scrollY || window.pageYOffset || 0)
        : Number(scroller.scrollTop || 0);
      if (currentScrollTop === previousScrollTop) stableRounds += 1;
      previousScrollTop = currentScrollTop;
      if (stableRounds >= 16) break;
      await sleep(delays[params.scroll_speed] || delays.normal);
    }
    return {
      loaded: true,
      rounds,
      visible_comments: document.querySelectorAll(".parent-comment").length,
      expanded_replies: expandedReplies,
      skipped_replies: skippedReplies,
      reached_end: reachedEnd,
      stopped_by_limit: maxItems > 0
        && document.querySelectorAll(".parent-comment").length >= maxItems,
    };
  }

  async function domDetail(params = {}) {
    const actualFeedId = (() => {
      try {
        return decodeURIComponent(location.pathname.match(/^\/explore\/([^/]+)\/?$/)?.[1] || "");
      } catch {
        return "";
      }
    })();
    if (!actualFeedId || (params.feed_id && actualFeedId !== params.feed_id)) {
      throw new Error("当前页面不是请求的笔记");
    }
    await waitFor(() => document.querySelector("#detail-title,.note-content,.interaction-container"), 15000);
    const loading = await loadComments(params);
    const title = cleanText(document.querySelector("#detail-title,.note-content .title"));
    const descRoot = document.querySelector("#detail-desc,.note-content .desc");
    const content = domNoteContent();
    const author = document.querySelector(".author-container .name,.author-wrapper .name,.note-detail-mask .author .name");
    const userLink = author?.closest("a[href*='/user/profile/']") || document.querySelector(".author-container a[href*='/user/profile/']");
    const images = Array.from(document.querySelectorAll(".swiper-slide img,.note-slider img,.carousel img"))
      .filter((image) => image.src && !image.src.includes("avatar"))
      .map((image) => image.currentSrc || image.src);
    const comments = Array.from(document.querySelectorAll(".parent-comment"))
      .map(commentFromNode)
      .filter(Boolean);
    const userId = userLink?.dataset.userId || userLink?.getAttribute("href")?.match(/\/user\/profile\/([^/?]+)/)?.[1] || "";
    let userUrl = null;
    try {
      userUrl = userLink ? new URL(userLink.href || userLink.getAttribute("href"), location.origin) : null;
    } catch {
      userUrl = null;
    }
    const result = {
      note: {
        feed_id: actualFeedId,
        xsec_token: params.xsec_token || "",
        xsec_source: params.xsec_source || "pc_feed",
        title,
        description: cleanText(descRoot),
        body: content.body,
        tags: content.tags,
        author: {
          user_id: userId,
          nickname: cleanText(author),
          xsec_token: userUrl?.searchParams.get("xsec_token") || "",
          xsec_source: userUrl?.searchParams.get("xsec_source") || "pc_note",
        },
        images: [...new Set(images)],
      },
      comments,
      comment_loading: loading,
      source: "dom",
    };
    if (params.max_comment_items > 0) result.comments = comments.slice(0, params.max_comment_items);
    return result;
  }

  async function domProfile({ limit = 40, user_id: userId = "" } = {}) {
    const actualUserId = (() => {
      try {
        return decodeURIComponent(location.pathname.match(/^\/user\/profile\/([^/]+)\/?$/)?.[1] || "");
      } catch {
        return "";
      }
    })();
    if (!actualUserId || (userId && actualUserId !== userId)) {
      throw new Error("当前页面不是请求的用户主页");
    }
    const outcome = await waitFor(() => {
      const root = document.querySelector(".user-name,.user-page-box,.user-info");
      if (root) return { root };
      const pageText = scopedFeedbackText();
      const inaccessible = NOTE_INACCESSIBLE_MARKERS.find(
        (marker) => pageText.toLowerCase().includes(marker.toLowerCase()),
      );
      return inaccessible ? { inaccessible } : null;
    }, 15000);
    if (!outcome?.root) {
      throw new Error(outcome?.inaccessible || "用户主页未加载或不可访问");
    }
    const interaction = Array.from(document.querySelectorAll(".user-interactions .count,.interaction-info"));
    return {
      profile: {
        user_id: actualUserId,
        nickname: cleanText(document.querySelector(".user-name")),
        red_id: cleanText(document.querySelector(".user-redId,.red-id")).replace(/^小红书号[：:]\s*/, ""),
        description: cleanText(document.querySelector(".user-desc,.desc")),
        interactions: interaction.map((item) => cleanText(item)),
      },
      ...(await domFeeds({ limit })),
      source: "dom",
    };
  }

  function commentEditor() {
    return firstVisible([
      "div.input-box p.content-input",
      "div.input-box [contenteditable='true']",
      "p.content-input[contenteditable='true']",
    ]);
  }

  function matchingCommentCount(content) {
    return Array.from(document.querySelectorAll(".comment-item .content,.parent-comment .content"))
      .filter((item) => cleanText(item).includes(content)).length;
  }

  function commentOpenTarget() {
    if (commentEditor()) return { skip: true, editor_ready: true };
    const trigger = firstVisible(["div.input-box div.content-edit span", "div.input-box .content-edit"]);
    if (!trigger) throw new Error("找不到评论输入入口");
    return {
      skip: false,
      ...elementTarget(trigger.closest(".content-edit") || trigger, "评论输入入口", "comment-open"),
    };
  }

  async function prepareComment({ content }) {
    const editor = await waitFor(commentEditor, 6000);
    if (!editor) throw new Error("找不到评论输入框");
    fillEditable(editor, content);
    const submit = firstVisible(["div.input-box button.submit", "div.bottom button.submit", "button.submit"]);
    if (!submit) throw new Error("找不到评论发送按钮");
    return {
      skip: false,
      before_matches: matchingCommentCount(content),
      ...elementTarget(submit, "评论发送按钮", "comment-submit"),
    };
  }

  async function waitCommentSent({ content, before_matches: beforeMatches = 0 }) {
    const editor = commentEditor();
    const riskPattern = /访问频繁|操作频繁|账号异常|安全验证|禁止评论|评论受限|无法评论/;
    const failurePattern = /评论失败|发送失败|网络异常|请重试|内容违规/;
    const successPattern = /评论成功|发送成功/;
    const deadline = Date.now() + 10000;
    let clearedAt = 0;
    let editorClearedOnly = false;
    while (Date.now() < deadline) {
      const feedback = scopedFeedbackText();
      const risk = feedback.match(riskPattern);
      if (risk) {
        return {
          success: false,
          status: "risk_control",
          risk_control: true,
          message: risk[0],
          url: safeLocationUrl(),
        };
      }
      const failure = feedback.match(failurePattern)?.[0] || "";
      if (failure) return { success: false, status: "failed", message: failure };
      if (matchingCommentCount(content) > beforeMatches || successPattern.test(feedback)) {
        return { success: true, status: "comment_sent", evidence: "page_confirmation" };
      }
      if (cleanText(editor) === "") {
        if (!clearedAt) clearedAt = Date.now();
        if (Date.now() - clearedAt >= 1500) {
          editorClearedOnly = true;
        }
      } else {
        clearedAt = 0;
        editorClearedOnly = false;
      }
      await sleep(250);
    }
    return {
      success: false,
      status: "unconfirmed",
      evidence: editorClearedOnly ? "editor_cleared_only" : "none",
      message: "评论发送后未观察到可确认的成功状态",
    };
  }

  function findReplyComment(commentId, userId) {
    if (commentId) {
      const byId = document.getElementById(`comment-${commentId}`);
      return byId ? (byId.closest(".parent-comment,.comment-item") || byId) : null;
    }
    if (!userId) return null;
    const link = Array.from(document.querySelectorAll([
      ".parent-comment a[data-user-id]",
      ".comment-item a[data-user-id]",
      ".parent-comment a[href*='/user/profile/']",
      ".comment-item a[href*='/user/profile/']",
    ].join(","))).find((item) => {
      const href = item.getAttribute("href") || "";
      return item.dataset.userId === userId || href.includes(`/user/profile/${userId}`);
    });
    return link?.closest(".parent-comment,.comment-item") || null;
  }

  async function replyTarget({ comment_id: commentId, user_id: userId }) {
    const scroller = firstVisible([".note-scroller", ".interaction-container", ".comments-container"]);
    let target = null;
    let previousCount = -1;
    let stagnantRounds = 0;
    let scannedRounds = 0;
    while (scannedRounds++ < 100) {
      target = findReplyComment(commentId, userId);
      if (target) break;
      if (firstVisible([".end-container", ".no-comments-text"])) break;
      const count = document.querySelectorAll(".parent-comment").length;
      stagnantRounds = count === previousCount ? stagnantRounds + 1 : 0;
      previousCount = count;
      if (stagnantRounds >= 10) break;
      if (scroller && scroller.scrollHeight > scroller.clientHeight + 10) {
        scroller.scrollTop = Math.min(
          scroller.scrollHeight,
          scroller.scrollTop + Math.max(scroller.clientHeight * 0.85, 500),
        );
        scroller.dispatchEvent(new Event("scroll", { bubbles: true }));
      } else {
        window.scrollBy(0, Math.max(window.innerHeight * 0.8, 500));
      }
      await sleep(450);
    }
    if (!target) throw new Error("滚动加载评论后仍找不到回复目标");
    target.scrollIntoView({ block: "center", inline: "nearest" });
    const reply = firstVisible([".reply", ".interactions .reply"], target);
    return {
      skip: false,
      scanned_rounds: scannedRounds,
      visible_comments: document.querySelectorAll(".parent-comment").length,
      ...elementTarget(reply, "回复评论按钮", "comment-reply"),
    };
  }

  function interactionState() {
    const like = firstVisible([".interact-container .like-wrapper", ".interact-container .like-lottie"]);
    const favorite = firstVisible([".interact-container .collect-wrapper", ".interact-container .collect-icon"]);
    const wrapper = (element) => element?.closest(".like-wrapper,.collect-wrapper") || null;
    const iconRef = (element) => wrapper(element)?.querySelector("use")?.getAttribute("href")
      || wrapper(element)?.querySelector("use")?.getAttribute("xlink:href")
      || "";
    const classValue = (element) => {
      const value = element?.className;
      return typeof value === "string" ? value : value?.baseVal || "";
    };
    const stateText = (element) => {
      const owner = wrapper(element);
      return [
        classValue(element),
        classValue(owner),
        element?.getAttribute?.("data-state") || "",
        owner?.getAttribute?.("data-state") || "",
      ].join(" ");
    };
    const pressed = (element) => {
      const values = [element, wrapper(element)]
        .map((item) => item?.getAttribute?.("aria-pressed"))
        .filter((value) => value === "true" || value === "false");
      return values.length ? values[0] === "true" : null;
    };
    const likeRef = iconRef(like);
    const favoriteRef = iconRef(favorite);
    const likePressed = pressed(like);
    const favoritePressed = pressed(favorite);
    const hasLikedState = /(?:^|\s)liked(?:\s|$)/i.test(stateText(like));
    const hasCollectedState = /(?:^|\s)collected(?:\s|$)/i.test(stateText(favorite));
    const likeIconState = /(?:^|#)(?:liked|like-filled)$/i.test(likeRef)
      ? true
      : /(?:^|#)like$/i.test(likeRef) ? false : null;
    const favoriteIconState = /(?:^|#)(?:collected|collect-filled)$/i.test(favoriteRef)
      ? true
      : /(?:^|#)collect$/i.test(favoriteRef) ? false : null;
    const likedPositive = likeIconState === true || hasLikedState;
    const collectedPositive = favoriteIconState === true || hasCollectedState;
    const likeKnown = likePressed !== null || likeIconState !== null;
    const favoriteKnown = favoritePressed !== null || favoriteIconState !== null;
    return {
      liked: likeKnown
        ? (likePressed ?? (likedPositive ? true : likeIconState === false ? false : undefined))
        : undefined,
      favorited: favoriteKnown
        ? (favoritePressed
          ?? (collectedPositive ? true : favoriteIconState === false ? false : undefined))
        : undefined,
      like_known: likeKnown,
      favorite_known: favoriteKnown,
      like_evidence: likePressed !== null
        ? "aria_pressed"
        : likeIconState !== null ? "icon_exact" : likedPositive ? "class_positive" : "unknown",
      favorite_evidence: favoritePressed !== null
        ? "aria_pressed"
        : favoriteIconState !== null ? "icon_exact" : collectedPositive ? "class_positive" : "unknown",
    };
  }

  function interactionClickElement(element, kind) {
    if (!element) return null;
    const semanticControl = element.closest("button,[role='button'],a,[tabindex]");
    const wrapper = element.closest(kind === "like" ? ".like-wrapper" : ".collect-wrapper");
    return [semanticControl, wrapper, element].find((candidate) => {
      if (!candidate || !isVisible(candidate)) return false;
      return getComputedStyle(candidate).pointerEvents !== "none";
    }) || element;
  }

  function interactionTarget({ kind }) {
    const selectors = kind === "like"
      ? [".interact-container .left .like-lottie", ".interact-container .like-wrapper"]
      : [".interact-container .left .collect-icon", ".interact-container .collect-wrapper"];
    const icon = firstVisible(selectors);
    const target = interactionClickElement(icon, kind);
    if (!target) throw new Error(`找不到${kind === "like" ? "点赞" : "收藏"}按钮`);
    return {
      skip: false,
      ...elementTarget(
        target,
        kind === "like" ? "点赞按钮" : "收藏按钮",
        kind === "like" ? "interaction-like" : "interaction-favorite",
        { anchor: icon },
      ),
    };
  }

  async function actionReadiness(params = {}) {
    const comment = commentEditor()
      || firstVisible(["div.input-box div.content-edit span", "div.input-box .content-edit"]);
    const likeIcon = firstVisible([
      ".interact-container .left .like-lottie",
      ".interact-container .like-wrapper",
    ]);
    const favoriteIcon = firstVisible([
      ".interact-container .left .collect-icon",
      ".interact-container .collect-wrapper",
    ]);
    const like = interactionClickElement(likeIcon, "like");
    const favorite = interactionClickElement(favoriteIcon, "favorite");
    const result = {
      comment_available: Boolean(comment),
      like_available: Boolean(like),
      favorite_available: Boolean(favorite),
      like_target: like ? {
        tag_name: String(like.tagName || "").toLowerCase(),
        resolved_to_ancestor: like !== likeIcon,
        geometry_anchored: like !== likeIcon,
      } : null,
      favorite_target: favorite ? {
        tag_name: String(favorite.tagName || "").toLowerCase(),
        resolved_to_ancestor: favorite !== favoriteIcon,
        geometry_anchored: favorite !== favoriteIcon,
      } : null,
      reply: null,
    };
    if (params.comment_id || params.user_id) {
      try {
        const target = await replyTarget(params);
        result.reply = {
          available: true,
          scanned_rounds: target.scanned_rounds,
          visible_comments: target.visible_comments,
        };
      } catch (error) {
        result.reply = { available: false, reason: error?.message || String(error) };
      }
    }
    return result;
  }

  function creatorTab(name) {
    const matches = Array.from(document.querySelectorAll(".creator-tab"))
      .filter((item) => isVisible(item) && cleanText(item) === name);
    return matches.find((item) => item.hasAttribute("data-hp-bound")) || matches[0] || null;
  }

  async function activateCreatorTab(name) {
    const target = await waitFor(() => creatorTab(name), 15000);
    if (!target) throw new Error(`找不到“${name}”标签`);
    if (!target.classList.contains("active")) clickElement(target);
    const active = await waitFor(() => {
      const candidate = creatorTab(name);
      return candidate?.classList.contains("active") ? candidate : null;
    }, 5000);
    if (!active) throw new Error(`“${name}”标签未成功切换`);
    return active;
  }

  function acceptsPublishMedia(accept, tab) {
    return tab === "上传图文"
      ? /image\/\*|jpe?g|png|gif|webp|bmp|svg/i.test(accept || "")
      : /video\/\*|mp4|mov|flv|f4v|mkv|m4v|mpeg|mpg/i.test(accept || "");
  }

  async function preparePublishTab({ tab }) {
    await activateCreatorTab(tab);
    const input = await waitFor(
      () => {
        const candidates = Array.from(document.querySelectorAll("input.upload-input,input[type='file']"));
        return candidates.find((item) => (
          !item.closest("[data-hp-kind],[button-hp-installed]")
          && acceptsPublishMedia(item.getAttribute("accept"), tab)
        )) || null;
      },
      10000,
    );
    if (input) input.dataset.hongshuskillUpload = tab === "上传图文" ? "images" : "video";
    return {
      ready: Boolean(input),
      input_selector: tab === "上传图文"
        ? "input[data-hongshuskill-upload='images']"
        : "input[data-hongshuskill-upload='video']",
    };
  }

  async function waitUpload({ expected, video = false }) {
    const deadline = Date.now() + (video ? 600000 : 120000);
    while (Date.now() < deadline) {
      const errorText = [
        ...Array.from(document.querySelectorAll(
          ".upload-error,[class*='upload'] [class*='error'],[class*='transcode'] [class*='error']",
        )).filter(isVisible).map(cleanText),
        scopedFeedbackText(),
      ].join(" ");
      const uploadFailure = errorText.match(/上传失败|处理失败|转码失败|文件不支持|重新上传/);
      if (uploadFailure) throw new Error(uploadFailure[0]);
      const observation = publishMediaObservation(video ? "video" : "images", expected);
      if (observation.ready && observation.count === expected) {
        return { uploaded: true, previews: observation.count, video };
      }
      await sleep(video ? 1000 : 350);
    }
    throw new Error(video ? "视频上传或处理超时" : "图片上传超时");
  }

  function publishEditor() {
    return firstVisible(["div.ql-editor", "[contenteditable='true'][data-placeholder]", ".edit-container [contenteditable='true']"]);
  }

  function publishTitleInput() {
    return firstVisible([
      "div.d-input input",
      "input[placeholder*='标题']",
      "textarea[placeholder='输入标题']",
    ]);
  }

  function uploadProgressVisible() {
    return Array.from(document.querySelectorAll([
      ".upload-progress",
      "[class*='upload'] [class*='progress']",
      "[class*='transcode']",
      "[class*='processing']",
    ].join(","))).some((item) => (
      isVisible(item) && /上传中|处理中|转码中|正在上传|正在处理/.test(cleanText(item))
    ));
  }

  function mediaDescriptor(element) {
    const image = element.matches?.("img,video") ? element : element.querySelector?.("img,video");
    const style = element.getAttribute?.("style") || "";
    return [
      image?.currentSrc || image?.src || image?.getAttribute?.("poster") || "",
      image?.getAttribute?.("alt") || "",
      style,
      cleanText(element),
    ].join("|");
  }

  function uniquePreviewRoots(selectors) {
    const candidates = Array.from(document.querySelectorAll(selectors)).filter(isVisible);
    return candidates.filter((candidate, index) => !candidates.some((other, otherIndex) => (
      otherIndex !== index && other.contains?.(candidate)
    )));
  }

  function publishMediaObservation(type, expected = 0) {
    const progress = uploadProgressVisible();
    if (type === "images") {
      let items = uniquePreviewRoots([
        ".img-preview-area .pr",
        ".img-preview-area [data-index]",
        ".img-preview-area li",
        ".img-preview-area .cover-preview",
      ].join(","));
      if (!items.length) {
        items = Array.from(document.querySelectorAll(".img-preview-area img"))
          .filter((item) => isVisible(item) && !/avatar/i.test(item.className || ""));
      }
      return {
        type,
        count: items.length,
        ready: !progress && items.length === expected,
        descriptors: items.map(mediaDescriptor),
      };
    }
    if (type === "video") {
      const items = uniquePreviewRoots([
        ".video-preview",
        ".cover-preview",
        "video",
        "[class*='video-cover']",
      ].join(","));
      return {
        type,
        count: items.length ? 1 : 0,
        ready: !progress && items.length > 0 && expected === 1,
        descriptors: items.map(mediaDescriptor),
      };
    }
    return {
      type: "long_article",
      count: 0,
      ready: !progress && Boolean(publishEditor()),
      descriptors: ["long_article"],
    };
  }

  async function sha256Text(value) {
    const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(value));
    return Array.from(new Uint8Array(digest), (byte) => byte.toString(16).padStart(2, "0")).join("");
  }

  async function publishSnapshot(settings, mediaType, mediaExpected) {
    const title = publishTitleInput();
    const editor = publishEditor();
    if (!editor) throw new Error("无法回读发布表单正文");
    const media = publishMediaObservation(mediaType, mediaExpected);
    const identity = await sha256Text(JSON.stringify(media.descriptors));
    const normalizedTitle = normalizedFieldText(title?.value || "");
    const normalizedContent = normalizedFieldText(editableText(editor));
    const tags = Array.from(editor.querySelectorAll?.("a[href*='/topic/'],[data-topic-id]") || [])
      .filter(isVisible)
      .map(cleanText)
      .filter(Boolean);
    return {
      route: safeLocationUrl(),
      form: {
        title_hash: await sha256Text(normalizedTitle),
        content_hash: await sha256Text(normalizedContent),
        tags_hash: await sha256Text(JSON.stringify(tags)),
        title_length: normalizedTitle.length,
        content_length: normalizedContent.length,
        tag_count: tags.length,
      },
      media: {
        type: media.type,
        count: media.count,
        ready: media.ready,
        identity,
      },
      settings: {
        visibility: settings.visibility,
        original: settings.original,
        schedule_at: settings.schedule_at,
      },
    };
  }

  function matchingTopicSuggestion(tag) {
    const candidates = Array.from(document.querySelectorAll([
      "#creator-editor-topic-container .item",
      "[class*='topic-container'] .item",
    ].join(","))).filter(isVisible);
    return candidates.find((item) => {
      const text = cleanText(item).replace(/^#/, "");
      const firstToken = text.split(/\s+/)[0];
      return firstToken === tag || text.includes(`#${tag}`);
    }) || null;
  }

  function normalizedFieldText(value) {
    return String(value ?? "")
      .replace(/\r\n?/g, "\n")
      .replace(/\u00a0/g, " ")
      .replace(/\n$/, "");
  }

  function editableText(element) {
    if (!element) return "";
    return typeof element.innerText === "string" ? element.innerText : (element.textContent || "");
  }

  function editorContentMatches(editor, expected) {
    return normalizedFieldText(editableText(editor)) === normalizedFieldText(expected);
  }

  function publishFieldsMatch(title, editor, params) {
    return String(title?.value ?? "") === String(params.title ?? "")
      && editorContentMatches(editor, params.content);
  }

  async function fillPublishForm(params) {
    const title = await waitFor(() => firstVisible(["div.d-input input", "input[placeholder*='标题']"]), 15000);
    const editor = await waitFor(publishEditor, 15000);
    if (!title || !editor) throw new Error("发布表单尚未就绪");
    setNativeValue(title, params.title);
    fillEditable(editor, params.content);

    const fieldsReady = await waitFor(
      () => (publishFieldsMatch(title, editor, params) ? true : null),
      3000,
      100,
    );
    if (!fieldsReady) throw new Error("发布标题或正文未能可靠写入表单");

    const lengthError = firstVisible([".edit-container .length-error", ".length-error"]);
    if (lengthError) throw new Error(cleanText(lengthError) || "正文长度超过平台限制");

    let tagLineStarted = false;
    const selectedTags = [];
    const plainTags = [];
    for (const tag of params.tags || []) {
      const separator = tagLineStarted ? " " : (cleanText(editor) ? "\n" : "");
      appendEditable(editor, `${separator}#${tag}`);
      const suggestion = await waitFor(() => matchingTopicSuggestion(tag), 2500);
      if (suggestion) {
        clickElement(suggestion);
        selectedTags.push(tag);
      } else {
        // Commit niche tags as visible editor text when the platform offers no
        // matching topic suggestion. This preserves the requested content while
        // keeping selected platform topics distinguishable in the result.
        appendEditable(editor, " ");
        plainTags.push(tag);
      }
      tagLineStarted = true;
    }

    return {
      status: "filled",
      title: params.title,
      tags: params.tags || [],
      selected_tags: selectedTags,
      plain_tags: plainTags,
      visibility: params.visibility,
    };
  }

  function elementTarget(element, label, key, { anchor = null } = {}) {
    if (!element) throw new Error(`找不到${label}`);
    element.scrollIntoView({ block: "center", inline: "nearest" });
    const rect = element.getBoundingClientRect();
    if (rect.width <= 0 || rect.height <= 0) throw new Error(`${label}当前不可点击`);
    document.querySelectorAll("[data-hongshuskill-click]")
      .forEach((item) => item.removeAttribute("data-hongshuskill-click"));
    document.querySelectorAll("[data-hongshuskill-anchor]")
      .forEach((item) => item.removeAttribute("data-hongshuskill-anchor"));
    const nonceBytes = new Uint8Array(12);
    crypto.getRandomValues(nonceBytes);
    const marker = `${key}-${Array.from(
      nonceBytes,
      (byte) => byte.toString(16).padStart(2, "0"),
    ).join("")}`;
    element.setAttribute("data-hongshuskill-click", marker);
    const result = {
      selector: `[data-hongshuskill-click="${marker}"]`,
      disabled: Boolean(element.disabled || element.getAttribute("aria-disabled") === "true"),
    };
    if (anchor && anchor !== element) {
      const anchorRect = anchor.getBoundingClientRect();
      if (anchorRect.width > 0 && anchorRect.height > 0) {
        anchor.setAttribute("data-hongshuskill-anchor", marker);
        result.anchor_selector = `[data-hongshuskill-anchor="${marker}"]`;
      }
    }
    return result;
  }

  function originalSwitch() {
    const card = Array.from(document.querySelectorAll(".custom-switch-card"))
      .find((item) => cleanText(item).includes("原创"));
    return card ? firstVisible([".d-switch"], card) : null;
  }

  function scheduleSwitch() {
    const card = Array.from(document.querySelectorAll(".post-time-wrapper,.custom-switch-card"))
      .find((item) => cleanText(item).includes("定时"));
    // Never fall back to an unrelated switch. Creator pages can contain other
    // persisted toggles (for example the originality declaration), and treating
    // the first one as the schedule control would silently mutate the wrong
    // setting when the schedule card is unavailable or has changed markup.
    return card ? firstVisible([".d-switch"], card) : null;
  }

  async function publishSettingRect({ setting, value, enabled }) {
    if (setting === "schedule_switch") {
      const switcher = await waitFor(scheduleSwitch, 5000);
      if (!switcher) {
        if (enabled) throw new Error("找不到定时发布开关");
        return { skip: true, checked: false, unavailable: true };
      }
      const checked = switchIsChecked(switcher);
      if (checked === Boolean(enabled)) return { skip: true, checked };
      return {
        skip: false,
        checked,
        target_checked: Boolean(enabled),
        ...elementTarget(switcher, "定时发布开关", "schedule-switch"),
      };
    }
    if (setting === "schedule_input") {
      const input = await waitFor(() => firstVisible([".date-picker-container input", "input[placeholder*='时间']"]), 5000);
      return { skip: false, ...elementTarget(input, "定时发布时间输入框", "schedule-input") };
    }
    if (setting === "visibility_dropdown") {
      const current = await waitFor(() => firstVisible([".permission-card-wrapper .d-select-content"]), 5000);
      if (!current) throw new Error("找不到可见范围设置");
      if (cleanText(current) === value) return { skip: true, current: value };
      return { skip: false, ...elementTarget(current.closest(".d-select") || current, "可见范围设置", "visibility-dropdown") };
    }
    if (setting === "visibility_option") {
      const option = await waitFor(() => Array.from(document.querySelectorAll(".d-options-wrapper .d-grid-item"))
        .find((item) => isVisible(item) && cleanText(item) === value), 8000);
      return { skip: false, ...elementTarget(option, `可见范围选项：${value}`, "visibility-option") };
    }
    if (setting === "original_switch") {
      const switcher = await waitFor(originalSwitch, 5000);
      if (!switcher) {
        if (enabled) throw new Error("找不到原创声明设置");
        return { skip: true, checked: false, unavailable: true };
      }
      const checked = switchIsChecked(switcher);
      if (checked === Boolean(enabled)) return { skip: true, checked };
      return {
        skip: false,
        checked,
        target_checked: Boolean(enabled),
        ...elementTarget(switcher, "原创声明开关", "original-switch"),
      };
    }
    if (setting === "original_checkbox") {
      const notice = await waitFor(() => Array.from(document.querySelectorAll("[role='dialog'],.d-modal,.footer"))
        .find((item) => isVisible(item) && /原创声明|声明原创/.test(cleanText(item))), 2500);
      if (!notice) return { skip: true, reason: "notice_not_shown" };
      const checkbox = notice.querySelector("input[type='checkbox']");
      if (!checkbox || checkbox.checked) return { skip: true, checked: Boolean(checkbox?.checked) };
      const clickable = checkbox.closest("label,[class*='checkbox']") || checkbox;
      return { skip: false, ...elementTarget(clickable, "原创声明须知复选框", "original-checkbox") };
    }
    if (setting === "original_confirm") {
      const confirm = await waitFor(() => exactText("声明原创", "button,[role='button']"), 2500);
      if (!confirm) return { skip: true, reason: "confirmation_not_shown" };
      return { skip: false, ...elementTarget(confirm, "声明原创按钮", "original-confirm") };
    }
    throw new Error(`不支持的发布设置：${setting}`);
  }

  async function waitPublishSettings({
    visibility,
    original,
    schedule_at: scheduleAt,
    include_snapshot: includeSnapshot = false,
    media_type: mediaType = "",
    media_expected: mediaExpected = null,
  }) {
    const state = await waitFor(() => {
      const current = cleanText(firstVisible([".permission-card-wrapper .d-select-content"]));
      const originalEnabled = switchIsChecked(originalSwitch());
      const dateInput = firstVisible([".date-picker-container input", "input[placeholder*='时间']"]);
      const scheduleValue = scheduleAt ? scheduleAt.replace("T", " ").slice(0, 16) : null;
      const scheduleEnabled = switchIsChecked(scheduleSwitch());
      if (visibility && current !== visibility) return null;
      if (originalEnabled !== Boolean(original)) return null;
      if (scheduleEnabled !== Boolean(scheduleValue)) return null;
      if (scheduleValue && dateInput?.value !== scheduleValue) return null;
      return {
        visibility: current,
        original: originalEnabled,
        schedule_at: scheduleValue ? dateInput.value : null,
      };
    }, 5000);
    if (!state) throw new Error("发布设置未能生效");
    if (!includeSnapshot) return state;
    if (!mediaType || !Number.isInteger(mediaExpected) || mediaExpected < 0) {
      throw new Error("发布预览缺少媒体校验参数");
    }
    const snapshot = await publishSnapshot(state, mediaType, mediaExpected);
    if (
      snapshot.media.type !== mediaType
      || snapshot.media.count !== mediaExpected
      || snapshot.media.ready !== true
    ) {
      throw new Error("发布媒体状态与预览不一致");
    }
    return { ...state, snapshot };
  }

  function targetRect({ target }) {
    let element = null;
    if (target === "publish") {
      element = firstVisible([
        ".publish-page-publish-btn button.bg-red",
        ".publish-page-publish-btn button",
        "xhs-publish-btn[is-publish='true']",
      ]);
    } else if (target === "draft") {
      const controls = "button,[role='button']";
      element = exactText("暂存离开", controls)
        || exactText("存草稿", controls)
        || exactText("保存草稿", controls);
    }
    if (!element) throw new Error(`找不到${target === "publish" ? "发布" : "草稿"}按钮`);
    const result = elementTarget(
      element,
      target === "publish" ? "发布按钮" : "草稿按钮",
      target === "publish" ? "submit-publish" : "submit-draft",
    );
    return {
      ...result,
      disabled: Boolean(
        result.disabled
        || element.classList.contains("disabled")
        || element.getAttribute("submit-disabled") === "true"
      ),
    };
  }

  async function observeSubmission({
    before_url: beforeUrl,
    timeout_ms: timeoutMs = 20000,
    target = "publish",
  }) {
    const riskPattern = /违反|违规|禁止发笔记|审核未通过|账号异常|无法发布|发布受限/;
    const failurePattern = target === "draft"
      ? /保存失败|网络异常|请重试/
      : /发布失败|网络异常|请重试/;
    const successPattern = target === "draft"
      ? /保存成功|草稿已保存|已保存到草稿箱/
      : /发布成功/;
    const deadline = Date.now() + timeoutMs;
    while (Date.now() < deadline) {
      const text = scopedFeedbackText();
      const riskMatch = text.match(riskPattern);
      if (riskMatch) {
        return {
          success: false,
          status: "risk_control",
          risk_control: true,
          message: riskMatch[0],
          url: safeLocationUrl(),
        };
      }
      const failureMatch = text.match(failurePattern);
      if (failureMatch) {
        return {
          success: false,
          status: "failed",
          message: failureMatch[0],
          url: safeLocationUrl(),
        };
      }
      const successUrl = location.href !== beforeUrl
        && (/published=true|publish\/success|\/creator\/home/.test(location.href));
      if (successPattern.test(text) || successUrl) {
        return {
          success: true,
          status: target === "draft" ? "draft_saved" : "submitted",
          action: target,
          url: safeLocationUrl(),
        };
      }
      await sleep(300);
    }
    return { success: false, status: "unconfirmed", url: safeLocationUrl() };
  }

  async function prepareLongArticle({ title, content }) {
    await activateCreatorTab("写长文");
    const create = await waitFor(() => exactText("新的创作"), 8000);
    if (create) {
      clickElement(create);
      await sleep(300);
    }
    const titleInput = await waitFor(() => firstVisible(["textarea[placeholder='输入标题']"]), 10000);
    const editor = await waitFor(() => firstVisible([".tiptap.ProseMirror", ".ProseMirror", "div.ql-editor"]), 10000);
    if (!titleInput || !editor) throw new Error("长文编辑器尚未就绪");
    if (!longEditorIsEmpty(titleInput, editor)) {
      throw new Error("长文编辑器中已有内容；为避免覆盖现有草稿，请先由用户处理后重试");
    }
    setNativeValue(titleInput, title);
    fillEditable(editor, content);
    const fieldsReady = await waitFor(
      () => (longFieldsMatch(titleInput, editor, { title, content }) ? true : null),
      3000,
      100,
    );
    if (!fieldsReady) throw new Error("长文标题或正文未能可靠写入编辑器");
    return { status: "long_article_filled" };
  }

  function longEditorIsEmpty(titleInput, editor) {
    return !String(titleInput?.value || "").trim() && !cleanText(editor);
  }

  function longFieldsMatch(titleInput, editor, { title, content }) {
    return String(titleInput?.value ?? "") === String(title ?? "")
      && editorContentMatches(editor, content);
  }

  async function prepareLongImages() {
    const buttons = Array.from(document.querySelectorAll("button.menu-item")).filter(isVisible);
    const imageButton = buttons.find((button) => {
      const label = [
        cleanText(button),
        button.getAttribute("aria-label") || "",
        button.getAttribute("title") || "",
      ].join(" ");
      return /插图|图片|上传图/.test(label);
    }) || buttons.find((button) => button.querySelector("svg path[d^='M6.916']"));
    if (!imageButton) throw new Error("找不到长文插图按钮");
    return {
      skip: false,
      ...elementTarget(imageButton, "长文插图按钮", "long-image"),
    };
  }

  async function waitLongImages({ expected }) {
    const editor = await waitFor(() => firstVisible([".tiptap.ProseMirror", ".ProseMirror", "div.ql-editor"]), 5000);
    const result = await waitFor(() => {
      const images = editor?.querySelectorAll("img")?.length || 0;
      return images >= expected ? { inserted: images } : null;
    }, 60000, 300);
    if (!result) throw new Error("长文插图上传或插入超时");
    return result;
  }

  function selectedTemplateName() {
    const selected = Array.from(document.querySelectorAll(".template-card")).find((card) => (
      card.classList?.contains("active")
      || card.classList?.contains("selected")
      || card.getAttribute?.("aria-selected") === "true"
      || card.getAttribute?.("data-selected") === "true"
    ));
    return selected ? cleanText(selected.querySelector(".template-title")) : "";
  }

  async function longDraftSnapshot() {
    const title = document.querySelector("textarea[placeholder='输入标题']");
    const editor = document.querySelector(".tiptap.ProseMirror,.ProseMirror,div.ql-editor");
    if (!title || !editor) throw new Error("无法回读长文标题或正文");
    const normalizedTitle = normalizedFieldText(title.value || "");
    const normalizedContent = normalizedFieldText(editableText(editor));
    const images = Array.from(editor.querySelectorAll?.("img") || []);
    return {
      title_hash: await sha256Text(normalizedTitle),
      content_hash: await sha256Text(normalizedContent),
      title_length: normalizedTitle.length,
      content_length: normalizedContent.length,
      media: {
        count: images.length,
        identity: await sha256Text(JSON.stringify(images.map(mediaDescriptor))),
      },
      template: selectedTemplateName(),
    };
  }

  async function formatLongArticle({ include_snapshot: includeSnapshot = false } = {}) {
    if (includeSnapshot) await longDraftSnapshot();
    clickElement(exactText("一键排版"));
    const cards = await waitFor(() => {
      const items = Array.from(document.querySelectorAll(".template-card")).filter(isVisible);
      return items.length ? items : null;
    }, 18000, 300);
    if (!cards) throw new Error("排版模板加载超时");
    const draftSnapshot = includeSnapshot ? await longDraftSnapshot() : null;
    return {
      templates: cards.map((card, index) => cleanText(card.querySelector(".template-title")) || `模板 ${index + 1}`),
      status: "templates_ready",
      ...(draftSnapshot ? { draft_snapshot: draftSnapshot } : {}),
    };
  }

  async function selectTemplate({ name, include_snapshot: includeSnapshot = false }) {
    const beforeSnapshot = includeSnapshot ? await longDraftSnapshot() : null;
    const card = Array.from(document.querySelectorAll(".template-card"))
      .find((item) => cleanText(item.querySelector(".template-title")) === name);
    if (!card) throw new Error(`未找到模板：${name}`);
    clickElement(card);
    if (includeSnapshot) {
      const confirmed = await waitFor(() => (selectedTemplateName() === name ? true : null), 5000, 100);
      if (!confirmed) throw new Error("排版模板选择未能确认");
    }
    const afterSnapshot = includeSnapshot ? await longDraftSnapshot() : null;
    return {
      selected: true,
      name,
      ...(beforeSnapshot ? { draft_snapshot_before: beforeSnapshot } : {}),
      ...(afterSnapshot ? { draft_snapshot: afterSnapshot } : {}),
    };
  }

  async function longNext({ content, include_snapshot: includeSnapshot = false }) {
    const beforeSnapshot = includeSnapshot ? await longDraftSnapshot() : null;
    clickElement(exactText("下一步"));
    const editor = await waitFor(publishEditor, 15000);
    if (!editor) throw new Error("长文发布描述编辑器未出现");
    fillEditable(editor, content);
    const descriptionReady = await waitFor(
      () => (editorContentMatches(editor, content) ? true : null),
      3000,
      100,
    );
    if (!descriptionReady) throw new Error("长文发布描述未能可靠写入表单");
    return {
      status: "description_filled",
      length: content.length,
      ...(beforeSnapshot ? { draft_snapshot_before: beforeSnapshot } : {}),
    };
  }

  async function activeRiskProbes({ probe_urls: probeUrls = [] } = {}) {
    const probes = [
      {
        url: "https://www.xiaohongshu.com/api/sns/web/v1/search/complete?keyword=test",
        method: "GET",
      },
      {
        url: "https://www.xiaohongshu.com/api/sns/web/v1/homefeed",
        method: "POST",
        body: JSON.stringify({ cursor_score: "", num: 1, refresh_type: 1, note_index: 1 }),
      },
      {
        url: "https://www.xiaohongshu.com/api/sns/web/v2/user/me",
        method: "GET",
      },
      ...probeUrls.map((url) => ({ url, method: "GET" })),
    ];
    const results = [];
    for (const [index, probe] of probes.entries()) {
      if (index) await sleep(350);
      const started = Date.now();
      const options = { method: probe.method, credentials: "include" };
      if (probe.body) {
        options.body = probe.body;
        options.headers = { "Content-Type": "application/json" };
      }
      try {
        const response = await fetch(probe.url, options);
        let payload = null;
        try {
          payload = await response.json();
        } catch {
          // Probe results intentionally retain no response body.
        }
        results.push({
          url: probe.url,
          method: probe.method,
          status: response.status,
          ok: response.ok,
          xhs_code: payload?.code ?? null,
          risk_blocked: [404, 429, 461, 999].includes(response.status),
          elapsed_ms: Date.now() - started,
        });
      } catch (error) {
        results.push({
          url: probe.url,
          method: probe.method,
          error: error?.name || "FetchError",
          elapsed_ms: Date.now() - started,
        });
      }
    }
    return { results, count: results.length };
  }

  async function riskSignals() {
    const body = scopedFeedbackText();
    const markers = [
      "访问频繁",
      "操作频繁",
      "账号异常",
      "扫码验证",
      "扫码查看",
      "打开小红书App扫码",
      "请使用小红书App扫码",
      "安全验证",
      "禁止发笔记",
      "发布受限",
      "无法发布",
      "禁止评论",
      "评论受限",
      "账号受限",
      "网络异常",
    ]
      .filter((text) => body.includes(text));
    const verificationRequired = NOTE_VERIFICATION_MARKERS.some((text) => body.includes(text));
    const userAgent = navigator.userAgent || "";
    let notificationPermission = "unknown";
    try {
      notificationPermission = (await navigator.permissions?.query({ name: "notifications" }))?.state || "unknown";
    } catch {
      notificationPermission = "unavailable";
    }
    let webglVendor = "";
    let webglRenderer = "";
    try {
      const canvas = document.createElement("canvas");
      const gl = canvas.getContext("webgl") || canvas.getContext("experimental-webgl");
      const extension = gl?.getExtension("WEBGL_debug_renderer_info");
      if (extension) {
        webglVendor = String(gl.getParameter(extension.UNMASKED_VENDOR_WEBGL) || "");
        webglRenderer = String(gl.getParameter(extension.UNMASKED_RENDERER_WEBGL) || "");
      }
    } catch {
      // Some browsers intentionally hide renderer details; absence is not itself a risk signal.
    }
    const fingerprints = {
      webdriver: navigator.webdriver === true,
      plugins_count: navigator.plugins?.length || 0,
      languages: Array.from(navigator.languages || []),
      headless_user_agent: /HeadlessChrome|Electron\/|PhantomJS/i.test(userAgent),
      user_agent: userAgent,
      outer_size: { width: window.outerWidth || 0, height: window.outerHeight || 0 },
      screen_size: { width: window.screen?.width || 0, height: window.screen?.height || 0 },
      color_depth: window.screen?.colorDepth || 0,
      device_memory: navigator.deviceMemory ?? null,
      hardware_concurrency: navigator.hardwareConcurrency ?? null,
      platform: navigator.platform || "",
      visibility_state: document.visibilityState || "unknown",
      document_hidden: Boolean(document.hidden),
      notifications_permission: notificationPermission,
      webgl_vendor: webglVendor,
      webgl_renderer: webglRenderer,
      software_renderer: /SwiftShader|llvmpipe|softpipe/i.test(webglRenderer),
    };
    const fingerprintIssues = [];
    if (fingerprints.webdriver) fingerprintIssues.push({ severity: "high", signal: "navigator.webdriver 已暴露" });
    if (fingerprints.headless_user_agent) fingerprintIssues.push({ severity: "high", signal: "User-Agent 含无头浏览器标记" });
    if (fingerprints.software_renderer) fingerprintIssues.push({ severity: "high", signal: "WebGL 使用软件渲染器" });
    if (!fingerprints.outer_size.width || !fingerprints.outer_size.height) {
      fingerprintIssues.push({ severity: "medium", signal: "浏览器外部窗口尺寸为零" });
    }
    if (fingerprints.visibility_state !== "visible") {
      fingerprintIssues.push({ severity: "info", signal: `页面当前位于后台：${fingerprints.visibility_state}` });
    }
    if (!fingerprints.plugins_count) fingerprintIssues.push({ severity: "low", signal: "浏览器插件列表为空" });
    const captchaVisible = Boolean(firstVisible([
      "[class*='captcha']",
      "[class*='verify-modal']",
      "#captcha-container",
    ]));
    const pageIs404 = /404|页面不存在/.test(document.title || "")
      || Boolean(firstVisible(["[class*='not-found']", "[class*='error-page']"]));
    const riskBlockVisible = Boolean(firstVisible(["[class*='risk-block']", "[class*='forbidden-page']"]));
    return {
      url: safeLocationUrl(),
      fingerprints,
      fingerprint_issues: fingerprintIssues,
      page_markers: markers,
      verification_required: verificationRequired,
      access_error_visible: Boolean(firstVisible([".access-wrapper", ".error-wrapper", ".blocked-wrapper", ".not-found-wrapper"])),
      captcha_visible: captchaVisible,
      page_is_404: pageIs404,
      risk_block_visible: riskBlockVisible,
    };
  }

  const operations = {
    ping: async () => ({ ready: true, url: safeLocationUrl() }),
    check_login: checkLogin,
    note_access: async () => noteAccess(),
    get_qrcode: getQrCode,
    prepare_phone: preparePhone,
    send_code_target: async () => sendCodeTarget(),
    wait_code_sent: waitCodeSent,
    prepare_verify_code: prepareVerifyCode,
    wait_verify_code: async () => waitVerifyCode(),
    apply_filters: applyFilters,
    dom_feeds: domFeeds,
    dom_note_content: async () => domNoteContent(),
    load_comments: loadComments,
    dom_detail: domDetail,
    dom_profile: domProfile,
    comment_open_target: async () => commentOpenTarget(),
    prepare_comment: prepareComment,
    wait_comment_sent: waitCommentSent,
    reply_target: async (params) => replyTarget(params),
    interaction_state: async () => interactionState(),
    interaction_target: async (params) => interactionTarget(params),
    action_readiness: actionReadiness,
    prepare_publish_tab: preparePublishTab,
    wait_upload: waitUpload,
    fill_publish_form: fillPublishForm,
    publish_setting_rect: publishSettingRect,
    wait_publish_settings: waitPublishSettings,
    target_rect: async (params) => targetRect(params),
    observe_submission: observeSubmission,
    prepare_long_article: prepareLongArticle,
    prepare_long_images: prepareLongImages,
    wait_long_images: waitLongImages,
    format_long_article: formatLongArticle,
    long_draft_snapshot: longDraftSnapshot,
    select_template: selectTemplate,
    long_next: longNext,
    active_risk_probes: activeRiskProbes,
    risk_signals: async () => riskSignals(),
  };

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.channel !== CHANNEL) return undefined;
    const operation = operations[message.operation];
    if (!operation) {
      sendResponse({ ok: false, error: { code: "unknown_page_operation", message: "页面操作不受支持" } });
      return false;
    }
    Promise.resolve(operation(message.params || {}))
      .then((result) => sendResponse({ ok: true, result }))
      .catch((error) => sendResponse({
        ok: false,
        error: { code: error?.code || "page_operation_failed", message: error?.message || String(error) },
      }));
    return true;
  });
})();
