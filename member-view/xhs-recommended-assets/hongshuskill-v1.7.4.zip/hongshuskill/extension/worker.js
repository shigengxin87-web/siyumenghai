const BRIDGE_URL = "ws://127.0.0.1:9345";
const PROTOCOL = 2;
const EXTENSION_NAME = "hongshuskill-extension";
const EXTENSION_VERSION = "1.7.4";
const PAGE_CHANNEL = "hongshuskill-page";
const EXPLORE_URL = "https://www.xiaohongshu.com/explore";
const CREATOR_URL = "https://creator.xiaohongshu.com/publish/publish?source=official";
const MAX_LOG_ENTRIES = 500;
const MAX_RISK_EVENTS = 200;
const RISK_EVENT_RETENTION_MS = 24 * 60 * 60 * 1000;
const RISK_WINDOW_MINUTES = 15;
const PREPARED_SESSION_TTL_MS = 4 * 60 * 60 * 1000;
const INTERACTION_SETTLE_MS = 1200;
const AUTH_TIME_WINDOW_MS = 60 * 1000;
const AUTH_NONCE_RETENTION_MS = 2 * AUTH_TIME_WINDOW_MS;
const RPC_RESULT_CACHE_TTL_MS = 10 * 60 * 1000;
const MAX_RPC_RESULT_CACHE = 256;
const BRIDGE_KEEPALIVE_INTERVAL_MS = 20 * 1000;
const HIGH_RISK_STATUSES = new Set([429, 461, 999]);
const CLICK_TARGET_KEYS = new Set([
  "login-agreement",
  "login-send-code",
  "login-verify",
  "comment-open",
  "comment-submit",
  "comment-reply",
  "interaction-like",
  "interaction-favorite",
  "schedule-switch",
  "schedule-input",
  "visibility-dropdown",
  "visibility-option",
  "original-switch",
  "original-checkbox",
  "original-confirm",
  "submit-publish",
  "submit-draft",
  "long-image",
]);

let socket = null;
let reconnectTimer = null;
let bridgeKeepaliveTimer = null;
let networkEntries = [];
let riskEvents = [];
let storageLoaded = false;
let storageLoadPromise = null;
let storageWriteQueue = Promise.resolve();
let pairingKeyPromise = null;
let instanceIdPromise = null;
let socketAuthenticated = false;
let pairingError = "";
let rpcExecutionQueue = Promise.resolve();
const rpcResultCache = new Map();

class RpcError extends Error {
  constructor(code, message, details = {}) {
    super(message);
    this.code = code;
    this.details = details;
  }
}

function normalizedRpcErrorCode(value, fallback = "browser_operation_failed") {
  return typeof value === "string" && /^[a-z][a-z0-9_]{0,63}$/.test(value)
    ? value
    : fallback;
}

function operationStateUncertain(action, error) {
  return new RpcError(
    "operation_state_uncertain",
    `${action}动作已发出，但后续页面状态无法确认；为避免重复操作，请先由用户在浏览器中核对`,
    {
      action,
      cause_code: normalizedRpcErrorCode(error?.code),
    },
  );
}

function throwPostDispatchError(action, error, knownCodes = []) {
  const code = normalizedRpcErrorCode(error?.code);
  if (code === "operation_state_uncertain" || knownCodes.includes(code)) throw error;
  throw operationStateUncertain(action, error);
}

function requireConfirmed(params, action) {
  if (params?.confirmed === true) return;
  throw new RpcError(
    "confirmation_required",
    `${action}需要本次用户明确确认`,
    { action },
  );
}

function recentHighRiskSignals(now = Date.now()) {
  const cutoff = now - RISK_WINDOW_MINUTES * 60 * 1000;
  return riskEvents.filter(
    (item) => item.timestamp >= cutoff && HIGH_RISK_STATUSES.has(item.status),
  );
}

function pruneRiskEvents(events, now = Date.now()) {
  const cutoff = now - RISK_EVENT_RETENTION_MS;
  const retained = events.filter((item) => item.timestamp >= cutoff);
  if (retained.length <= MAX_RISK_EVENTS) return retained;

  // A burst of lower-severity failures must not evict a recent 429/461/999 gate.
  const highRisk = retained.filter((item) => HIGH_RISK_STATUSES.has(item.status));
  if (highRisk.length >= MAX_RISK_EVENTS) return highRisk.slice(-MAX_RISK_EVENTS);
  const other = retained.filter((item) => !HIGH_RISK_STATUSES.has(item.status));
  return [
    ...other.slice(-(MAX_RISK_EVENTS - highRisk.length)),
    ...highRisk,
  ].sort((left, right) => left.timestamp - right.timestamp);
}

async function requireRiskClear(action) {
  await loadStorage();
  const signals = recentHighRiskSignals();
  if (!signals.length) return;
  const latest = signals.reduce(
    (current, item) => (item.timestamp > current.timestamp ? item : current),
  );
  const retryAt = latest.timestamp + RISK_WINDOW_MINUTES * 60 * 1000;
  throw new RpcError(
    "risk_control_active",
    `最近 ${RISK_WINDOW_MINUTES} 分钟观察到平台高风险响应，已阻止${action}`,
    {
      status: latest.status,
      observed_at: latest.timestamp,
      retry_after_seconds: Math.max(1, Math.ceil((retryAt - Date.now()) / 1000)),
      window_minutes: RISK_WINDOW_MINUTES,
    },
  );
}

async function requireWriteAllowed(params, action) {
  requireConfirmed(params, action);
  await requireRiskClear(action);
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function loadStorage() {
  if (storageLoaded) return;
  if (!storageLoadPromise) {
    storageLoadPromise = (async () => {
      const stored = await chrome.storage.local.get(["network_entries", "risk_events"]);
      networkEntries = Array.isArray(stored.network_entries)
        ? stored.network_entries.slice(-MAX_LOG_ENTRIES)
        : [];
      const storedRiskEvents = Array.isArray(stored.risk_events)
        ? stored.risk_events
        : networkEntries.filter((item) => isActionableNetworkFailure(item));
      riskEvents = pruneRiskEvents(storedRiskEvents);
      storageLoaded = true;
    })().finally(() => {
      storageLoadPromise = null;
    });
  }
  await storageLoadPromise;
}

function persistNetworkEntries() {
  const snapshot = {
    network_entries: networkEntries.slice(-MAX_LOG_ENTRIES),
    risk_events: riskEvents.slice(-MAX_RISK_EVENTS),
  };
  const pending = storageWriteQueue
    .catch(() => undefined)
    .then(() => chrome.storage.local.set(snapshot));
  storageWriteQueue = pending;
  return pending;
}

function compareUnicodeCodePoints(left, right) {
  const leftPoints = Array.from(left, (character) => character.codePointAt(0));
  const rightPoints = Array.from(right, (character) => character.codePointAt(0));
  const length = Math.min(leftPoints.length, rightPoints.length);
  for (let index = 0; index < length; index += 1) {
    if (leftPoints[index] !== rightPoints[index]) return leftPoints[index] - rightPoints[index];
  }
  return leftPoints.length - rightPoints.length;
}

function requirePairedSurrogates(value) {
  for (let index = 0; index < value.length; index += 1) {
    const unit = value.charCodeAt(index);
    if (unit >= 0xd800 && unit <= 0xdbff) {
      const next = value.charCodeAt(index + 1);
      if (!(next >= 0xdc00 && next <= 0xdfff)) {
        throw new Error("认证消息包含未配对的 Unicode 代理项");
      }
      index += 1;
    } else if (unit >= 0xdc00 && unit <= 0xdfff) {
      throw new Error("认证消息包含未配对的 Unicode 代理项");
    }
  }
  return value;
}

function canonicalJson(value, { inArray = false } = {}) {
  if (value === null) return "null";
  if (typeof value === "string") return JSON.stringify(requirePairedSurrogates(value));
  if (typeof value === "boolean") return JSON.stringify(value);
  if (typeof value === "number") {
    if (!Number.isFinite(value)) throw new Error("认证消息包含非有限数值");
    if (Object.is(value, -0) || value === 0) return "0";
    if (Number.isInteger(value)) {
      if (!Number.isSafeInteger(value)) throw new Error("认证消息包含超出安全范围的整数");
      return String(value);
    }
    return value.toExponential(16).replace(/e([+-])0+(\d+)$/, "e$1$2");
  }
  if (["undefined", "function", "symbol"].includes(typeof value)) {
    return inArray ? "null" : undefined;
  }
  if (Array.isArray(value)) {
    return `[${value.map((item) => canonicalJson(item, { inArray: true })).join(",")}]`;
  }
  if (typeof value === "object") {
    const entries = Object.keys(value)
      .sort(compareUnicodeCodePoints)
      .flatMap((key) => {
        requirePairedSurrogates(key);
        const encoded = canonicalJson(value[key]);
        return encoded === undefined ? [] : [`${JSON.stringify(key)}:${encoded}`];
      });
    return `{${entries.join(",")}}`;
  }
  throw new Error("认证消息包含不支持的数据类型");
}

function envelopeWithoutAuth(message) {
  if (!message || typeof message !== "object" || Array.isArray(message)) {
    throw new Error("认证消息必须是对象");
  }
  return Object.fromEntries(
    Object.entries(message).filter(([key]) => key !== "auth"),
  );
}

function hexToBytes(value) {
  if (typeof value !== "string" || value.length % 2 !== 0 || !/^[0-9a-f]+$/.test(value)) {
    throw new Error("认证字段不是有效的小写十六进制");
  }
  const bytes = new Uint8Array(value.length / 2);
  for (let index = 0; index < bytes.length; index += 1) {
    bytes[index] = Number.parseInt(value.slice(index * 2, index * 2 + 2), 16);
  }
  return bytes;
}

function bytesToHex(value) {
  return Array.from(value, (byte) => byte.toString(16).padStart(2, "0")).join("");
}

function randomNonce() {
  const bytes = new Uint8Array(16);
  crypto.getRandomValues(bytes);
  return bytesToHex(bytes);
}

async function loadInstanceId() {
  if (!instanceIdPromise) {
    instanceIdPromise = (async () => {
      const stored = await chrome.storage.local.get("instance_id");
      if (/^[0-9a-f]{32}$/.test(stored.instance_id || "")) return stored.instance_id;
      const instanceId = randomNonce();
      await chrome.storage.local.set({ instance_id: instanceId });
      return instanceId;
    })().catch((error) => {
      instanceIdPromise = null;
      throw error;
    });
  }
  return instanceIdPromise;
}

function authenticationPayload(envelope, timestampMs, nonce) {
  return `${timestampMs}\n${nonce}\n${canonicalJson(envelopeWithoutAuth(envelope))}`;
}

async function loadPairingKey() {
  if (!pairingKeyPromise) {
    pairingKeyPromise = (async () => {
      const response = await fetch(chrome.runtime.getURL("pairing.json"), { cache: "no-store" });
      if (!response.ok) throw new Error(`配对文件读取失败（HTTP ${response.status}）`);
      const pairing = await response.json();
      if (!/^[0-9a-f]{64}$/.test(pairing?.token || "")) {
        throw new Error("pairing.json 缺少有效的 32 字节 token");
      }
      return crypto.subtle.importKey(
        "raw",
        hexToBytes(pairing.token),
        { name: "HMAC", hash: "SHA-256" },
        false,
        ["sign", "verify"],
      );
    })().catch((error) => {
      pairingKeyPromise = null;
      throw error;
    });
  }
  return pairingKeyPromise;
}

async function signedEnvelope(envelope, key, now = Date.now()) {
  const unsigned = envelopeWithoutAuth(envelope);
  const nonce = randomNonce();
  const data = new TextEncoder().encode(authenticationPayload(unsigned, now, nonce));
  const mac = await crypto.subtle.sign("HMAC", key, data);
  return {
    ...unsigned,
    auth: {
      nonce,
      timestamp_ms: now,
      mac: bytesToHex(new Uint8Array(mac)),
    },
  };
}

function pruneReceivedNonces(state, now = Date.now()) {
  for (const [nonce, observedAt] of state.receivedNonces.entries()) {
    if (now - observedAt > AUTH_NONCE_RETENTION_MS) state.receivedNonces.delete(nonce);
  }
}

async function verifySignedEnvelope(message, state, now = Date.now()) {
  const auth = message?.auth;
  if (
    !auth
    || !/^[0-9a-f]{32}$/.test(auth.nonce || "")
    || !Number.isSafeInteger(auth.timestamp_ms)
    || !/^[0-9a-f]{64}$/.test(auth.mac || "")
  ) {
    throw new RpcError("authentication_failed", "桥接消息缺少有效认证字段");
  }
  if (Math.abs(now - auth.timestamp_ms) > AUTH_TIME_WINDOW_MS) {
    throw new RpcError("authentication_failed", "桥接消息时间戳已过期");
  }
  pruneReceivedNonces(state, now);
  const data = new TextEncoder().encode(
    authenticationPayload(message, auth.timestamp_ms, auth.nonce),
  );
  const valid = await crypto.subtle.verify("HMAC", state.key, hexToBytes(auth.mac), data);
  if (!valid) throw new RpcError("authentication_failed", "桥接消息签名无效");
  if (state.receivedNonces.has(auth.nonce)) {
    throw new RpcError("authentication_failed", "桥接消息 nonce 已被使用");
  }
  state.receivedNonces.set(auth.nonce, now);
  return envelopeWithoutAuth(message);
}

async function sendSigned(connection, state, envelope) {
  if (connection.readyState !== WebSocket.OPEN) return false;
  const message = await signedEnvelope(envelope, state.key);
  if (connection.readyState !== WebSocket.OPEN) return false;
  connection.send(JSON.stringify(message));
  return true;
}

async function sendRpcResponseIfCurrent(connection, state, response, currentConnection = socket) {
  if (
    connection !== currentConnection
    || !state.paired
    || connection.readyState !== WebSocket.OPEN
  ) return false;
  return sendSigned(connection, state, response);
}

async function sendBridgeKeepaliveIfCurrent(
  connection,
  state,
  currentConnection = socket,
) {
  if (
    connection !== currentConnection
    || !state.paired
    || connection.readyState !== WebSocket.OPEN
  ) return false;
  return sendSigned(connection, state, {
    kind: "extension_keepalive",
    protocol: PROTOCOL,
  });
}

function stopBridgeKeepalive() {
  if (bridgeKeepaliveTimer !== null) {
    clearInterval(bridgeKeepaliveTimer);
    bridgeKeepaliveTimer = null;
  }
}

function startBridgeKeepalive(connection, state) {
  stopBridgeKeepalive();
  bridgeKeepaliveTimer = setInterval(() => {
    sendBridgeKeepaliveIfCurrent(connection, state)
      .then((sent) => {
        if (!sent && connection === socket) stopBridgeKeepalive();
      })
      .catch(() => {
        if (connection === socket) stopBridgeKeepalive();
      });
  }, BRIDGE_KEEPALIVE_INTERVAL_MS);
}

async function rejectConnection(connection, state, code, message) {
  try {
    if (state.key) {
      await sendSigned(connection, state, {
        ok: false,
        error: { code, message },
      });
    }
  } finally {
    connection.close(1008, code);
  }
}

function pruneRpcResultCache(now = Date.now()) {
  for (const [id, entry] of rpcResultCache.entries()) {
    if (now - entry.createdAt > RPC_RESULT_CACHE_TTL_MS) rpcResultCache.delete(id);
  }
  while (rpcResultCache.size > MAX_RPC_RESULT_CACHE) {
    rpcResultCache.delete(rpcResultCache.keys().next().value);
  }
}

function requestCacheKey(request) {
  if (typeof request.id !== "string" || !/^[0-9a-f]{32}$/.test(request.id)) {
    throw new RpcError("invalid_request", "RPC id 必须是 32 位小写十六进制字符串");
  }
  return request.id;
}

async function executeCachedRequest(request) {
  const id = requestCacheKey(request);
  const fingerprint = canonicalJson({
    op: request.op,
    params: request.params || {},
    account_guard: request.account_guard || null,
  });
  pruneRpcResultCache();
  const cached = rpcResultCache.get(id);
  if (cached) {
    if (cached.fingerprint !== fingerprint) {
      return {
        kind: "rpc_result",
        id,
        ok: false,
        error: {
          code: "rpc_id_conflict",
          message: "同一 RPC id 不能用于不同请求",
          details: {},
        },
      };
    }
    return cached.response;
  }
  const response = await executeRequest(request);
  rpcResultCache.set(id, { fingerprint, response, createdAt: Date.now() });
  pruneRpcResultCache();
  return response;
}

function executeSerializedRequest(request) {
  const pending = rpcExecutionQueue
    .catch(() => undefined)
    .then(() => executeCachedRequest(request));
  rpcExecutionQueue = pending.catch(() => undefined);
  return pending;
}

function enqueueConnectionMessage(state, handler) {
  const pending = state.messageQueue.catch(() => undefined).then(handler);
  state.messageQueue = pending.catch(() => undefined);
  return pending;
}

function connectBridge() {
  if (socket && [WebSocket.CONNECTING, WebSocket.OPEN].includes(socket.readyState)) return;
  clearTimeout(reconnectTimer);
  const connection = new WebSocket(BRIDGE_URL);
  const state = {
    key: null,
    helloSent: false,
    paired: false,
    receivedNonces: new Map(),
    messageQueue: Promise.resolve(),
  };
  socket = connection;
  socketAuthenticated = false;
  pairingError = "";
  connection.addEventListener("open", async () => {
    try {
      state.key = await loadPairingKey();
      const instanceId = await loadInstanceId();
      if (connection !== socket || connection.readyState !== WebSocket.OPEN) return;
      await sendSigned(connection, state, {
        role: "extension",
        name: EXTENSION_NAME,
        version: EXTENSION_VERSION,
        protocol: PROTOCOL,
        extension_id: chrome.runtime.id,
        instance_id: instanceId,
      });
      state.helloSent = true;
    } catch (error) {
      pairingError = error?.message || String(error);
      await rejectConnection(connection, state, "authentication_failed", pairingError).catch(() => {});
    }
  });
  connection.addEventListener("message", (event) => {
    enqueueConnectionMessage(state, async () => {
      let message;
      try {
        message = JSON.parse(event.data);
      } catch {
        await rejectConnection(connection, state, "authentication_failed", "桥接消息不是有效 JSON").catch(() => {});
        return;
      }
      try {
        if (connection.readyState !== WebSocket.OPEN) return;
        if (!state.key || !state.helloSent) {
          throw new RpcError("authentication_failed", "扩展配对尚未初始化");
        }
        const verified = await verifySignedEnvelope(message, state);
        if (!state.paired) {
          if (
            verified.kind !== "paired"
            || verified.ok !== true
            || verified.protocol !== PROTOCOL
            || verified.extension_version !== EXTENSION_VERSION
          ) {
            throw new RpcError("pairing_rejected", "桥接服务没有返回兼容的 paired ACK");
          }
          state.paired = true;
          if (connection === socket) {
            socketAuthenticated = true;
            pairingError = "";
            startBridgeKeepalive(connection, state);
          }
          return;
        }
        if (verified.kind !== "rpc_request" || verified.protocol !== PROTOCOL) {
          throw new RpcError("authentication_failed", "已配对连接收到了无效消息类型");
        }
        // Dispatch onto the global operation queue without keeping this connection's
        // authentication queue blocked for the full browser operation. Subsequent
        // messages are therefore timestamp-checked when received, while execution
        // remains globally serialized.
        executeSerializedRequest(verified)
          .then((response) => sendRpcResponseIfCurrent(connection, state, response))
          .catch(async (error) => {
            pairingError = error?.message || String(error);
            await rejectConnection(
              connection,
              state,
              "authentication_failed",
              pairingError,
            ).catch(() => {});
          });
      } catch (error) {
        pairingError = error?.message || String(error);
        await rejectConnection(
          connection,
          state,
          error?.code === "pairing_rejected" ? "pairing_rejected" : "authentication_failed",
          pairingError,
        ).catch(() => {});
      }
    });
  });
  const reconnect = () => {
    if (socket !== connection) return;
    stopBridgeKeepalive();
    socket = null;
    socketAuthenticated = false;
    clearTimeout(reconnectTimer);
    reconnectTimer = setTimeout(connectBridge, 800);
  };
  connection.addEventListener("close", reconnect);
  connection.addEventListener("error", () => connection.close());
}

chrome.runtime.onStartup.addListener(connectBridge);
chrome.runtime.onInstalled.addListener(connectBridge);
chrome.alarms.create("hongshuskill-keepalive", { periodInMinutes: 0.5 });
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "hongshuskill-keepalive") connectBridge();
});
connectBridge();
loadStorage();

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.channel !== "hongshuskill-popup" || message.type !== "status") return undefined;
  Promise.all([loadStorage(), loadInstanceId()]).then(([, instanceId]) => sendResponse({
      connected: socketAuthenticated,
      socket_open: socket?.readyState === WebSocket.OPEN,
      pairing_error: pairingError || undefined,
      instance_id: instanceId,
      network_entries: networkEntries.length,
    }));
  return true;
});

function privacySafeUrl(url) {
  try {
    const parsed = new URL(url);
    if (!["http:", "https:"].includes(parsed.protocol)) return "invalid-url";
    return `${parsed.origin}${parsed.pathname}`;
  } catch {
    return "invalid-url";
  }
}

function isAllowedRiskProbeUrl(url) {
  if (typeof url !== "string" || url.length === 0 || url.length > 4096) return false;
  try {
    const parsed = new URL(url);
    const hostname = parsed.hostname.toLowerCase();
    return parsed.protocol === "https:"
      && (hostname === "xiaohongshu.com" || hostname.endsWith(".xiaohongshu.com"))
      && !parsed.username
      && !parsed.password
      && (!parsed.port || parsed.port === "443")
      && parsed.pathname.startsWith("/api/")
      && !parsed.hash;
  } catch {
    return false;
  }
}

function privacySafeText(value) {
  return String(value ?? "").replace(
    /https?:\/\/[^\s"'<>]+/gi,
    (url) => privacySafeUrl(url),
  );
}

function privacySafeErrorDetails(value) {
  if (Array.isArray(value)) return value.map(privacySafeErrorDetails);
  if (value && typeof value === "object") {
    return Object.fromEntries(
      Object.entries(value).map(([key, item]) => [key, privacySafeErrorDetails(item)]),
    );
  }
  return typeof value === "string" ? privacySafeText(value) : value;
}

function sanitizedNetworkEntry(details) {
  let safeUrl = "";
  let category = "other";
  try {
    const parsed = new URL(details.url);
    safeUrl = privacySafeUrl(details.url);
    if (parsed.hostname.startsWith("t2.") || parsed.hostname.startsWith("apm-fe.")) category = "telemetry";
    else if (parsed.pathname.includes("/api/sns/web/v1/search")) category = "search";
    else if (parsed.pathname.includes("/api/sns/web/v1/feed")) category = "feed";
    else if (parsed.pathname.includes("/comment")) category = "comment";
    else if (/\/api\/sns\/web\/v1\/note\/(?:like|dislike)/.test(parsed.pathname)) category = "like";
    else if (/\/api\/sns\/web\/v1\/note\/(?:collect|uncollect)/.test(parsed.pathname)) category = "favorite";
    else if (parsed.hostname.startsWith("creator.")) category = "creator";
  } catch {
    safeUrl = "invalid-url";
  }
  return {
    timestamp: Date.now(),
    method: details.method || "GET",
    url: safeUrl,
    status: Number(details.statusCode || 0),
    error: details.error || "",
    category,
    tab_id: details.tabId,
  };
}

function isBenignNetworkFailure(item) {
  if (item.category === "telemetry" && item.error) return true;
  if (item.error === "net::ERR_ABORTED") return true;
  return item.error === "net::ERR_FAILED"
    && item.category === "creator"
    && item.url.endsWith("/worker.js");
}

function isActionableNetworkFailure(item, { include404 = true } = {}) {
  const statuses = include404 ? [401, 403, 404, 429, 461, 999] : [401, 403, 429, 461, 999];
  return statuses.includes(item.status) || Boolean(item.error && !isBenignNetworkFailure(item));
}

function diagnoseNotFound(item) {
  const category = item.category || "other";
  const categoryHints = {
    feed: "笔记可能已删除、不可见，或 feed_id 与 xsec_token 不匹配",
    search: "搜索接口或页面资源路径可能已经变化",
    comment: "评论目标可能已删除，或评论接口路径已经变化",
    creator: "创作中心资源可能更新，建议刷新页面并检查扩展选择器",
  };
  return {
    root_cause: categoryHints[category] || "页面或接口返回了资源不存在响应",
    cause_category: category === "other" ? "resource_not_found" : `${category}_not_found`,
    confidence: "low",
    detail: "诊断仅基于去查询参数的路径、状态码和请求类别，不读取 Cookie、请求头或正文。",
    how_xhs_decides: "可能由内容可见性、资源状态、令牌配对或前端接口版本共同决定。",
  };
}

async function recordNetwork(details) {
  await loadStorage();
  const entry = sanitizedNetworkEntry(details);
  networkEntries.push(entry);
  networkEntries = networkEntries.slice(-MAX_LOG_ENTRIES);
  if (isActionableNetworkFailure(entry)) {
    riskEvents.push(entry);
  }
  riskEvents = pruneRiskEvents(riskEvents);
  await persistNetworkEntries();
}

async function recordPageRiskSignal(tabId, url) {
  await loadStorage();
  const entry = sanitizedNetworkEntry({
    url,
    method: "PAGE",
    statusCode: 999,
    error: "page_risk_control",
    tabId,
  });
  riskEvents.push(entry);
  riskEvents = pruneRiskEvents(riskEvents);
  await persistNetworkEntries();
  return entry;
}

function visiblePageRiskReason(page = {}) {
  const markers = Array.isArray(page.page_markers) ? page.page_markers : [];
  const marker = markers.find((item) => (
    /访问频繁|操作频繁|账号异常|扫码验证|扫码查看|安全验证|禁止|受限|无法发布|无法评论/.test(String(item))
  ));
  if (marker) return String(marker);
  if (page.verification_required) return "页面要求安全验证";
  if (page.captcha_visible) return "页面出现验证码";
  if (page.risk_block_visible) return "页面出现风险控制拦截";
  return "";
}

async function requirePageRiskClear(tabId, action) {
  let page;
  try {
    page = await pageCall(tabId, "risk_signals");
  } catch {
    // Network risk events remain authoritative when a passive page scan is unavailable.
    return null;
  }
  const reason = visiblePageRiskReason(page);
  if (!reason) return page;
  const tab = await chrome.tabs.get(tabId).catch(() => null);
  const signal = await recordPageRiskSignal(tabId, page.url || tab?.url || "https://www.xiaohongshu.com/");
  throw new RpcError(
    "risk_control_active",
    `${reason}，已阻止${action}`,
    {
      status: signal.status,
      observed_at: signal.timestamp,
      source: "page",
      action,
    },
  );
}

async function rethrowVisiblePageRisk(tabId, action, originalError) {
  try {
    await requirePageRiskClear(tabId, action);
  } catch (error) {
    if (error?.code === "risk_control_active") throw error;
  }
  throw originalError;
}

const networkFilter = {
  urls: [
    "https://*.xiaohongshu.com/*",
    "https://www.xiaohongshu.com/*",
    "https://creator.xiaohongshu.com/*",
  ],
};
function recordNetworkSafely(details) {
  recordNetwork(details).catch(() => {
    // Diagnostics must never interfere with the browser request that produced them.
  });
}

chrome.webRequest.onCompleted.addListener(recordNetworkSafely, networkFilter);
chrome.webRequest.onErrorOccurred.addListener(recordNetworkSafely, networkFilter);

async function executeRequest(request) {
  try {
    const handler = OPERATIONS[request.op];
    if (!handler) throw new RpcError("unknown_operation", `不支持的操作：${request.op}`);
    const guard = request.account_guard;
    if (guard !== undefined && guard !== null) {
      if (
        typeof guard !== "object"
        || Array.isArray(guard)
        || !/^[0-9a-f]{64}$/.test(guard.session_fingerprint || "")
      ) {
        throw new RpcError("invalid_request", "账号安全路由信息无效");
      }
      const currentFingerprint = await currentAccountFingerprint();
      if (currentFingerprint !== guard.session_fingerprint) {
        await clearPreparedSurface("creator");
        throw new RpcError(
          "account_changed",
          "当前 Chrome Profile 的小红书会话与已绑定账号不一致，已拒绝继续",
        );
      }
    }
    const result = await handler(request.params || {});
    if (!result || typeof result !== "object" || Array.isArray(result)) {
      throw new RpcError("invalid_operation_result", "浏览器操作未返回有效结果对象");
    }
    const response = { kind: "rpc_result", id: request.id, ok: true, result };
    // Validate the exact value before it reaches the signing layer. Malformed
    // page data (for example a lone surrogate or NaN) becomes a typed RPC error
    // instead of tearing down an otherwise authenticated socket.
    canonicalJson(response);
    return response;
  } catch (error) {
    const code = normalizedRpcErrorCode(error?.code);
    const safeMessage = privacySafeText(error?.message || "").trim().slice(0, 512)
      || "浏览器操作失败";
    let details = {};
    try {
      const candidateDetails = privacySafeErrorDetails(error?.details || {});
      if (
        candidateDetails
        && typeof candidateDetails === "object"
        && !Array.isArray(candidateDetails)
      ) details = candidateDetails;
    } catch {
      details = {};
    }
    const response = {
      kind: "rpc_result",
      id: request.id,
      ok: false,
      error: {
        code,
        message: safeMessage,
        details,
      },
    };
    try {
      canonicalJson(response);
      return response;
    } catch {
      return {
        kind: "rpc_result",
        id: request.id,
        ok: false,
        error: {
          code: "browser_operation_failed",
          message: "浏览器操作返回了无法安全序列化的结果",
          details: {},
        },
      };
    }
  }
}

async function storedTab(surface) {
  const key = `tab_${surface}`;
  const stored = await chrome.storage.session.get(key);
  const tabId = stored[key];
  if (Number.isInteger(tabId)) {
    try {
      return await chrome.tabs.get(tabId);
    } catch {
      await chrome.storage.session.remove(key);
    }
  }
  return null;
}

async function setStoredTab(surface, tabId) {
  await chrome.storage.session.set({ [`tab_${surface}`]: tabId });
}

function preparedSurfaceKey(surface) {
  return `prepared_${surface}`;
}

async function currentAccountFingerprint() {
  const cookies = await chrome.cookies.getAll({ domain: "xiaohongshu.com" });
  const sessions = cookies
    .filter((cookie) => /^web_session(?:_|$)/.test(cookie.name || "") && cookie.value)
    .map((cookie) => ({
      name: cookie.name,
      value: cookie.value,
      domain: cookie.domain || "",
      path: cookie.path || "",
      store_id: cookie.storeId || "",
      partition_site: cookie.partitionKey?.topLevelSite || "",
    }))
    .sort((left, right) => compareUnicodeCodePoints(canonicalJson(left), canonicalJson(right)));
  if (!sessions.length) {
    throw new RpcError(
      "account_identity_unknown",
      "无法确认当前小红书账号会话，已停止登记或提交预览",
    );
  }
  const key = await loadPairingKey();
  const digest = await crypto.subtle.sign(
    "HMAC",
    key,
    new TextEncoder().encode(canonicalJson(sessions)),
  );
  return bytesToHex(new Uint8Array(digest));
}

async function setPreparedSurface(
  surface,
  tabId,
  stage,
  metadata = {},
  { preserveCreatedAt = false } = {},
) {
  const key = preparedSurfaceKey(surface);
  const stored = preserveCreatedAt ? await chrome.storage.session.get(key) : {};
  const previous = stored[key] || {};
  await chrome.storage.session.set({
    [key]: {
      ...(preserveCreatedAt ? previous : {}),
      ...metadata,
      tab_id: tabId,
      stage,
      created_at: preserveCreatedAt && Number.isFinite(previous.created_at)
        ? previous.created_at
        : Date.now(),
    },
  });
}

async function clearPreparedSurface(surface, expectedTabId = null) {
  const key = preparedSurfaceKey(surface);
  if (Number.isInteger(expectedTabId)) {
    const stored = await chrome.storage.session.get(key);
    if (stored[key]?.tab_id !== expectedTabId) return;
  }
  await chrome.storage.session.remove(key);
}

async function requirePreparedTab(surface, allowedStages, action) {
  const key = preparedSurfaceKey(surface);
  const stored = await chrome.storage.session.get(key);
  const prepared = stored[key];
  if (!prepared || !Number.isInteger(prepared.tab_id) || !prepared.stage) {
    throw new RpcError(
      "draft_tab_missing",
      "没有已完成校验的发布预览，请先重新填写发布表单",
      { action },
    );
  }
  if (
    !Number.isFinite(prepared.created_at)
    || Date.now() - prepared.created_at > PREPARED_SESSION_TTL_MS
  ) {
    await clearPreparedSurface(surface, prepared.tab_id);
    throw new RpcError(
      "draft_session_expired",
      "发布预览已过期，请重新填写并让用户再次确认",
      { action, max_age_minutes: PREPARED_SESSION_TTL_MS / 60000 },
    );
  }
  if (!allowedStages.includes(prepared.stage)) {
    const uncertain = /uncertain/.test(prepared.stage);
    throw new RpcError(
      uncertain ? "submission_state_uncertain" : "draft_state_not_ready",
      uncertain
        ? "上次提交结果未能确认；请先由用户检查浏览器，不能自动重复提交"
        : "当前草稿尚未进入可执行这一步的预览阶段",
      { action, stage: prepared.stage, allowed_stages: allowedStages },
    );
  }
  const tab = await storedTab(surface);
  if (
    !tab
    || tab.id !== prepared.tab_id
    || (surface === "creator" && !isCreatorPageUrl(tab.url))
    || (surface === "creator" && prepared.creator_url && tab.url !== prepared.creator_url)
  ) {
    await clearPreparedSurface(surface, prepared.tab_id);
    throw new RpcError(
      "draft_tab_missing",
      "发布预览标签页已关闭或离开创作中心，请重新填写发布表单",
      { action },
    );
  }
  if (surface === "creator") {
    const accountFingerprint = await currentAccountFingerprint();
    if (!prepared.account_fingerprint) {
      throw new RpcError(
        "preview_validation_failed",
        "发布预览未绑定可确认的账号，请重新生成预览",
      );
    }
    if (accountFingerprint !== prepared.account_fingerprint) {
      await setPreparedSurface(
        surface,
        tab.id,
        "account_changed",
        { creator_url: tab.url },
        { preserveCreatedAt: true },
      );
      throw new RpcError(
        "account_changed",
        "当前账号与生成发布预览时的账号不一致，已拒绝继续",
      );
    }
  }
  return { tab, prepared };
}

function requireMatchingPreviewId(params, prepared) {
  if (!params?.preview_id) {
    throw new RpcError("preview_id_required", "该操作必须携带本次预览的 preview_id");
  }
  if (params.preview_id !== prepared.preview_id) {
    throw new RpcError("preview_id_mismatch", "preview_id 与当前已确认预览不一致");
  }
}

function isXhsPageUrl(url) {
  try {
    const parsed = new URL(url || "");
    return parsed.protocol === "https:"
      && ["www.xiaohongshu.com", "creator.xiaohongshu.com"].includes(parsed.hostname);
  } catch {
    return false;
  }
}

function isCreatorPageUrl(url) {
  try {
    const parsed = new URL(url || "");
    return parsed.protocol === "https:" && parsed.hostname === "creator.xiaohongshu.com";
  } catch {
    return false;
  }
}

function routeId(url, pattern) {
  try {
    const parsed = new URL(url || "");
    if (parsed.protocol !== "https:" || parsed.hostname !== "www.xiaohongshu.com") return "";
    const match = parsed.pathname.match(pattern);
    return match ? decodeURIComponent(match[1]) : "";
  } catch {
    return "";
  }
}

async function requireNoteRoute(tabId, expectedFeedId) {
  const tab = await chrome.tabs.get(tabId);
  const actualFeedId = routeId(tab.url, /^\/explore\/([^/]+)\/?$/);
  if (!actualFeedId || actualFeedId !== String(expectedFeedId || "")) {
    throw new RpcError(
      "target_route_mismatch",
      "当前页面不是请求的笔记，已停止读取或写入",
      { expected_feed_id: expectedFeedId || "", actual_feed_id: actualFeedId },
    );
  }
  return tab;
}

async function requireUserRoute(tabId, expectedUserId) {
  const tab = await chrome.tabs.get(tabId);
  const actualUserId = routeId(tab.url, /^\/user\/profile\/([^/]+)\/?$/);
  if (!actualUserId || actualUserId !== String(expectedUserId || "")) {
    throw new RpcError(
      "target_route_mismatch",
      "当前页面不是请求的用户主页，已停止读取",
      { expected_user_id: expectedUserId || "", actual_user_id: actualUserId },
    );
  }
  return tab;
}

async function existingXhsTab() {
  for (const surface of ["read", "creator"]) {
    const tab = await storedTab(surface);
    if (tab && isXhsPageUrl(tab.url)) return tab;
  }
  const tabs = await chrome.tabs.query({
    url: [
      "https://www.xiaohongshu.com/*",
      "https://creator.xiaohongshu.com/*",
    ],
  });
  return tabs.find((tab) => Number.isInteger(tab.id) && isXhsPageUrl(tab.url)) || null;
}

async function automationTab(surface, initialUrl) {
  let tab = await storedTab(surface);
  if (!tab) {
    tab = await chrome.tabs.create({ url: initialUrl, active: true });
    await setStoredTab(surface, tab.id);
    await waitForTab(tab.id);
    return { tab, created: true };
  }
  return { tab, created: false };
}

async function waitForTab(tabId, timeoutMs = 45000) {
  const current = await chrome.tabs.get(tabId);
  if (current.status === "complete") return current;
  return new Promise((resolve, reject) => {
    const timeout = setTimeout(() => {
      chrome.tabs.onUpdated.removeListener(listener);
      reject(new RpcError("navigation_timeout", "页面加载超时"));
    }, timeoutMs);
    const listener = (updatedId, info) => {
      if (updatedId === tabId && info.status === "complete") {
        clearTimeout(timeout);
        chrome.tabs.onUpdated.removeListener(listener);
        chrome.tabs.get(tabId).then(resolve, reject);
      }
    };
    chrome.tabs.onUpdated.addListener(listener);
  });
}

async function navigate(surface, url, { reload = false } = {}) {
  const { tab, created } = await automationTab(surface, url);
  if (tab.url !== url) {
    await chrome.tabs.update(tab.id, { url, active: true });
    await waitForTab(tab.id);
  } else if (reload && !created) {
    await chrome.tabs.reload(tab.id);
    await waitForTab(tab.id);
  } else if (!created) {
    await chrome.tabs.update(tab.id, { active: true });
  }
  try {
    await waitForPageAgent(tab.id);
  } catch (error) {
    if (!(error instanceof RpcError) || error.code !== "page_agent_unavailable") throw error;
    await chrome.tabs.reload(tab.id);
    await waitForTab(tab.id);
    await waitForPageAgent(tab.id);
  }
  return chrome.tabs.get(tab.id);
}

async function waitForPageAgent(tabId, timeoutMs = 12000) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    try {
      const response = await chrome.tabs.sendMessage(tabId, {
        channel: PAGE_CHANNEL,
        operation: "ping",
        params: {},
      });
      if (response?.ok) return response.result;
    } catch {
      // The content script starts after document_idle; retry while the page settles.
    }
    await sleep(150);
  }
  throw new RpcError("page_agent_unavailable", "页面助手没有响应，请刷新小红书页面后重试");
}

async function pageCall(tabId, operation, params = {}) {
  await waitForPageAgent(tabId);
  const response = await chrome.tabs.sendMessage(tabId, {
    channel: PAGE_CHANNEL,
    operation,
    params,
  });
  if (response?.ok) return response.result;
  throw new RpcError(
    response?.error?.code || "page_operation_failed",
    response?.error?.message || "页面操作失败",
  );
}

async function requireLogin(tabId) {
  const status = await pageCall(tabId, "check_login");
  if (status.inconclusive) {
    throw new RpcError("authentication_state_unknown", "页面未显示明确的登录或未登录状态");
  }
  if (!status.logged_in) throw new RpcError("not_logged_in", "小红书账号未登录");
  return status;
}

async function requireNoteAccessible(tabId, { keyword = "" } = {}) {
  const access = await pageCall(tabId, "note_access");
  const safeAccess = { ...access, url: privacySafeUrl(access.url || "") };
  if (safeAccess.accessible) return safeAccess;
  const code = safeAccess.verification_required ? "verification_required" : "page_not_accessible";
  throw new RpcError(
    code,
    safeAccess.reason || "笔记当前不可访问",
    {
      url: safeAccess.url === "invalid-url" ? "" : safeAccess.url,
      suggested_search_keyword: keyword || undefined,
      recovery: safeAccess.verification_required
        ? "请由用户在 Chrome 中完成验证后再重试"
        : "请确认笔记未删除、未设为私密，且 feed_id 与 xsec_token 来自同一结果",
    },
  );
}

function unwrap(value) {
  if (value && Object.prototype.hasOwnProperty.call(value, "value")) return value.value;
  if (value && Object.prototype.hasOwnProperty.call(value, "_value")) return value._value;
  return value;
}

async function stateSnapshot(tabId, kind, key = "") {
  const [{ result }] = await chrome.scripting.executeScript({
    target: { tabId },
    world: "MAIN",
    args: [kind, key],
    func: (snapshotKind, snapshotKey) => {
      const state = window.__INITIAL_STATE__ || {};
      const unwrapLocal = (value) => {
        if (value && Object.prototype.hasOwnProperty.call(value, "value")) return value.value;
        if (value && Object.prototype.hasOwnProperty.call(value, "_value")) return value._value;
        return value;
      };
      let value = null;
      if (snapshotKind === "feeds") value = unwrapLocal(state.feed?.feeds) || [];
      if (snapshotKind === "search") value = unwrapLocal(state.search?.feeds) || [];
      if (snapshotKind === "detail") {
        const map = unwrapLocal(state.note?.noteDetailMap) || {};
        value = snapshotKey
          ? (map[snapshotKey] || null)
          : (Object.values(map)[0] || null);
      }
      if (snapshotKind === "user") {
        value = {
          profile: unwrapLocal(state.user?.userPageData) || null,
          notes: unwrapLocal(state.user?.notes) || [],
        };
      }
      try {
        return JSON.parse(JSON.stringify(value));
      } catch {
        return null;
      }
    },
  });
  return result;
}

async function optionalStateSnapshot(tabId, kind, key = "") {
  try {
    return await stateSnapshot(tabId, kind, key);
  } catch {
    return null;
  }
}

function snapshotFingerprint(value) {
  try {
    return JSON.stringify(value);
  } catch {
    return "";
  }
}

async function waitForStateRefresh(tabId, kind, key, previous, timeoutMs = 8000) {
  if (previous === null) {
    await sleep(700);
    return {
      value: await optionalStateSnapshot(tabId, kind, key),
      changed: false,
    };
  }
  const previousFingerprint = snapshotFingerprint(previous);
  const deadline = Date.now() + timeoutMs;
  let latest = previous;
  while (Date.now() < deadline) {
    const candidate = await optionalStateSnapshot(tabId, kind, key);
    if (candidate !== null) latest = candidate;
    if (candidate !== null && snapshotFingerprint(candidate) !== previousFingerprint) {
      return { value: candidate, changed: true };
    }
    await sleep(200);
  }
  return { value: latest, changed: false };
}

function pickImage(cover) {
  if (!cover) return "";
  if (typeof cover === "string") return cover;
  return cover.urlDefault || cover.urlPre || cover.url || cover.infoList?.find((item) => item.url)?.url || "";
}

function safeXsecSource(value, fallback = "pc_feed") {
  const source = typeof value === "string" ? value.trim() : "";
  return /^[a-zA-Z0-9_-]{1,64}$/.test(source) ? source : fallback;
}

function normalizeFeed(raw, index = 0, defaultSource = "pc_feed") {
  if (!raw) return null;
  if (raw.feed_id) {
    return {
      ...raw,
      xsec_source: safeXsecSource(raw.xsec_source, defaultSource),
      author: normalizeUser(raw.author || {}, raw.author?.xsec_source || defaultSource),
    };
  }
  const card = raw.noteCard || raw.note_card || raw;
  const user = card.user || {};
  const interact = card.interactInfo || card.interact_info || {};
  const feedId = raw.id || card.noteId || card.note_id || "";
  if (!feedId || raw.modelType === "hot_query") return null;
  return {
    feed_id: feedId,
    xsec_token: raw.xsecToken || raw.xsec_token || card.xsecToken || "",
    xsec_source: safeXsecSource(
      raw.xsecSource || raw.xsec_source || card.xsecSource || card.xsec_source,
      defaultSource,
    ),
    title: card.displayTitle || card.title || "",
    note_type: card.type || "",
    author: {
      user_id: user.userId || user.user_id || "",
      nickname: user.nickname || user.nickName || "",
      avatar_url: user.avatar || "",
      xsec_token: user.xsecToken || user.xsec_token || "",
      xsec_source: safeXsecSource(
        user.xsecSource || user.xsec_source,
        defaultSource,
      ),
    },
    metrics: {
      likes: interact.likedCount ?? interact.liked_count ?? "",
      comments: interact.commentCount ?? interact.comment_count ?? "",
      favorites: interact.collectedCount ?? interact.collected_count ?? "",
      shares: interact.sharedCount ?? interact.shared_count ?? "",
    },
    cover_url: pickImage(card.cover),
    video_duration: card.video?.capa?.duration ?? card.video?.duration ?? null,
    index: Number.isFinite(raw.index) ? raw.index : index,
  };
}

function normalizeFeeds(raw, limit = 40, defaultSource = "pc_feed") {
  const list = Array.isArray(raw) ? raw.flat(Infinity) : [];
  return list
    .map((item, index) => normalizeFeed(item, index, defaultSource))
    .filter(Boolean)
    .slice(0, Math.max(1, limit));
}

function normalizeUser(raw = {}, defaultSource = "pc_note") {
  return {
    user_id: raw.userId || raw.user_id || "",
    nickname: raw.nickname || raw.nickName || "",
    avatar_url: raw.avatar || raw.image || "",
    xsec_token: raw.xsecToken || raw.xsec_token || "",
    xsec_source: safeXsecSource(raw.xsecSource || raw.xsec_source, defaultSource),
  };
}

function normalizeComment(raw) {
  if (!raw) return null;
  return {
    comment_id: raw.id || raw.commentId || "",
    content: raw.content || "",
    likes: raw.likeCount ?? raw.likedCount ?? "",
    created_at: raw.createTime || raw.create_time || null,
    ip_location: raw.ipLocation || "",
    author: normalizeUser(raw.userInfo || raw.user || {}, "pc_comment"),
    reply_count: raw.subCommentCount || 0,
    replies: (raw.subComments || []).map(normalizeComment).filter(Boolean),
  };
}

function commentIdentity(comment, index = 0) {
  const id = comment?.comment_id || comment?.id || "";
  if (id) return `id:${id}`;
  const userId = comment?.author?.user_id || comment?.user_id || "";
  const content = comment?.content || "";
  const time = comment?.created_at || comment?.date || "";
  return `fallback:${userId}:${content}:${time}:${index}`;
}

function preferPresent(primary, fallback) {
  return primary !== undefined && primary !== null && primary !== "" ? primary : fallback;
}

function mergeComment(primary, fallback) {
  if (!primary) return fallback;
  if (!fallback) return primary;
  const merged = { ...fallback, ...primary };
  for (const [key, value] of Object.entries(fallback)) {
    merged[key] = preferPresent(primary[key], value);
  }
  merged.author = {
    ...(fallback.author || {}),
    ...(primary.author || {}),
  };
  for (const [key, value] of Object.entries(fallback.author || {})) {
    merged.author[key] = preferPresent(primary.author?.[key], value);
  }
  merged.replies = mergeCommentCollections(primary.replies || [], fallback.replies || []);
  return merged;
}

function mergeCommentCollections(initialComments = [], domComments = []) {
  const initial = Array.isArray(initialComments) ? initialComments : [];
  const dom = Array.isArray(domComments) ? domComments : [];
  const initialByKey = new Map(
    initial.map((comment, index) => [commentIdentity(comment, index), comment]),
  );
  const consumed = new Set();
  const merged = dom.map((comment, index) => {
    const key = commentIdentity(comment, index);
    const richer = initialByKey.get(key);
    if (richer) consumed.add(key);
    return mergeComment(richer, comment);
  });
  initial.forEach((comment, index) => {
    const key = commentIdentity(comment, index);
    if (!consumed.has(key)) merged.push(comment);
  });
  return merged;
}

function normalizeNote(raw, requestedId, {
  xsecToken = "",
  xsecSource = "pc_feed",
} = {}) {
  const note = raw?.note || raw || {};
  const interact = note.interactInfo || {};
  const tags = (note.tagList || [])
    .map((item) => {
      const value = typeof item === "object" && item !== null
        ? (item.name ?? item.title ?? "")
        : item;
      return typeof value === "string" || typeof value === "number"
        ? String(value).trim()
        : "";
    })
    .filter(Boolean)
    .map((item) => (item.startsWith("#") ? item : `#${item}`));
  return {
    feed_id: note.noteId || note.id || requestedId || "",
    xsec_token: note.xsecToken || xsecToken,
    xsec_source: safeXsecSource(note.xsecSource, xsecSource),
    title: note.title || "",
    description: note.desc || note.description || "",
    body: note.desc || note.description || "",
    tags,
    note_type: note.type || "",
    created_at: note.time || null,
    updated_at: note.lastUpdateTime || null,
    ip_location: note.ipLocation || "",
    author: normalizeUser(note.user || {}, "pc_note"),
    metrics: {
      liked: Boolean(interact.liked),
      likes: interact.likedCount ?? "",
      favorited: Boolean(interact.collected),
      favorites: interact.collectedCount ?? "",
      comments: interact.commentCount ?? "",
      shares: interact.sharedCount ?? "",
    },
    images: (note.imageList || []).map((item) => ({
      width: item.width || 0,
      height: item.height || 0,
      url: pickImage(item),
    })).filter((item) => item.url),
  };
}

function normalizeDetail(raw, requestedId, maxComments = 0, xsec = {}) {
  const commentsState = raw?.comments || {};
  let comments = (commentsState.list || (Array.isArray(commentsState) ? commentsState : []))
    .map(normalizeComment)
    .filter(Boolean);
  if (maxComments > 0) comments = comments.slice(0, maxComments);
  return {
    note: normalizeNote(raw, requestedId, xsec),
    comments,
    comments_meta: {
      count: comments.length,
      has_more: Boolean(commentsState.hasMore),
      cursor: commentsState.cursor || "",
    },
    source: "initial_state",
  };
}

function mergeDomNoteContent(note, domContent) {
  if (!note || !domContent) return false;
  let changed = false;
  if (typeof domContent.body === "string" && domContent.body.trim()) {
    note.body = domContent.body;
    changed = true;
  }
  if (Array.isArray(domContent.tags) && domContent.tags.length) {
    note.tags = domContent.tags;
    changed = true;
  }
  return changed;
}

function noteUrl(feedId, token, source = "pc_feed") {
  const query = new URLSearchParams({
    xsec_token: String(token || ""),
    xsec_source: safeXsecSource(source, "pc_feed"),
  });
  return `https://www.xiaohongshu.com/explore/${encodeURIComponent(feedId)}?${query}`;
}

async function interactionStatus(tabId, feedId, requiredField = "") {
  let dom = {};
  try {
    dom = await pageCall(tabId, "interaction_state");
  } catch {
    // The structured page state below remains authoritative. DOM is only a
    // fallback because icon names can describe the control rather than its
    // current state (for example an inactive control may still render a
    // symbol whose id contains "liked").
  }
  const raw = await optionalStateSnapshot(tabId, "detail", feedId);
  const interact = raw?.note?.interactInfo || {};
  const resolveField = (snapshotValue, domKnown, domValue, domEvidence = "unknown") => {
    const snapshotKnown = typeof snapshotValue === "boolean";
    const fallbackKnown = domKnown === true && typeof domValue === "boolean";
    if (snapshotKnown) {
      return {
        value: snapshotValue,
        source: "initial_state",
        conflict: fallbackKnown && domValue !== snapshotValue,
        initial_state: snapshotValue,
        dom: fallbackKnown ? domValue : null,
        dom_evidence: fallbackKnown ? domEvidence : "unknown",
      };
    }
    if (fallbackKnown) {
      return {
        value: domValue,
        source: "dom",
        conflict: false,
        initial_state: null,
        dom: domValue,
        dom_evidence: domEvidence,
      };
    }
    return {
      value: undefined,
      source: "unknown",
      conflict: false,
      initial_state: null,
      dom: null,
      dom_evidence: "unknown",
    };
  };
  const likeState = resolveField(
    interact.liked,
    dom.like_known,
    dom.liked,
    dom.like_evidence,
  );
  const favoriteState = resolveField(
    interact.collected,
    dom.favorite_known,
    dom.favorited,
    dom.favorite_evidence,
  );
  const requiredState = requiredField === "liked" ? likeState
    : requiredField === "favorited" ? favoriteState
      : null;
  const stateKnown = requiredField
    ? typeof requiredState?.value === "boolean"
    : typeof likeState.value === "boolean" && typeof favoriteState.value === "boolean";
  if (!stateKnown) {
    throw new RpcError("interaction_state_unknown", "无法可靠判断当前点赞或收藏状态");
  }
  const sources = new Set([likeState.source, favoriteState.source]);
  const source = sources.size === 1 ? likeState.source : "mixed";
  return {
    liked: likeState.value,
    favorited: favoriteState.value,
    source,
    evidence: {
      liked: likeState,
      favorited: favoriteState,
    },
  };
}

async function waitInteractionStatus(tabId, feedId, field, targetValue, timeoutMs = 5000) {
  const deadline = Date.now() + timeoutMs;
  let lastState = null;
  while (Date.now() < deadline) {
    try {
      lastState = await interactionStatus(tabId, feedId, field);
      if (lastState[field] === targetValue) return lastState;
    } catch {
      // The page state can be temporarily unavailable while the animation settles.
    }
    await sleep(250);
  }
  throw new RpcError(
    "state_not_changed",
    `${field === "liked" ? "点赞" : "收藏"}状态未按预期变化`,
    {
      expected: targetValue,
      observed: lastState?.[field] ?? null,
      evidence: lastState?.evidence?.[field] || null,
    },
  );
}

async function verifyPersistedInteractionStatus(tabId, feedId, field, targetValue) {
  // Xiaohongshu can update __INITIAL_STATE__ optimistically before the API result
  // is durable. A cache-bypassing reload discards that in-memory state and gives
  // us a new server-backed snapshot before we claim that a write succeeded.
  await sleep(INTERACTION_SETTLE_MS);
  await chrome.tabs.reload(tabId, { bypassCache: true });
  await waitForTab(tabId);
  await waitForPageAgent(tabId);
  await requireNoteRoute(tabId, feedId);
  await requireLogin(tabId);
  await requireNoteAccessible(tabId);
  const state = await interactionStatus(tabId, feedId, field);
  const evidence = state.evidence?.[field] || null;
  const initialStatePersisted = evidence?.source === "initial_state" && evidence.conflict !== true;
  const exactDomPersisted = evidence?.source === "dom"
    && evidence.dom_evidence === "icon_exact"
    && evidence.conflict !== true;
  if (state[field] !== targetValue || (!initialStatePersisted && !exactDomPersisted)) {
    throw new RpcError(
      "state_not_persisted",
      `${field === "liked" ? "点赞" : "收藏"}状态在重新加载后未得到服务器页面确认`,
      {
        expected: targetValue,
        observed: state[field] ?? null,
        evidence,
        verification: "reload_exact_state",
      },
    );
  }
  return {
    ...state,
    verification: {
      method: initialStatePersisted ? "reload_initial_state" : "reload_dom_exact",
      persisted: true,
    },
  };
}

async function observeAndVerifyPersistedInteraction(tabId, feedId, field, targetValue) {
  let transientError = null;
  try {
    await waitInteractionStatus(tabId, feedId, field, targetValue);
  } catch (error) {
    // A stale reactive store or delayed animation must not prevent the stronger
    // reload-based verification. We waited out the observation window, so the
    // action request has time to finish before the reload starts.
    transientError = error;
  }
  try {
    const state = await verifyPersistedInteractionStatus(tabId, feedId, field, targetValue);
    return {
      ...state,
      verification: {
        ...state.verification,
        transient_observed: transientError === null,
        ...(transientError ? { transient_error_code: transientError.code || "unknown" } : {}),
      },
    };
  } catch (error) {
    if (transientError && error instanceof RpcError) {
      error.details = {
        ...error.details,
        transient_observed: false,
        transient_error_code: transientError.code || "unknown",
      };
    }
    throw error;
  }
}

function freshInteractionVerification(state, field) {
  const evidence = state.evidence?.[field] || null;
  if (evidence?.source === "initial_state" && evidence.conflict !== true) {
    return { method: "fresh_initial_state", persisted: true };
  }
  if (
    evidence?.source === "dom"
    && evidence.dom_evidence === "icon_exact"
    && evidence.conflict !== true
  ) {
    return { method: "fresh_dom_exact", persisted: true };
  }
  throw new RpcError(
    "interaction_state_unknown",
    "无法用无冲突的精确页面证据确认当前互动状态",
    { evidence },
  );
}

function userUrl(userId, token, source = "pc_feed") {
  const query = new URLSearchParams({
    xsec_token: String(token || ""),
    xsec_source: safeXsecSource(source, "pc_feed"),
  });
  return `https://www.xiaohongshu.com/user/profile/${encodeURIComponent(userId)}?${query}`;
}

async function withDebugger(tabId, callback) {
  const target = { tabId };
  try {
    await chrome.debugger.attach(target, "1.3");
  } catch (error) {
    throw new RpcError(
      "debugger_unavailable",
      "无法连接浏览器调试接口；请关闭该标签页的开发者工具后重试",
      { reason: error?.message || String(error) },
    );
  }
  try {
    return await callback(target);
  } finally {
    await chrome.debugger.detach(target).catch(() => {});
  }
}

async function uploadFiles(tabId, selector, files) {
  return withDebugger(tabId, async (target) => {
    const { root } = await chrome.debugger.sendCommand(target, "DOM.getDocument", { depth: -1, pierce: true });
    const { nodeId } = await chrome.debugger.sendCommand(target, "DOM.querySelector", {
      nodeId: root.nodeId,
      selector,
    });
    if (!nodeId) throw new RpcError("file_input_missing", "找不到文件上传控件");
    await chrome.debugger.sendCommand(target, "DOM.setFileInputFiles", { nodeId, files });
    return { uploaded_files: files.length };
  });
}

function validateClickTarget(targetInfo) {
  if (targetInfo.skip) return { clicked: false, skipped: true };
  if (targetInfo.disabled) throw new RpcError("button_disabled", "目标控件当前不可用");
  const ownerMatch = /^\[data-hongshuskill-click="([a-z-]+)-([0-9a-f]{24})"\]$/.exec(
    targetInfo.selector || "",
  );
  if (!ownerMatch || !CLICK_TARGET_KEYS.has(ownerMatch[1])) {
    throw new RpcError("click_target_invalid", "页面返回了无效的点击目标");
  }
  if (targetInfo.anchor_selector) {
    const anchorMatch = /^\[data-hongshuskill-anchor="([a-z-]+)-([0-9a-f]{24})"\]$/.exec(
      targetInfo.anchor_selector,
    );
    if (
      !anchorMatch
      || anchorMatch[1] !== ownerMatch[1]
      || anchorMatch[2] !== ownerMatch[2]
    ) {
      throw new RpcError("click_target_invalid", "页面返回了无效的点击落点");
    }
  }
  return null;
}

async function validateDebuggerNode(target, nodeId, selector) {
  const { object } = await chrome.debugger.sendCommand(target, "DOM.resolveNode", { nodeId });
  if (!object?.objectId) throw new RpcError("click_target_missing", "无法复核页面点击目标");
  const inspection = await chrome.debugger.sendCommand(target, "Runtime.callFunctionOn", {
    objectId: object.objectId,
    functionDeclaration: `function (expectedSelector) {
      const rect = this.getBoundingClientRect();
      const style = getComputedStyle(this);
      return {
        connected: this.isConnected,
        selector_matches: this.matches(expectedSelector),
        visible: rect.width > 0 && rect.height > 0
          && style.display !== "none" && style.visibility !== "hidden"
          && Number.parseFloat(style.opacity || "1") > 0.01,
        disabled: Boolean(this.disabled || this.getAttribute("aria-disabled") === "true"),
        trapped: Boolean(this.closest("[data-hp-kind],[button-hp-installed]")),
      };
    }`,
    arguments: [{ value: selector }],
    returnByValue: true,
  });
  const state = inspection?.result?.value;
  if (
    !state?.connected
    || !state.selector_matches
    || !state.visible
    || state.disabled
    || state.trapped
  ) {
    throw new RpcError("click_target_invalid", "页面点击目标在执行前已失效或不可用");
  }
}

async function debuggerClick(target, targetInfo, { onDispatch = null } = {}) {
  const skipped = validateClickTarget(targetInfo);
  if (skipped) return skipped;
  const { root } = await chrome.debugger.sendCommand(target, "DOM.getDocument", { depth: -1, pierce: true });
  const { nodeId: ownerNodeId } = await chrome.debugger.sendCommand(target, "DOM.querySelector", {
    nodeId: root.nodeId,
    selector: targetInfo.selector,
  });
  if (!ownerNodeId) throw new RpcError("click_target_missing", "页面点击目标已失效");
  await validateDebuggerNode(target, ownerNodeId, targetInfo.selector);
  let geometryNodeId = ownerNodeId;
  if (targetInfo.anchor_selector) {
    const { nodeId: anchorNodeId } = await chrome.debugger.sendCommand(target, "DOM.querySelector", {
      nodeId: root.nodeId,
      selector: targetInfo.anchor_selector,
    });
    if (!anchorNodeId) throw new RpcError("click_target_missing", "页面点击落点已失效");
    await validateDebuggerNode(target, anchorNodeId, targetInfo.anchor_selector);
    geometryNodeId = anchorNodeId;
  }
  await chrome.debugger.sendCommand(target, "DOM.scrollIntoViewIfNeeded", { nodeId: ownerNodeId });
  const { model } = await chrome.debugger.sendCommand(target, "DOM.getBoxModel", { nodeId: geometryNodeId });
  const quad = model.border || model.content;
  const x = (quad[0] + quad[2] + quad[4] + quad[6]) / 4;
  const y = (quad[1] + quad[3] + quad[5] + quad[7]) / 4;
  const base = { x, y, button: "left", clickCount: 1 };
  await chrome.debugger.sendCommand(target, "Input.dispatchMouseEvent", { ...base, type: "mouseMoved" });
  await chrome.debugger.sendCommand(target, "Input.dispatchMouseEvent", { ...base, type: "mousePressed", buttons: 1 });
  await onDispatch?.();
  await chrome.debugger.sendCommand(target, "Input.dispatchMouseEvent", { ...base, type: "mouseReleased", buttons: 0 });
  return { clicked: true };
}

async function trustedClick(tabId, targetInfo, options = {}) {
  return withDebugger(tabId, (target) => debuggerClick(target, targetInfo, options));
}

async function chooseFilesWithClick(tabId, targetInfo, files) {
  return withDebugger(tabId, async (target) => {
    let resolveChooser;
    let rejectChooser;
    const chooserPromise = new Promise((resolve, reject) => {
      resolveChooser = resolve;
      rejectChooser = reject;
    });
    const timeout = setTimeout(
      () => rejectChooser(new RpcError("file_chooser_timeout", "长文图片选择器未出现")),
      10000,
    );
    const listener = (source, method, params) => {
      if (source.tabId === tabId && method === "Page.fileChooserOpened") resolveChooser(params);
    };
    chrome.debugger.onEvent.addListener(listener);
    try {
      await chrome.debugger.sendCommand(target, "Page.enable");
      await chrome.debugger.sendCommand(target, "Page.setInterceptFileChooserDialog", { enabled: true });
      await debuggerClick(target, targetInfo);
      const chooser = await chooserPromise;
      if (!chooser.backendNodeId) throw new RpcError("file_input_missing", "无法定位长文图片上传控件");
      await chrome.debugger.sendCommand(target, "DOM.setFileInputFiles", {
        backendNodeId: chooser.backendNodeId,
        files,
      });
      return { uploaded_files: files.length };
    } finally {
      clearTimeout(timeout);
      chrome.debugger.onEvent.removeListener(listener);
      await chrome.debugger.sendCommand(target, "Page.setInterceptFileChooserDialog", { enabled: false }).catch(() => {});
    }
  });
}

async function trustedFillInput(tabId, targetInfo, value) {
  const match = /^\[data-hongshuskill-click="([a-z-]+)-[0-9a-f]{24}"\]$/.exec(
    targetInfo.selector || "",
  );
  if (!match || !CLICK_TARGET_KEYS.has(match[1])) {
    throw new RpcError("input_target_invalid", "页面返回了无效的输入目标");
  }
  return withDebugger(tabId, async (target) => {
    const { root } = await chrome.debugger.sendCommand(target, "DOM.getDocument", { depth: -1, pierce: true });
    const { nodeId } = await chrome.debugger.sendCommand(target, "DOM.querySelector", {
      nodeId: root.nodeId,
      selector: targetInfo.selector,
    });
    if (!nodeId) throw new RpcError("input_target_missing", "页面输入目标已失效");
    await chrome.debugger.sendCommand(target, "DOM.focus", { nodeId });
    const { object } = await chrome.debugger.sendCommand(target, "DOM.resolveNode", { nodeId });
    if (!object?.objectId) throw new RpcError("input_target_missing", "无法访问页面输入目标");
    await chrome.debugger.sendCommand(target, "Runtime.callFunctionOn", {
      objectId: object.objectId,
      functionDeclaration: `function (nextValue) {
        const prototype = this instanceof HTMLTextAreaElement
          ? HTMLTextAreaElement.prototype
          : HTMLInputElement.prototype;
        const setter = Object.getOwnPropertyDescriptor(prototype, "value").set;
        setter.call(this, nextValue);
        this.dispatchEvent(new Event("input", { bubbles: true }));
      }`,
      arguments: [{ value }],
      userGesture: true,
    });
    await chrome.debugger.sendCommand(target, "Input.dispatchKeyEvent", {
      type: "rawKeyDown", key: "Enter", code: "Enter", windowsVirtualKeyCode: 13,
    });
    await chrome.debugger.sendCommand(target, "Input.dispatchKeyEvent", {
      type: "keyUp", key: "Enter", code: "Enter", windowsVirtualKeyCode: 13,
    });
    return { filled: true };
  });
}

function expectedPublishSettings(params = {}) {
  return {
    visibility: params.visibility || "公开可见",
    original: Boolean(params.original),
    schedule_at: params.schedule_at || null,
  };
}

function publicPublishSettings(settings = {}) {
  return {
    visibility: settings.visibility || "",
    original: Boolean(settings.original),
    schedule_at: settings.schedule_at || null,
  };
}

function normalizedCreatorSnapshotRoute(value) {
  try {
    const url = new URL(value || "");
    if (url.protocol !== "https:" || url.hostname !== "creator.xiaohongshu.com") return "";
    return `${url.origin}${url.pathname}`;
  } catch {
    return "";
  }
}

function requireObservedPreview(settings, mediaType, mediaExpected) {
  const snapshot = settings?.snapshot;
  if (!snapshot || typeof snapshot !== "object" || Array.isArray(snapshot)) {
    throw new RpcError("preview_validation_failed", "页面未返回可验证的发布预览摘要");
  }
  const route = normalizedCreatorSnapshotRoute(snapshot.route);
  const form = snapshot.form;
  const validForm = form
    && /^[0-9a-f]{64}$/.test(form.title_hash || "")
    && /^[0-9a-f]{64}$/.test(form.content_hash || "")
    && /^[0-9a-f]{64}$/.test(form.tags_hash || "")
    && Number.isSafeInteger(form.title_length)
    && form.title_length >= 0
    && Number.isSafeInteger(form.content_length)
    && form.content_length >= 0
    && Number.isSafeInteger(form.tag_count)
    && form.tag_count >= 0;
  const validSettings = snapshot.settings
    && typeof snapshot.settings.visibility === "string"
    && typeof snapshot.settings.original === "boolean"
    && (snapshot.settings.schedule_at === null || typeof snapshot.settings.schedule_at === "string");
  if (
    !route
    || !validForm
    || !validSettings
    || snapshot.media?.type !== mediaType
    || snapshot.media?.ready !== true
    || (Number.isInteger(mediaExpected) && snapshot.media?.count !== mediaExpected)
    || !Number.isSafeInteger(snapshot.media?.count)
    || snapshot.media.count < 0
    || !/^[0-9a-f]{64}$/.test(snapshot.media?.identity || "")
  ) {
    throw new RpcError(
      "preview_validation_failed",
      "发布表单、媒体或设置摘要无法可靠校验",
      {
        expected_type: mediaType,
        expected_count: mediaExpected,
        observed_media: snapshot.media
          ? { type: snapshot.media.type, count: snapshot.media.count, ready: snapshot.media.ready }
          : null,
      },
    );
  }
  // Project the page result onto a strict digest-only schema before it reaches
  // extension session storage. Even a future page-agent regression cannot
  // accidentally persist post text, tags, media descriptors, or URL queries.
  return {
    route,
    form: {
      title_hash: form.title_hash,
      content_hash: form.content_hash,
      tags_hash: form.tags_hash,
      title_length: form.title_length,
      content_length: form.content_length,
      tag_count: form.tag_count,
    },
    media: {
      type: snapshot.media.type,
      count: snapshot.media.count,
      ready: true,
      identity: snapshot.media.identity,
    },
    settings: {
      visibility: snapshot.settings.visibility,
      original: snapshot.settings.original,
      schedule_at: snapshot.settings.schedule_at,
    },
  };
}

async function applyPublishSettings(tabId, params, { mediaType, mediaExpected } = {}) {
  const scheduleEnabled = Boolean(params.schedule_at);
  const scheduleSwitcher = await pageCall(tabId, "publish_setting_rect", {
    setting: "schedule_switch",
    enabled: scheduleEnabled,
  });
  if (!scheduleSwitcher.skip) await trustedClick(tabId, scheduleSwitcher);
  if (scheduleEnabled) {
    const input = await pageCall(tabId, "publish_setting_rect", { setting: "schedule_input" });
    await trustedFillInput(tabId, input, params.schedule_at.replace("T", " ").slice(0, 16));
  }

  const visibility = params.visibility || "公开可见";
  if (visibility) {
    const dropdown = await pageCall(tabId, "publish_setting_rect", {
      setting: "visibility_dropdown",
      value: visibility,
    });
    if (!dropdown.skip) {
      await trustedClick(tabId, dropdown);
      const option = await pageCall(tabId, "publish_setting_rect", {
        setting: "visibility_option",
        value: visibility,
      });
      await trustedClick(tabId, option);
    }
  }

  const originalEnabled = Boolean(params.original);
  const originalSwitcher = await pageCall(tabId, "publish_setting_rect", {
    setting: "original_switch",
    enabled: originalEnabled,
  });
  if (!originalSwitcher.skip) {
    await trustedClick(tabId, originalSwitcher);
    if (originalEnabled) {
      const checkbox = await pageCall(tabId, "publish_setting_rect", { setting: "original_checkbox" });
      await trustedClick(tabId, checkbox);
      const confirm = await pageCall(tabId, "publish_setting_rect", { setting: "original_confirm" });
      await trustedClick(tabId, confirm);
    }
  }

  const expected = expectedPublishSettings(params);
  return pageCall(tabId, "wait_publish_settings", {
    ...expected,
    include_snapshot: Boolean(mediaType),
    media_type: mediaType || "",
    media_expected: Number.isInteger(mediaExpected) ? mediaExpected : null,
  });
}

async function verifyPreparedPreview(surface, tab, prepared) {
  if (!prepared.form_snapshot || !prepared.settings_expected || !prepared.media_type) {
    throw new RpcError(
      "preview_validation_failed",
      "发布预览缺少可复核的表单摘要，请重新填写",
    );
  }
  let observed;
  try {
    const settings = await pageCall(tab.id, "wait_publish_settings", {
      ...prepared.settings_expected,
      include_snapshot: true,
      media_type: prepared.media_type,
      media_expected: prepared.media_expected,
    });
    observed = requireObservedPreview(
      settings,
      prepared.media_type,
      prepared.media_expected,
    );
  } catch (error) {
    await setPreparedSurface(
      surface,
      tab.id,
      "preview_invalidated",
      { creator_url: tab.url },
      { preserveCreatedAt: true },
    );
    throw new RpcError(
      "preview_changed",
      "发布表单、媒体或设置已变化，请重新生成预览并确认",
      { reason: error?.message || String(error) },
    );
  }
  if (canonicalJson(observed) !== canonicalJson(prepared.form_snapshot)) {
    await setPreparedSurface(
      surface,
      tab.id,
      "preview_invalidated",
      { creator_url: tab.url },
      { preserveCreatedAt: true },
    );
    throw new RpcError(
      "preview_changed",
      "发布表单、媒体或设置在确认后被修改，已拒绝提交",
    );
  }
  return observed;
}

function requireLongDraftSnapshot(snapshot, { imageCount = null, template = null } = {}) {
  const valid = snapshot
    && /^[0-9a-f]{64}$/.test(snapshot.title_hash || "")
    && /^[0-9a-f]{64}$/.test(snapshot.content_hash || "")
    && Number.isSafeInteger(snapshot.title_length)
    && Number.isSafeInteger(snapshot.content_length)
    && Number.isSafeInteger(snapshot.media?.count)
    && /^[0-9a-f]{64}$/.test(snapshot.media?.identity || "")
    && typeof snapshot.template === "string";
  if (!valid || (Number.isInteger(imageCount) && snapshot.media.count !== imageCount)) {
    throw new RpcError("preview_validation_failed", "页面未返回可验证的长文草稿摘要");
  }
  if (template !== null && snapshot.template !== template) {
    throw new RpcError("preview_validation_failed", "长文排版模板未能确认");
  }
  return snapshot;
}

async function requireUnchangedLongDraft(tab, prepared, observed) {
  requireLongDraftSnapshot(observed);
  if (canonicalJson(observed) === canonicalJson(prepared.long_source_snapshot)) return;
  await setPreparedSurface(
    "creator",
    tab.id,
    "preview_invalidated",
    { creator_url: tab.url },
    { preserveCreatedAt: true },
  );
  throw new RpcError(
    "preview_changed",
    "长文标题、正文、插图或排版模板在确认后被修改，已拒绝继续",
  );
}

async function fillImage(params) {
  await clearPreparedSurface("creator");
  const tab = await navigate("creator", CREATOR_URL, { reload: true });
  await requireRiskClear("上传图片并填写发布预览");
  await requirePageRiskClear(tab.id, "上传图片并填写发布预览");
  const prepared = await pageCall(tab.id, "prepare_publish_tab", { tab: "上传图文" });
  if (!prepared.ready) throw new RpcError("upload_not_ready", "图文上传区未就绪");
  await uploadFiles(tab.id, prepared.input_selector, params.images);
  await pageCall(tab.id, "wait_upload", { expected: params.images.length, video: false });
  await requireRiskClear("填写图文发布预览");
  const form = await pageCall(tab.id, "fill_publish_form", params);
  await requireRiskClear("应用图文发布设置");
  const settings = await applyPublishSettings(tab.id, params, {
    mediaType: "images",
    mediaExpected: params.images.length,
  });
  const snapshot = requireObservedPreview(settings, "images", params.images.length);
  await requireRiskClear("完成图文发布预览");
  await setStoredTab("creator", tab.id);
  const currentTab = await chrome.tabs.get(tab.id);
  const previewId = randomNonce();
  const accountFingerprint = await currentAccountFingerprint();
  await setPreparedSurface("creator", tab.id, "image_preview", {
    preview_id: previewId,
    creator_url: currentTab.url,
    form_snapshot: snapshot,
    form_summary: snapshot.form || {},
    media_type: "images",
    media_expected: params.images.length,
    settings_expected: expectedPublishSettings(params),
    account_fingerprint: accountFingerprint,
  });
  return {
    ...form,
    settings: publicPublishSettings(settings),
    media_type: "images",
    image_count: params.images.length,
    preview_stage: "image_preview",
    preview_only: true,
    preview_id: previewId,
  };
}

async function fillVideo(params) {
  await clearPreparedSurface("creator");
  const tab = await navigate("creator", CREATOR_URL, { reload: true });
  await requireRiskClear("上传视频并填写发布预览");
  await requirePageRiskClear(tab.id, "上传视频并填写发布预览");
  const prepared = await pageCall(tab.id, "prepare_publish_tab", { tab: "上传视频" });
  if (!prepared.ready) throw new RpcError("upload_not_ready", "视频上传区未就绪");
  await uploadFiles(tab.id, prepared.input_selector, [params.video]);
  await pageCall(tab.id, "wait_upload", { expected: 1, video: true });
  await requireRiskClear("填写视频发布预览");
  const form = await pageCall(tab.id, "fill_publish_form", params);
  await requireRiskClear("应用视频发布设置");
  const settings = await applyPublishSettings(tab.id, params, {
    mediaType: "video",
    mediaExpected: 1,
  });
  const snapshot = requireObservedPreview(settings, "video", 1);
  await requireRiskClear("完成视频发布预览");
  await setStoredTab("creator", tab.id);
  const currentTab = await chrome.tabs.get(tab.id);
  const previewId = randomNonce();
  const accountFingerprint = await currentAccountFingerprint();
  await setPreparedSurface("creator", tab.id, "video_preview", {
    preview_id: previewId,
    creator_url: currentTab.url,
    form_snapshot: snapshot,
    form_summary: snapshot.form || {},
    media_type: "video",
    media_expected: 1,
    settings_expected: expectedPublishSettings(params),
    account_fingerprint: accountFingerprint,
  });
  return {
    ...form,
    settings: publicPublishSettings(settings),
    media_type: "video",
    preview_stage: "video_preview",
    preview_only: true,
    preview_id: previewId,
  };
}

async function clickCurrent(surface, target, params = {}) {
  const allowedStages = target === "publish"
    ? ["image_preview", "video_preview", "long_article_publish"]
    : [
      "image_preview",
      "video_preview",
      "long_article_templates",
      "long_article_template_selected",
      "long_article_publish",
    ];
  const { tab, prepared } = await requirePreparedTab(
    surface,
    allowedStages,
    target === "publish" ? "提交发布" : "保存云端草稿",
  );
  requireMatchingPreviewId(params, prepared);
  const beforeUrl = tab.url;
  if (
    prepared.long_source_snapshot
    && ["long_article_templates", "long_article_template_selected"].includes(prepared.stage)
  ) {
    const observedLongDraft = await pageCall(tab.id, "long_draft_snapshot");
    await requireUnchangedLongDraft(tab, prepared, observedLongDraft);
  }
  if (prepared.form_snapshot) await verifyPreparedPreview(surface, tab, prepared);
  await requireRiskClear(target === "publish" ? "提交发布" : "保存云端草稿");
  await requirePageRiskClear(tab.id, target === "publish" ? "提交发布" : "保存云端草稿");
  const point = await pageCall(tab.id, "target_rect", { target });
  const preflight = validateClickTarget(point);
  if (preflight?.skipped) {
    throw new RpcError("click_target_missing", "页面没有可执行的提交按钮");
  }
  await requireRiskClear(target === "publish" ? "提交发布" : "保存云端草稿");
  const action = target === "publish" ? "提交发布" : "保存云端草稿";
  let dispatchStarted = false;
  try {
    await trustedClick(tab.id, point, {
      onDispatch: async () => {
        dispatchStarted = true;
        await setPreparedSurface(
          surface,
          tab.id,
          target === "publish" ? "publish_submission_uncertain" : "draft_submission_uncertain",
          { creator_url: tab.url },
          { preserveCreatedAt: true },
        );
      },
    });
    const result = await pageCall(tab.id, "observe_submission", {
      before_url: beforeUrl,
      timeout_ms: target === "publish" ? 25000 : 12000,
      target,
    });
    if (result.risk_control) {
      const signal = await recordPageRiskSignal(tab.id, result.url || beforeUrl);
      throw new RpcError(
        "risk_control_active",
        result.message || "平台页面返回了风险控制提示",
        {
          status: signal.status,
          observed_at: signal.timestamp,
          source: "page",
          action: target,
        },
      );
    }
    if (!result.success) {
      if (result.status === "failed") {
        throw new RpcError(
          "submission_failed",
          result.message || `${action}失败`,
          result,
        );
      }
      throw operationStateUncertain(
        action,
        new RpcError("submission_unconfirmed", result.message || "页面未返回可确认的结果"),
      );
    }
    let previewStateCleared = true;
    try {
      await clearPreparedSurface(surface, tab.id);
    } catch {
      // The marker was changed to an uncertain state before clicking, so a storage
      // cleanup failure still cannot make the same preview automatically reusable.
      previewStateCleared = false;
    }
    return {
      ...result,
      action: target,
      submitted_stage: prepared.stage,
      preview_state_cleared: previewStateCleared,
    };
  } catch (error) {
    if (!dispatchStarted) throw error;
    throwPostDispatchError(action, error, ["risk_control_active", "submission_failed"]);
  }
}

async function submitPreparedComment(tabId, params, { reply = false } = {}) {
  if (reply) {
    const replyButton = await pageCall(tabId, "reply_target", params);
    await trustedClick(tabId, replyButton);
  } else {
    const opener = await pageCall(tabId, "comment_open_target");
    await trustedClick(tabId, opener);
  }
  const submit = await pageCall(tabId, "prepare_comment", { content: params.content });
  const action = reply ? "回复评论" : "发表评论";
  await requireRiskClear(action);
  await requirePageRiskClear(tabId, action);
  let dispatchStarted = false;
  try {
    await trustedClick(tabId, submit, { onDispatch: () => { dispatchStarted = true; } });
    const result = await pageCall(tabId, "wait_comment_sent", {
      content: params.content,
      before_matches: submit.before_matches || 0,
    });
    if (result.risk_control) {
      const tab = await chrome.tabs.get(tabId).catch(() => null);
      const signal = await recordPageRiskSignal(tabId, result.url || tab?.url || "https://www.xiaohongshu.com/");
      throw new RpcError(
        "risk_control_active",
        result.message || "平台页面返回了互动风险控制提示",
        { status: signal.status, observed_at: signal.timestamp, source: "page" },
      );
    }
    if (!result.success) {
      if (result.status === "failed") {
        throw new RpcError(
          "comment_submission_failed",
          result.message || `${action}失败`,
          result,
        );
      }
      throw operationStateUncertain(
        action,
        new RpcError(
          "comment_submission_unconfirmed",
          result.message || "评论发送后未观察到可确认的成功状态",
        ),
      );
    }
    return result;
  } catch (error) {
    if (!dispatchStarted) throw error;
    throwPostDispatchError(action, error, ["risk_control_active", "comment_submission_failed"]);
  }
}

const OPERATIONS = {
  account_identity: async () => {
    const instanceId = await loadInstanceId();
    const tab = await navigate("read", EXPLORE_URL);
    const status = await pageCall(tab.id, "check_login");
    if (!status.logged_in || !status.user_id) {
      throw new RpcError(
        "not_logged_in",
        "当前 Chrome Profile 未登录，或无法读取可绑定的用户 ID",
      );
    }
    return {
      instance_id: instanceId,
      user_id: status.user_id,
      nickname: status.nickname || "",
      session_fingerprint: await currentAccountFingerprint(),
      logged_in: true,
    };
  },

  check_login: async () => {
    const tab = await navigate("read", EXPLORE_URL);
    const status = await pageCall(tab.id, "check_login");
    if (status.logged_in === false && !status.inconclusive) {
      await clearPreparedSurface("creator");
    }
    return status;
  },

  get_qrcode: async () => {
    const tab = await navigate("read", EXPLORE_URL);
    const result = await pageCall(tab.id, "get_qrcode");
    if (result.logged_in === false) await clearPreparedSurface("creator");
    return result;
  },

  wait_login: async ({ timeout_seconds: timeoutSeconds = 120 }) => {
    const tab = await navigate("read", EXPLORE_URL);
    const deadline = Date.now() + Math.max(1, timeoutSeconds) * 1000;
    while (Date.now() < deadline) {
      const status = await pageCall(tab.id, "check_login");
      if (status.logged_in) return status;
      if (status.logged_in === false && !status.inconclusive) {
        await clearPreparedSurface("creator");
      }
      await sleep(300);
    }
    return { logged_in: false, timed_out: true };
  },

  send_code: async (params) => {
    await requireWriteAllowed(params, "发送登录验证码");
    const tab = await navigate("read", EXPLORE_URL);
    let sendDispatched = false;
    try {
      const agreement = await pageCall(tab.id, "prepare_phone", params);
      if (agreement.logged_in) return agreement;
      await clearPreparedSurface("creator");
      await trustedClick(tab.id, agreement);
      const button = await pageCall(tab.id, "send_code_target");
      if (button.logged_in) return button;
      await requireRiskClear("发送登录验证码");
      await requirePageRiskClear(tab.id, "发送登录验证码");
      await trustedClick(tab.id, button, { onDispatch: () => { sendDispatched = true; } });
      return await pageCall(tab.id, "wait_code_sent", params);
    } catch (error) {
      if (error?.code === "risk_control_active") throw error;
      if (/频率|倒计时/.test(error?.message || "")) {
        try {
          const qr = await pageCall(tab.id, "get_qrcode");
          return {
            ...qr,
            status: "qrcode_fallback",
            message: "验证码发送受限，已切换为二维码登录",
          };
        } catch (fallbackError) {
          if (sendDispatched) {
            throw operationStateUncertain("发送登录验证码", fallbackError);
          }
          throw fallbackError;
        }
      }
      if (sendDispatched) {
        throw operationStateUncertain("发送登录验证码", error);
      }
      throw error;
    }
  },

  verify_code: async (params) => {
    await clearPreparedSurface("creator");
    const tab = await navigate("read", EXPLORE_URL);
    const submit = await pageCall(tab.id, "prepare_verify_code", params);
    await requireRiskClear("提交登录验证码");
    await requirePageRiskClear(tab.id, "提交登录验证码");
    let dispatchStarted = false;
    try {
      await trustedClick(tab.id, submit, { onDispatch: () => { dispatchStarted = true; } });
      const result = await pageCall(tab.id, "wait_verify_code");
      if (!result.logged_in) await requirePageRiskClear(tab.id, "提交登录验证码");
      return result;
    } catch (error) {
      if (!dispatchStarted) throw error;
      throwPostDispatchError("提交登录验证码", error, ["risk_control_active"]);
    }
  },

  delete_cookies: async (params) => {
    await requireWriteAllowed(params, "退出登录并清除 cookies");
    await clearPreparedSurface("creator");
    const cookies = await chrome.cookies.getAll({ domain: "xiaohongshu.com" });
    let removed = 0;
    try {
      for (const cookie of cookies) {
        const host = cookie.domain.replace(/^\./, "");
        const protocol = cookie.secure ? "https" : "http";
        const url = `${protocol}://${host}${cookie.path || "/"}`;
        const removal = { url, name: cookie.name, storeId: cookie.storeId };
        if (cookie.partitionKey) removal.partitionKey = cookie.partitionKey;
        const result = await chrome.cookies.remove(removal);
        if (result) removed += 1;
      }
      const tab = await navigate("read", EXPLORE_URL);
      await chrome.tabs.reload(tab.id);
      await waitForTab(tab.id);
      await waitForPageAgent(tab.id);
      const status = await pageCall(tab.id, "check_login");
      if (status.logged_in || status.inconclusive) {
        throw new RpcError(
          "logout_unconfirmed",
          "cookies 已删除，但页面尚未明确确认退出登录",
          { cookies_removed: removed, observed: status },
        );
      }
      return { ...status, logged_in: false, cookies_removed: removed };
    } catch (error) {
      if (removed > 0) {
        throwPostDispatchError("退出登录并清除 cookies", error, ["logout_unconfirmed"]);
      }
      throw error;
    }
  },

  list_feeds: async ({ limit = 40 }) => {
    const tab = await navigate("read", EXPLORE_URL);
    await requireLogin(tab.id);
    await sleep(700);
    const raw = await optionalStateSnapshot(tab.id, "feeds");
    const feeds = normalizeFeeds(raw, limit, "pc_feed");
    if (feeds.length) return { feeds, count: feeds.length, source: "initial_state" };
    return pageCall(tab.id, "dom_feeds", { limit, xsec_source: "pc_feed" });
  },

  search_feeds: async ({ keyword, filters, limit = 40 }) => {
    const query = new URLSearchParams({ keyword, source: "web_explore_feed" });
    const tab = await navigate(
      "read",
      `https://www.xiaohongshu.com/search_result?${query}`,
      { reload: true },
    );
    await requireLogin(tab.id);
    const requestedFilters = Object.values(filters || {}).some((value) => value && value !== "不限");
    const beforeFilters = requestedFilters
      ? await optionalStateSnapshot(tab.id, "search")
      : null;
    const applied = await pageCall(tab.id, "apply_filters", { filters });
    let refresh = { value: null, changed: false };
    if (applied.applied.length) {
      refresh = await waitForStateRefresh(tab.id, "search", "", beforeFilters);
    } else {
      await sleep(700);
      refresh.value = await optionalStateSnapshot(tab.id, "search");
    }
    const raw = refresh.value;
    const feeds = normalizeFeeds(raw, limit, "pc_search");
    if (feeds.length) {
      return {
        keyword,
        filters: applied.applied,
        filter_refresh_observed: refresh.changed,
        feeds,
        count: feeds.length,
        source: "initial_state",
      };
    }
    const fallback = await pageCall(tab.id, "dom_feeds", { limit, xsec_source: "pc_search" });
    return {
      keyword,
      filters: applied.applied,
      filter_refresh_observed: refresh.changed,
      ...fallback,
    };
  },

  get_feed_detail: async (params) => {
    const tab = await navigate(
      "read",
      noteUrl(params.feed_id, params.xsec_token, params.xsec_source || "pc_feed"),
    );
    await requireNoteRoute(tab.id, params.feed_id);
    await requireLogin(tab.id);
    await requireNoteAccessible(tab.id, { keyword: params.keyword });
    const commentLoading = params.load_all_comments
      ? await pageCall(tab.id, "load_comments", params)
      : { loaded: false };
    await sleep(350);
    const raw = await optionalStateSnapshot(tab.id, "detail", params.feed_id);
    if (raw?.note) {
      const maxComments = Number(params.max_comment_items || 0);
      const detail = normalizeDetail(
        raw,
        params.feed_id,
        params.load_all_comments ? 0 : maxComments,
        {
          xsecToken: params.xsec_token || "",
          xsecSource: params.xsec_source || "pc_feed",
        },
      );
      const domContent = await pageCall(tab.id, "dom_note_content").catch(() => null);
      if (mergeDomNoteContent(detail.note, domContent)) {
        detail.source = "initial_state+dom";
      }
      if (params.load_all_comments) {
        const domDetail = await pageCall(tab.id, "dom_detail", {
          ...params,
          load_all_comments: false,
          max_comment_items: 0,
        }).catch(() => null);
        if (domDetail) {
          detail.comments = mergeCommentCollections(detail.comments, domDetail.comments);
          if (maxComments > 0) detail.comments = detail.comments.slice(0, maxComments);
          detail.comments_meta.count = detail.comments.length;
          detail.comments_meta.visible_dom_count = domDetail.comments?.length || 0;
          detail.comment_loading = commentLoading;
          detail.source = "initial_state+dom";
        }
      }
      return detail;
    }
    const domDetail = await pageCall(tab.id, "dom_detail", {
      ...params,
      load_all_comments: false,
    });
    if (params.load_all_comments) domDetail.comment_loading = commentLoading;
    return domDetail;
  },

  user_profile: async ({
    user_id: userId,
    xsec_token: token,
    xsec_source: source = "pc_feed",
    limit = 40,
  }) => {
    const tab = await navigate("read", userUrl(userId, token, source));
    await requireUserRoute(tab.id, userId);
    await requireLogin(tab.id);
    await sleep(500);
    const raw = await optionalStateSnapshot(tab.id, "user");
    if (raw?.profile) {
      const profile = raw.profile;
      const feeds = normalizeFeeds(raw.notes, limit, "pc_user");
      return {
        profile: {
          user_id: userId,
          nickname: profile.basicInfo?.nickname || profile.nickname || "",
          red_id: profile.basicInfo?.redId || profile.redId || "",
          description: profile.basicInfo?.desc || profile.desc || "",
          gender: profile.basicInfo?.gender ?? profile.gender ?? null,
          ip_location: profile.basicInfo?.ipLocation || profile.ipLocation || "",
          interactions: profile.interactions || [],
        },
        feeds,
        count: feeds.length,
        source: "initial_state",
      };
    }
    return pageCall(tab.id, "dom_profile", {
      limit,
      user_id: userId,
      xsec_source: "pc_user",
    });
  },

  inspect_actions: async (params) => {
    const tab = await navigate(
      "read",
      noteUrl(params.feed_id, params.xsec_token, params.xsec_source || "pc_feed"),
      { reload: true },
    );
    await requireNoteRoute(tab.id, params.feed_id);
    await requireLogin(tab.id);
    const access = await requireNoteAccessible(tab.id);
    const readiness = await pageCall(tab.id, "action_readiness", params);
    try {
      const state = await interactionStatus(tab.id, params.feed_id);
      return {
        feed_id: params.feed_id,
        access,
        ...readiness,
        interaction_state_known: true,
        liked: state.liked,
        favorited: state.favorited,
        state_source: state.source,
        state_evidence: state.evidence,
      };
    } catch (error) {
      return {
        feed_id: params.feed_id,
        access,
        ...readiness,
        interaction_state_known: false,
        state_error: error?.message || String(error),
      };
    }
  },

  post_comment: async (params) => {
    await requireWriteAllowed(params, "发表评论");
    const tab = await navigate(
      "read",
      noteUrl(params.feed_id, params.xsec_token, params.xsec_source || "pc_feed"),
    );
    await requireNoteRoute(tab.id, params.feed_id);
    await requireLogin(tab.id);
    await requireNoteAccessible(tab.id);
    const result = await submitPreparedComment(tab.id, params);
    return { ...result, feed_id: params.feed_id };
  },

  reply_comment: async (params) => {
    await requireWriteAllowed(params, "回复评论");
    const tab = await navigate(
      "read",
      noteUrl(params.feed_id, params.xsec_token, params.xsec_source || "pc_feed"),
    );
    await requireNoteRoute(tab.id, params.feed_id);
    await requireLogin(tab.id);
    await requireNoteAccessible(tab.id);
    const result = await submitPreparedComment(tab.id, params, { reply: true });
    return { ...result, feed_id: params.feed_id, comment_id: params.comment_id || "" };
  },

  set_like: async (params) => {
    await requireWriteAllowed(params, params.target ? "点赞" : "取消点赞");
    const tab = await navigate(
      "read",
      noteUrl(params.feed_id, params.xsec_token, params.xsec_source || "pc_feed"),
      { reload: true },
    );
    await requireNoteRoute(tab.id, params.feed_id);
    await requireLogin(tab.id);
    await requireNoteAccessible(tab.id);
    await requirePageRiskClear(tab.id, params.target ? "点赞" : "取消点赞");
    let state = await interactionStatus(tab.id, params.feed_id, "liked");
    if (state.liked === params.target) {
      const verification = freshInteractionVerification(state, "liked");
      return {
        success: true,
        changed: false,
        liked: state.liked,
        feed_id: params.feed_id,
        state_source: state.source,
        state_evidence: state.evidence,
        verification,
      };
    }
    const target = await pageCall(tab.id, "interaction_target", { kind: "like" });
    const action = params.target ? "点赞" : "取消点赞";
    await requireRiskClear(action);
    let dispatchStarted = false;
    try {
      await trustedClick(tab.id, target, { onDispatch: () => { dispatchStarted = true; } });
      state = await observeAndVerifyPersistedInteraction(
        tab.id,
        params.feed_id,
        "liked",
        params.target,
      );
    } catch (error) {
      if (!dispatchStarted) throw error;
      let classified = error;
      try {
        await rethrowVisiblePageRisk(tab.id, action, error);
      } catch (pageError) {
        classified = pageError;
      }
      throwPostDispatchError(
        action,
        classified,
        ["risk_control_active", "state_not_changed", "state_not_persisted"],
      );
    }
    return {
      success: true,
      changed: true,
      liked: state.liked,
      feed_id: params.feed_id,
      state_source: state.source,
      state_evidence: state.evidence,
      verification: state.verification,
    };
  },

  set_favorite: async (params) => {
    await requireWriteAllowed(params, params.target ? "收藏" : "取消收藏");
    const tab = await navigate(
      "read",
      noteUrl(params.feed_id, params.xsec_token, params.xsec_source || "pc_feed"),
      { reload: true },
    );
    await requireNoteRoute(tab.id, params.feed_id);
    await requireLogin(tab.id);
    await requireNoteAccessible(tab.id);
    await requirePageRiskClear(tab.id, params.target ? "收藏" : "取消收藏");
    let state = await interactionStatus(tab.id, params.feed_id, "favorited");
    if (state.favorited === params.target) {
      const verification = freshInteractionVerification(state, "favorited");
      return {
        success: true,
        changed: false,
        favorited: state.favorited,
        feed_id: params.feed_id,
        state_source: state.source,
        state_evidence: state.evidence,
        verification,
      };
    }
    const target = await pageCall(tab.id, "interaction_target", { kind: "favorite" });
    const action = params.target ? "收藏" : "取消收藏";
    await requireRiskClear(action);
    let dispatchStarted = false;
    try {
      await trustedClick(tab.id, target, { onDispatch: () => { dispatchStarted = true; } });
      state = await observeAndVerifyPersistedInteraction(
        tab.id,
        params.feed_id,
        "favorited",
        params.target,
      );
    } catch (error) {
      if (!dispatchStarted) throw error;
      let classified = error;
      try {
        await rethrowVisiblePageRisk(tab.id, action, error);
      } catch (pageError) {
        classified = pageError;
      }
      throwPostDispatchError(
        action,
        classified,
        ["risk_control_active", "state_not_changed", "state_not_persisted"],
      );
    }
    return {
      success: true,
      changed: true,
      favorited: state.favorited,
      feed_id: params.feed_id,
      state_source: state.source,
      state_evidence: state.evidence,
      verification: state.verification,
    };
  },

  fill_image: async (params) => {
    await requireWriteAllowed(params, "上传图片并填写发布预览");
    return fillImage(params);
  },
  publish_image: async (params) => {
    await requireWriteAllowed(params, "生成图文发布预览");
    const preview = await fillImage(params);
    return {
      ...preview,
      preview_only: true,
      requires_separate_submit: true,
    };
  },
  fill_video: async (params) => {
    await requireWriteAllowed(params, "上传视频并填写发布预览");
    return fillVideo(params);
  },
  publish_video: async (params) => {
    await requireWriteAllowed(params, "生成视频发布预览");
    const preview = await fillVideo(params);
    return {
      ...preview,
      preview_only: true,
      requires_separate_submit: true,
    };
  },
  click_publish: async (params) => {
    await requireWriteAllowed(params, "提交发布");
    return clickCurrent("creator", "publish", params);
  },
  save_draft: async (params) => {
    await requireWriteAllowed(params, "保存云端草稿");
    return clickCurrent("creator", "draft", params);
  },

  fill_long_article: async (params) => {
    await requireWriteAllowed(params, "填写长文并创建新草稿");
    await clearPreparedSurface("creator");
    const tab = await navigate("creator", CREATOR_URL, { reload: true });
    await requireRiskClear("填写长文并创建新草稿");
    await requirePageRiskClear(tab.id, "填写长文并创建新草稿");
    await pageCall(tab.id, "prepare_long_article", params);
    if (params.images?.length) {
      const prepared = await pageCall(tab.id, "prepare_long_images");
      await chooseFilesWithClick(tab.id, prepared, params.images);
      await pageCall(tab.id, "wait_long_images", { expected: params.images.length });
    }
    const formatted = await pageCall(tab.id, "format_long_article", { include_snapshot: true });
    const sourceSnapshot = requireLongDraftSnapshot(formatted.draft_snapshot, {
      imageCount: params.images?.length || 0,
    });
    const { draft_snapshot: _privateDraftSnapshot, ...publicFormatted } = formatted;
    await setStoredTab("creator", tab.id);
    const currentTab = await chrome.tabs.get(tab.id);
    const previewId = randomNonce();
    const accountFingerprint = await currentAccountFingerprint();
    await setPreparedSurface("creator", tab.id, "long_article_templates", {
      preview_id: previewId,
      creator_url: currentTab.url,
      form_summary: {
        title_length: String(params.title || "").length,
        content_length: String(params.content || "").length,
        image_count: params.images?.length || 0,
      },
      long_source_snapshot: sourceSnapshot,
      account_fingerprint: accountFingerprint,
    });
    return {
      ...publicFormatted,
      image_count: params.images?.length || 0,
      preview_stage: "long_article_templates",
      preview_only: true,
      preview_id: previewId,
    };
  },

  select_template: async (params) => {
    await requireWriteAllowed(params, "更改长文草稿排版模板");
    const { tab, prepared } = await requirePreparedTab(
      "creator",
      ["long_article_templates", "long_article_template_selected"],
      "选择长文排版模板",
    );
    requireMatchingPreviewId(params, prepared);
    await requireRiskClear("更改长文草稿排版模板");
    await requirePageRiskClear(tab.id, "更改长文草稿排版模板");
    const beforeAction = await pageCall(tab.id, "long_draft_snapshot");
    await requireUnchangedLongDraft(tab, prepared, beforeAction);
    const result = await pageCall(tab.id, "select_template", {
      ...params,
      include_snapshot: true,
    });
    await requireUnchangedLongDraft(tab, prepared, result.draft_snapshot_before);
    const nextSourceSnapshot = requireLongDraftSnapshot(result.draft_snapshot, {
      imageCount: prepared.long_source_snapshot.media.count,
      template: params.name,
    });
    const {
      draft_snapshot_before: _privateBeforeSnapshot,
      draft_snapshot: _privateAfterSnapshot,
      ...publicResult
    } = result;
    const currentTab = await chrome.tabs.get(tab.id);
    await setPreparedSurface(
      "creator",
      tab.id,
      "long_article_template_selected",
      { creator_url: currentTab.url, long_source_snapshot: nextSourceSnapshot },
      { preserveCreatedAt: true },
    );
    return {
      ...publicResult,
      preview_stage: "long_article_template_selected",
      preview_id: prepared.preview_id,
    };
  },

  long_article_next: async (params) => {
    await requireWriteAllowed(params, "进入长文发布页并填写描述");
    const { tab, prepared } = await requirePreparedTab(
      "creator",
      ["long_article_template_selected"],
      "进入长文发布页",
    );
    requireMatchingPreviewId(params, prepared);
    await requireRiskClear("进入长文发布页并填写描述");
    await requirePageRiskClear(tab.id, "进入长文发布页并填写描述");
    const beforeAction = await pageCall(tab.id, "long_draft_snapshot");
    await requireUnchangedLongDraft(tab, prepared, beforeAction);
    const result = await pageCall(tab.id, "long_next", {
      ...params,
      include_snapshot: true,
    });
    await requireUnchangedLongDraft(tab, prepared, result.draft_snapshot_before);
    const { draft_snapshot_before: _privateBeforeSnapshot, ...publicResult } = result;
    const settings = await applyPublishSettings(tab.id, params, {
      mediaType: "long_article",
      mediaExpected: 0,
    });
    const snapshot = requireObservedPreview(settings, "long_article", 0);
    await requireRiskClear("完成长文发布预览");
    const currentTab = await chrome.tabs.get(tab.id);
    await setPreparedSurface(
      "creator",
      tab.id,
      "long_article_publish",
      {
        creator_url: currentTab.url,
        form_snapshot: snapshot,
        form_summary: snapshot.form || prepared.form_summary || {},
        media_type: "long_article",
        media_expected: 0,
        settings_expected: expectedPublishSettings(params),
      },
      { preserveCreatedAt: true },
    );
    return {
      ...publicResult,
      settings: publicPublishSettings(settings),
      preview_stage: "long_article_publish",
      preview_id: prepared.preview_id,
    };
  },

  diagnostics: async ({ clear = false }) => {
    await loadStorage();
    const notFound = riskEvents
      .filter((item) => item.status === 404)
      .map((item) => ({ ...item, diagnosis: diagnoseNotFound(item) }));
    if (clear) {
      networkEntries = networkEntries.filter((item) => item.status !== 404);
      riskEvents = riskEvents.filter((item) => item.status !== 404);
      await persistNetworkEntries();
    }
    return { entries: notFound.slice(-50), count: notFound.length, cleared: Boolean(clear) };
  },

  get_netlog: async ({ limit = null }) => {
    await loadStorage();
    const entries = Number.isInteger(limit) && limit > 0 ? networkEntries.slice(-limit) : [...networkEntries];
    return {
      entries,
      count: entries.length,
      risk_events: [...riskEvents],
      risk_event_count: riskEvents.length,
      privacy: "query strings, headers, cookies and bodies are excluded",
    };
  },

  check_risk: async (params = {}) => {
    let probeUrls = Array.isArray(params.probe_urls) ? params.probe_urls : [];
    const activeProbes = params.active_probes === true;
    if (activeProbes) {
      requireConfirmed(params, "执行主动风控探测");
      if (probeUrls.length > 10 || probeUrls.some((url) => !isAllowedRiskProbeUrl(url))) {
        throw new RpcError(
          "invalid_input",
          "主动探测只允许最多 10 个小红书 HTTPS API URL",
        );
      }
      probeUrls = [...new Set(probeUrls)];
    }
    await loadStorage();

    let activeProbeBlockedReason = "";
    let activeProbeError = "";
    let activeProbesExecuted = false;
    let apiProbes = [];
    const preflightHighRisk = recentHighRiskSignals();
    let tab = null;
    if (activeProbes && preflightHighRisk.length === 0) {
      try {
        tab = await navigate("risk", EXPLORE_URL);
      } catch (error) {
        activeProbeBlockedReason = "risk_page_unavailable";
        activeProbeError = privacySafeText(error?.message || String(error));
      }
    } else {
      tab = await existingXhsTab();
      if (activeProbes) activeProbeBlockedReason = "recent_high_risk_event";
    }
    let page = {
      url: "",
      fingerprints: {},
      fingerprint_issues: [],
      page_markers: [],
      verification_required: false,
      access_error_visible: false,
      captcha_visible: false,
      page_is_404: false,
      risk_block_visible: false,
    };
    let pageScanned = false;
    let pageScanError = "";
    if (tab) {
      try {
        const scannedPage = await pageCall(tab.id, "risk_signals");
        page = {
          ...page,
          ...scannedPage,
          fingerprint_issues: Array.isArray(scannedPage?.fingerprint_issues)
            ? scannedPage.fingerprint_issues
            : [],
          page_markers: Array.isArray(scannedPage?.page_markers)
            ? scannedPage.page_markers
            : [],
          url: privacySafeUrl(scannedPage?.url || tab.url),
        };
        pageScanned = true;
      } catch (error) {
        pageScanError = privacySafeText(error?.message || String(error));
      }
    }
    const pageHigh = Boolean(visiblePageRiskReason(page))
      || page.verification_required
      || page.captcha_visible
      || page.risk_block_visible;
    const pageUnsafeForActiveProbe = pageHigh
      || page.page_markers.length > 0
      || page.access_error_visible
      || page.page_is_404;
    if (activeProbes && !activeProbeBlockedReason) {
      if (!pageScanned) {
        activeProbeBlockedReason = "page_scan_unavailable";
      } else if (pageUnsafeForActiveProbe) {
        activeProbeBlockedReason = "page_risk_signal";
      } else {
        try {
          const probeReport = await pageCall(tab.id, "active_risk_probes", {
            probe_urls: probeUrls,
          });
          const rawResults = Array.isArray(probeReport?.results) ? probeReport.results : [];
          apiProbes = rawResults.map((item) => ({
            url: privacySafeUrl(item?.url || ""),
            method: item?.method === "POST" ? "POST" : "GET",
            ...(Number.isInteger(item?.status) ? { status: item.status } : {}),
            ...(typeof item?.ok === "boolean" ? { ok: item.ok } : {}),
            ...(typeof item?.xhs_code === "number" || item?.xhs_code === null
              ? { xhs_code: item.xhs_code }
              : {}),
            ...(item?.risk_blocked === true ? { risk_blocked: true } : {}),
            ...(Number.isFinite(item?.elapsed_ms)
              ? { elapsed_ms: Math.max(0, Math.round(item.elapsed_ms)) }
              : {}),
            ...(item?.error ? { error: String(item.error).slice(0, 80) } : {}),
          }));
          activeProbesExecuted = true;
        } catch (error) {
          activeProbeBlockedReason = "probe_operation_failed";
          activeProbeError = privacySafeText(error?.message || String(error));
        }
      }
    }
    const cutoff = Date.now() - RISK_WINDOW_MINUTES * 60 * 1000;
    const recent = riskEvents.filter((item) => item.timestamp >= cutoff);
    const blocked = recent.filter((item) => isActionableNetworkFailure(item, { include404: false }));
    const ignored = networkEntries.filter(
      (item) => item.timestamp >= cutoff && item.error && isBenignNetworkFailure(item),
    );
    const fingerprintIssues = Array.isArray(page.fingerprint_issues) ? page.fingerprint_issues : [];
    const fingerprintHigh = fingerprintIssues.filter((item) => item.severity === "high").length;
    const fingerprintMedium = fingerprintIssues.filter((item) => item.severity === "medium").length;
    const fingerprintLow = fingerprintIssues.filter((item) => item.severity === "low").length;
    const probeIssues = apiProbes.flatMap((item) => {
      const code = item.xhs_code;
      if ([404, 429, 461, 999].includes(item.status)) {
        return [{
          severity: "high",
          signal: `主动 API 探测返回风控状态码 ${item.status}`,
          url: item.url,
        }];
      }
      if ([300012, -9001].includes(code)) {
        return [{
          severity: "high",
          signal: `主动 API 探测返回平台风控码 ${code}`,
          url: item.url,
        }];
      }
      if (code === -1) {
        return [{
          severity: "medium",
          signal: "主动 API 探测返回系统繁忙码 -1",
          url: item.url,
        }];
      }
      if (item.error || (Number.isInteger(item.status) && item.status >= 400)) {
        return [{
          severity: "medium",
          signal: `主动 API 探测失败：${item.status || item.error || "unknown"}`,
          url: item.url,
        }];
      }
      return [];
    });
    if (activeProbeError) {
      probeIssues.push({
        severity: "medium",
        signal: "主动 API 探测未能完成",
      });
    }
    const probeHigh = probeIssues.some((item) => item.severity === "high");
    const probeMedium = probeIssues.filter((item) => item.severity === "medium").length;
    const networkHigh = blocked.some((item) => HIGH_RISK_STATUSES.has(item.status));
    const mediumSignals = page.page_markers.length
      + Number(page.access_error_visible)
      + Number(page.page_is_404)
      + blocked.length
      + probeMedium;
    let riskLevel = "safe";
    if (pageHigh || networkHigh || probeHigh || fingerprintHigh >= 2) riskLevel = "high";
    else if (fingerprintHigh || fingerprintMedium >= 2 || mediumSignals >= 2) riskLevel = "medium";
    else if (fingerprintMedium || fingerprintLow || mediumSignals) riskLevel = "low";
    const issues = [
      ...fingerprintIssues,
      ...page.page_markers.map((signal) => ({ severity: "medium", signal })),
      ...blocked.slice(-20).map((item) => ({
        severity: HIGH_RISK_STATUSES.has(item.status) ? "high" : "medium",
        signal: `网络请求异常：${item.status || item.error || "unknown"}`,
        url: item.url,
      })),
      ...probeIssues,
    ];
    return {
      risk_level: riskLevel,
      page,
      issues,
      recent_network_failures: blocked.slice(-20),
      ignored_navigation_failures: ignored.length,
      network_window_minutes: RISK_WINDOW_MINUTES,
      page_scanned: pageScanned,
      page_scan_error: pageScanError || undefined,
      api_probes: apiProbes,
      active_probes_requested: activeProbes,
      active_probes_executed: activeProbesExecuted,
      active_probe_blocked_reason: activeProbeBlockedReason || undefined,
      active_probe_error: activeProbeError || undefined,
      probe_urls_skipped: activeProbes ? [] : probeUrls.map(privacySafeUrl),
      note: activeProbes
        ? "主动模式仅在没有近期高风险响应且页面扫描安全时执行；结果只保留状态、平台数值代码和耗时，不保留查询参数、Cookie、请求头或响应正文。"
        : "被动检查仅复用已打开的小红书标签页；不会导航页面，probe URL 只记录、不自动访问。",
    };
  },
};
