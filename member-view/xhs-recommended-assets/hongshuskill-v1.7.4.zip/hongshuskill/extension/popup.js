chrome.runtime.sendMessage({ channel: "hongshuskill-popup", type: "status" }, (response) => {
  const bridge = document.getElementById("bridge");
  const entries = document.getElementById("entries");
  const instance = document.getElementById("instance");
  const connected = Boolean(response?.connected);
  const pairingFailed = Boolean(response?.pairing_error);
  bridge.textContent = connected
    ? "已认证"
    : pairingFailed
      ? "配对失败"
      : response?.socket_open ? "正在认证" : "等待 CLI";
  bridge.title = pairingFailed ? "请重新执行首次配对后重载扩展" : "";
  bridge.classList.add(connected ? "good" : "warn");
  instance.textContent = response?.instance_id
    ? response.instance_id.slice(0, 8)
    : "未就绪";
  entries.textContent = `${response?.network_entries ?? 0} 条`;
});
