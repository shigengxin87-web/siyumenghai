# Windows 首次运行

只在 Windows 10/11 新环境、本次安装尚未成功运行 `onboard`，或用户询问“在哪里输入命令”时读取。

## Agent 固定动作

在运行或要求用户运行第一条 `onboard` 命令前，先把下方“发给 Windows 用户的教程”完整发给用户。不要只发一条没有上下文的 PowerShell 命令，不要使用“在文件夹中打开 PowerShell”这类未说明点击位置的概括表达，也不要假定用户知道终端、地址栏或命令提示符是什么。

## 发给 Windows 用户的教程

下面的命令要输入在 **Windows 终端或 PowerShell 窗口**里，不是输入在 Chrome、小红书网页或 ChatGPT 输入框里。按以下步骤逐项操作即可，不需要懂编程，也不需要管理员权限。

### 第一步：解压并找到正确的文件夹

1. 打开 Windows 的“下载”文件夹，找到下载的 Skill 压缩包。
2. 用鼠标右键单击压缩包，选择“全部解压缩”，再点击“提取”。不要直接在压缩包预览窗口里运行文件。
3. 打开解压后的文件夹。如果里面只看到另一个 `hongshuskill` 文件夹，就再双击进入一层。
4. 确认当前窗口里同时能看到以下三个项目：
   - `SKILL.md`
   - `scripts` 文件夹
   - `extension` 文件夹

如果看不到这三个项目，说明还没有进入正确的 `hongshuskill` 文件夹。

### 第二步：从这个文件夹打开 PowerShell

1. 找到文件资源管理器窗口顶部、显示当前位置的长条区域。里面通常显示类似“此电脑 > 下载 > hongshuskill”，这就是地址栏。
2. 用鼠标左键单击地址栏空白处。原来的位置会变成一行文件夹路径。
3. 按 `Ctrl+A` 选中地址栏里的全部文字，输入：

   ```text
   powershell
   ```

4. 按键盘上的回车键。系统会弹出一个蓝色或黑色窗口，这个窗口就是 PowerShell。
5. 检查窗口最下面一行是否以 `hongshuskill>` 结尾，例如：

   ```text
   PS C:\Users\你的用户名\Downloads\hongshuskill>
   ```

看到 `hongshuskill>` 才表示位置正确。如果不是，请关闭这个窗口，回到第一步找到正确文件夹后重试。

### 第三步：检查并安装 uv

1. 在 PowerShell 窗口中输入下面这条命令，然后按回车：

   ```powershell
   uv --version
   ```

2. 如果出现类似 `uv 0.8.12` 的版本号，说明已经安装，请继续第四步。
3. 如果提示“无法将 uv 识别为命令”或“不是内部或外部命令”，输入下面这条命令并按回车：

   ```powershell
   winget install --id=astral-sh.uv -e
   ```

4. 如果电脑提示找不到 `winget`，改用下面这条命令：

   ```powershell
   powershell -ExecutionPolicy Bypass -c "irm https://astral.sh/uv/install.ps1 | iex"
   ```

5. 安装完成后关闭 PowerShell，重新按照第二步从 `hongshuskill` 文件夹打开 PowerShell，再运行一次 `uv --version`。看到版本号后继续。

### 第四步：启动 Skill 首次检查

1. 把下面这整条命令复制到 PowerShell 窗口，然后按回车：

   ```powershell
   powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\scripts\run-hongshu.ps1 onboard
   ```

2. 第一次运行可能需要几分钟下载运行依赖。期间不要关闭窗口，也不要重复运行命令。
3. 完成后，窗口会显示一段以 `{` 开头、以 `}` 结尾的 JSON 内容。用鼠标选中并复制完整内容，然后发回给 Agent。如果 Agent 可以直接读取本机终端，则由 Agent 继续处理。

## 常见问题

- 提示“找不到 `run-hongshu.ps1`”：PowerShell 打开在了错误文件夹。关闭窗口，重新按照第一、二步操作。也可以运行 `Get-ChildItem .\scripts\run-hongshu.ps1`；只有能显示该文件时才继续。
- 提示“找不到 `uv`”：按照第三步安装，关闭并重新打开 PowerShell。
- 当前是 WSL、Ubuntu 或类似 `user@computer:~$` 的终端：关闭它，改用 Windows 终端或 PowerShell。
- 路径包含中文或空格：只要在正确的 `hongshuskill` 文件夹打开终端，上述相对路径命令可直接使用。
- 不需要双击 `.ps1` 文件，也不需要以管理员身份打开 PowerShell。
