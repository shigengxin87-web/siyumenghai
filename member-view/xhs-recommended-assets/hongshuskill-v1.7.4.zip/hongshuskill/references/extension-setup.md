# 浏览器扩展首次安装

只在对应平台启动器的 `onboard` 返回 `ready: false` 且 `next_action=prepare_extension_install` 时读取。

原生支持 macOS、Linux 和 Windows 10/11。Windows 从本机 PowerShell 启动，不在 WSL 中运行；始终原样执行 `onboard` 返回的完整 `prepare_argv` 与 `verification_argv`。
Windows 用户在到达本流程前，应已按 [windows-first-run.md](windows-first-run.md) 完成终端定位、`uv` 检查和第一次 `onboard`。

## 固定流程

不检测 Computer Use，不询问是否需要帮助安装，也不尝试 AppleScript 或其他 UI 自动化。按固定顺序执行：

1. 按 `onboarding.prepare_argv` 原样运行安装准备命令，通常为：

   macOS/Linux 通常为 `./scripts/run-hongshu prepare-extension-install`；Windows 通常为 `powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\scripts\run-hongshu.ps1 prepare-extension-install`。

2. 检查 JSON 同时满足：
   - `prepared=true`
   - `automatic_install_completed=false`
   - `actions` 表明 Chrome 扩展页和系统文件管理器均已打开
   - `user_message` 非空
3. 将 `user_message` 原样发送给用户。它已包含当前机器的真实 `extension_path`、文件管理器名称、扩展名称和目标版本；不要改写为示例路径，也不要追加 `/Users/xxxx`。
4. 等用户完成 Chrome 要求的安全点击并回复后，运行 `verification_argv`。只有 `ready=true` 才算安装成功。
5. 验收成功后原样发送 `data.onboarding.success_user_message`。该消息会确认连接成功，并展示三个可直接使用的案例。发送后结束首次安装流程；不要自动执行案例，也不要运行 `risk-report`、`check-login` 或任何页面命令。扩展安装成功不代表小红书已经登录。用户之后明确提出实际小红书操作时，再按主流程依次运行 `risk-report` 与 `check-login`。

首次安装成功消息中的固定案例为：

1. 帮我抓取5篇关于运营起号的小红书笔记，并帮我拆解它们
2. 帮我找到5篇关于运营创业的小红书笔记，并帮我读取它们的评论区。帮我基于评论区给我3个内容选题灵感
3. 帮我抓取5篇运营创业的小红书笔记，并且把它们的图文保存到我本地

准备命令失败时，不得发送“我已经成功打开”的文案。报告 JSON 错误，并把 `onboard` 返回的真实 `extension_path` 告诉用户，让用户自行打开 `chrome://extensions`。

## 用户看到的安装步骤

准备命令生成的 `user_message` 必须说明已经完成：

- 打开 `chrome://extensions`。
- 在 macOS Finder、Linux 文件管理器或 Windows 文件资源管理器中定位包内 `extension` 文件夹。

并要求用户依次完成：

1. 开启扩展页右上角“开发者模式”。
2. 点击“加载已解压的扩展程序”。
3. 在文件夹选择器中选择消息里的真实 `extension_path` 文件夹本身，不要选择 `manifest.json`。
4. 确认出现 `Hongshu Local Companion` 目标版本卡片，且开关处于启用状态。

消息会提示用户可以尝试把已定位的 `extension` 文件夹拖入扩展页；若当前 Chrome 对文件夹拖入没有反应，仍按“加载已解压的扩展程序”流程操作。

如果页面已经存在同名卡片，先启用该卡片并点击一次“重新加载”。若版本仍不匹配，卡片可能指向另一个 unpacked 安装路径，单击“重新加载”不会切换到本次 `extension_path`。让用户先确认没有进行中的发布、评论、登录或其他账号操作，再由用户本人停用或移除旧卡片，然后点击“加载已解压的扩展程序”并选择当前 JSON 里的真实 `extension_path`。Agent 不得自动移除卡片。

## 状态路由

- `ready`：扩展、桥接与 CLI 版本一致，结束安装流程。
- `extension_install_required`：当前没有通过验证的配套扩展；可能是尚未安装、尚未连接，也可能是旧版扩展因版本或认证协议不兼容而被拒绝。直接运行 `prepare_argv` 并发送返回的 `user_message`；若已有同名卡片，按本包路径重新加载，不重复添加。
- `extension_reload_required`：已连接扩展版本过旧。执行相同准备流程；用户在扩展页启用或重载当前包内版本。
- `bridge_repair_required`：重新运行一次 `onboard`。当桥接能通过当前认证协议报告为空闲时，启动器才会安全替换自己管理的错版桥接。
- `bridge_recovery_required`：上次写操作的最终状态不确定。停止页面操作，让用户检查浏览器、个人主页、草稿箱、短信或互动状态；确认结果后，再经用户对解除隔离的本次明确确认，原样运行 `recovery_argv_after_confirmation`。
- `package_invalid`：包内扩展清单、配对模板、必需脚本缺失，或其结构/版本与 CLI 不匹配。该状态会在启动桥接前检出；停止并重新安装完整 Skill 包，不要联网搜索替代扩展，也不要自行补写配对密钥。

## 第二个账号 Profile

只有用户明确要新增可同时保持登录的账号时使用：

1. 由用户本人在 Chrome 的 Profile 菜单中新建或切换到另一个 Profile；Agent 不编辑 Chrome Profile 目录或 `Secure Preferences`。
2. 在新 Profile 中打开 `chrome://extensions`，按本文“用户看到的安装步骤”加载同一个 `extension_path`。
3. 打开小红书并由用户登录新账号。每个 Profile 内的扩展会生成独立 `instance_id`，但不导出或复制 Cookie。
4. 运行 `account-list` 查看未绑定实例，然后按 [commands.md](commands.md) 的账号绑定流程执行 `account-inspect` 和 `account-add`。

不允许为了多账号而复制当前 Profile 目录、Cookie 文件或扩展存储；复制会造成实例 ID 和登录身份冲突。

## 安全边界

- 只打开扩展页并定位包内目录；Chrome 最后的开发者模式和加载确认由用户本人完成。
- 不判断或调用 Computer Use，不反复尝试 AppleScript，也不要求用户开启辅助功能权限。
- 不硬编码 Skill 安装目录；只使用最新 JSON 的 `extension_path`、`prepare_argv` 和 `verification_argv`。
- 不编辑 Chrome `Secure Preferences`、用户配置文件或扩展注册数据。
- 不安装本地 CRX，不下载同名第三方扩展，不创建企业策略，不结束 Chrome 后注入 `--load-extension`，不清除浏览器数据。
- 不得把“页面和目录已打开”误报为“扩展已安装”；只有 `onboard` 返回 `ready=true` 才能继续小红书操作。

## 有界恢复

用户完成安装但首次验收未连接时，只恢复一轮：请用户确认卡片已启用并点击一次“重新加载”，打开任意 `https://www.xiaohongshu.com/` 页面，再运行一次 `onboard --wait-seconds 15`。若同名卡片显示的仍是旧版本，不要继续循环点击重载；按上述“另一安装路径”流程由用户切换到本次 `extension_path`。

仍失败时报告最新 JSON 中的状态、目标版本和扩展路径；不要循环点击、重复安装、安装第三方扩展或清除浏览器数据。

`doctor` 仅会自动替换能通过当前认证协议证明“空闲且未隔离”的自管桥接；替换前仍会核对 PID、当前用户、脚本绝对路径和端口。无法确认进程身份时不会终止进程。

检测到旧版未认证桥接时，`onboard` 会以 `bridge_unavailable` / `bridge_upgrade_deferred` 停止；因为旧协议无法可信报告是否忙碌，不会自动结束它。只有用户已确认浏览器中没有发布、评论、登录或其他进行中操作，并对本次升级再次明确确认后，才运行：

原样运行当前平台启动器的 `upgrade-bridge --confirm`。

不要直接杀进程、删 PID 文件或重复运行写操作。

若返回 `bridge_identity_unverified`，表示 9345 端口上的进程不是当前安装路径严格可验证的桥接，常见于另一份 hongshuskill 副本仍在运行。不得对它运行 `upgrade-bridge --confirm`，也不得由当前 Skill 终止它。让用户先确认旧副本没有发布、评论、登录或其他进行中操作，再从旧副本所属的应用或任务中关闭该 companion，随后重跑 `onboard`。

扩展只连接 `ws://127.0.0.1:9345`，桥接只监听本机回环地址；两端还使用本地配对密钥对每条消息认证并防重放，不把 `Origin` 当作身份证明。扩展权限用于小红书标签页操作、可信点击、文件上传、用户明确退出时清理小红书 Cookie，以及保存隐私精简的风控元数据；不会读取浏览器密码，也不提供任意 JavaScript 执行接口。

为防止用户在预览后切换账号却仍提交旧草稿，扩展会在本机内短暂读取最小会话 Cookie 标识，立即用配对密钥转换为 HMAC 指纹，并在最终提交前重新比对。原始 Cookie 值不写入扩展存储、日志或 RPC 输出。
