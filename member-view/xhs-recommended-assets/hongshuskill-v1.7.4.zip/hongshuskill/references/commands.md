# 命令参考

在 `hongshuskill` 目录运行命令。所有文件参数使用绝对本地路径；不把远程图片 URL 传给 CLI。macOS/Linux 使用下方的 `./scripts/run-hongshu`；Windows 10/11 从本机 PowerShell 运行，将每条命令前缀替换为 `powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\scripts\run-hongshu.ps1`。所有平台都要求 `uv` 和 Google Chrome；不在 WSL 中运行。机器可读的 `prepare_argv`、`verification_argv` 和恢复命令已包含当前平台的完整启动方式，始终优先原样执行它们。

## 目录

- [环境与认证](#环境与认证)
- [内容发现](#内容发现)
- [互动](#互动)
- [图文发布](#图文发布)
- [视频发布](#视频发布)
- [长文发布](#长文发布)
- [风控与诊断](#风控与诊断)
- [输出与退出码](#输出与退出码)

## 环境与认证

```bash
./scripts/run-hongshu onboard [--wait-seconds 15]
./scripts/run-hongshu prepare-extension-install
./scripts/run-hongshu doctor
./scripts/run-hongshu recover-bridge --request-id REQUEST_ID --confirm
./scripts/run-hongshu upgrade-bridge --confirm
./scripts/run-hongshu account-list
./scripts/run-hongshu account-inspect [--instance-id INSTANCE_ID]
./scripts/run-hongshu account-add --name NAME --expected-user-id USER_ID [--instance-id INSTANCE_ID] --confirm
./scripts/run-hongshu account-verify --name NAME --confirm
./scripts/run-hongshu account-unbind --name NAME --confirm
./scripts/run-hongshu check-login
./scripts/run-hongshu get-qrcode [--output /absolute/path/qrcode.png]
./scripts/run-hongshu wait-login [--timeout 120]
./scripts/run-hongshu login [--timeout 120] [--output /absolute/path/qrcode.png]
./scripts/run-hongshu send-code --phone 13800138000 --confirm
./scripts/run-hongshu verify-code --code 123456
./scripts/run-hongshu phone-login --phone 13800138000 --code 123456 --confirm
./scripts/run-hongshu delete-cookies --confirm
```

所有小红书页面命令都可在子命令前使用全局 `--account NAME`，例如：

```bash
./scripts/run-hongshu --account A check-login
./scripts/run-hongshu --account A fill-publish ... --confirm
```

### 账号绑定流程

1. 当前 Chrome Profile 已登录小红书后，运行 `account-inspect`。若已连接多个 Profile，先用 `account-list` 查看 `unbound_instance_ids`，再传入 `--instance-id`。
2. 向用户展示昵称、`user_id` 和 `instance_id`，并请用户确认账号名。不展示 `session_fingerprint`。
3. 确认后，将上一步的 `user_id` 原样传入 `account-add --expected-user-id ... --confirm`。CLI 会再次读取当前身份；两次用户 ID 不同时不会绑定。
4. 会话刷新或重新登录后，先用 `--account NAME check-login` 核对，再经用户确认运行 `account-verify --name NAME --confirm`。只有平台 `user_id` 未改变时才会更新会话指纹。

`account-unbind` 只解除本地路由，不退出登录、不删 Cookie 和 Chrome Profile。一个 Profile 已绑定账号后，不能再绑定第二个别名。存在多个已登记账号时，所有页面命令必须显式使用 `--account`。

`onboard` 是新环境的第一条命令：它启动本地桥接、检测包内扩展和 Chrome 连接，并返回机器可读的安装状态、绝对扩展路径、目标版本、准备命令和验收命令。它不检测 Computer Use，也不打开或修改 Chrome。扩展未连接或版本过旧时，Agent 不询问用户，直接按 `onboarding.prepare_argv` 运行下一条命令。

`prepare-extension-install` 打开 Chrome 扩展页并在系统文件管理器中定位包内 `extension` 文件夹，然后返回已经填入真实路径、文件管理器名称和当前版本的 Markdown `user_message`。Agent 检查 `prepared: true` 后必须把这段消息原样发给用户。该命令不会点击 Chrome 安全控件，`automatic_install_completed` 固定为 `false`。用户完成消息里的步骤后使用 `onboard --wait-seconds 15` 等待扩展接入；仅以 `ready: true` 为成功。
每次手机登录都先向用户确认手机号，只有确认本次号码后才添加 `--confirm`。不要在未得到本次验证码时运行 `verify-code`。
优先使用 `send-code` 与 `verify-code` 两步流程。`phone-login` 必须同时提供 `--phone`、已收到的 `--code` 和 `--confirm`；它只提交现有验证码，不会发送或重复发送短信，也不会进入交互式提示。
二维码会以 `0600` 权限保存到 `qrcode_path`；只向用户展示该本地图片。CLI 最终 JSON 不返回 `data_url` 或含一次性登录参数的 `qr_login_url`，二维码数据不上传到第三方识别服务。
检测到未登录、进入重新登录或执行 `delete-cookies` 时，任何尚未提交的发布预览都会失效；切换账号后必须重新填写并确认。
若退出登录返回 `remote_code=operation_state_uncertain` 且 `cause_code=logout_unconfirmed`，先让用户直接检查当前登录状态，再按隔离恢复流程处理；不要先运行会同样被隔离的页面诊断命令。

`bridge_recovery_required` 是故障后的安全隔离，不是可自动重试的普通错误。直接页面命令返回 `operation_quarantined` 或 `operation_state_uncertain` 后，先运行 `onboard` 取得当前隔离状态和唯一 `request_id`；此时 `risk-report`、`check-risk` 等其他页面命令也会被隔离，不要循环重试。先让用户核对上次操作在浏览器和账号中的实际结果；用户再次明确确认解除隔离后，才原样运行 `onboard` 本次返回的 `recovery_argv_after_confirmation`。不得改写、猜测或复用旧 `request_id`。

若 `onboard` 失败且 `error.details.remote_code=bridge_upgrade_deferred`，表示当前是旧版未认证桥接，工具无法安全判断它是否忙碌。只有用户已确认浏览器中没有发布、评论、登录或其他进行中操作，并对升级本身再次明确确认后，才运行 `upgrade-bridge --confirm`。

若 `error.details.remote_code=bridge_identity_unverified`，则端口占用者无法与当前安装路径严格匹配；不得运行 `upgrade-bridge`或主动终止它。让用户先确认另一副本中没有进行中的账号操作，再从该副本所属应用/任务中关闭 companion，然后重跑 `onboard`。

## 内容发现

```bash
./scripts/run-hongshu list-feeds [--limit 40]

./scripts/run-hongshu search-feeds \
  --keyword "咖啡" \
  [--sort-by 综合|最新|最多点赞|最多评论|最多收藏] \
  [--note-type 不限|视频|图文] \
  [--publish-time 不限|一天内|一周内|半年内] \
  [--search-scope 不限|已看过|未看过|已关注] \
  [--location 不限|同城|附近] \
  [--limit 40]

./scripts/run-hongshu get-feed-detail \
  --feed-id FEED_ID --xsec-token XSEC_TOKEN --xsec-source XSEC_SOURCE \
  [--load-all-comments] [--click-more-replies] \
  [--max-replies-threshold 10] [--max-comment-items 50] \
  [--scroll-speed slow|normal|fast]

./scripts/run-hongshu user-profile \
  --user-id USER_ID --xsec-token AUTHOR_XSEC_TOKEN --xsec-source AUTHOR_XSEC_SOURCE
```

从首页或搜索结果取得同一条结果的 `feed_id`、`xsec_token` 与 `xsec_source` 三元组，每次详情和互动都原样传入；不要混用不同结果的值，也不要猜测缺失的来源。搜索结果通常为 `pc_search`，首页结果通常为 `pc_feed`，但必须以返回值为准。

用户主页使用结果中 `author.user_id`、`author.xsec_token` 与 `author.xsec_source` 的作者三元组；作者令牌可能与笔记令牌不同，不得用笔记的 `xsec_token` 代替。
每次搜索都会重新加载搜索页后再应用本次筛选，未提供的筛选项不会继承上一次搜索状态。

## 互动

正式互动前可先做只读检查；该命令只读取当前状态和按钮，不会点击、评论或改动账号：

```bash
./scripts/run-hongshu inspect-actions \
  --feed-id FEED_ID --xsec-token XSEC_TOKEN --xsec-source XSEC_SOURCE

./scripts/run-hongshu inspect-actions \
  --feed-id FEED_ID --xsec-token XSEC_TOKEN --xsec-source XSEC_SOURCE \
  --comment-id COMMENT_ID

./scripts/run-hongshu inspect-actions \
  --feed-id FEED_ID --xsec-token XSEC_TOKEN --xsec-source XSEC_SOURCE \
  --user-id USER_ID
```

返回点赞/收藏当前状态、评论入口和互动按钮是否就绪；提供评论或用户 ID 时会滚动加载并检查回复目标。
互动状态优先读取页面的结构化笔记状态，图标 DOM 仅在结构化状态缺失时回退；`state_evidence` 会列出两类证据及是否冲突，避免把装饰性图标名称误判为当前状态。
互动点击会先验证真实按钮容器，再把受信鼠标落点锚定到对应的可见图标中心，避免点击到计数文字或控件空隙。
`inspect-actions` 会重新加载已复用的同一笔记页，避免读取旧标签页里的临时状态。点赞和收藏写命令也不会把前端动画或内存中的乐观状态当成最终成功：即使观察窗口内没有动画变化，仍会在等待请求落稳后进行一次绕过缓存的页面重新加载。重载后只接受新的 `__INITIAL_STATE__` 布尔状态，或精确的 `#like`/`#liked`、`#collect`/`#collected` 图标状态；任何冲突、模糊类名或未知状态都失败关闭并返回不可自动重试的 `operation_state_uncertain`。

```bash
./scripts/run-hongshu post-comment \
  --feed-id FEED_ID --xsec-token XSEC_TOKEN --xsec-source XSEC_SOURCE \
  --content-file /absolute/path/comment.txt --confirm

./scripts/run-hongshu reply-comment \
  --feed-id FEED_ID --xsec-token XSEC_TOKEN --xsec-source XSEC_SOURCE \
  --comment-id COMMENT_ID \
  --content-file /absolute/path/reply.txt --confirm

./scripts/run-hongshu reply-comment \
  --feed-id FEED_ID --xsec-token XSEC_TOKEN --xsec-source XSEC_SOURCE \
  --user-id USER_ID \
  --content "已确认的短回复" --confirm

./scripts/run-hongshu like-feed \
  --feed-id FEED_ID --xsec-token XSEC_TOKEN --xsec-source XSEC_SOURCE --confirm
./scripts/run-hongshu like-feed \
  --feed-id FEED_ID --xsec-token XSEC_TOKEN --xsec-source XSEC_SOURCE --unlike --confirm

./scripts/run-hongshu favorite-feed \
  --feed-id FEED_ID --xsec-token XSEC_TOKEN --xsec-source XSEC_SOURCE --confirm
./scripts/run-hongshu favorite-feed \
  --feed-id FEED_ID --xsec-token XSEC_TOKEN --xsec-source XSEC_SOURCE --unfavorite --confirm
```

点赞与收藏命令是目标状态操作：若已经处于目标状态，返回 `changed: false`，不重复点击。
评论或回复若返回 `remote_code=operation_state_uncertain` 且 `cause_code=comment_submission_unconfirmed`，不要自动重发相同内容；先由用户检查目标笔记，避免重复评论。

## 图文发布

先填写预览：

```bash
./scripts/run-hongshu fill-publish \
  --title-file /absolute/path/title.txt \
  --content-file /absolute/path/content.txt \
  --images /absolute/path/1.jpg /absolute/path/2.webp \
  [--tags 标签1 标签2] \
  [--schedule-at YYYY-MM-DDTHH:MM] \
  [--original] [--visibility 公开可见] --confirm
```

图文支持 1–18 张绝对本地路径图片，单张不超过 32 MB；标签去重后最多使用前 10 个。标题和正文必须是 UTF-8 文件，正文文件的本地安全上限为 128 KiB；超限会在打开发布页前拒绝。定时发布以本机时区的分钟精度校验和回传；即使输入含秒，也会先归一到分钟再检查是否仍在未来。
填写后会回读标题与正文。标签存在同名平台话题建议时会选择该话题；没有建议时保留普通 `#标签` 文本，并在结果的 `plain_tags` 中列出。标题、正文或标签文本未写入时不会登记可提交预览；成功时保留返回的 `preview_id`。

用户检查浏览器预览并再次明确确认后：

```bash
./scripts/run-hongshu click-publish --preview-id PREVIEW_ID --confirm
```

只有上传、正文、标签和发布设置全部校验成功后，扩展才会登记可提交预览。`PREVIEW_ID` 必须原样使用当前预览返回的 `preview_id`；不要推断或复用旧值。开始新的填写会使旧预览失效；发布或保存成功后同一预览不能再次提交，预览超过 4 小时也必须重新填写并确认。

若点击后返回 `remote_code=operation_state_uncertain` 且 `cause_code` 为 `submission_unconfirmed` 或 `submission_state_uncertain`，不要再次运行 `click-publish`。先让用户检查浏览器、个人主页和草稿箱，以免重复发布。
任何账号写命令若返回 `operation_state_uncertain`，说明扩展断线或超时发生在动作可能已经开始之后；不要自动重试，先按动作类型检查短信、登录状态、互动结果、浏览器预览、个人主页或草稿箱。

用户取消时：

```bash
./scripts/run-hongshu save-draft --preview-id PREVIEW_ID --confirm
```

`publish` 是填写并校验图文的快捷预览命令，仍不会点击最终发布：

```bash
./scripts/run-hongshu publish \
  --title-file /absolute/path/title.txt \
  --content-file /absolute/path/content.txt \
  --images /absolute/path/1.jpg \
  [--tags 标签1 标签2] [--schedule-at ISO8601] \
  [--original] [--visibility 公开可见] --confirm
```

`publish` 成功后会返回 `preview_id` 和 `requires_separate_submit: true`。保留该 ID，等用户检查浏览器预览并再次明确确认，再执行 `click-publish --preview-id PREVIEW_ID --confirm`。最终点击前会重新检查风控事件；若页面出现“禁止发笔记”“账号异常”等提示，扩展会把它保留为 `999` 风控事件并阻止后续写操作。

## 视频发布

```bash
./scripts/run-hongshu fill-publish-video \
  --title-file /absolute/path/title.txt \
  --content-file /absolute/path/content.txt \
  --video /absolute/path/video.mp4 \
  [--tags 标签1 标签2] [--schedule-at ISO8601] \
  [--visibility 公开可见] --confirm

./scripts/run-hongshu click-publish --preview-id PREVIEW_ID --confirm

./scripts/run-hongshu publish-video \
  --title-file /absolute/path/title.txt \
  --content-file /absolute/path/content.txt \
  --video /absolute/path/video.mp4 \
  [--tags 标签1 标签2] [--schedule-at ISO8601] \
  [--visibility 公开可见] --confirm
```

`fill-publish-video` 和 `publish-video` 都只创建视频预览并返回 `preview_id`，不点击最终发布；`publish-video` 还会返回 `requires_separate_submit: true`。视频处理最长等待 10 分钟；用户检查预览并再次明确确认后，才使用该 `preview_id` 执行 `click-publish`。

## 长文发布

```bash
./scripts/run-hongshu long-article \
  --title-file /absolute/path/title.txt \
  --content-file /absolute/path/content.txt \
  [--images /absolute/path/1.jpg] --confirm

./scripts/run-hongshu select-template \
  --name "模板名称" --preview-id PREVIEW_ID --confirm
./scripts/run-hongshu next-step \
  --content-file /absolute/path/description.txt \
  --preview-id PREVIEW_ID \
  [--schedule-at ISO8601] [--visibility 公开可见] [--original] --confirm
./scripts/run-hongshu click-publish --preview-id PREVIEW_ID --confirm
```

`long-article` 返回 `templates` 和 `preview_id`；后续选模板、进入下一步、保存草稿或最终发布时，都原样使用该 ID。`next-step` 会应用本次明确确认的可见范围、定时时间和原创声明；不得依赖创作中心残留的旧设置。未显式传入时分别为“公开可见”、立即发布和非原创声明，Agent 仍必须在用户确认前展示这些最终设置。`next-step` 描述超过 1000 字时会返回 `invalid_input`，不会静默截断；请用户检查并确认缩短后的最终文本。
模板加载失败时 `long-article` 会明确报错；`select-template` 成功前，`next-step` 不会继续。
若长文编辑器中已有标题或正文，`long-article` 会停止并要求用户先处理，不会静默覆盖现有草稿。

## 风控与诊断

```bash
./scripts/run-hongshu diagnose-404 [--clear]
./scripts/run-hongshu check-risk
./scripts/run-hongshu check-risk --active-probes --confirm
./scripts/run-hongshu check-risk --active-probes \
  --probe-url https://edith.xiaohongshu.com/api/sns/web/v1/example --confirm
./scripts/run-hongshu get-netlog [--limit 100]
./scripts/run-hongshu risk-report
```

网络日志只保存时间、方法、不含查询参数的路径、状态码、错误类别和标签页 ID；不保存请求头、Cookie、查询令牌或正文。

`check-risk` 默认只复用已经打开的小红书标签页做被动检查；没有可用标签页时只分析现有网络记录，不会为了诊断而新建或导航页面。输出中的页面 URL 和跳过的 probe URL 都会移除查询参数。

`check-risk --active-probes --confirm` 会打开或复用独立诊断标签页，执行三个内置小红书 API 探测。用户还可提供最多 10 个 `https://*.xiaohongshu.com/api/...` 自定义 GET URL。该模式会产生真实网络请求，必须先取得用户对本次诊断的明确授权；若最近 15 分钟已有 `429`、`461`、`999`，或页面出现验证、访问错误、404、风控提示，扩展会跳过探测。报告只保留 HTTP 状态、平台数值代码和耗时，不保留查询参数、Cookie、请求头或 API 响应正文。

`diagnose-404` 会为每条 404 返回基于路径类别的低置信度诊断，并明确列出证据范围；它不会读取 Cookie、请求头或请求正文来猜测根因。

扩展分别维护最多 500 条滚动网络记录，以及最多 200 条、保留 24 小时的异常事件。后者不会被大量正常轮询挤出。`risk-report` 的 `risk_level` 只表示最近 15 分钟，`historical_risk_level` 表示合并保留记录后的历史等级；历史风险降出当前窗口不等于账号已经恢复。`diagnose-404 --clear` 只清除 404 诊断记录，不会清除 `429`、`461` 或 `999` 门禁事件。

最近 15 分钟内出现 `429`、`461` 或 `999` 时，所有带确认的账号写命令都会返回 `risk_control_active`。等待窗口结束并由用户检查账号状态后再继续，不要通过清除日志绕过门禁。

## 输出与退出码

启动器检测到缺少依赖或 `uv` 无法启动锁定环境时，以及 CLI 成功启动后，每条命令只输出一个 JSON 对象；启动失败时不会把可能含本机路径或参数的原始 `uv` stderr 塞入 `details`。退出码 `0` 表示成功，`1` 表示检查到需要登录，`2` 表示输入/未知错误或本次登录未完成，`3` 表示桥接不可用，`4` 表示浏览器操作失败，`5` 表示缺少用户确认。
