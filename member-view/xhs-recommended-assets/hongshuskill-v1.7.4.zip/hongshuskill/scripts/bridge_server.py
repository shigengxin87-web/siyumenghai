#!/usr/bin/env python3
"""Local WebSocket broker shared by the CLI and the paired Chrome extension.

The broker deliberately understands only envelopes. Browser behavior lives in the
extension, while input validation and policy live in the CLI. Operations are
serialized so two agents cannot drive the same browser tab at once.
"""

from __future__ import annotations

import argparse
import asyncio
import contextlib
import json
import logging
import math
import os
import re
import signal
import stat
import sys
import tempfile
import time
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from websockets.asyncio.server import ServerConnection, serve
from websockets.exceptions import ConnectionClosed
from websockets.protocol import State

SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from hongshu.auth import (  # noqa: E402
    EnvelopeAuthenticationError,
    NonceReplayCache,
    load_or_create_token,
    sign_envelope,
    verify_envelope,
)
from hongshu.permissions import tighten_file_descriptor, tighten_path  # noqa: E402

PROTOCOL_VERSION = 2
EXTENSION_NAME = "hongshuskill-extension"
EXTENSION_VERSION = "1.7.4"
MAX_MESSAGE_BYTES = 8 * 1024 * 1024
MAX_PARAMS_BYTES = 1024 * 1024
MAX_JOURNAL_BYTES = 4096
MAX_ERROR_MESSAGE_LENGTH = 512
TERMINAL_GRACE_SECONDS = 30.0
ERROR_CODE_PATTERN = re.compile(r"[a-z][a-z0-9_]{0,63}")

logger = logging.getLogger("hongshuskill.bridge")


OPERATION_ALLOWLIST = frozenset(
    {
        "check_login",
        "account_identity",
        "get_qrcode",
        "wait_login",
        "send_code",
        "verify_code",
        "delete_cookies",
        "list_feeds",
        "search_feeds",
        "get_feed_detail",
        "user_profile",
        "inspect_actions",
        "post_comment",
        "reply_comment",
        "set_like",
        "set_favorite",
        "fill_image",
        "publish_image",
        "fill_video",
        "publish_video",
        "click_publish",
        "save_draft",
        "fill_long_article",
        "select_template",
        "long_article_next",
        "diagnostics",
        "check_risk",
        "get_netlog",
        "broker_recover",
    }
)
CONFIRMATION_REQUIRED_OPERATIONS = frozenset(
    {
        "send_code",
        "delete_cookies",
        "post_comment",
        "reply_comment",
        "set_like",
        "set_favorite",
        "fill_image",
        "publish_image",
        "fill_video",
        "publish_video",
        "click_publish",
        "save_draft",
        "fill_long_article",
        "select_template",
        "long_article_next",
    }
)
UNCERTAIN_WRITE_OPERATIONS = CONFIRMATION_REQUIRED_OPERATIONS | {"verify_code"}
UNCERTAIN_TERMINAL_CODES = frozenset(
    {
        "bridge_failure",
        "comment_submission_unconfirmed",
        "draft_submission_uncertain",
        "extension_disconnected",
        "logout_unconfirmed",
        "operation_state_uncertain",
        "operation_timeout",
        "publish_submission_uncertain",
        "state_not_changed",
        "state_not_persisted",
        "submission_state_uncertain",
        "submission_unconfirmed",
    }
)


@dataclass
class PendingOperation:
    future: asyncio.Future[dict[str, Any]]
    extension: ServerConnection
    instance_id: str
    generation: int
    operation: str


@dataclass
class ExtensionPeer:
    websocket: ServerConnection
    instance_id: str
    extension_id: str
    version: str
    generation: int


class Broker:
    def __init__(
        self,
        token: bytes | None = None,
        *,
        journal_path: Path | None = None,
        terminal_grace_seconds: float = TERMINAL_GRACE_SECONDS,
    ) -> None:
        if (
            isinstance(terminal_grace_seconds, bool)
            or not isinstance(terminal_grace_seconds, (int, float))
            or not math.isfinite(terminal_grace_seconds)
            or terminal_grace_seconds <= 0
        ):
            raise ValueError("terminal grace must be a positive finite duration")
        self.token = token if token is not None else load_or_create_token()
        self.journal_path = journal_path
        self.terminal_grace_seconds = terminal_grace_seconds
        self.inbound_nonces = NonceReplayCache()
        self.extension: ServerConnection | None = None
        self.extension_id: str | None = None
        self.extension_version: str | None = None
        self.extension_ready = asyncio.Event()
        self.extension_generation = 0
        self.extensions: dict[str, ExtensionPeer] = {}
        self.pending: dict[str, PendingOperation] = {}
        self.operation_lock = asyncio.Lock()
        self.busy_request_id: str | None = None
        self.busy_operation: str | None = None
        self.quarantined = False
        self.quarantine_reason: str | None = None
        self.quarantine_request_id: str | None = None
        self.quarantine_since_ms: int | None = None
        if self.journal_path is not None:
            recovered = _read_inflight_journal(self.journal_path)
            if recovered is not None:
                self.quarantined = True
                self.quarantine_reason = "operation_state_uncertain"
                self.quarantine_request_id = str(recovered["id"])
                self.quarantine_since_ms = int(recovered["started_ms"])

    async def _send_signed(self, websocket: ServerConnection, payload: dict[str, Any]) -> bool:
        try:
            await websocket.send(_json(sign_envelope(payload, self.token)))
        except (ConnectionClosed, EnvelopeAuthenticationError, OSError, TypeError, ValueError):
            return False
        return True

    async def _reject(
        self,
        websocket: ServerConnection,
        code: str,
        message: str,
        *,
        request_id: str = "",
        close: bool = False,
    ) -> None:
        await self._send_signed(
            websocket,
            {
                "kind": "rpc_result",
                "id": request_id,
                "ok": False,
                "error": {"code": code, "message": message},
            },
        )
        if close:
            with contextlib.suppress(ConnectionClosed, OSError):
                await websocket.close(code=1008, reason=code)

    @staticmethod
    async def _cancel_task(task: asyncio.Task[Any]) -> None:
        if not task.done():
            task.cancel()
        with contextlib.suppress(asyncio.CancelledError):
            await task

    async def _wait_for_extension(
        self,
        websocket: ServerConnection,
        deadline: float,
        target_instance_id: str | None = None,
    ) -> str:
        loop = asyncio.get_running_loop()
        while loop.time() < deadline:
            if websocket.state is not State.OPEN:
                return "disconnected"
            if target_instance_id is not None:
                if target_instance_id in self.extensions:
                    return "ready"
            elif len(self.extensions) == 1:
                return "ready"
            elif len(self.extensions) > 1:
                return "ambiguous"
            await asyncio.sleep(min(0.1, max(0.0, deadline - loop.time())))
        return "timeout"

    def _sync_legacy_extension_view(self) -> None:
        """Keep the v1.6 single-extension attributes usable by old callers/tests."""

        peer = next(reversed(self.extensions.values()), None) if self.extensions else None
        self.extension = peer.websocket if peer else None
        self.extension_version = peer.version if peer else None
        if peer is not None:
            self.extension_generation = peer.generation
            self.extension_ready.set()
        else:
            self.extension_ready.clear()

    def _selected_extension(self, target_instance_id: str | None) -> ExtensionPeer | None:
        if target_instance_id is not None:
            return self.extensions.get(target_instance_id)
        if len(self.extensions) == 1:
            return next(iter(self.extensions.values()))
        return None

    async def _acquire_operation_lock(
        self,
        websocket: ServerConnection,
        deadline: float,
    ) -> str:
        acquire_task = asyncio.create_task(self.operation_lock.acquire())
        closed_task = asyncio.create_task(websocket.wait_closed())
        remaining = max(0.0, deadline - asyncio.get_running_loop().time())
        done, _ = await asyncio.wait(
            {acquire_task, closed_task},
            timeout=remaining,
            return_when=asyncio.FIRST_COMPLETED,
        )
        if closed_task in done:
            if acquire_task.done() and not acquire_task.cancelled() and acquire_task.result():
                self.operation_lock.release()
            else:
                await self._cancel_task(acquire_task)
            return "disconnected"
        if acquire_task in done:
            await self._cancel_task(closed_task)
            return "acquired"
        await self._cancel_task(acquire_task)
        await self._cancel_task(closed_task)
        return "timeout"

    async def _close_silent_extension(self, pending: PendingOperation) -> None:
        peer = self.extensions.get(pending.instance_id)
        if (
            peer is None
            or peer.websocket is not pending.extension
            or peer.generation != pending.generation
        ):
            return
        try:
            await asyncio.wait_for(
                pending.extension.close(code=1011, reason="terminal response timeout"),
                timeout=2.0,
            )
        except (ConnectionClosed, OSError, TimeoutError):
            transport = getattr(pending.extension, "transport", None)
            if transport is not None:
                transport.abort()
        finally:
            peer = self.extensions.get(pending.instance_id)
            if (
                peer is not None
                and peer.websocket is pending.extension
                and peer.generation == pending.generation
            ):
                self.extensions.pop(pending.instance_id, None)
                self._sync_legacy_extension_view()

    def _enter_quarantine(self, reason: str, request_id: str) -> None:
        self.quarantined = True
        self.quarantine_reason = reason
        self.quarantine_request_id = request_id
        self.quarantine_since_ms = int(time.time() * 1000)

    def _clear_quarantine(self, request_id: str) -> None:
        if self.quarantine_request_id != request_id:
            return
        self.quarantined = False
        self.quarantine_reason = None
        self.quarantine_request_id = None
        self.quarantine_since_ms = None

    def _record_inflight_write(self, operation: str, request_id: str) -> None:
        if self.journal_path is None:
            return
        _write_inflight_journal(
            self.journal_path,
            {
                "operation": operation,
                "id": request_id,
                "generation": self.extension_generation,
                "started_ms": int(time.time() * 1000),
            },
        )

    def _complete_inflight_write(self, request_id: str) -> None:
        if self.journal_path is not None:
            journal = _read_inflight_journal(self.journal_path)
            if journal is not None and journal["id"] != request_id:
                raise OSError("inflight journal request does not match terminal result")
            _clear_inflight_journal(self.journal_path)
        self._clear_quarantine(request_id)

    def _status_result(self) -> dict[str, Any]:
        return {
            "broker": "hongshuskill",
            "protocol": PROTOCOL_VERSION,
            "broker_version": EXTENSION_VERSION,
            "broker_pid": os.getpid(),
            "broker_parent_pid": os.getppid(),
            "extension_connected": self.extension is not None,
            "extension_version": self.extension_version,
            "extension_instances": [
                {"instance_id": peer.instance_id, "version": peer.version}
                for peer in self.extensions.values()
            ],
            "busy": self.busy_request_id is not None,
            "busy_operation": self.busy_operation,
            "quarantined": self.quarantined,
            "quarantine_reason": self.quarantine_reason,
            "quarantine_request_id": self.quarantine_request_id,
            "quarantine_since_ms": self.quarantine_since_ms,
        }

    async def handler(self, websocket: ServerConnection) -> None:
        try:
            raw = await asyncio.wait_for(websocket.recv(), timeout=8)
            hello = json.loads(raw)
            if not isinstance(hello, dict):
                raise ValueError("handshake must be an object")
        except (
            ConnectionClosed,
            TimeoutError,
            UnicodeError,
            json.JSONDecodeError,
            RecursionError,
            ValueError,
            TypeError,
        ):
            await websocket.close(code=1008, reason="invalid handshake")
            return

        request_id = str(hello.get("id", ""))[:128]
        try:
            hello = verify_envelope(hello, self.token, self.inbound_nonces)
        except EnvelopeAuthenticationError:
            await self._reject(
                websocket,
                "authentication_failed",
                "本地桥接认证失败",
                request_id=request_id,
                close=True,
            )
            return

        role = hello.get("role")
        if role == "extension":
            await self._serve_extension(websocket, hello)
        elif role == "client":
            await self._serve_client(websocket, hello)
        else:
            await self._reject(websocket, "invalid_role", "未知连接角色", request_id=request_id)

    async def _serve_extension(self, websocket: ServerConnection, hello: dict[str, Any]) -> None:
        origins = _request_origins(websocket)
        origin = origins[0] if len(origins) == 1 else None
        origin_match = re.fullmatch(r"chrome-extension://([a-p]{32})", origin or "")
        claimed_id = str(hello.get("extension_id", ""))
        raw_instance_id = hello.get("instance_id")
        # Protocol-2 test fixtures and older development builds did not send an
        # instance id.  They remain usable in single-profile mode only.
        instance_id = (
            raw_instance_id
            if isinstance(raw_instance_id, str) and re.fullmatch(r"[0-9a-f]{32}", raw_instance_id)
            else claimed_id
        )
        valid_origin = bool(origin_match and claimed_id == origin_match.group(1))
        valid_identity = (
            hello.get("name") == EXTENSION_NAME
            and hello.get("version") == EXTENSION_VERSION
            and hello.get("protocol") == PROTOCOL_VERSION
        )
        valid_pin = self.extension_id in {None, claimed_id}
        if not valid_origin or not valid_identity or not valid_pin:
            await self._reject(
                websocket,
                "pairing_rejected",
                "扩展身份校验失败",
                close=True,
            )
            return

        previous_peer = self.extensions.get(instance_id)
        if previous_peer and previous_peer.websocket is not websocket:
            instance_busy = any(
                pending.instance_id == instance_id for pending in self.pending.values()
            )
            if instance_busy:
                await self._reject(
                    websocket,
                    "broker_busy",
                    "浏览器操作执行期间不能替换扩展连接",
                    close=True,
                )
                return
            await previous_peer.websocket.close(code=1012, reason="new extension connection")

        self.extension_id = claimed_id
        self.extension_version = EXTENSION_VERSION
        self.extension_generation += 1
        generation = self.extension_generation
        self.extensions[instance_id] = ExtensionPeer(
            websocket=websocket,
            instance_id=instance_id,
            extension_id=claimed_id,
            version=EXTENSION_VERSION,
            generation=generation,
        )
        self._sync_legacy_extension_view()
        paired = await self._send_signed(
            websocket,
            {
                "ok": True,
                "kind": "paired",
                "protocol": PROTOCOL_VERSION,
                "extension_version": EXTENSION_VERSION,
            },
        )
        if not paired:
            peer = self.extensions.get(instance_id)
            if peer is not None and peer.websocket is websocket:
                self.extensions.pop(instance_id, None)
                self._sync_legacy_extension_view()
            return
        logger.info("paired extension %s instance %s", claimed_id, instance_id)

        try:
            async for raw in websocket:
                try:
                    message = json.loads(raw)
                    if not isinstance(message, dict):
                        raise EnvelopeAuthenticationError("extension response must be an object")
                    message = verify_envelope(message, self.token, self.inbound_nonces)
                except (
                    json.JSONDecodeError,
                    EnvelopeAuthenticationError,
                    RecursionError,
                    TypeError,
                    UnicodeError,
                ):
                    await websocket.close(code=1008, reason="invalid authenticated response")
                    break
                if _valid_extension_keepalive(message):
                    continue
                if not _valid_extension_result(message):
                    await websocket.close(code=1008, reason="invalid rpc result")
                    break
                request_id = message["id"]
                pending = self.pending.get(request_id)
                if (
                    pending
                    and pending.extension is websocket
                    and pending.generation == generation
                    and not pending.future.done()
                ):
                    pending.future.set_result(message)
        finally:
            peer = self.extensions.get(instance_id)
            if peer is not None and peer.websocket is websocket:
                self.extensions.pop(instance_id, None)
                self._sync_legacy_extension_view()
            for request_id, pending in tuple(self.pending.items()):
                if (
                    pending.extension is websocket
                    and pending.generation == generation
                    and not pending.future.done()
                ):
                    pending.future.set_result(
                        {
                            "kind": "bridge_internal",
                            "id": request_id,
                            "ok": False,
                            "error": {
                                "code": "extension_disconnected",
                                "message": "浏览器扩展在操作期间断开连接",
                            },
                        }
                    )
            logger.info("extension instance %s disconnected", instance_id)

    async def _serve_client(self, websocket: ServerConnection, request: dict[str, Any]) -> None:
        raw_request_id = request.get("id")
        raw_operation = request.get("op")
        request_id = raw_request_id if isinstance(raw_request_id, str) else ""
        if _request_origins(websocket):
            await self._reject(
                websocket,
                "origin_rejected",
                "仅允许本机 CLI 调用",
                request_id=request_id,
            )
            return
        if request.get("protocol") != PROTOCOL_VERSION:
            await self._reject(
                websocket,
                "protocol_mismatch",
                "通信协议版本不匹配",
                request_id=request_id,
            )
            return

        if (
            not isinstance(raw_request_id, str)
            or not raw_request_id
            or len(raw_request_id) > 128
            or not isinstance(raw_operation, str)
            or not raw_operation
            or len(raw_operation) > 64
        ):
            await self._reject(
                websocket,
                "invalid_request",
                "请求缺少合法的 id 或 op",
                request_id=request_id,
            )
            return

        operation = raw_operation
        params = request.get("params", {})
        if not isinstance(params, dict):
            await self._reject(
                websocket,
                "invalid_request",
                "请求参数必须是 JSON 对象",
                request_id=request_id,
            )
            return
        try:
            params_size = len(_json(params).encode("utf-8"))
        except (TypeError, ValueError, RecursionError):
            params_size = MAX_PARAMS_BYTES + 1
        if params_size > MAX_PARAMS_BYTES:
            await self._reject(
                websocket,
                "invalid_request",
                "请求参数超过安全大小限制或不是有效 JSON",
                request_id=request_id,
            )
            return
        target_instance_id = request.get("target_instance_id")
        if target_instance_id is not None and (
            not isinstance(target_instance_id, str)
            or not re.fullmatch(r"[0-9a-f]{32}", target_instance_id)
        ):
            await self._reject(
                websocket,
                "invalid_request",
                "目标扩展实例标识无效",
                request_id=request_id,
            )
            return
        account_guard = request.get("account_guard")
        if account_guard is not None and (
            not isinstance(account_guard, dict)
            or set(account_guard) != {"user_id", "session_fingerprint"}
            or not isinstance(account_guard.get("user_id"), str)
            or not re.fullmatch(r"[A-Za-z0-9_-]{1,128}", account_guard["user_id"])
            or not isinstance(account_guard.get("session_fingerprint"), str)
            or not re.fullmatch(r"[0-9a-f]{64}", account_guard["session_fingerprint"])
        ):
            await self._reject(
                websocket,
                "invalid_request",
                "账号安全路由信息无效",
                request_id=request_id,
            )
            return
        if operation == "broker_status":
            await self._send_signed(
                websocket,
                {
                    "kind": "rpc_result",
                    "id": request_id,
                    "ok": True,
                    "result": self._status_result(),
                },
            )
            return
        if operation not in OPERATION_ALLOWLIST:
            await self._reject(
                websocket,
                "operation_not_allowed",
                "请求的浏览器操作不在允许列表中",
                request_id=request_id,
            )
            return
        if operation == "broker_recover":
            expected_request_id = params.get("expected_request_id")
            if params.get("confirmed") is not True:
                await self._reject(
                    websocket,
                    "confirmation_required",
                    "解除桥接隔离状态需要明确确认",
                    request_id=request_id,
                )
                return
            if self.busy_request_id is not None or self.pending or self.operation_lock.locked():
                await self._reject(
                    websocket,
                    "broker_busy",
                    "浏览器操作仍在执行，不能解除隔离状态",
                    request_id=request_id,
                )
                return
            if not self.quarantined or self.quarantine_request_id is None:
                await self._reject(
                    websocket,
                    "no_quarantine",
                    "桥接当前没有需要解除的隔离状态",
                    request_id=request_id,
                )
                return
            if not isinstance(expected_request_id, str) or not re.fullmatch(
                r"[0-9a-f]{32}", expected_request_id
            ):
                await self._reject(
                    websocket,
                    "invalid_request",
                    "待恢复请求标识格式不正确",
                    request_id=request_id,
                )
                return
            if expected_request_id != self.quarantine_request_id:
                await self._reject(
                    websocket,
                    "recovery_request_mismatch",
                    "待恢复请求标识与当前隔离状态不匹配",
                    request_id=request_id,
                )
                return
            recovered_reason = self.quarantine_reason
            try:
                self._complete_inflight_write(self.quarantine_request_id)
            except OSError:
                await self._reject(
                    websocket,
                    "bridge_failure",
                    "无法安全清除桥接隔离记录",
                    request_id=request_id,
                )
                return
            await self._send_signed(
                websocket,
                {
                    "kind": "rpc_result",
                    "id": request_id,
                    "ok": True,
                    "result": {
                        "recovered": True,
                        "request_id": expected_request_id,
                        "previous_reason": recovered_reason,
                    },
                },
            )
            return
        requires_confirmation = operation in CONFIRMATION_REQUIRED_OPERATIONS or (
            operation == "check_risk" and params.get("active_probes") is True
        )
        if requires_confirmation and params.get("confirmed") is not True:
            await self._reject(
                websocket,
                "confirmation_required",
                "账号写操作缺少明确确认",
                request_id=request_id,
            )
            return
        if self.quarantined:
            await self._reject(
                websocket,
                "operation_quarantined",
                "上一浏览器操作的最终状态尚未确认",
                request_id=request_id,
            )
            return

        requested_timeout = request.get("timeout", 90)
        if (
            isinstance(requested_timeout, bool)
            or not isinstance(requested_timeout, (int, float))
            or not math.isfinite(requested_timeout)
            or not 1 <= requested_timeout <= 720
        ):
            await self._reject(
                websocket,
                "invalid_request",
                "timeout 必须是 1 到 720 之间的有限秒数",
                request_id=request_id,
            )
            return
        timeout = requested_timeout
        loop = asyncio.get_running_loop()
        deadline = loop.time() + timeout
        extension_deadline = min(deadline, loop.time() + 15.0)
        extension_state = await self._wait_for_extension(
            websocket,
            extension_deadline,
            target_instance_id,
        )
        if extension_state == "disconnected":
            return
        if extension_state == "timeout":
            await self._reject(
                websocket,
                "extension_unavailable",
                "红薯浏览器扩展未连接",
                request_id=request_id,
            )
            return
        if extension_state == "ambiguous":
            await self._reject(
                websocket,
                "account_required",
                "已连接多个 Chrome Profile；请显式指定账号",
                request_id=request_id,
            )
            return

        lock_state = await self._acquire_operation_lock(websocket, deadline)
        if lock_state == "disconnected":
            return
        if lock_state == "timeout":
            await self._reject(
                websocket,
                "operation_queue_timeout",
                "浏览器操作排队超时，操作尚未开始",
                request_id=request_id,
            )
            return

        broker_request_id: str | None = None
        pending: PendingOperation | None = None
        write_journal_recorded = False
        terminal_received = False
        try:
            if websocket.state is not State.OPEN:
                return
            if self.quarantined:
                await self._reject(
                    websocket,
                    "operation_quarantined",
                    "上一浏览器操作的最终状态尚未确认",
                    request_id=request_id,
                )
                return
            selected_peer = self._selected_extension(target_instance_id)
            if selected_peer is None:
                await self._reject(
                    websocket,
                    "extension_unavailable",
                    "红薯浏览器扩展未连接",
                    request_id=request_id,
                )
                return
            extension = selected_peer.websocket
            if loop.time() >= deadline:
                await self._reject(
                    websocket,
                    "operation_queue_timeout",
                    "浏览器操作排队超时，操作尚未开始",
                    request_id=request_id,
                )
                return

            future: asyncio.Future[dict[str, Any]] = loop.create_future()
            broker_request_id = uuid.uuid4().hex
            pending = PendingOperation(
                future=future,
                extension=extension,
                instance_id=selected_peer.instance_id,
                generation=selected_peer.generation,
                operation=operation,
            )
            self.pending[broker_request_id] = pending
            self.busy_request_id = broker_request_id
            self.busy_operation = operation
            envelope = {
                "kind": "rpc_request",
                "protocol": PROTOCOL_VERSION,
                "id": broker_request_id,
                "op": operation,
                "params": params,
            }
            if account_guard is not None:
                envelope["account_guard"] = account_guard
            if operation in UNCERTAIN_WRITE_OPERATIONS:
                try:
                    self._record_inflight_write(operation, broker_request_id)
                    write_journal_recorded = self.journal_path is not None
                except OSError:
                    await self._send_signed(
                        websocket,
                        {
                            "kind": "rpc_result",
                            "id": request_id,
                            "ok": False,
                            "error": {
                                "code": "bridge_failure",
                                "message": "无法安全记录账号写操作，操作尚未开始",
                            },
                        },
                    )
                    return
                if loop.time() >= deadline:
                    try:
                        self._complete_inflight_write(broker_request_id)
                        terminal_received = True
                    except OSError:
                        self._enter_quarantine("journal_cleanup_failed", broker_request_id)
                        await self._reject(
                            websocket,
                            "bridge_failure",
                            "请求已超时，且无法安全清除未转发的操作记录",
                            request_id=request_id,
                        )
                        return
                    await self._reject(
                        websocket,
                        "operation_queue_timeout",
                        "浏览器操作准备超时，操作尚未开始",
                        request_id=request_id,
                    )
                    return
            try:
                sent = await self._send_signed(extension, envelope)
                if not sent:
                    raise ConnectionError("extension connection closed before request send")
                remaining = max(0.0, deadline - loop.time())
                response = await asyncio.wait_for(asyncio.shield(future), timeout=remaining)
            except TimeoutError:
                self._enter_quarantine("operation_timeout", broker_request_id)
                await self._send_signed(
                    websocket,
                    {
                        "kind": "rpc_result",
                        "id": request_id,
                        "ok": False,
                        "error": {
                            "code": "operation_timeout",
                            "message": f"浏览器操作超时（{timeout:g} 秒）",
                        },
                    },
                )
                # Keep the operation slot until the authenticated extension reports a
                # matching terminal result. This prevents overlapping browser control.
                try:
                    response = await asyncio.wait_for(
                        asyncio.shield(future),
                        timeout=self.terminal_grace_seconds,
                    )
                except TimeoutError:
                    # A live WebSocket isn't proof that the page task can ever
                    # finish. Close only the generation that owns this request,
                    # then retain quarantine for explicit human recovery.
                    await self._close_silent_extension(pending)
                    return
                if response.get("kind") == "rpc_result":
                    terminal_received = True
                    if operation not in UNCERTAIN_WRITE_OPERATIONS:
                        self._clear_quarantine(broker_request_id)
                    # Once the client has observed a timeout, even a late signed
                    # success cannot prove what state the user saw or acted on.
                    # Keep write quarantine and its durable journal for explicit
                    # human verification and broker_recover.
                return
            except (ConnectionClosed, OSError, ConnectionError):
                if operation in UNCERTAIN_WRITE_OPERATIONS:
                    self._enter_quarantine("extension_disconnected", broker_request_id)
                response = {
                    "kind": "bridge_internal",
                    "id": broker_request_id,
                    "ok": False,
                    "error": {
                        "code": "bridge_failure",
                        "message": "浏览器扩展连接在请求期间中断",
                    },
                }
            if response.get("kind") == "rpc_result" and operation in UNCERTAIN_WRITE_OPERATIONS:
                terminal_received = True
                error = response.get("error") if response.get("ok") is False else None
                error_code = error.get("code") if isinstance(error, dict) else None
                if error_code in UNCERTAIN_TERMINAL_CODES:
                    self._enter_quarantine(str(error_code), broker_request_id)
                else:
                    try:
                        self._complete_inflight_write(broker_request_id)
                    except OSError:
                        self._enter_quarantine("journal_cleanup_failed", broker_request_id)
            if (
                response.get("kind") == "bridge_internal"
                and operation in UNCERTAIN_WRITE_OPERATIONS
            ):
                self._enter_quarantine(
                    str((response.get("error") or {}).get("code", "bridge_failure")),
                    broker_request_id,
                )
            client_response = {**response, "kind": "rpc_result", "id": request_id}
            await self._send_signed(websocket, client_response)
        finally:
            if (
                broker_request_id is not None
                and write_journal_recorded
                and not terminal_received
                and not self.quarantined
            ):
                self._enter_quarantine("operation_state_uncertain", broker_request_id)
            if broker_request_id is not None and self.pending.get(broker_request_id) is pending:
                self.pending.pop(broker_request_id, None)
            if self.busy_request_id == broker_request_id:
                self.busy_request_id = None
                self.busy_operation = None
            self.operation_lock.release()


def _json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, allow_nan=False, separators=(",", ":"))


def _request_origins(websocket: ServerConnection) -> list[str]:
    try:
        return websocket.request.headers.get_all("Origin")
    except (AttributeError, KeyError, TypeError, ValueError):
        # Malformed or multiply-encoded header state must fail closed.
        return ["<invalid-origin>"]


def _valid_extension_result(message: dict[str, Any]) -> bool:
    if (
        message.get("kind") != "rpc_result"
        or not isinstance(message.get("id"), str)
        or not re.fullmatch(r"[0-9a-f]{32}", message["id"])
        or not isinstance(message.get("ok"), bool)
    ):
        return False
    if message["ok"]:
        return set(message) == {"kind", "id", "ok", "result"} and isinstance(
            message.get("result"), dict
        )
    if set(message) != {"kind", "id", "ok", "error"}:
        return False
    error = message.get("error")
    if not isinstance(error, dict) or not {"code", "message"} <= set(error) <= {
        "code",
        "message",
        "details",
    }:
        return False
    code = error.get("code")
    error_message = error.get("message")
    details = error.get("details", {})
    return bool(
        isinstance(code, str)
        and ERROR_CODE_PATTERN.fullmatch(code)
        and isinstance(error_message, str)
        and 0 < len(error_message) <= MAX_ERROR_MESSAGE_LENGTH
        and isinstance(details, dict)
    )


def _valid_extension_keepalive(message: dict[str, Any]) -> bool:
    return (
        set(message) == {"kind", "protocol"}
        and message.get("kind") == "extension_keepalive"
        and message.get("protocol") == PROTOCOL_VERSION
    )


def _runtime_dir() -> Path:
    runtime_dir = Path(tempfile.gettempdir()) / "hongshuskill-runtime"
    if runtime_dir.is_symlink():
        raise OSError("runtime directory must not be a symlink")
    runtime_dir.mkdir(mode=0o700, parents=True, exist_ok=True)
    metadata = runtime_dir.lstat()
    if not stat.S_ISDIR(metadata.st_mode):
        raise OSError("runtime path must be a directory")
    if hasattr(os, "getuid") and metadata.st_uid != os.getuid():
        raise OSError("runtime directory must be owned by the current user")
    tighten_path(runtime_dir, 0o700)
    return runtime_dir


def _pid_path(port: int) -> Path:
    return _runtime_dir() / f"bridge-{port}.pid"


def _journal_path(port: int) -> Path:
    return _runtime_dir() / f"inflight-{port}.json"


def _validate_private_file(path: Path) -> os.stat_result:
    if path.is_symlink():
        raise OSError(f"{path.name} must not be a symlink")
    metadata = path.lstat()
    if not stat.S_ISREG(metadata.st_mode):
        raise OSError(f"{path.name} must be a regular file")
    if hasattr(os, "getuid") and metadata.st_uid != os.getuid():
        raise OSError(f"{path.name} must be owned by the current user")
    return metadata


def _atomic_write_private_json(path: Path, payload: dict[str, Any]) -> None:
    if path.exists() or path.is_symlink():
        _validate_private_file(path)
    descriptor: int | None = None
    temporary_path: Path | None = None
    try:
        descriptor, raw_path = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
        temporary_path = Path(raw_path)
        tighten_file_descriptor(descriptor)
        with os.fdopen(descriptor, "w", encoding="utf-8", closefd=True) as handle:
            descriptor = None
            handle.write(_json(payload) + "\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary_path, path)
        temporary_path = None
        _fsync_directory(path.parent)
    finally:
        if descriptor is not None:
            os.close(descriptor)
        if temporary_path is not None:
            with contextlib.suppress(OSError):
                temporary_path.unlink()


def _write_inflight_journal(path: Path, payload: dict[str, Any]) -> None:
    _atomic_write_private_json(path, payload)


def _read_inflight_journal(path: Path) -> dict[str, Any] | None:
    if not path.exists() and not path.is_symlink():
        return None
    metadata = _validate_private_file(path)
    if metadata.st_size > MAX_JOURNAL_BYTES:
        raise OSError("inflight journal is invalid")
    tighten_path(path, 0o600)
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise OSError("inflight journal is invalid") from exc
    if (
        not isinstance(payload, dict)
        or set(payload) != {"operation", "id", "generation", "started_ms"}
        or payload.get("operation") not in UNCERTAIN_WRITE_OPERATIONS
        or not isinstance(payload.get("id"), str)
        or not re.fullmatch(r"[0-9a-f]{32}", payload["id"])
        or isinstance(payload.get("generation"), bool)
        or not isinstance(payload.get("generation"), int)
        or payload["generation"] < 0
        or isinstance(payload.get("started_ms"), bool)
        or not isinstance(payload.get("started_ms"), int)
        or not 0 <= payload["started_ms"] <= (1 << 53) - 1
    ):
        raise OSError("inflight journal is invalid")
    return payload


def _clear_inflight_journal(path: Path) -> None:
    if not path.exists() and not path.is_symlink():
        return
    _validate_private_file(path)
    path.unlink()
    _fsync_directory(path.parent)


def _fsync_directory(path: Path) -> None:
    with contextlib.suppress(OSError):
        descriptor = os.open(path, os.O_RDONLY)
        try:
            os.fsync(descriptor)
        finally:
            os.close(descriptor)


def _write_pid(port: int) -> Path:
    path = _pid_path(port)
    if path.is_symlink():
        raise OSError("PID path must not be a symlink")
    if path.exists():
        metadata = path.lstat()
        if not stat.S_ISREG(metadata.st_mode):
            raise OSError("PID path must be a regular file")
        if hasattr(os, "getuid") and metadata.st_uid != os.getuid():
            raise OSError("PID file must be owned by the current user")
    descriptor: int | None = None
    temporary_path: Path | None = None
    try:
        descriptor, raw_path = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
        temporary_path = Path(raw_path)
        tighten_file_descriptor(descriptor)
        with os.fdopen(descriptor, "w", encoding="ascii", closefd=True) as handle:
            descriptor = None
            handle.write(str(os.getpid()))
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary_path, path)
        temporary_path = None
        _fsync_directory(path.parent)
    finally:
        if descriptor is not None:
            os.close(descriptor)
        if temporary_path is not None:
            with contextlib.suppress(OSError):
                temporary_path.unlink()
    return path


async def run(port: int) -> None:
    broker = Broker(journal_path=_journal_path(port))
    stop = asyncio.Event()
    loop = asyncio.get_running_loop()
    for sig in (signal.SIGINT, signal.SIGTERM):
        with contextlib.suppress(NotImplementedError):
            loop.add_signal_handler(sig, stop.set)

    pid_path: Path | None = None
    try:
        async with serve(
            broker.handler,
            "127.0.0.1",
            port,
            max_size=MAX_MESSAGE_BYTES,
            ping_interval=20,
            ping_timeout=20,
        ):
            # Only the process that successfully binds the port may publish its PID.
            pid_path = _write_pid(port)
            logger.info("broker listening on ws://127.0.0.1:%d", port)
            await stop.wait()
    finally:
        with contextlib.suppress(OSError, ValueError):
            if (
                pid_path is not None
                and not pid_path.is_symlink()
                and int(pid_path.read_text(encoding="ascii").strip()) == os.getpid()
            ):
                pid_path.unlink()
                _fsync_directory(pid_path.parent)


def main() -> None:
    parser = argparse.ArgumentParser(description="hongshuskill 本地浏览器桥接服务")
    parser.add_argument("--port", type=int, default=9345)
    parser.add_argument("--verbose", action="store_true")
    args = parser.parse_args()
    logging.basicConfig(level=logging.DEBUG if args.verbose else logging.INFO)
    asyncio.run(run(args.port))


if __name__ == "__main__":
    main()
