#!/usr/bin/env python3
"""Build a clean, version-consistent hongshuskill release archive."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import tempfile
import tomllib
import zipfile
from pathlib import Path, PurePosixPath
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
RELEASE_ROOT = "hongshuskill"
INCLUDED_TOP_LEVEL = (
    "SKILL.md",
    "agents",
    "extension",
    "pyproject.toml",
    "references",
    "scripts",
    "tests",
    "uv.lock",
)
EXCLUDED_DIRECTORIES = {".git", ".pytest_cache", ".ruff_cache", ".venv", "__pycache__"}
EXCLUDED_FILES = {".pairing.json.lock"}
VERSION_PATTERN = re.compile(r"[0-9]+\.[0-9]+\.[0-9]+")
PAIRING_PATTERN = re.compile(r"[0-9a-f]{64}")
FIXED_ZIP_TIMESTAMP = (2020, 1, 1, 0, 0, 0)


class ReleaseValidationError(ValueError):
    """The source tree or generated archive is unsafe to release."""


def _read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8-sig")


def _required_match(path: Path, pattern: str, label: str) -> str:
    match = re.search(pattern, _read_text(path), flags=re.MULTILINE)
    if match is None:
        raise ReleaseValidationError(f"cannot read {label} version")
    return match.group(1)


def source_versions(root: Path = ROOT) -> dict[str, str]:
    project = tomllib.loads(_read_text(root / "pyproject.toml"))
    manifest = json.loads(_read_text(root / "extension" / "manifest.json"))
    lock = tomllib.loads(_read_text(root / "uv.lock"))
    locked_project = next(
        (item for item in lock.get("package", []) if item.get("name") == "hongshuskill"),
        None,
    )
    if not isinstance(locked_project, dict) or not isinstance(locked_project.get("version"), str):
        raise ReleaseValidationError("cannot read lockfile project version")
    return {
        "pyproject": str(project["project"]["version"]),
        "lockfile": locked_project["version"],
        "manifest": str(manifest["version"]),
        "package": _required_match(
            root / "scripts" / "hongshu" / "__init__.py",
            r'^VERSION = "([^"]+)"',
            "package",
        ),
        "broker": _required_match(
            root / "scripts" / "bridge_server.py",
            r'^EXTENSION_VERSION = "([^"]+)"',
            "broker",
        ),
        "extension": _required_match(
            root / "extension" / "worker.js",
            r'^const EXTENSION_VERSION = "([^"]+)";',
            "extension",
        ),
        "skill_output": _required_match(
            root / "SKILL.md",
            r'"meta": \{"version": "([^"]+)"',
            "skill output",
        ),
    }


def validate_source(expected_version: str, root: Path = ROOT) -> None:
    if VERSION_PATTERN.fullmatch(expected_version) is None:
        raise ReleaseValidationError("release version must use MAJOR.MINOR.PATCH")
    versions = source_versions(root)
    mismatches = {name: value for name, value in versions.items() if value != expected_version}
    if mismatches:
        detail = ", ".join(f"{name}={value}" for name, value in sorted(mismatches.items()))
        raise ReleaseValidationError(f"release version mismatch: {detail}")

    pairing_path = root / "extension" / "pairing.json"
    pairing = json.loads(_read_text(pairing_path))
    token = pairing.get("token")
    if not isinstance(token, str) or (token and PAIRING_PATTERN.fullmatch(token) is None):
        raise ReleaseValidationError("pairing template is invalid")


def _is_excluded(relative: Path) -> bool:
    return (
        any(part in EXCLUDED_DIRECTORIES for part in relative.parts)
        or relative.name in EXCLUDED_FILES
        or relative.suffix == ".pyc"
    )


def release_files(root: Path = ROOT) -> list[Path]:
    files: list[Path] = []
    for name in INCLUDED_TOP_LEVEL:
        item = root / name
        if not item.exists():
            raise ReleaseValidationError(f"required release item is missing: {name}")
        candidates = [item] if item.is_file() else item.rglob("*")
        for candidate in candidates:
            if candidate.is_symlink():
                raise ReleaseValidationError(
                    f"release tree must not contain symlinks: {candidate.relative_to(root)}"
                )
            if not candidate.is_file():
                continue
            relative = candidate.relative_to(root)
            if not _is_excluded(relative):
                files.append(candidate)
    return sorted(files, key=lambda path: path.relative_to(root).as_posix())


def _archive_bytes(path: Path, root: Path) -> bytes:
    relative = path.relative_to(root).as_posix()
    if relative == "extension/pairing.json":
        return b'{"token":""}\n'
    return path.read_bytes()


def _zip_info(archive_name: str, *, executable: bool) -> zipfile.ZipInfo:
    info = zipfile.ZipInfo(archive_name, FIXED_ZIP_TIMESTAMP)
    info.compress_type = zipfile.ZIP_DEFLATED
    info.create_system = 3
    mode = 0o755 if executable else 0o644
    info.external_attr = (mode & 0xFFFF) << 16
    return info


def validate_archive(path: Path, expected_version: str) -> dict[str, Any]:
    with zipfile.ZipFile(path) as archive:
        names = archive.namelist()
        if len(names) != len(set(names)):
            raise ReleaseValidationError("release archive contains duplicate paths")
        if not names or any(
            not name.startswith(f"{RELEASE_ROOT}/") or "\\" in name for name in names
        ):
            raise ReleaseValidationError("release archive has an invalid root layout")
        for name in names:
            relative = Path(PurePosixPath(name).relative_to(RELEASE_ROOT).as_posix())
            if _is_excluded(relative):
                raise ReleaseValidationError(f"release archive contains forbidden file: {name}")

        pairing = json.loads(archive.read(f"{RELEASE_ROOT}/extension/pairing.json"))
        if pairing != {"token": ""}:
            raise ReleaseValidationError("release archive contains a generated pairing token")
        manifest = json.loads(archive.read(f"{RELEASE_ROOT}/extension/manifest.json"))
        if manifest.get("version") != expected_version:
            raise ReleaseValidationError("release archive manifest version is inconsistent")

    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    return {
        "archive": str(path),
        "version": expected_version,
        "file_count": len(names),
        "sha256": digest,
    }


def build_release(output: Path, expected_version: str, root: Path = ROOT) -> dict[str, Any]:
    root = root.resolve()
    output = output.resolve()
    validate_source(expected_version, root)
    files = release_files(root)
    output.parent.mkdir(parents=True, exist_ok=True)

    temporary: Path | None = None
    try:
        descriptor, raw_path = tempfile.mkstemp(
            prefix=f".{output.name}.", suffix=".tmp", dir=output.parent
        )
        os.close(descriptor)
        temporary = Path(raw_path)
        with zipfile.ZipFile(temporary, "w", compresslevel=9) as archive:
            for path in files:
                relative = path.relative_to(root)
                archive_name = str(PurePosixPath(RELEASE_ROOT, *relative.parts))
                executable = relative.as_posix() in {
                    "scripts/build_release.py",
                    "scripts/run-hongshu",
                }
                archive.writestr(
                    _zip_info(archive_name, executable=executable),
                    _archive_bytes(path, root),
                )
        result = validate_archive(temporary, expected_version)
        os.replace(temporary, output)
        temporary = None
        result["archive"] = str(output)
        return result
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--version", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    result = build_release(args.output, args.version)
    print(json.dumps(result, ensure_ascii=False, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
