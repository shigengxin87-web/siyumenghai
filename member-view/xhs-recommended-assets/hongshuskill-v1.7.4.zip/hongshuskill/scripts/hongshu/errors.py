"""Typed user-facing failures and stable process exit codes."""

from __future__ import annotations

from typing import Any


class HongshuError(Exception):
    code = "hongshu_error"
    exit_status = 2

    def __init__(self, message: str, *, details: dict[str, Any] | None = None) -> None:
        super().__init__(message)
        self.message = message
        self.details = details or {}


class AuthenticationRequired(HongshuError):
    code = "authentication_required"
    exit_status = 1


class InvalidInput(HongshuError):
    code = "invalid_input"
    exit_status = 2


class BridgeUnavailable(HongshuError):
    code = "bridge_unavailable"
    exit_status = 3


class BrowserOperationFailed(HongshuError):
    code = "browser_operation_failed"
    exit_status = 4


class RiskControlActive(HongshuError):
    code = "risk_control_active"
    exit_status = 4


class ConfirmationRequired(HongshuError):
    code = "confirmation_required"
    exit_status = 5
