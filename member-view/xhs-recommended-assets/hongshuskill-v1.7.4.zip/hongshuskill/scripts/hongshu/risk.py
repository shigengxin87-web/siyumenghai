"""Turn privacy-preserving network metadata into an actionable risk summary."""

from __future__ import annotations

import math
import time
from collections import Counter
from typing import Any
from urllib.parse import urlparse

BLOCKING_STATUSES = {401, 403, 404, 429, 461, 999}
RISK_WINDOW_MINUTES = 15
HISTORICAL_WINDOW_HOURS = 24
_MILLISECONDS_THRESHOLD = 100_000_000_000
_FUTURE_SKEW_MS = 5 * 60 * 1000


def _status_code(item: dict[str, Any]) -> int:
    try:
        value = item.get("status", 0)
        if isinstance(value, bool):
            return 0
        status = int(value or 0)
        return status if 0 <= status <= 999 else 0
    except (TypeError, ValueError, OverflowError):
        return 0


def _is_benign_transport_error(item: dict[str, Any]) -> bool:
    error = str(item.get("error", ""))
    url = str(item.get("url", ""))
    category = str(item.get("category", ""))
    if category == "telemetry" and error:
        return True
    if error == "net::ERR_ABORTED":
        return True
    return error == "net::ERR_FAILED" and category == "creator" and url.endswith("/worker.js")


def _entry_key(item: dict[str, Any]) -> tuple[Any, ...]:
    """Identify the same privacy-reduced event across the rolling and preserved stores."""
    return (
        item.get("timestamp"),
        str(item.get("method", "")),
        str(item.get("url", "")),
        _status_code(item),
        str(item.get("error", "")),
        str(item.get("category", "")),
        item.get("tab_id"),
    )


def _dedupe_entries(entries: list[dict[str, Any]]) -> list[dict[str, Any]]:
    seen: set[tuple[Any, ...]] = set()
    unique: list[dict[str, Any]] = []
    for item in entries:
        key = _entry_key(item)
        if key in seen:
            continue
        seen.add(key)
        unique.append(item)
    return unique


def _merge_entries(
    entries: list[dict[str, Any]],
    risk_events: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    return _dedupe_entries([*entries, *risk_events])


def _timestamp_ms(item: dict[str, Any]) -> float | None:
    raw_timestamp = item.get("timestamp")
    if raw_timestamp in (None, ""):
        # Hand-authored/imported evidence without a timestamp remains useful instead of
        # silently producing a false-safe report.
        return None
    try:
        timestamp = float(raw_timestamp)
    except (TypeError, ValueError):
        return None
    if not math.isfinite(timestamp):
        return None
    if timestamp < _MILLISECONDS_THRESHOLD:
        timestamp *= 1000
    return timestamp


def _safe_hostname(raw_url: Any) -> str:
    try:
        return urlparse(str(raw_url or "")).hostname or "unknown"
    except (TypeError, ValueError):
        return "unknown"


def _is_in_current_window(item: dict[str, Any], *, now_ms: float) -> bool:
    timestamp = _timestamp_ms(item)
    if timestamp is None:
        return True
    if timestamp > now_ms + _FUTURE_SKEW_MS:
        return False
    cutoff = now_ms - RISK_WINDOW_MINUTES * 60 * 1000
    return timestamp >= cutoff


def _is_in_historical_window(item: dict[str, Any], *, now_ms: float) -> bool:
    timestamp = _timestamp_ms(item)
    if timestamp is None:
        return True
    if timestamp > now_ms + _FUTURE_SKEW_MS:
        return False
    cutoff = now_ms - HISTORICAL_WINDOW_HOURS * 60 * 60 * 1000
    return timestamp >= cutoff


def _signal_summary(entries: list[dict[str, Any]]) -> dict[str, Any]:
    statuses = Counter(_status_code(item) for item in entries)
    ignored_failures = [
        item for item in entries if item.get("error") and _is_benign_transport_error(item)
    ]
    failures = [
        item
        for item in entries
        if _status_code(item) in BLOCKING_STATUSES
        or (item.get("error") and not _is_benign_transport_error(item))
    ]

    signals: list[dict[str, Any]] = []
    if statuses[461] or statuses[999]:
        signals.append(
            {
                "severity": "high",
                "signal": "平台风控响应",
                "count": statuses[461] + statuses[999],
            }
        )
    if statuses[429]:
        signals.append({"severity": "high", "signal": "请求频率过高", "count": statuses[429]})
    if statuses[403] or statuses[401]:
        signals.append(
            {
                "severity": "medium",
                "signal": "认证或访问被拒绝",
                "count": statuses[403] + statuses[401],
            }
        )
    if statuses[404]:
        signals.append({"severity": "low", "signal": "接口或资源不存在", "count": statuses[404]})
    transport_failures = [
        item for item in entries if item.get("error") and not _is_benign_transport_error(item)
    ]
    if transport_failures:
        signals.append(
            {
                "severity": "low",
                "signal": "网络请求失败",
                "count": len(transport_failures),
            }
        )

    if not entries:
        level = "unknown"
    elif any(signal["severity"] == "high" for signal in signals):
        level = "high"
    elif any(signal["severity"] == "medium" for signal in signals):
        level = "medium"
    elif signals:
        level = "low"
    else:
        level = "safe"

    high_risk_signals = [
        f"{signal['signal']}（{signal['count']} 次）"
        for signal in signals
        if signal["severity"] == "high"
    ]
    return {
        "level": level,
        "statuses": statuses,
        "signals": signals,
        "failures": failures,
        "ignored_failures": ignored_failures,
        "high_risk_signals": high_risk_signals,
    }


def _detection_axes(entries: list[dict[str, Any]]) -> dict[str, Any]:
    shield = [
        item for item in entries if "/api/sec/v1/shield/webprofile" in str(item.get("url", ""))
    ]
    behavior = [item for item in entries if _safe_hostname(item.get("url")) == "t2.xiaohongshu.com"]
    apm = [item for item in entries if _safe_hostname(item.get("url")) == "apm-fe.xiaohongshu.com"]
    axes: dict[str, Any] = {
        "privacy_scope": {
            "query_strings": "not_collected",
            "request_headers": "not_collected",
            "cookies": "not_collected",
            "request_bodies": "not_collected",
            "evidence": "报告只使用时间、方法、去查询参数路径、状态码、错误和类别。",
        }
    }
    if shield:
        axes["browser_fingerprint"] = {
            "endpoint": "/api/sec/v1/shield/webprofile",
            "called_count": len(shield),
            "evidence": "观察到平台浏览器指纹端点；未采集其请求内容。",
        }
    if behavior:
        axes["behavior_tracking"] = {
            "host": "t2.xiaohongshu.com",
            "called_count": len(behavior),
            "evidence": "观察到平台行为遥测流量；未采集事件正文。",
        }
    if apm:
        axes["apm_monitoring"] = {
            "host": "apm-fe.xiaohongshu.com",
            "called_count": len(apm),
            "evidence": "观察到平台前端监控流量；未采集会话标识或上报正文。",
        }
    return axes


def build_risk_report(entries: Any, risk_events: Any = None) -> dict[str, Any]:
    now_ms = time.time() * 1000
    if not isinstance(entries, list):
        entries = []
        malformed_count = 1
    else:
        malformed_count = 0
    malformed_count += sum(not isinstance(item, dict) for item in entries)
    clean_entries = [item for item in entries if isinstance(item, dict)]
    if risk_events is None:
        raw_risk_events = []
    elif isinstance(risk_events, list):
        raw_risk_events = risk_events
    else:
        raw_risk_events = []
        malformed_count += 1
    malformed_count += sum(not isinstance(item, dict) for item in raw_risk_events)
    clean_risk_events = [item for item in raw_risk_events if isinstance(item, dict)]
    preserved_all = _dedupe_entries(clean_risk_events)
    evidence_all = _merge_entries(clean_entries, preserved_all)
    future_count = sum(
        (timestamp := _timestamp_ms(item)) is not None and timestamp > now_ms + _FUTURE_SKEW_MS
        for item in evidence_all
    )
    evidence = [item for item in evidence_all if _is_in_historical_window(item, now_ms=now_ms)]
    preserved = [item for item in preserved_all if _is_in_historical_window(item, now_ms=now_ms)]
    if not evidence:
        expired = bool(evidence_all)
        return {
            "risk_level": "unknown",
            "historical_risk_level": "unknown",
            "network_window_minutes": RISK_WINDOW_MINUTES,
            "historical_window_hours": HISTORICAL_WINDOW_HOURS,
            "sample_size": 0,
            "active_sample_size": 0,
            "preserved_risk_event_count": 0,
            "total_requests": len(clean_entries),
            "summary": (
                "现有网络记录均已超过 24 小时，无法判断当前会话风险。"
                if expired
                else "未采集到网络记录，无法判断会话风险。"
            ),
            "status_counts": {},
            "signals": [],
            "historical_signals": [],
            "recent_failures": [],
            "ignored_navigation_failures": 0,
            "detection_axes": {},
            "category_distribution": {},
            "top_hosts": {},
            "high_risk_signals": [],
            "historical_high_risk_signals": [],
            "warnings": [
                (
                    "24 小时内没有可用网络记录；先进行一次只读浏览，再重新生成报告。"
                    if expired
                    else "网络日志为空；先进行一次只读浏览，再重新生成报告。"
                ),
                *([f"已忽略 {malformed_count} 条格式损坏的网络记录。"] if malformed_count else []),
                *([f"已忽略 {future_count} 条时间明显超前的网络记录。"] if future_count else []),
            ],
            "recommendation": _recommendation("unknown"),
        }

    active = [item for item in evidence if _is_in_current_window(item, now_ms=now_ms)]
    current = _signal_summary(active)
    historical = _signal_summary(evidence)

    statuses = historical["statuses"]
    categories = Counter(str(item.get("category", "other") or "other") for item in evidence)
    hosts = Counter(_safe_hostname(item.get("url")) for item in evidence)
    axes = _detection_axes(evidence)

    warnings: list[str] = []
    if malformed_count:
        warnings.append(f"已忽略 {malformed_count} 条格式损坏的网络记录。")
    if future_count:
        warnings.append(f"已忽略 {future_count} 条时间明显超前的网络记录。")
    behavior_count = axes.get("behavior_tracking", {}).get("called_count", 0)
    if len(active) > 20 and not behavior_count:
        warnings.append("当前样本未观察到 t2 行为遥测；可能是样本窗口较短或页面尚未产生事件。")
    if not active:
        warnings.append(
            f"最近 {RISK_WINDOW_MINUTES} 分钟没有可用证据；当前风险为 unknown，不能解释为安全。"
        )
    if historical["level"] == "high" and current["level"] != "high":
        warnings.append(
            "保留记录中存在历史高风险响应，但当前窗口已无同等级信号；"
            "这不等于账号状态已恢复，继续前应由用户检查。"
        )

    if active:
        summary = (
            f"滚动日志 {len(clean_entries)} 条，合并保留事件后去重为 {len(evidence)} 条；"
            f"最近 {RISK_WINDOW_MINUTES} 分钟有 {len(active)} 条证据，"
            f"其中 {len(current['failures'])} 条需关注失败，"
            f"忽略 {len(current['ignored_failures'])} 条正常导航中断。"
        )
    else:
        summary = (
            f"滚动日志 {len(clean_entries)} 条，合并保留事件后去重为 {len(evidence)} 条；"
            f"最近 {RISK_WINDOW_MINUTES} 分钟无可用证据。"
        )

    return {
        "risk_level": current["level"],
        "historical_risk_level": historical["level"],
        "network_window_minutes": RISK_WINDOW_MINUTES,
        "historical_window_hours": HISTORICAL_WINDOW_HOURS,
        "sample_size": len(evidence),
        "active_sample_size": len(active),
        "preserved_risk_event_count": len(preserved),
        "total_requests": len(clean_entries),
        "summary": summary,
        "status_counts": {str(key): value for key, value in sorted(statuses.items()) if key},
        "signals": current["signals"],
        "historical_signals": historical["signals"],
        "recent_failures": current["failures"][-20:],
        "ignored_navigation_failures": len(current["ignored_failures"]),
        "detection_axes": axes,
        "category_distribution": dict(categories),
        "top_hosts": dict(hosts.most_common(10)),
        "high_risk_signals": current["high_risk_signals"],
        "historical_high_risk_signals": historical["high_risk_signals"],
        "warnings": warnings,
        "recommendation": _recommendation(current["level"]),
    }


def _recommendation(level: str) -> str:
    return {
        "unknown": "先进行一次只读浏览以形成样本；不要把缺少日志解释为安全。",
        "safe": "未发现明显异常；仍应保持人工节奏和小批量操作。",
        "low": "存在轻微异常；检查目标链接并放慢操作频率。",
        "medium": "暂停连续操作，确认登录状态和页面可访问性后再继续。",
        "high": "立即停止自动化操作，等待一段时间并由用户在浏览器中检查账号状态。",
    }[level]
