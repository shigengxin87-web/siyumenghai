"""Start the local broker when needed and make one typed RPC call."""

from __future__ import annotations

import asyncio
import json
import math
import os
import re
import shutil
import signal
import socket
import stat
import subprocess
import sys
import tempfile
import time
import uuid
from pathlib import Path
from urllib.parse import urlparse

from websockets.asyncio.client import connect

from . import DEFAULT_BRIDGE_PORT, DEFAULT_BRIDGE_URL, VERSION
from .auth import (
    EnvelopeAuthenticationError,
    NonceReplayCache,
    load_or_create_token,
    sign_envelope,
    unsigned_envelope,
    verify_envelope,
)
from .errors import (
    AuthenticationRequired,
    BridgeUnavailable,
    BrowserOperationFailed,
    ConfirmationRequired,
    InvalidInput,
    RiskControlActive,
)

MAX_MESSAGE_BYTES = 8 * 1024 * 1024
MAX_PARAMS_BYTES = 1024 * 1024
PROTOCOL_VERSION = 2
RESPONSE_NONCES = NonceReplayCache()
ERROR_CODE_PATTERN = re.compile(r"[a-z][a-z0-9_]{0,63}")
MAX_ERROR_MESSAGE_LENGTH = 512
MAX_DETAIL_STRING_LENGTH = 512
MAX_DETAIL_ITEMS = 64
MAX_DETAIL_DEPTH = 4
SENSITIVE_DETAIL_TERMS = (
    "authorization",
    "password",
    "secret",
    "token",
    "cookie",
    "content",
    "body",
    "payload",
    "html",
    "令牌",
    "密码",
    "内容",
    "正文",
)
SENSITIVE_VALUE_PATTERN = re.compile(
    r"(?i)(?:bearer\s+\S+|(?:web_session|webid|a1|gid|xsecappid)\s*=\s*[^;\s]+|"
    r"\b[0-9a-f]{64}\b)"
)
UNCERTAIN_WRITE_OPERATIONS = frozenset(
    {
        "send_code",
        "verify_code",
        "delete_cookies",
        "post_comment",
        "reply_comment",
        "set_like",
        "set_favorite",
        "fill_image",
        "publish_image",
        "fill_video",
        "publish_video",
        "click_publish",
        "save_draft",
        "fill_long_article",
        "select_template",
        "long_article_next",
    }
)


def _is_windows() -> bool:
    return os.name == "nt"


UNCERTAIN_REMOTE_CODES = frozenset(
    {
        "bridge_failure",
        "comment_submission_unconfirmed",
        "draft_submission_uncertain",
        "extension_disconnected",
        "logout_unconfirmed",
        "operation_timeout",
        "operation_quarantined",
        "operation_state_uncertain",
        "publish_submission_uncertain",
        "state_not_changed",
        "state_not_persisted",
        "submission_state_uncertain",
        "submission_unconfirmed",
    }
)


def _validate_bridge_url(url: str) -> tuple[str, int]:
    parsed = urlparse(url)
    try:
        port = parsed.port if parsed.port is not None else DEFAULT_BRIDGE_PORT
    except ValueError as exc:
        raise BridgeUnavailable("bridge URL 端口不正确") from exc
    if (
        parsed.scheme != "ws"
        or parsed.hostname not in {"127.0.0.1", "localhost", "::1"}
        or parsed.username
        or parsed.password
        or parsed.netloc.endswith(":")
        or parsed.netloc.endswith("]:")
        or parsed.path not in {"", "/"}
        or parsed.params
        or parsed.query
        or parsed.fragment
        or not 1 <= port <= 65535
    ):
        raise BridgeUnavailable("bridge URL 只能指向本机 ws:// 地址")
    # The broker always binds IPv4 loopback. Canonicalizing every accepted local
    # spelling avoids localhost preferring ::1 and makes process/PID checks agree.
    return f"ws://127.0.0.1:{port}", port


def _sanitize_detail_value(value: object, *, depth: int = 0) -> object:
    if depth >= MAX_DETAIL_DEPTH:
        return "[omitted: nesting limit]"
    if value is None or isinstance(value, (bool, int)):
        return value
    if isinstance(value, float):
        return value if math.isfinite(value) else "[omitted: non-finite number]"
    if isinstance(value, str):
        if len(value) > MAX_DETAIL_STRING_LENGTH:
            return f"[omitted: {len(value)} characters]"
        if SENSITIVE_VALUE_PATTERN.search(value):
            return "[redacted]"
        return value
    if isinstance(value, list):
        sanitized = [
            _sanitize_detail_value(item, depth=depth + 1) for item in value[:MAX_DETAIL_ITEMS]
        ]
        if len(value) > MAX_DETAIL_ITEMS:
            sanitized.append(f"[omitted: {len(value) - MAX_DETAIL_ITEMS} items]")
        return sanitized
    if isinstance(value, dict):
        sanitized_dict: dict[str, object] = {}
        for key, item in list(value.items())[:MAX_DETAIL_ITEMS]:
            folded = key.casefold()
            if any(term in folded for term in SENSITIVE_DETAIL_TERMS):
                sanitized_dict[key] = "[redacted]"
            else:
                sanitized_dict[key] = _sanitize_detail_value(item, depth=depth + 1)
        if len(value) > MAX_DETAIL_ITEMS:
            sanitized_dict["_omitted_items"] = len(value) - MAX_DETAIL_ITEMS
        return sanitized_dict
    return "[omitted: unsupported value]"


def _sanitize_error_message(message: str) -> str:
    if len(message) > MAX_ERROR_MESSAGE_LENGTH:
        return "浏览器操作失败（远程错误信息过长，已隐藏）"
    return SENSITIVE_VALUE_PATTERN.sub("[redacted]", message)


def _validate_rpc_response(response: dict, expected_id: str) -> dict:
    if response.get("kind") != "rpc_result":
        raise EnvelopeAuthenticationError("broker response kind is invalid")
    if response.get("id") != expected_id:
        raise EnvelopeAuthenticationError("broker response id does not match the request")
    ok = response.get("ok")
    if not isinstance(ok, bool):
        raise EnvelopeAuthenticationError("broker response ok flag is invalid")
    if ok:
        if not isinstance(response.get("result"), dict):
            raise EnvelopeAuthenticationError("successful broker response result must be an object")
        return response

    error = response.get("error")
    if not isinstance(error, dict):
        raise EnvelopeAuthenticationError("failed broker response error must be an object")
    code = error.get("code")
    message = error.get("message")
    details = error.get("details", {})
    if not isinstance(code, str) or not ERROR_CODE_PATTERN.fullmatch(code):
        raise EnvelopeAuthenticationError("broker error code is invalid")
    if not isinstance(message, str) or not message:
        raise EnvelopeAuthenticationError("broker error message is invalid")
    if not isinstance(details, dict):
        raise EnvelopeAuthenticationError("broker error details must be an object")
    sanitized_details = _sanitize_detail_value(details)
    if not isinstance(sanitized_details, dict):  # pragma: no cover - guarded above
        raise EnvelopeAuthenticationError("broker error details are invalid")
    return {
        "kind": "rpc_result",
        "id": expected_id,
        "ok": False,
        "error": {
            "code": code,
            "message": _sanitize_error_message(message),
            "details": sanitized_details,
        },
    }


def _valid_status_result(result: dict) -> bool:
    optional_strings = (
        result.get("extension_version"),
        result.get("busy_operation"),
        result.get("quarantine_reason"),
    )
    request_id = result.get("quarantine_request_id")
    since_ms = result.get("quarantine_since_ms")
    instances = result.get("extension_instances", [])
    return bool(
        result.get("broker") == "hongshuskill"
        and result.get("protocol") == PROTOCOL_VERSION
        and isinstance(result.get("broker_version"), str)
        and 0 < len(result["broker_version"]) <= 64
        and isinstance(result.get("extension_connected"), bool)
        and all(
            value is None or (isinstance(value, str) and len(value) <= 128)
            for value in optional_strings
        )
        and isinstance(result.get("busy"), bool)
        and isinstance(result.get("quarantined"), bool)
        and isinstance(instances, list)
        and all(
            isinstance(item, dict)
            and set(item) == {"instance_id", "version"}
            and isinstance(item.get("instance_id"), str)
            and len(item["instance_id"]) == 32
            and isinstance(item.get("version"), str)
            and 0 < len(item["version"]) <= 64
            for item in instances
        )
        and (
            request_id is None
            or (isinstance(request_id, str) and re.fullmatch(r"[0-9a-f]{32}", request_id))
        )
        and (
            since_ms is None
            or (
                isinstance(since_ms, int)
                and not isinstance(since_ms, bool)
                and 0 <= since_ms <= (1 << 53) - 1
            )
        )
        and (not result["busy"] or isinstance(result.get("busy_operation"), str))
        and (result["busy"] or result.get("busy_operation") is None)
        and (
            not result["quarantined"]
            or (
                isinstance(result.get("quarantine_reason"), str)
                and isinstance(request_id, str)
                and since_ms is not None
            )
        )
        and (
            result["quarantined"]
            or (result.get("quarantine_reason") is None and request_id is None and since_ms is None)
        )
    )


async def _exchange(url: str, payload: dict, timeout: float) -> dict:
    token = load_or_create_token()
    signed_payload = sign_envelope(payload, token)
    async with connect(
        url,
        open_timeout=min(timeout, 5.0),
        close_timeout=2,
        max_size=MAX_MESSAGE_BYTES,
    ) as websocket:
        await websocket.send(
            json.dumps(signed_payload, ensure_ascii=False, allow_nan=False, separators=(",", ":"))
        )
        raw = await asyncio.wait_for(websocket.recv(), timeout=timeout)
    response = json.loads(raw)
    if not isinstance(response, dict):
        raise EnvelopeAuthenticationError("broker response must be an object")
    return verify_envelope(response, token, RESPONSE_NONCES)


async def _legacy_exchange(url: str, payload: dict, timeout: float) -> dict:
    """Probe protocol v1 only to identify a managed broker that needs manual shutdown."""

    async with connect(
        url,
        open_timeout=min(timeout, 2.0),
        close_timeout=1,
        max_size=1024 * 1024,
    ) as websocket:
        await websocket.send(
            json.dumps(payload, ensure_ascii=False, allow_nan=False, separators=(",", ":"))
        )
        raw = await asyncio.wait_for(websocket.recv(), timeout=timeout)
    response = json.loads(raw)
    if not isinstance(response, dict) or "auth" in response:
        return {}
    return response


def _broker_payload(operation: str) -> dict:
    return {
        "role": "client",
        "protocol": PROTOCOL_VERSION,
        "id": uuid.uuid4().hex,
        "op": operation,
        "params": {},
        "timeout": 5,
    }


def broker_status(url: str = DEFAULT_BRIDGE_URL) -> dict:
    url, _ = _validate_bridge_url(url)
    payload = _broker_payload("broker_status")
    try:
        response = _validate_rpc_response(asyncio.run(_exchange(url, payload, 5)), payload["id"])
    except Exception:
        return {"running": False, "extension_connected": False}
    if response.get("ok") is not True:
        return {"running": False, "extension_connected": False}
    result = response["result"]
    valid_identity = _valid_status_result(result)
    return {
        "running": valid_identity,
        "broker_version": result.get("broker_version"),
        "extension_connected": bool(result.get("extension_connected")),
        "extension_version": result.get("extension_version"),
        "extension_instances": result.get("extension_instances", []),
        "protocol": result.get("protocol"),
        "busy": bool(result.get("busy")),
        "busy_operation": result.get("busy_operation"),
        "quarantined": bool(result.get("quarantined")),
        "quarantine_reason": result.get("quarantine_reason"),
        "quarantine_request_id": result.get("quarantine_request_id"),
        "quarantine_since_ms": result.get("quarantine_since_ms"),
    }


def _legacy_broker_status(url: str) -> dict:
    payload = {
        "role": "client",
        "protocol": 1,
        "id": uuid.uuid4().hex,
        "op": "broker_status",
        "params": {},
        "timeout": 2,
    }
    try:
        response = asyncio.run(_legacy_exchange(url, payload, 2))
    except Exception:
        return {"running": False}
    result = response.get("result") or {}
    if (
        response.get("ok") is not True
        or not isinstance(result, dict)
        or response.get("id") not in {None, payload["id"]}
        or result.get("broker") != "hongshuskill"
        or result.get("protocol") != 1
    ):
        return {"running": False}
    return {
        "running": True,
        "broker_version": result.get("broker_version"),
        "protocol": 1,
        "extension_connected": bool(result.get("extension_connected")),
    }


def _broker_pid_paths(port: int) -> tuple[Path, ...]:
    current = Path(tempfile.gettempdir()) / "hongshuskill-runtime" / f"bridge-{port}.pid"
    if _is_windows():
        return (current,)
    legacy = Path(f"/tmp/hongshuskill-bridge-{port}.pid")
    return (current,) if current == legacy else (current, legacy)


def _loopback_port_occupied(port: int) -> bool:
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as connection:
            connection.settimeout(0.25)
            return connection.connect_ex(("127.0.0.1", port)) == 0
    except OSError:
        return False


def _read_owned_pid_file(path: Path) -> int | None:
    descriptor: int | None = None
    try:
        flags = os.O_RDONLY | getattr(os, "O_CLOEXEC", 0) | getattr(os, "O_NOFOLLOW", 0)
        descriptor = os.open(path, flags)
        metadata = os.fstat(descriptor)
        invalid_posix_ownership = (
            not _is_windows()
            and hasattr(os, "getuid")
            and (metadata.st_uid != os.getuid() or bool(metadata.st_mode & 0o022))
        )
        if (
            not stat.S_ISREG(metadata.st_mode)
            or invalid_posix_ownership
            or metadata.st_size < 1
            or metadata.st_size > 64
        ):
            return None
        raw = os.read(descriptor, 65)
    except (OSError, AttributeError):
        return None
    finally:
        if descriptor is not None:
            os.close(descriptor)
    if len(raw) > 64:
        return None
    try:
        pid = int(raw.decode("ascii").strip())
    except (UnicodeDecodeError, ValueError):
        return None
    return pid if pid > 0 else None


def _ps_executable() -> str:
    for candidate in (Path("/bin/ps"), Path("/usr/bin/ps")):
        if candidate.is_file():
            return str(candidate)
    raise BridgeUnavailable(
        "系统缺少可信的 ps 工具，无法安全确认旧桥接进程身份",
        details={"remote_code": "bridge_identity_unverified"},
    )


def _windows_process_snapshot(pid: int) -> dict[str, str] | None:
    system_root = os.environ.get("SYSTEMROOT", r"C:\Windows")
    candidates = [
        Path(system_root) / "System32/WindowsPowerShell/v1.0/powershell.exe",
        Path(system_root) / "Sysnative/WindowsPowerShell/v1.0/powershell.exe",
    ]
    powershell = next((str(path) for path in candidates if path.is_file()), None)
    powershell = powershell or shutil.which("powershell.exe") or shutil.which("pwsh.exe")
    if powershell is None:
        return None
    script = (
        "$ErrorActionPreference='Stop';"
        "$OutputEncoding=New-Object System.Text.UTF8Encoding($false);"
        f'$p=Get-CimInstance Win32_Process -Filter "ProcessId = {pid}";'
        "if($null -eq $p){exit 3};"
        "$o=Invoke-CimMethod -InputObject $p -MethodName GetOwnerSid;"
        "$c=[Security.Principal.WindowsIdentity]::GetCurrent().User.Value;"
        "[pscustomobject]@{owner_sid=$o.Sid;current_sid=$c;"
        "command_line=$p.CommandLine;executable_path=$p.ExecutablePath}|"
        "ConvertTo-Json -Compress"
    )
    creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    try:
        inspected = subprocess.run(
            [powershell, "-NoProfile", "-NonInteractive", "-Command", script],
            check=False,
            capture_output=True,
            text=True,
            encoding="utf-8",
            timeout=5,
            creationflags=creationflags,
        )
        payload = json.loads(inspected.stdout) if inspected.returncode == 0 else None
    except (OSError, subprocess.SubprocessError, UnicodeError, json.JSONDecodeError):
        return None
    if not isinstance(payload, dict):
        return None
    return {
        key: value
        for key in ("owner_sid", "current_sid", "command_line", "executable_path")
        if isinstance((value := payload.get(key)), str)
    }


def _managed_broker_pid(port: int, bridge_script: Path) -> int:
    for path in _broker_pid_paths(port):
        pid = _read_owned_pid_file(path)
        if pid is None:
            continue
        if _is_windows():
            snapshot = _windows_process_snapshot(pid)
            if snapshot is None:
                continue
            command = snapshot.get("command_line", "")
            same_user = bool(snapshot.get("owner_sid")) and (
                snapshot.get("owner_sid") == snapshot.get("current_sid")
            )
            has_script = str(bridge_script.resolve()).casefold() in command.casefold()
        else:
            inspected = subprocess.run(
                [_ps_executable(), "-ww", "-p", str(pid), "-o", "uid=", "-o", "command="],
                check=False,
                capture_output=True,
                text=True,
            )
            line = inspected.stdout.strip()
            if inspected.returncode != 0 or not line:
                continue
            uid_text, _, command = line.partition(" ")
            try:
                same_user = int(uid_text) == os.getuid()
            except (AttributeError, ValueError):
                same_user = False
            has_script = str(bridge_script.resolve()) in command
        has_port = bool(re.search(rf"(?:^|\s)--port\s+{port}(?:\s|$)", command))
        if same_user and has_script and has_port:
            return pid
    raise BridgeUnavailable(
        "检测到不兼容的本地桥接服务，但无法安全确认其进程身份；请关闭旧进程后重试",
        details={
            "remote_code": "bridge_identity_unverified",
            "port": port,
            "expected_script": str(bridge_script),
        },
    )


def _stop_stale_broker(port: int, bridge_script: Path) -> None:
    pid = _managed_broker_pid(port, bridge_script)
    try:
        os.kill(pid, signal.SIGTERM)
    except ProcessLookupError:
        return
    deadline = time.monotonic() + 3.0
    while time.monotonic() < deadline:
        try:
            os.kill(pid, 0)
        except ProcessLookupError:
            return
        except SystemError as exc:
            # On Windows, the venv launcher can terminate its base-interpreter
            # child successfully and a subsequent zero-signal probe may surface
            # as SystemError instead of ProcessLookupError. Only treat that as
            # exited after independently confirming that the loopback port is free.
            if not _loopback_port_occupied(port):
                return
            raise BridgeUnavailable(
                "旧版 hongshuskill 桥接进程状态无法确认；不会继续启动新桥接",
                details={"pid": pid, "port": port},
            ) from exc
        time.sleep(0.05)
    raise BridgeUnavailable(
        "旧版 hongshuskill 桥接服务未能安全退出；请手动关闭后重试",
        details={"pid": pid, "port": port},
    )


def ensure_broker(url: str = DEFAULT_BRIDGE_URL) -> dict:
    url, port = _validate_bridge_url(url)
    try:
        load_or_create_token()
    except EnvelopeAuthenticationError as exc:
        raise BridgeUnavailable(
            "无法安全初始化本地桥接认证",
            details={"reason": str(exc)},
        ) from exc
    status = broker_status(url)
    bridge_script = Path(__file__).resolve().parents[1] / "bridge_server.py"
    if not status["running"]:
        legacy_status = _legacy_broker_status(url)
        if legacy_status.get("running"):
            pid = _managed_broker_pid(port, bridge_script)
            raise BridgeUnavailable(
                "检测到旧版未认证桥接；无法判断是否仍有账号操作进行中，因此不会自动停止",
                details={
                    "remote_code": "bridge_upgrade_deferred",
                    "pid": pid,
                    "port": port,
                    "broker_version": legacy_status.get("broker_version"),
                },
            )
        if _loopback_port_occupied(port):
            raise BridgeUnavailable(
                "本地桥接端口已被无法验证身份的服务占用；不会启动或终止任何进程",
                details={
                    "remote_code": "bridge_identity_unverified",
                    "port": port,
                },
            )
    if (
        status["running"]
        and status.get("broker_version") == VERSION
        and status.get("protocol") == PROTOCOL_VERSION
    ):
        return status
    if status["running"]:
        if status.get("protocol") == PROTOCOL_VERSION and status.get("quarantined"):
            # A compatible authenticated broker must remain reachable long enough
            # for doctor to expose its recovery id and broker_recover to clear the
            # durable quarantine. Version replacement becomes safe only afterward.
            return status
        if status.get("busy"):
            raise BridgeUnavailable(
                "旧版 hongshuskill 桥接仍有未完成或未确认的浏览器操作，不能自动重启",
                details={
                    "port": port,
                    "busy": bool(status.get("busy")),
                    "quarantined": bool(status.get("quarantined")),
                },
            )
        _stop_stale_broker(port, bridge_script)

    process_options: dict[str, object] = {}
    if _is_windows():
        process_options["creationflags"] = getattr(
            subprocess, "CREATE_NEW_PROCESS_GROUP", 0
        ) | getattr(subprocess, "CREATE_NO_WINDOW", 0)
    else:
        process_options["start_new_session"] = True
    subprocess.Popen(
        [sys.executable, str(bridge_script), "--port", str(port)],
        stdin=subprocess.DEVNULL,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        cwd=str(bridge_script.parent),
        env={**os.environ, "PYTHONDONTWRITEBYTECODE": "1"},
        **process_options,
    )
    deadline = time.monotonic() + 5.0
    while time.monotonic() < deadline:
        status = broker_status(url)
        if (
            status["running"]
            and status.get("broker_version") == VERSION
            and status.get("protocol") == PROTOCOL_VERSION
        ):
            return status
        time.sleep(0.1)
    raise BridgeUnavailable("无法启动 hongshuskill 本地桥接服务", details={"url": url})


def call(
    operation: str,
    params: dict | None = None,
    *,
    url: str = DEFAULT_BRIDGE_URL,
    timeout: float = 90.0,
    target_instance_id: str | None = None,
    account_guard: dict | None = None,
):
    url, _ = _validate_bridge_url(url)
    if not isinstance(operation, str) or not operation or len(operation) > 64:
        raise InvalidInput("浏览器操作名称不正确")
    if params is not None and not isinstance(params, dict):
        raise InvalidInput("浏览器操作参数必须是 JSON 对象")
    if target_instance_id is not None and (
        not isinstance(target_instance_id, str)
        or re.fullmatch(r"[0-9a-f]{32}", target_instance_id) is None
    ):
        raise InvalidInput("目标扩展实例标识不正确")
    if account_guard is not None and not isinstance(account_guard, dict):
        raise InvalidInput("账号安全路由信息必须是 JSON 对象")
    if (
        isinstance(timeout, bool)
        or not isinstance(timeout, (int, float))
        or not math.isfinite(timeout)
        or not 1 <= timeout <= 720
    ):
        raise InvalidInput("timeout 必须是 1 到 720 之间的有限秒数")
    payload = {
        "role": "client",
        "protocol": PROTOCOL_VERSION,
        "id": uuid.uuid4().hex,
        "op": operation,
        "params": params if params is not None else {},
        "timeout": timeout,
    }
    if target_instance_id is not None:
        payload["target_instance_id"] = target_instance_id
    if account_guard is not None:
        payload["account_guard"] = account_guard
    try:
        normalized_payload = unsigned_envelope(payload)
    except EnvelopeAuthenticationError as exc:
        raise InvalidInput("浏览器操作参数不是可验证的 JSON", details={"reason": str(exc)}) from exc
    params_size = len(
        json.dumps(
            normalized_payload["params"],
            ensure_ascii=False,
            allow_nan=False,
            separators=(",", ":"),
        ).encode("utf-8")
    )
    if params_size > MAX_PARAMS_BYTES:
        raise InvalidInput(
            "浏览器操作参数超过 1 MiB 安全上限",
            details={"actual_bytes": params_size, "max_bytes": MAX_PARAMS_BYTES},
        )
    ensure_broker(url)
    try:
        response = _validate_rpc_response(
            asyncio.run(_exchange(url, payload, timeout + 5.0)),
            payload["id"],
        )
    except KeyboardInterrupt as exc:
        if operation in UNCERTAIN_WRITE_OPERATIONS:
            raise BrowserOperationFailed(
                "账号写操作等待被用户中断，执行结果无法确认；"
                "请先检查浏览器和账号状态，不要自动重试",
                details={
                    "remote_code": "operation_state_uncertain",
                    "operation": operation,
                    "cause": "KeyboardInterrupt",
                },
            ) from exc
        raise
    except Exception as exc:
        if operation in UNCERTAIN_WRITE_OPERATIONS:
            raise BrowserOperationFailed(
                "本地连接在账号写操作期间中断，执行结果无法确认；"
                "请先检查浏览器和账号状态，不要自动重试",
                details={
                    "remote_code": "operation_state_uncertain",
                    "operation": operation,
                    "cause": exc.__class__.__name__,
                },
            ) from exc
        raise BridgeUnavailable(
            "无法连接 hongshuskill 本地桥接服务",
            details={"reason": _sanitize_error_message(str(exc))},
        ) from exc

    if response.get("ok") is True:
        return response["result"]

    error = response["error"]
    code = error["code"]
    message = error["message"]
    details = error["details"]
    if operation in UNCERTAIN_WRITE_OPERATIONS and code in UNCERTAIN_REMOTE_CODES:
        reported_cause_code = details.get("cause_code")
        cause_code = (
            reported_cause_code
            if isinstance(reported_cause_code, str)
            and ERROR_CODE_PATTERN.fullmatch(reported_cause_code)
            else code
        )
        raise BrowserOperationFailed(
            "账号写操作已开始，但本地连接未能确认最终结果；请先检查浏览器和账号状态，不要自动重试",
            details={
                **details,
                "cause_code": cause_code,
                "remote_code": "operation_state_uncertain",
                "operation": operation,
            },
        )
    if code in {"authentication_required", "not_logged_in"}:
        raise AuthenticationRequired(message, details=details)
    if code == "confirmation_required":
        raise ConfirmationRequired(message, details=details)
    if code in {"risk_control_active", "verification_required"}:
        raise RiskControlActive(message, details={**details, "remote_code": code})
    if code in {"extension_unavailable", "extension_disconnected", "pairing_rejected"}:
        raise BridgeUnavailable(
            message,
            details={
                **details,
                "extension_path": str(Path(__file__).resolve().parents[2] / "extension"),
            },
        )
    raise BrowserOperationFailed(message, details={**details, "remote_code": code})


def recover_broker(
    url: str,
    expected_request_id: str,
    *,
    confirmed: bool,
) -> dict:
    """Clear a persisted uncertain-operation quarantine after explicit user verification."""

    if confirmed is not True:
        raise ConfirmationRequired(
            "解除桥接隔离前必须由用户核验浏览器和账号状态并明确确认",
            details={"action": "recover_broker", "required_flag": "--confirm"},
        )
    if not isinstance(expected_request_id, str) or not re.fullmatch(
        r"[0-9a-f]{32}", expected_request_id
    ):
        raise InvalidInput("待恢复请求标识格式不正确")
    result = call(
        "broker_recover",
        {"expected_request_id": expected_request_id, "confirmed": True},
        url=url,
        timeout=15,
    )
    if not isinstance(result, dict) or result.get("recovered") is not True:
        raise BridgeUnavailable("本地桥接未确认解除隔离状态")
    return result


def replace_legacy_broker(
    url: str = DEFAULT_BRIDGE_URL,
    *,
    confirmed: bool,
) -> dict:
    """Replace a managed protocol-v1 broker after explicit user safety verification."""

    if confirmed is not True:
        raise ConfirmationRequired(
            "升级桥接前必须由用户确认没有正在进行的账号操作",
            details={"action": "replace_legacy_broker", "required_flag": "--confirm"},
        )
    url, port = _validate_bridge_url(url)
    legacy_status = _legacy_broker_status(url)
    if not legacy_status.get("running"):
        raise BridgeUnavailable(
            "未检测到可安全升级的旧版 hongshuskill 桥接",
            details={"remote_code": "legacy_broker_not_found", "port": port},
        )
    bridge_script = Path(__file__).resolve().parents[1] / "bridge_server.py"
    # Resolve identity before any signal is sent. _stop_stale_broker repeats the
    # same check immediately before SIGTERM to narrow PID-reuse races.
    _managed_broker_pid(port, bridge_script)
    _stop_stale_broker(port, bridge_script)
    return ensure_broker(url)
