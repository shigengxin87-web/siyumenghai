"""Shared authenticated-envelope helpers for the CLI, broker, and extension."""

from __future__ import annotations

import contextlib
import hashlib
import hmac
import json
import math
import os
import re
import secrets
import stat
import tempfile
import threading
import time
from pathlib import Path
from typing import Any

from .permissions import tighten_file_descriptor

AUTH_WINDOW_MS = 60_000
NONCE_PATTERN = re.compile(r"[0-9a-f]{32}")
MAC_PATTERN = re.compile(r"[0-9a-f]{64}")
TOKEN_PATTERN = re.compile(r"[0-9a-f]{64}")
MAX_SAFE_INTEGER = (1 << 53) - 1
MAX_JSON_DEPTH = 64
MAX_JSON_NODES = 100_000
MAX_JSON_CONTAINER_ITEMS = 50_000
MAX_JSON_STRING_BYTES = 2 * 1024 * 1024
MAX_JSON_KEY_BYTES = 1024
MAX_PAIRING_FILE_BYTES = 1024
PAIRING_PATH = Path(__file__).resolve().parents[2] / "extension" / "pairing.json"


class EnvelopeAuthenticationError(ValueError):
    """An authenticated envelope or pairing credential is invalid."""


def _read_token_text(path: Path) -> str:
    flags = os.O_RDONLY
    if hasattr(os, "O_NOFOLLOW"):
        flags |= os.O_NOFOLLOW
    if hasattr(os, "O_NONBLOCK"):
        flags |= os.O_NONBLOCK
    try:
        descriptor = os.open(path, flags)
    except OSError as exc:
        raise EnvelopeAuthenticationError("pairing token file is unavailable") from exc
    try:
        metadata = os.fstat(descriptor)
        if not stat.S_ISREG(metadata.st_mode):
            raise EnvelopeAuthenticationError("pairing token path must be a regular file")
        if hasattr(os, "getuid") and metadata.st_uid != os.getuid():
            raise EnvelopeAuthenticationError("pairing token file is owned by another user")
        if metadata.st_size > MAX_PAIRING_FILE_BYTES:
            raise EnvelopeAuthenticationError("pairing token file is too large")
        tighten_file_descriptor(descriptor)
        with os.fdopen(descriptor, "r", encoding="utf-8", closefd=True) as handle:
            descriptor = -1
            raw = handle.read(MAX_PAIRING_FILE_BYTES + 1)
        if len(raw.encode("utf-8")) > MAX_PAIRING_FILE_BYTES:
            raise EnvelopeAuthenticationError("pairing token file is too large")
        payload = json.loads(raw)
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise EnvelopeAuthenticationError("pairing token file is invalid") from exc
    finally:
        if descriptor >= 0:
            os.close(descriptor)
    if not isinstance(payload, dict) or set(payload) != {"token"}:
        raise EnvelopeAuthenticationError("pairing token file is invalid")
    token = payload.get("token")
    if not isinstance(token, str):
        raise EnvelopeAuthenticationError("pairing token file is invalid")
    return token


def _pairing_lock_path(path: Path) -> Path:
    return path.with_name(f".{path.name}.lock")


@contextlib.contextmanager
def _pairing_lock(path: Path):
    """Serialize first-run token replacement across concurrent CLI processes."""

    lock_path = _pairing_lock_path(path)
    flags = os.O_RDWR | os.O_CREAT
    if hasattr(os, "O_NOFOLLOW"):
        flags |= os.O_NOFOLLOW
    if hasattr(os, "O_NONBLOCK"):
        flags |= os.O_NONBLOCK
    try:
        descriptor = os.open(lock_path, flags, 0o600)
    except OSError as exc:
        raise EnvelopeAuthenticationError("cannot lock pairing token file") from exc
    windows_lock = False
    try:
        metadata = os.fstat(descriptor)
        if not stat.S_ISREG(metadata.st_mode):
            raise EnvelopeAuthenticationError("pairing lock must be a regular file")
        if hasattr(os, "getuid") and metadata.st_uid != os.getuid():
            raise EnvelopeAuthenticationError("pairing lock is owned by another user")
        tighten_file_descriptor(descriptor)
        try:
            import fcntl

            fcntl.flock(descriptor, fcntl.LOCK_EX)
        except ImportError:
            import msvcrt

            os.lseek(descriptor, 0, os.SEEK_SET)
            msvcrt.locking(descriptor, msvcrt.LK_LOCK, 1)
            windows_lock = True
        yield
    finally:
        if windows_lock:
            import msvcrt

            with contextlib.suppress(OSError):
                os.lseek(descriptor, 0, os.SEEK_SET)
                msvcrt.locking(descriptor, msvcrt.LK_UNLCK, 1)
        os.close(descriptor)


def _atomic_write_token(path: Path, token: str) -> None:
    temporary_path: Path | None = None
    descriptor: int | None = None
    try:
        descriptor, raw_path = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
        temporary_path = Path(raw_path)
        tighten_file_descriptor(descriptor)
        payload = json.dumps({"token": token}, ensure_ascii=False, separators=(",", ":")) + "\n"
        with os.fdopen(descriptor, "w", encoding="utf-8", closefd=True) as handle:
            descriptor = None
            handle.write(payload)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary_path, path)
        temporary_path = None
        with contextlib.suppress(OSError):
            directory_descriptor = os.open(path.parent, os.O_RDONLY)
            try:
                os.fsync(directory_descriptor)
            finally:
                os.close(directory_descriptor)
    except OSError as exc:
        raise EnvelopeAuthenticationError("cannot persist pairing token") from exc
    finally:
        if descriptor is not None:
            os.close(descriptor)
        if temporary_path is not None:
            with contextlib.suppress(OSError):
                temporary_path.unlink()


def load_or_create_token(path: Path = PAIRING_PATH) -> bytes:
    """Load the shared 32-byte token, generating it atomically on first use."""

    path = Path(path)
    if path.is_symlink():
        raise EnvelopeAuthenticationError("pairing token path must not be a symlink")
    if not path.exists():
        raise EnvelopeAuthenticationError("pairing token template is missing")
    with _pairing_lock(path):
        token = _read_token_text(path)
        if not token:
            token = secrets.token_hex(32)
            _atomic_write_token(path, token)
        else:
            if not TOKEN_PATTERN.fullmatch(token):
                raise EnvelopeAuthenticationError("pairing token must be 32-byte lowercase hex")
    return bytes.fromhex(token)


def _normalize_json(
    value: Any,
    *,
    depth: int = 0,
    budget: list[int] | None = None,
) -> Any:
    if budget is None:
        budget = [0]
    budget[0] += 1
    if budget[0] > MAX_JSON_NODES:
        raise EnvelopeAuthenticationError("JSON envelope contains too many values")
    if depth > MAX_JSON_DEPTH:
        raise EnvelopeAuthenticationError("JSON envelope nesting is too deep")
    if value is None or isinstance(value, bool):
        return value
    if isinstance(value, str):
        try:
            encoded = value.encode("utf-8")
        except UnicodeEncodeError as exc:
            raise EnvelopeAuthenticationError("JSON strings must contain valid Unicode") from exc
        if len(encoded) > MAX_JSON_STRING_BYTES:
            raise EnvelopeAuthenticationError("JSON string exceeds the size limit")
        return value
    if isinstance(value, int):
        if not -MAX_SAFE_INTEGER <= value <= MAX_SAFE_INTEGER:
            raise EnvelopeAuthenticationError("JSON integer exceeds the safe range")
        return value
    if isinstance(value, float):
        if not math.isfinite(value):
            raise EnvelopeAuthenticationError("JSON number must be finite")
        if value == 0:
            return 0
        if value.is_integer():
            integer = int(value)
            if not -MAX_SAFE_INTEGER <= integer <= MAX_SAFE_INTEGER:
                raise EnvelopeAuthenticationError("JSON integer exceeds the safe range")
            return integer
        return value
    if isinstance(value, list):
        if len(value) > MAX_JSON_CONTAINER_ITEMS:
            raise EnvelopeAuthenticationError("JSON array contains too many items")
        return [_normalize_json(item, depth=depth + 1, budget=budget) for item in value]
    if isinstance(value, dict):
        if any(not isinstance(key, str) for key in value):
            raise EnvelopeAuthenticationError("JSON object keys must be strings")
        if len(value) > MAX_JSON_CONTAINER_ITEMS:
            raise EnvelopeAuthenticationError("JSON object contains too many items")
        try:
            for key in value:
                if len(key.encode("utf-8")) > MAX_JSON_KEY_BYTES:
                    raise EnvelopeAuthenticationError("JSON object key exceeds the size limit")
        except UnicodeEncodeError as exc:
            raise EnvelopeAuthenticationError(
                "JSON object keys must contain valid Unicode"
            ) from exc
        return {
            key: _normalize_json(value[key], depth=depth + 1, budget=budget)
            for key in sorted(value)
        }
    raise EnvelopeAuthenticationError("envelope contains a non-JSON value")


def unsigned_envelope(envelope: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(envelope, dict):
        raise EnvelopeAuthenticationError("envelope must be an object")
    try:
        normalized = _normalize_json(
            {key: value for key, value in envelope.items() if key != "auth"}
        )
    except RecursionError as exc:
        raise EnvelopeAuthenticationError("JSON envelope nesting is too deep") from exc
    if not isinstance(normalized, dict):  # pragma: no cover - input is checked above
        raise EnvelopeAuthenticationError("envelope must be an object")
    return normalized


def canonical_envelope(envelope: dict[str, Any]) -> bytes:
    return _canonical_json(unsigned_envelope(envelope)).encode("utf-8")


def _canonical_json(value: Any) -> str:
    if value is None:
        return "null"
    if value is True:
        return "true"
    if value is False:
        return "false"
    if isinstance(value, int):
        return str(value)
    if isinstance(value, float):
        # Both Python and JavaScript operate on IEEE-754 binary64. A fixed 17
        # significant-digit representation avoids their different shortest-form
        # thresholds while preserving every finite non-integral binary64 value.
        mantissa, exponent = format(value, ".16e").split("e")
        return f"{mantissa}e{int(exponent):+d}"
    if isinstance(value, str):
        return json.dumps(value, ensure_ascii=False, allow_nan=False)
    if isinstance(value, list):
        return "[" + ",".join(_canonical_json(item) for item in value) + "]"
    if isinstance(value, dict):
        return (
            "{"
            + ",".join(
                f"{_canonical_json(key)}:{_canonical_json(value[key])}" for key in sorted(value)
            )
            + "}"
        )
    raise EnvelopeAuthenticationError("envelope contains a non-JSON value")


def _mac_input(envelope: dict[str, Any], nonce: str, timestamp_ms: int) -> bytes:
    prefix = f"{timestamp_ms}\n{nonce}\n".encode()
    return prefix + canonical_envelope(envelope)


def sign_envelope(
    envelope: dict[str, Any],
    token: bytes,
    *,
    nonce: str | None = None,
    timestamp_ms: int | None = None,
) -> dict[str, Any]:
    if len(token) != 32:
        raise EnvelopeAuthenticationError("pairing token must contain 32 bytes")
    normalized = unsigned_envelope(envelope)
    nonce = nonce or secrets.token_hex(16)
    timestamp_ms = int(time.time() * 1000) if timestamp_ms is None else timestamp_ms
    if not NONCE_PATTERN.fullmatch(nonce):
        raise EnvelopeAuthenticationError("auth nonce must be 16-byte lowercase hex")
    if (
        isinstance(timestamp_ms, bool)
        or not isinstance(timestamp_ms, int)
        or not 0 <= timestamp_ms <= MAX_SAFE_INTEGER
    ):
        raise EnvelopeAuthenticationError("auth timestamp must be an integer")
    mac = hmac.new(token, _mac_input(normalized, nonce, timestamp_ms), hashlib.sha256).hexdigest()
    return {
        **normalized,
        "auth": {"nonce": nonce, "timestamp_ms": timestamp_ms, "mac": mac},
    }


class NonceReplayCache:
    """Bounded, thread-safe replay cache for authenticated inbound messages."""

    def __init__(self, *, window_ms: int = AUTH_WINDOW_MS) -> None:
        self.window_ms = window_ms
        self._seen: dict[str, int] = {}
        self._lock = threading.Lock()

    def consume(self, nonce: str, timestamp_ms: int, *, now_ms: int) -> None:
        cutoff = now_ms - self.window_ms
        with self._lock:
            self._seen = {
                cached_nonce: cached_timestamp
                for cached_nonce, cached_timestamp in self._seen.items()
                if cached_timestamp >= cutoff
            }
            if nonce in self._seen:
                raise EnvelopeAuthenticationError("auth nonce was already used")
            self._seen[nonce] = timestamp_ms


def verify_envelope(
    envelope: dict[str, Any],
    token: bytes,
    replay_cache: NonceReplayCache,
    *,
    now_ms: int | None = None,
) -> dict[str, Any]:
    if not isinstance(envelope, dict):
        raise EnvelopeAuthenticationError("envelope must be an object")
    auth = envelope.get("auth")
    if not isinstance(auth, dict) or set(auth) != {"nonce", "timestamp_ms", "mac"}:
        raise EnvelopeAuthenticationError("authenticated envelope is missing auth metadata")
    nonce = auth.get("nonce")
    timestamp_ms = auth.get("timestamp_ms")
    mac = auth.get("mac")
    if not isinstance(nonce, str) or not NONCE_PATTERN.fullmatch(nonce):
        raise EnvelopeAuthenticationError("auth nonce is invalid")
    if (
        isinstance(timestamp_ms, bool)
        or not isinstance(timestamp_ms, int)
        or not 0 <= timestamp_ms <= MAX_SAFE_INTEGER
    ):
        raise EnvelopeAuthenticationError("auth timestamp is invalid")
    if not isinstance(mac, str) or not MAC_PATTERN.fullmatch(mac):
        raise EnvelopeAuthenticationError("auth MAC is invalid")
    now_ms = int(time.time() * 1000) if now_ms is None else now_ms
    if abs(now_ms - timestamp_ms) > replay_cache.window_ms:
        raise EnvelopeAuthenticationError("authenticated envelope is outside the time window")
    expected = hmac.new(
        token,
        _mac_input(envelope, nonce, timestamp_ms),
        hashlib.sha256,
    ).hexdigest()
    if not hmac.compare_digest(mac, expected):
        raise EnvelopeAuthenticationError("authenticated envelope MAC is invalid")
    replay_cache.consume(nonce, timestamp_ms, now_ms=now_ms)
    return unsigned_envelope(envelope)
