"""Validate untrusted CLI input before it can reach the browser."""

from __future__ import annotations

import contextlib
import math
import re
import shutil
import urllib.parse
from collections.abc import Iterator
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path

from .errors import ConfirmationRequired, InvalidInput

SORT_OPTIONS = ("综合", "最新", "最多点赞", "最多评论", "最多收藏")
NOTE_TYPES = ("不限", "视频", "图文")
PUBLISH_TIMES = ("不限", "一天内", "一周内", "半年内")
SEARCH_SCOPES = ("不限", "已看过", "未看过", "已关注")
LOCATIONS = ("不限", "同城", "附近")
VISIBILITIES = ("公开可见", "仅自己可见", "仅互关好友可见")

IMAGE_SUFFIXES = {".jpg", ".jpeg", ".png", ".gif", ".webp", ".bmp", ".svg"}
VIDEO_SUFFIXES = {".mp4", ".mov", ".flv", ".f4v", ".mkv", ".m4v", ".mpeg", ".mpg"}
MAX_IMAGE_BYTES = 32 * 1024 * 1024
MAX_IMAGES = 18
MAX_TAGS = 10
MAX_RISK_PROBE_URLS = 10
DEFAULT_TEXT_MAX_BYTES = 4 * 1024 * 1024


def require_confirmation(
    confirmed: bool,
    action: str,
    *,
    consequence: str | None = None,
) -> None:
    if not confirmed:
        raise ConfirmationRequired(
            consequence
            or f"{action}会改变小红书账号状态；请在用户明确确认后重新执行并添加 --confirm",
            details={"action": action, "required_flag": "--confirm"},
        )


def require_nonempty(value: str, label: str) -> str:
    clean = value.strip()
    if not clean:
        raise InvalidInput(f"{label}不能为空")
    return clean


def require_choice(value: str | None, choices: tuple[str, ...], label: str) -> str | None:
    if value is None:
        return None
    if value not in choices:
        raise InvalidInput(f"{label}不支持“{value}”", details={"allowed": list(choices)})
    return value


def require_int_range(value: int, label: str, minimum: int, maximum: int) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or not minimum <= value <= maximum:
        raise InvalidInput(
            f"{label}必须在 {minimum}–{maximum} 之间",
            details={"value": value, "minimum": minimum, "maximum": maximum},
        )
    return value


def require_float_range(value: float, label: str, minimum: float, maximum: float) -> float:
    if not math.isfinite(value) or not minimum <= value <= maximum:
        safe_value: float | str = value if math.isfinite(value) else str(value)
        raise InvalidInput(
            f"{label}必须在 {minimum:g}–{maximum:g} 之间",
            details={"value": safe_value, "minimum": minimum, "maximum": maximum},
        )
    return value


def require_feed_pair(feed_id: str, xsec_token: str) -> tuple[str, str]:
    feed_id = require_nonempty(feed_id, "feed_id")
    if not re.fullmatch(r"[0-9a-zA-Z_-]{8,80}", feed_id):
        raise InvalidInput("feed_id 格式不正确")
    return feed_id, require_xsec_token(xsec_token)


def require_xsec_token(xsec_token: str) -> str:
    value = require_nonempty(xsec_token, "xsec_token")
    if not 12 <= len(value) <= 512 or re.search(r"\s", value):
        raise InvalidInput("xsec_token 格式不正确")
    return value


def require_xsec_source(xsec_source: str | None) -> str | None:
    if xsec_source is None:
        return None
    value = require_nonempty(xsec_source, "xsec_source")
    if not re.fullmatch(r"[a-z][a-z0-9_]{1,40}", value):
        raise InvalidInput("xsec_source 格式不正确")
    return value


def require_preview_id(preview_id: str | None) -> str:
    if preview_id is None:
        raise InvalidInput("必须提供本次发布预览返回的 --preview-id")
    value = require_nonempty(preview_id, "preview_id")
    if not re.fullmatch(r"[0-9A-Za-z_-]{16,128}", value):
        raise InvalidInput("preview_id 格式不正确")
    return value


def validate_risk_probe_urls(urls: list[str] | None) -> list[str]:
    values = urls or []
    if len(values) > MAX_RISK_PROBE_URLS:
        raise InvalidInput(f"主动风控探测最多支持 {MAX_RISK_PROBE_URLS} 个自定义 URL")
    result: list[str] = []
    for raw in values:
        value = require_nonempty(raw, "主动探测 URL")
        if len(value) > 4096:
            raise InvalidInput("主动探测 URL 过长")
        try:
            parsed = urllib.parse.urlparse(value)
            port = parsed.port
        except ValueError as exc:
            raise InvalidInput("主动探测 URL 格式不正确") from exc
        host = (parsed.hostname or "").lower()
        is_xhs = host == "xiaohongshu.com" or host.endswith(".xiaohongshu.com")
        if (
            parsed.scheme != "https"
            or not is_xhs
            or parsed.username
            or parsed.password
            or port not in {None, 443}
            or not parsed.path.startswith("/api/")
            or parsed.fragment
        ):
            raise InvalidInput(
                "主动探测只允许小红书 HTTPS API URL",
                details={"requirements": "https://*.xiaohongshu.com/api/..."},
            )
        if value not in result:
            result.append(value)
    return result


def require_user_id(user_id: str) -> str:
    value = require_nonempty(user_id, "user_id")
    if not re.fullmatch(r"[0-9a-zA-Z_-]{8,80}", value):
        raise InvalidInput("user_id 格式不正确")
    return value


def require_phone(phone: str) -> str:
    value = re.sub(r"[\s-]", "", phone)
    if not re.fullmatch(r"1[3-9]\d{9}", value):
        raise InvalidInput("手机号必须是 11 位中国大陆号码")
    return value


def require_code(code: str) -> str:
    value = code.strip()
    if not re.fullmatch(r"\d{4,8}", value):
        raise InvalidInput("验证码必须是 4–8 位数字")
    return value


def require_absolute_file(path_text: str, suffixes: set[str], label: str) -> Path:
    path = Path(path_text).expanduser()
    if not path.is_absolute():
        raise InvalidInput(f"{label}必须使用绝对路径", details={"path": path_text})
    if not path.is_file():
        raise InvalidInput(f"{label}不存在", details={"path": str(path)})
    if path.suffix.lower() not in suffixes:
        raise InvalidInput(
            f"{label}格式不支持",
            details={"path": str(path), "allowed_suffixes": sorted(suffixes)},
        )
    return path.resolve()


def read_utf8_file(
    path_text: str,
    label: str,
    *,
    max_bytes: int = DEFAULT_TEXT_MAX_BYTES,
) -> str:
    path = Path(path_text).expanduser()
    if not path.is_absolute():
        raise InvalidInput(f"{label}必须使用绝对路径", details={"path": path_text})
    if not path.is_file():
        raise InvalidInput(f"{label}不存在", details={"path": str(path)})
    try:
        size = path.stat().st_size
        if size > max_bytes:
            raise InvalidInput(
                f"{label}超过安全大小上限",
                details={"path": str(path), "max_bytes": max_bytes, "size_bytes": size},
            )
        with path.open("rb") as handle:
            raw = handle.read(max_bytes + 1)
        if len(raw) > max_bytes:
            raise InvalidInput(
                f"{label}超过安全大小上限",
                details={"path": str(path), "max_bytes": max_bytes, "size_bytes": len(raw)},
            )
        text = raw.decode("utf-8")
    except UnicodeDecodeError as exc:
        raise InvalidInput(f"{label}必须是 UTF-8 文本文件") from exc
    except OSError as exc:
        raise InvalidInput(
            f"无法读取{label}",
            details={"path": str(path), "reason": exc.__class__.__name__},
        ) from exc
    return require_nonempty(text, label)


def title_units(text: str) -> int:
    """Count UTF-16 code units: non-ASCII as 1 and ASCII as 0.5, rounded up."""
    encoded = text.encode("utf-16-le")
    weighted = 0
    for index in range(0, len(encoded), 2):
        code_unit = int.from_bytes(encoded[index : index + 2], "little")
        weighted += 1 if code_unit < 128 else 2
    return math.ceil(weighted / 2)


def validate_short_title(title: str) -> str:
    units = title_units(title)
    if units > 20:
        raise InvalidInput(
            f"标题长度为 {units} 单位，超过 20；请语义改写后再试",
            details={"title_units": units, "limit": 20},
        )
    return title


def validate_schedule(value: str | None) -> str | None:
    if not value:
        return None
    if not re.fullmatch(
        r"\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}"
        r"(?::\d{2}(?:\.\d{1,6})?)?(?:Z|[+-]\d{2}:\d{2})?",
        value,
    ):
        raise InvalidInput("定时发布时间必须是包含小时和分钟的 ISO 8601 格式")
    try:
        parsed = datetime.fromisoformat(value)
    except ValueError as exc:
        raise InvalidInput("定时发布时间必须是 ISO 8601 格式") from exc
    local = parsed.astimezone().replace(tzinfo=None) if parsed.tzinfo is not None else parsed
    normalized = local.replace(second=0, microsecond=0)
    if normalized <= datetime.now():
        raise InvalidInput("定时发布时间必须晚于当前时间")
    return normalized.isoformat(timespec="minutes")


def normalize_tags(tags: list[str] | None) -> list[str]:
    result: list[str] = []
    for tag in tags or []:
        value = tag.strip().lstrip("#")
        if value and value not in result:
            result.append(value)
    return result[:MAX_TAGS]


def extract_trailing_tags(content: str, tags: list[str] | None) -> tuple[str, list[str]]:
    """Move a final hashtag-only line into structured tags for topic selection."""
    lines = content.rstrip().splitlines()
    if not lines:
        return content, normalize_tags(tags)
    final_line = lines[-1].strip()
    if not re.fullmatch(r"(?:#[^\s#]+\s*)+", final_line):
        return content, normalize_tags(tags)
    extracted = re.findall(r"#([^\s#]+)", final_line)
    cleaned = "\n".join(lines[:-1]).rstrip()
    return cleaned, normalize_tags([*(tags or []), *extracted])


@dataclass
class MediaBundle:
    paths: list[str]
    temporary_directory: Path | None = None
    sources: list[str] = field(default_factory=list)

    def close(self) -> None:
        if self.temporary_directory:
            shutil.rmtree(self.temporary_directory, ignore_errors=True)


@contextlib.contextmanager
def resolve_images(items: list[str]) -> Iterator[MediaBundle]:
    if not items:
        raise InvalidInput("图文发布至少需要一张图片")
    if len(items) > MAX_IMAGES:
        raise InvalidInput(f"图文发布最多支持 {MAX_IMAGES} 张图片")

    temp_dir: Path | None = None
    paths: list[str] = []
    try:
        for item in items:
            try:
                scheme = urllib.parse.urlparse(item).scheme
            except ValueError as exc:
                raise InvalidInput("图片路径或 URL 格式不正确") from exc
            if scheme in {"http", "https"}:
                raise InvalidInput(
                    "为防止内网访问与 DNS 重绑风险，图片必须先下载到本地并使用绝对路径",
                    details={"remote_images_supported": False},
                )
            path = require_absolute_file(item, IMAGE_SUFFIXES, "图片")
            if path.stat().st_size > MAX_IMAGE_BYTES:
                raise InvalidInput("图片超过 32MB", details={"path": str(path)})
            paths.append(str(path))
        bundle = MediaBundle(paths=paths, temporary_directory=temp_dir, sources=list(items))
        yield bundle
    finally:
        if temp_dir:
            shutil.rmtree(temp_dir, ignore_errors=True)


def resolve_video(path_text: str) -> str:
    return str(require_absolute_file(path_text, VIDEO_SUFFIXES, "视频"))
