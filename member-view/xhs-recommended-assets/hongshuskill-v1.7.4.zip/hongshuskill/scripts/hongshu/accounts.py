"""Private local registry for named Xiaohongshu browser accounts.

The registry stores only routing and verification metadata.  Raw cookies,
phone numbers, verification codes, passwords, and page tokens never belong in
this file.
"""

from __future__ import annotations

import contextlib
import json
import os
import re
import stat
import tempfile
import time
from pathlib import Path
from typing import Any

from .errors import InvalidInput
from .permissions import tighten_file_descriptor, tighten_path

REGISTRY_VERSION = 1
MAX_REGISTRY_BYTES = 256 * 1024
INSTANCE_ID_PATTERN = re.compile(r"[0-9a-f]{32}")
FINGERPRINT_PATTERN = re.compile(r"[0-9a-f]{64}")
USER_ID_PATTERN = re.compile(r"[A-Za-z0-9_-]{1,128}")


def registry_path() -> Path:
    override = os.environ.get("HONGSHUSKILL_CONFIG_DIR")
    directory = Path(override).expanduser() if override else Path.home() / ".hongshuskill"
    if not directory.is_absolute():
        raise InvalidInput("HONGSHUSKILL_CONFIG_DIR 必须是绝对路径")
    return directory / "accounts.json"


def require_account_name(value: str | None) -> str:
    name = str(value or "").strip()
    if not name or len(name) > 32:
        raise InvalidInput("账号名称必须是 1到32 个字符")
    if (
        name in {".", ".."}
        or any(separator in name for separator in ("/", "\\", "\0"))
        or any(ord(character) < 32 for character in name)
    ):
        raise InvalidInput("账号名称不能包含路径分隔符或控制字符")
    return name


def require_instance_id(value: str | None) -> str:
    instance_id = str(value or "")
    if not INSTANCE_ID_PATTERN.fullmatch(instance_id):
        raise InvalidInput("扩展实例标识格式不正确")
    return instance_id


def _empty_registry() -> dict[str, Any]:
    return {"version": REGISTRY_VERSION, "accounts": {}}


def _validate_private_directory(directory: Path) -> None:
    if directory.is_symlink():
        raise InvalidInput("账号配置目录不能是符号链接")
    directory.mkdir(mode=0o700, parents=True, exist_ok=True)
    metadata = directory.lstat()
    if not stat.S_ISDIR(metadata.st_mode):
        raise InvalidInput("账号配置路径不是目录")
    if hasattr(os, "getuid") and metadata.st_uid != os.getuid():
        raise InvalidInput("账号配置目录不属于当前用户")
    with contextlib.suppress(OSError):
        tighten_path(directory, 0o700)


def _validate_private_file(path: Path) -> os.stat_result:
    if path.is_symlink():
        raise InvalidInput("账号配置文件不能是符号链接")
    metadata = path.lstat()
    if not stat.S_ISREG(metadata.st_mode):
        raise InvalidInput("账号配置路径不是普通文件")
    if hasattr(os, "getuid") and metadata.st_uid != os.getuid():
        raise InvalidInput("账号配置文件不属于当前用户")
    return metadata


@contextlib.contextmanager
def _registry_lock():
    path = registry_path().with_name(".accounts.lock")
    _validate_private_directory(path.parent)
    flags = os.O_RDWR | os.O_CREAT
    if hasattr(os, "O_NOFOLLOW"):
        flags |= os.O_NOFOLLOW
    try:
        descriptor = os.open(path, flags, 0o600)
    except OSError as exc:
        raise InvalidInput("无法锁定账号配置") from exc
    windows_lock = False
    try:
        metadata = os.fstat(descriptor)
        if not stat.S_ISREG(metadata.st_mode):
            raise InvalidInput("账号配置锁不是普通文件")
        if hasattr(os, "getuid") and metadata.st_uid != os.getuid():
            raise InvalidInput("账号配置锁不属于当前用户")
        with contextlib.suppress(OSError):
            tighten_file_descriptor(descriptor)
        try:
            import fcntl

            fcntl.flock(descriptor, fcntl.LOCK_EX)
        except ImportError:
            import msvcrt

            if metadata.st_size == 0:
                os.write(descriptor, b"\0")
                os.fsync(descriptor)
            os.lseek(descriptor, 0, os.SEEK_SET)
            msvcrt.locking(descriptor, msvcrt.LK_LOCK, 1)
            windows_lock = True
        yield
    finally:
        if windows_lock:
            import msvcrt

            with contextlib.suppress(OSError):
                os.lseek(descriptor, 0, os.SEEK_SET)
                msvcrt.locking(descriptor, msvcrt.LK_UNLCK, 1)
        os.close(descriptor)


def _validate_account_record(name: str, value: object) -> dict[str, Any]:
    require_account_name(name)
    if not isinstance(value, dict) or set(value) != {
        "instance_id",
        "user_id",
        "nickname",
        "session_fingerprint",
        "bound_at_ms",
        "verified_at_ms",
    }:
        raise InvalidInput("账号配置文件内容无效")
    instance_id = require_instance_id(value.get("instance_id"))
    user_id = value.get("user_id")
    nickname = value.get("nickname")
    fingerprint = value.get("session_fingerprint")
    if not isinstance(user_id, str) or not USER_ID_PATTERN.fullmatch(user_id):
        raise InvalidInput("账号配置中的用户标识无效")
    if not isinstance(nickname, str) or len(nickname) > 128:
        raise InvalidInput("账号配置中的昵称无效")
    if not isinstance(fingerprint, str) or not FINGERPRINT_PATTERN.fullmatch(fingerprint):
        raise InvalidInput("账号配置中的会话指纹无效")
    for field in ("bound_at_ms", "verified_at_ms"):
        timestamp = value.get(field)
        if isinstance(timestamp, bool) or not isinstance(timestamp, int) or timestamp < 0:
            raise InvalidInput("账号配置中的时间戳无效")
    return {
        **value,
        "instance_id": instance_id,
        "user_id": user_id,
        "nickname": nickname,
        "session_fingerprint": fingerprint,
    }


def load_registry() -> dict[str, Any]:
    path = registry_path()
    if not path.exists() and not path.is_symlink():
        return _empty_registry()
    metadata = _validate_private_file(path)
    if metadata.st_size > MAX_REGISTRY_BYTES:
        raise InvalidInput("账号配置文件超过安全大小限制")
    with contextlib.suppress(OSError):
        tighten_path(path, 0o600)
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise InvalidInput("账号配置文件无法解析") from exc
    if (
        not isinstance(payload, dict)
        or set(payload) != {"version", "accounts"}
        or payload.get("version") != REGISTRY_VERSION
        or not isinstance(payload.get("accounts"), dict)
    ):
        raise InvalidInput("账号配置文件版本或结构无效")
    accounts = {
        name: _validate_account_record(name, value)
        for name, value in payload["accounts"].items()
    }
    instance_ids = [record["instance_id"] for record in accounts.values()]
    if len(instance_ids) != len(set(instance_ids)):
        raise InvalidInput("多个账号不能绑定同一扩展实例")
    return {"version": REGISTRY_VERSION, "accounts": accounts}


def save_registry(registry: dict[str, Any]) -> None:
    accounts = registry.get("accounts") if isinstance(registry, dict) else None
    if not isinstance(accounts, dict):
        raise InvalidInput("账号配置内容无效")
    normalized = {
        "version": REGISTRY_VERSION,
        "accounts": {
            name: _validate_account_record(name, value)
            for name, value in accounts.items()
        },
    }
    path = registry_path()
    _validate_private_directory(path.parent)
    if path.exists() or path.is_symlink():
        _validate_private_file(path)
    descriptor: int | None = None
    temporary_path: Path | None = None
    try:
        descriptor, raw_path = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
        temporary_path = Path(raw_path)
        tighten_file_descriptor(descriptor)
        with os.fdopen(descriptor, "w", encoding="utf-8", closefd=True) as handle:
            descriptor = None
            json.dump(normalized, handle, ensure_ascii=False, separators=(",", ":"))
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary_path, path)
        temporary_path = None
        with contextlib.suppress(OSError):
            directory_descriptor = os.open(path.parent, os.O_RDONLY)
            try:
                os.fsync(directory_descriptor)
            finally:
                os.close(directory_descriptor)
    finally:
        if descriptor is not None:
            os.close(descriptor)
        if temporary_path is not None:
            with contextlib.suppress(OSError):
                temporary_path.unlink()


def bind_account(name: str, identity: dict[str, Any]) -> dict[str, Any]:
    name = require_account_name(name)
    instance_id = require_instance_id(identity.get("instance_id"))
    user_id = identity.get("user_id")
    nickname = identity.get("nickname") or ""
    fingerprint = identity.get("session_fingerprint")
    if not isinstance(user_id, str) or not USER_ID_PATTERN.fullmatch(user_id):
        raise InvalidInput("当前登录页未返回可绑定的小红书用户 ID")
    if not isinstance(nickname, str) or len(nickname) > 128:
        raise InvalidInput("当前登录账号昵称无效")
    if not isinstance(fingerprint, str) or not FINGERPRINT_PATTERN.fullmatch(fingerprint):
        raise InvalidInput("无法安全确认当前账号会话")
    with _registry_lock():
        registry = load_registry()
        accounts = registry["accounts"]
        if name in accounts:
            raise InvalidInput(f"账号名称“{name}”已存在；请先核对或解除旧绑定")
        owner = next(
            (other for other, item in accounts.items() if item["instance_id"] == instance_id),
            None,
        )
        if owner is not None:
            raise InvalidInput(f"当前 Chrome Profile 已绑定账号“{owner}”")
        now = int(time.time() * 1000)
        record = {
            "instance_id": instance_id,
            "user_id": user_id,
            "nickname": nickname,
            "session_fingerprint": fingerprint,
            "bound_at_ms": now,
            "verified_at_ms": now,
        }
        accounts[name] = record
        save_registry(registry)
    return {"name": name, **record}


def verify_account(name: str, identity: dict[str, Any]) -> dict[str, Any]:
    name = require_account_name(name)
    with _registry_lock():
        registry = load_registry()
        record = registry["accounts"].get(name)
        if record is None:
            raise InvalidInput(f"未找到账号“{name}”")
        if require_instance_id(identity.get("instance_id")) != record["instance_id"]:
            raise InvalidInput("连接的 Chrome Profile 与账号绑定不一致")
        if identity.get("user_id") != record["user_id"]:
            raise InvalidInput(
                "当前 Chrome Profile 登录了不同的小红书账号，已拒绝更新绑定"
            )
        fingerprint = identity.get("session_fingerprint")
        if not isinstance(fingerprint, str) or not FINGERPRINT_PATTERN.fullmatch(fingerprint):
            raise InvalidInput("无法安全确认当前账号会话")
        record["session_fingerprint"] = fingerprint
        record["nickname"] = str(identity.get("nickname") or record["nickname"])[:128]
        record["verified_at_ms"] = int(time.time() * 1000)
        save_registry(registry)
    return {"name": name, **record}


def unbind_account(name: str) -> dict[str, Any]:
    name = require_account_name(name)
    with _registry_lock():
        registry = load_registry()
        record = registry["accounts"].pop(name, None)
        if record is None:
            raise InvalidInput(f"未找到账号“{name}”")
        save_registry(registry)
    return {"name": name, "unbound": True, "cookies_deleted": False, "profile_deleted": False}


def account_record(name: str) -> dict[str, Any]:
    name = require_account_name(name)
    record = load_registry()["accounts"].get(name)
    if record is None:
        raise InvalidInput(f"未找到账号“{name}”")
    return {"name": name, **record}


def resolve_routing(account: str | None) -> dict[str, Any] | None:
    registry = load_registry()
    accounts = registry["accounts"]
    if account:
        return account_record(account)
    if not accounts:
        return None
    if len(accounts) > 1:
        raise InvalidInput("已登记多个账号；本次操作必须显式提供 --account")
    name, record = next(iter(accounts.items()))
    return {"name": name, **record}


def list_accounts(connected_instance_ids: set[str] | None = None) -> list[dict[str, Any]]:
    connected = connected_instance_ids or set()
    return [
        {
            "name": name,
            "nickname": record["nickname"],
            "user_id": record["user_id"],
            "instance_id": record["instance_id"],
            "connected": record["instance_id"] in connected,
            "bound_at_ms": record["bound_at_ms"],
            "verified_at_ms": record["verified_at_ms"],
        }
        for name, record in load_registry()["accounts"].items()
    ]
