"""Cross-platform helpers for private local files.

POSIX mode bits are an actual access-control boundary on macOS and Linux.
Windows uses ACLs instead; the PowerShell launcher applies those ACLs before
starting Python, so chmod-style calls must not be treated as authoritative.
"""

from __future__ import annotations

import os
from pathlib import Path


def _is_windows() -> bool:
    return os.name == "nt"


def tighten_file_descriptor(descriptor: int, mode: int = 0o600) -> None:
    """Apply a private POSIX mode, or defer to launcher-managed Windows ACLs."""

    if _is_windows():
        return
    os.fchmod(descriptor, mode)


def tighten_path(path: Path, mode: int) -> None:
    """Apply a private POSIX path mode, or defer to launcher-managed Windows ACLs."""

    if _is_windows():
        return
    path.chmod(mode)
