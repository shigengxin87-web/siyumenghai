"""One JSON envelope for every command, including failures."""

from __future__ import annotations

import json
import sys
import time
from typing import Any

from . import VERSION
from .errors import HongshuError


def _meta(started: float) -> dict[str, Any]:
    return {
        "version": VERSION,
        "elapsed_ms": round((time.monotonic() - started) * 1000),
    }


def emit_success(command: str, data: Any, started: float) -> None:
    payload = {
        "ok": True,
        "command": command,
        "data": data,
        "meta": _meta(started),
    }
    print(json.dumps(payload, ensure_ascii=False, allow_nan=False, indent=2))


def emit_error(command: str, error: Exception, started: float) -> int:
    if isinstance(error, HongshuError):
        code = error.code
        details = error.details
        status = error.exit_status
        message = error.message
    else:
        code = "unexpected_error"
        details = {"exception_type": error.__class__.__name__}
        status = 2
        # Unexpected exception strings can contain local paths, command arguments,
        # page text, or credentials returned by a dependency. Keep the one-JSON
        # contract without reflecting those untrusted details to stdout/stderr.
        message = "执行遇到未预期错误；未输出异常详情"

    payload = {
        "ok": False,
        "command": command,
        "error": {"code": code, "message": message, "details": details},
        "meta": _meta(started),
    }
    print(json.dumps(payload, ensure_ascii=False, allow_nan=False, indent=2), file=sys.stderr)
    return status
