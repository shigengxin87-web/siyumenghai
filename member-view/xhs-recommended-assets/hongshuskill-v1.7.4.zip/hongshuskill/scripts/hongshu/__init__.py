"""Core helpers for hongshuskill."""

VERSION = "1.7.4"
DEFAULT_BRIDGE_URL = "ws://127.0.0.1:9345"
DEFAULT_BRIDGE_PORT = 9345
