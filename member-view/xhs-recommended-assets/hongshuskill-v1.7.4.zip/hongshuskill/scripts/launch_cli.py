#!/usr/bin/env python3
"""Mark a launcher handoff complete, then execute the real CLI in-process."""

from __future__ import annotations

import runpy
import sys
from pathlib import Path


def main() -> None:
    if len(sys.argv) < 3:
        raise SystemExit(70)
    marker = Path(sys.argv[1])
    cli = Path(sys.argv[2])
    if (
        marker.exists()
        or marker.is_symlink()
        or not marker.parent.is_dir()
        or marker.parent.is_symlink()
        or not cli.is_file()
        or cli.is_symlink()
    ):
        raise SystemExit(70)
    with marker.open("x", encoding="ascii") as handle:
        handle.write("started\n")
        handle.flush()
    sys.argv = [str(cli), *sys.argv[3:]]
    runpy.run_path(str(cli), run_name="__main__")


if __name__ == "__main__":
    main()
