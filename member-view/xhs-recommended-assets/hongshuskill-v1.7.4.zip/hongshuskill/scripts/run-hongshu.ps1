﻿$ErrorActionPreference = "Stop"
Set-StrictMode -Version 2.0
$PSDefaultParameterValues['Out-File:Encoding'] = 'utf8'
$PSDefaultParameterValues['Out-File:Width'] = 16777216

# Emit UTF-8 on stdout so Chinese titles/names survive the PowerShell -> host
# pipe on zh-CN Windows (default console codepage is GBK otherwise). InputEncoding
# can throw "handle is invalid" in hosts without an attached console, so guard it.
try { [Console]::OutputEncoding = [Text.Encoding]::UTF8 } catch { }
try { [Console]::InputEncoding = [Text.Encoding]::UTF8 } catch { }

$script:LauncherAbortSignal = "__HONGSHUSKILL_LAUNCHER_ABORT__"
$script:LauncherErrorEmitted = $false
$script:LauncherExitCode = 0
$script:NestedInvocation = $MyInvocation.InvocationName -in @("&", ".")

function Write-LauncherError {
    param(
        [Parameter(Mandatory = $true)][string]$Code,
        [Parameter(Mandatory = $true)][string]$Message,
        [switch]$NoAbort
    )

    $payload = @{
        ok = $false
        command = "launcher"
        error = @{
            code = $Code
            message = $Message
            details = @{}
        }
        meta = @{}
    } | ConvertTo-Json -Compress -Depth 4
    Microsoft.PowerShell.Utility\Write-Output -NoEnumerate $payload
    $script:LauncherErrorEmitted = $true
    $script:LauncherExitCode = 2
    if (-not $NoAbort) {
        throw $script:LauncherAbortSignal
    }
}

function Protect-PrivateDirectory {
    param([Parameter(Mandatory = $true)][string]$Path)

    if (Test-Path -LiteralPath $Path) {
        $existing = Get-Item -LiteralPath $Path -Force
        if (-not $existing.PSIsContainer -or
            (($existing.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0)) {
            Write-LauncherError "unsafe_runtime_directory" "hongshuskill 运行路径必须是非重解析点目录"
        }
    } else {
        [IO.Directory]::CreateDirectory($Path) | Out-Null
    }

    $directory = Get-Item -LiteralPath $Path -Force
    if (-not $directory.PSIsContainer -or
        (($directory.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0)) {
        Write-LauncherError "unsafe_runtime_directory" "hongshuskill 运行目录验收失败"
    }

    try {
        $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
        $sid = $identity.User
        $security = New-Object System.Security.AccessControl.DirectorySecurity
        $security.SetOwner($sid)
        $security.SetAccessRuleProtection($true, $false)
        $inheritance = [Security.AccessControl.InheritanceFlags]::ContainerInherit -bor
            [Security.AccessControl.InheritanceFlags]::ObjectInherit
        $rule = [Security.AccessControl.FileSystemAccessRule]::new(
            $sid,
            [Security.AccessControl.FileSystemRights]::FullControl,
            $inheritance,
            [Security.AccessControl.PropagationFlags]::None,
            [Security.AccessControl.AccessControlType]::Allow
        )
        $security.AddAccessRule($rule)
        # DirectoryInfo.SetAccessControl works in both Windows PowerShell 5.1
        # (.NET Framework) and PowerShell 7 (.NET Core). The static type
        # System.IO.FileSystemAclExtensions only exists on .NET Core, so it must
        # not be used here or PS 5.1 would throw "找不到类型".
        $directory.SetAccessControl($security)
    } catch {
        Write-LauncherError "runtime_setup_failed" "无法收紧 hongshuskill Windows 运行目录权限"
    }
}

function Find-UvApplication {
    $command = Get-Command uv -CommandType Application -ErrorAction SilentlyContinue
    if ($null -ne $command) {
        return $command.Source
    }

    # WinGet updates PATH for future terminals only. These fallbacks make the
    # launcher work immediately after a first-time per-user installation.
    $candidates = @(
        (Join-Path $env:USERPROFILE ".local\bin\uv.exe"),
        (Join-Path $env:LOCALAPPDATA "Microsoft\WinGet\Links\uv.exe")
    )
    foreach ($candidate in $candidates) {
        if (Test-Path -LiteralPath $candidate -PathType Leaf) {
            return [IO.Path]::GetFullPath($candidate)
        }
    }

    $wingetRoot = Join-Path $env:LOCALAPPDATA "Microsoft\WinGet\Packages"
    if (Test-Path -LiteralPath $wingetRoot -PathType Container) {
        $packages = Get-ChildItem -LiteralPath $wingetRoot -Directory -Filter "astral-sh.uv_*" `
            -ErrorAction SilentlyContinue
        foreach ($package in $packages) {
            $candidate = Join-Path $package.FullName "uv.exe"
            if (Test-Path -LiteralPath $candidate -PathType Leaf) {
                return [IO.Path]::GetFullPath($candidate)
            }
        }
    }

    return $null
}

function ConvertTo-ProcessArgument {
    param([AllowEmptyString()][Parameter(Mandatory = $true)][string]$Value)

    if ($Value.Length -gt 0 -and $Value -notmatch '[\s"]') {
        return $Value
    }

    $builder = New-Object Text.StringBuilder
    [void]$builder.Append('"')
    $backslashes = 0
    foreach ($character in $Value.ToCharArray()) {
        if ($character -eq '\') {
            $backslashes += 1
            continue
        }
        if ($character -eq '"') {
            [void]$builder.Append(('\' * (($backslashes * 2) + 1)))
            [void]$builder.Append('"')
            $backslashes = 0
            continue
        }
        if ($backslashes -gt 0) {
            [void]$builder.Append(('\' * $backslashes))
            $backslashes = 0
        }
        [void]$builder.Append($character)
    }
    if ($backslashes -gt 0) {
        [void]$builder.Append(('\' * ($backslashes * 2)))
    }
    [void]$builder.Append('"')
    return $builder.ToString()
}

function Invoke-CapturedProcess {
    param(
        [Parameter(Mandatory = $true)][string]$FilePath,
        [Parameter(Mandatory = $true)][string[]]$ArgumentList
    )

    $startInfo = New-Object Diagnostics.ProcessStartInfo
    $startInfo.FileName = $FilePath
    $startInfo.Arguments = (($ArgumentList | ForEach-Object {
        ConvertTo-ProcessArgument ([string]$_)
    }) -join ' ')
    $startInfo.UseShellExecute = $false
    $startInfo.CreateNoWindow = $true
    $startInfo.RedirectStandardOutput = $true
    $startInfo.RedirectStandardError = $true
    # The CLI emits UTF-8 (PYTHONUTF8=1). Without an explicit encoding the
    # process defaults to the OEM/console codepage (GBK on zh-CN Windows), which
    # garbles all Chinese text in captured output.
    $startInfo.StandardOutputEncoding = [Text.Encoding]::UTF8
    $startInfo.StandardErrorEncoding = [Text.Encoding]::UTF8

    $process = New-Object Diagnostics.Process
    $process.StartInfo = $startInfo
    try {
        if (-not $process.Start()) {
            throw "process did not start"
        }
        $stdoutTask = $process.StandardOutput.ReadToEndAsync()
        $stderrTask = $process.StandardError.ReadToEndAsync()
        $process.WaitForExit()
        return [PSCustomObject]@{
            ExitCode = $process.ExitCode
            Stdout = $stdoutTask.Result
            Stderr = $stderrTask.Result
        }
    } finally {
        $process.Dispose()
    }
}

try {
    $launcherDir = [IO.Path]::GetFullPath($PSScriptRoot)
    $skillDir = [IO.Directory]::GetParent($launcherDir).FullName
    $cliPath = Join-Path $launcherDir "cli.py"
    $bootstrapPath = Join-Path $launcherDir "launch_cli.py"
    $extensionDir = Join-Path $skillDir "extension"
    if (-not (Test-Path -LiteralPath $cliPath -PathType Leaf) -or
        -not (Test-Path -LiteralPath $bootstrapPath -PathType Leaf) -or
        -not (Test-Path -LiteralPath $extensionDir -PathType Container)) {
        Write-LauncherError "launcher_path_invalid" "无法定位 hongshuskill CLI"
    }

    # pairing.json and its lock live beside the unpacked extension. Windows
    # ignores POSIX 0600 semantics, so protect this directory with a real ACL.
    Protect-PrivateDirectory $extensionDir

    $uvPath = Find-UvApplication
    if ($null -eq $uvPath) {
        Write-LauncherError "runtime_dependency_missing" "缺少运行依赖 uv；请先安装 uv 后重试"
    }

    # Do not inherit Git Bash/MSYS TEMP=C:/tmp. Use the native per-user Windows
    # temp directory and pass it to uv/Python so every child agrees on paths.
    $localAppData = [Environment]::GetFolderPath(
        [Environment+SpecialFolder]::LocalApplicationData
    )
    if ([string]::IsNullOrWhiteSpace($localAppData)) {
        Write-LauncherError "runtime_setup_failed" "无法定位 Windows 用户临时目录"
    }
    $runtimeParent = [IO.Path]::GetFullPath((Join-Path $localAppData "Temp"))
    $hashAlgorithm = [Security.Cryptography.SHA256]::Create()
    try {
        $pathBytes = [Text.Encoding]::UTF8.GetBytes($skillDir.ToLowerInvariant())
        $skillKey = -join ($hashAlgorithm.ComputeHash($pathBytes) | ForEach-Object { $_.ToString("x2") })
    } finally {
        $hashAlgorithm.Dispose()
    }

    $runtimeRoot = Join-Path $runtimeParent "hongshuskill-runtime"
    $runtimeDir = Join-Path $runtimeRoot $skillKey
    $venvDir = Join-Path $runtimeDir "venv"
    Protect-PrivateDirectory $runtimeRoot
    Protect-PrivateDirectory $runtimeDir

    # v1.7.3 could leave an empty venv directory that newer uv versions reject.
    # Recover only this exact private cache child; never follow a reparse point.
    if (Test-Path -LiteralPath $venvDir) {
        $venvItem = Get-Item -LiteralPath $venvDir -Force
        if (-not $venvItem.PSIsContainer -or
            (($venvItem.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0)) {
            Write-LauncherError "unsafe_runtime_directory" "hongshuskill 虚拟环境路径不安全"
        }
        $venvConfig = Join-Path $venvDir "pyvenv.cfg"
        $venvPython = Join-Path $venvDir "Scripts\python.exe"
        if (-not (Test-Path -LiteralPath $venvConfig -PathType Leaf) -or
            -not (Test-Path -LiteralPath $venvPython -PathType Leaf)) {
            Remove-Item -LiteralPath $venvDir -Recurse -Force
        }
    }

    $captureDir = Join-Path $runtimeDir ("launch." + [Guid]::NewGuid().ToString("N"))
    Protect-PrivateDirectory $captureDir
    $syncStdout = Join-Path $captureDir "sync-stdout"
    $syncStderr = Join-Path $captureDir "sync-stderr"
    $cliStdout = Join-Path $captureDir "cli-stdout"
    $cliStderr = Join-Path $captureDir "cli-stderr"
    $cliStarted = Join-Path $captureDir "cli-started"

    $oldEnvironment = @{
        UV_PROJECT_ENVIRONMENT = $env:UV_PROJECT_ENVIRONMENT
        PYTHONDONTWRITEBYTECODE = $env:PYTHONDONTWRITEBYTECODE
        PYTHONUTF8 = $env:PYTHONUTF8
        TEMP = $env:TEMP
        TMP = $env:TMP
    }
    $env:UV_PROJECT_ENVIRONMENT = $venvDir
    $env:PYTHONDONTWRITEBYTECODE = "1"
    $env:PYTHONUTF8 = "1"
    $env:TEMP = $runtimeParent
    $env:TMP = $runtimeParent

    try {
        $launcherErrorAction = $ErrorActionPreference
        $ErrorActionPreference = "Continue"
        try {
            $syncResult = Invoke-CapturedProcess $uvPath @(
                "sync", "--quiet", "--frozen", "--no-dev", "--project", $skillDir
            )
            $syncExit = $syncResult.ExitCode
            [IO.File]::WriteAllText($syncStdout, $syncResult.Stdout)
            [IO.File]::WriteAllText($syncStderr, $syncResult.Stderr)
        } finally {
            $ErrorActionPreference = $launcherErrorAction
        }
        if ($syncExit -ne 0) {
            Write-LauncherError "runtime_launch_failed" "uv 无法创建 hongshuskill 锁定运行环境"
        }

        $ErrorActionPreference = "Continue"
        try {
            $cliArguments = @(
                "run", "--quiet", "--frozen", "--no-dev", "--no-sync", "--project", $skillDir,
                "python", $bootstrapPath, $cliStarted, $cliPath
            ) + $args
            $cliResult = Invoke-CapturedProcess $uvPath $cliArguments
            $cliExit = $cliResult.ExitCode
            [IO.File]::WriteAllText($cliStdout, $cliResult.Stdout)
            [IO.File]::WriteAllText($cliStderr, $cliResult.Stderr)
        } finally {
            $ErrorActionPreference = $launcherErrorAction
        }

        if (-not (Test-Path -LiteralPath $cliStarted -PathType Leaf) -or
            (Get-Item -LiteralPath $cliStarted).Length -eq 0) {
            Write-LauncherError "runtime_launch_failed" "uv 无法启动 hongshuskill 锁定运行环境"
        }

        if (Test-Path -LiteralPath $cliStdout) {
            $stdoutText = [IO.File]::ReadAllText($cliStdout)
            if ($stdoutText.Length -gt 0) {
                Microsoft.PowerShell.Utility\Write-Output -NoEnumerate $stdoutText
            }
        }
        if (Test-Path -LiteralPath $cliStderr) {
            $stderrText = [IO.File]::ReadAllText($cliStderr)
            if ($stderrText.Length -gt 0) {
                # Write-Error decorates redirected output and corrupts the JSON
                # contract, so replay the one raw object on the success stream.
                Microsoft.PowerShell.Utility\Write-Output -NoEnumerate $stderrText
            }
        }
        $script:LauncherExitCode = $cliExit
    } finally {
        $env:UV_PROJECT_ENVIRONMENT = $oldEnvironment.UV_PROJECT_ENVIRONMENT
        $env:PYTHONDONTWRITEBYTECODE = $oldEnvironment.PYTHONDONTWRITEBYTECODE
        $env:PYTHONUTF8 = $oldEnvironment.PYTHONUTF8
        $env:TEMP = $oldEnvironment.TEMP
        $env:TMP = $oldEnvironment.TMP
        if (Test-Path -LiteralPath $captureDir) {
            Remove-Item -LiteralPath $captureDir -Recurse -Force -ErrorAction SilentlyContinue
        }
    }
} catch {
    if (-not $script:LauncherErrorEmitted) {
        Write-LauncherError "runtime_setup_failed" "hongshuskill Windows 启动器准备失败" -NoAbort
    }
}

if ($script:NestedInvocation) {
    $global:LASTEXITCODE = $script:LauncherExitCode
    return
}
exit $script:LauncherExitCode
