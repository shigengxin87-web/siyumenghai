#!/usr/bin/env python3
"""hongshuskill command-line interface.

The CLI is intentionally thin: validate inputs, enforce confirmations, resolve
local media, send one high-level browser operation, and emit one JSON envelope.
"""

from __future__ import annotations

import argparse
import base64
import contextlib
import json
import os
import platform
import re
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path
from typing import Any

SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from hongshu import DEFAULT_BRIDGE_URL, VERSION  # noqa: E402
from hongshu.accounts import (  # noqa: E402
    account_record,
    bind_account,
    list_accounts,
    require_account_name,
    require_instance_id,
    resolve_routing,
    unbind_account,
    verify_account,
)
from hongshu.client import (  # noqa: E402
    PROTOCOL_VERSION,
    broker_status,
    call,
    ensure_broker,
    recover_broker,
    replace_legacy_broker,
)
from hongshu.errors import InvalidInput  # noqa: E402
from hongshu.output import emit_error, emit_success  # noqa: E402
from hongshu.risk import build_risk_report  # noqa: E402
from hongshu.validation import (  # noqa: E402
    LOCATIONS,
    NOTE_TYPES,
    PUBLISH_TIMES,
    SEARCH_SCOPES,
    SORT_OPTIONS,
    VISIBILITIES,
    MediaBundle,
    extract_trailing_tags,
    read_utf8_file,
    require_choice,
    require_code,
    require_confirmation,
    require_feed_pair,
    require_float_range,
    require_int_range,
    require_nonempty,
    require_phone,
    require_preview_id,
    require_user_id,
    require_xsec_source,
    require_xsec_token,
    resolve_images,
    resolve_video,
    validate_risk_probe_urls,
    validate_schedule,
    validate_short_title,
)

EXTENSION_DISPLAY_NAME = "Hongshu Local Companion"
MACOS_OPEN_PATH = Path("/usr/bin/open")
EXTENSION_PERMISSIONS = [
    "alarms",
    "tabs",
    "scripting",
    "debugger",
    "cookies",
    "webRequest",
    "storage",
]
FIRST_USE_EXAMPLES = [
    "帮我抓取5篇关于运营起号的小红书笔记，并帮我拆解它们",
    (
        "帮我找到5篇关于运营创业的小红书笔记，并帮我读取它们的评论区。"
        "帮我基于评论区给我3个内容选题灵感"
    ),
    "帮我抓取5篇运营创业的小红书笔记，并且把它们的图文保存到我本地",
]
FIRST_INSTALL_SUCCESS_MESSAGE = (
    "安装完成 ✅ Hongshu Local Companion 已连接。\n\n"
    "你可以直接这样对我说：\n\n"
    + "\n".join(f"{index}. {example}" for index, example in enumerate(FIRST_USE_EXAMPLES, 1))
)
MAX_PUBLISH_TEXT_BYTES = 128 * 1024
MAX_BUNDLED_JSON_BYTES = 64 * 1024
ACCOUNT_GUARD_EXEMPT_OPERATIONS = frozenset(
    {
        "account_identity",
        "check_login",
        "get_qrcode",
        "wait_login",
        "send_code",
        "verify_code",
    }
)


def _launcher_path(skill_dir: Path) -> Path:
    name = "run-hongshu.ps1" if platform.system() == "Windows" else "run-hongshu"
    return skill_dir / "scripts" / name


def _launcher_argv(skill_dir: Path, *arguments: str) -> list[str]:
    launcher = _launcher_path(skill_dir)
    if platform.system() != "Windows":
        return [str(launcher), *arguments]
    powershell = (
        shutil.which("pwsh.exe")
        or shutil.which("pwsh")
        or shutil.which("powershell.exe")
        or shutil.which("powershell")
        or "powershell.exe"
    )
    return [
        powershell,
        "-NoProfile",
        "-NonInteractive",
        "-ExecutionPolicy",
        "Bypass",
        "-File",
        str(launcher),
        *arguments,
    ]


def _launcher_command(skill_dir: Path, *arguments: str) -> str:
    if platform.system() == "Windows":
        suffix = " ".join(arguments)
        command = (
            "powershell.exe -NoProfile -ExecutionPolicy Bypass "
            f"-File .\\scripts\\run-hongshu.ps1 {suffix}"
        )
        return command.rstrip()
    suffix = " ".join(arguments)
    return f"./scripts/run-hongshu {suffix}".rstrip()


class HongshuArgumentParser(argparse.ArgumentParser):
    def error(self, message: str) -> None:
        raise InvalidInput(f"命令参数错误：{message}")


def _rpc(
    args: argparse.Namespace, operation: str, params: dict | None = None, timeout: float = 90.0
):
    route = resolve_routing(getattr(args, "account", None))
    account_guard = None
    target_instance_id = None
    if route is not None:
        target_instance_id = route["instance_id"]
        if operation not in ACCOUNT_GUARD_EXEMPT_OPERATIONS:
            account_guard = {
                "user_id": route["user_id"],
                "session_fingerprint": route["session_fingerprint"],
            }
    return call(
        operation,
        params,
        url=args.bridge_url,
        timeout=timeout,
        target_instance_id=target_instance_id,
        account_guard=account_guard,
    )


def _connected_instance_ids(args: argparse.Namespace) -> set[str]:
    status = broker_status(args.bridge_url)
    return {
        item["instance_id"]
        for item in status.get("extension_instances", [])
        if isinstance(item, dict)
        and isinstance(item.get("instance_id"), str)
        and re.fullmatch(r"[0-9a-f]{32}", item["instance_id"])
    }


def _select_instance(args: argparse.Namespace) -> str:
    connected = _connected_instance_ids(args)
    requested = getattr(args, "instance_id", None)
    if requested:
        instance_id = require_instance_id(requested)
        if instance_id not in connected:
            raise InvalidInput("指定的 Chrome Profile 扩展实例未连接")
        return instance_id
    if not connected:
        raise InvalidInput("没有已连接的新版 Chrome Profile 扩展实例")
    if len(connected) > 1:
        raise InvalidInput(
            "已连接多个 Chrome Profile；请使用 --instance-id 明确选择",
            details={"connected_instance_ids": sorted(connected)},
        )
    return next(iter(connected))


def _inspect_account_identity(args: argparse.Namespace, instance_id: str) -> dict:
    return call(
        "account_identity",
        {},
        url=args.bridge_url,
        timeout=45,
        target_instance_id=instance_id,
    )


def cmd_account_inspect(args: argparse.Namespace) -> dict:
    instance_id = _select_instance(args)
    return _inspect_account_identity(args, instance_id)


def cmd_account_add(args: argparse.Namespace) -> dict:
    name = require_account_name(args.name)
    require_confirmation(
        args.confirm,
        f"将当前已登录的 Chrome Profile 绑定为账号“{name}”",
        consequence="绑定后该账号的后续写操作将精确路由到这个 Chrome Profile",
    )
    instance_id = _select_instance(args)
    identity = _inspect_account_identity(args, instance_id)
    expected_user_id = require_user_id(args.expected_user_id)
    if identity.get("user_id") != expected_user_id:
        raise InvalidInput("当前检测到的用户 ID 与用户确认的账号不一致")
    record = bind_account(name, identity)
    return {
        **record,
        "bound": True,
        "cookies_stored": False,
        "profile_modified": False,
    }


def cmd_account_list(args: argparse.Namespace) -> dict:
    connected = _connected_instance_ids(args)
    accounts = list_accounts(connected)
    bound = {item["instance_id"] for item in accounts}
    return {
        "accounts": accounts,
        "count": len(accounts),
        "unbound_instance_ids": sorted(connected - bound),
    }


def cmd_account_verify(args: argparse.Namespace) -> dict:
    name = require_account_name(args.name)
    require_confirmation(
        args.confirm,
        f"复核账号“{name}”的当前登录会话",
        consequence="只有 Chrome Profile 和平台用户 ID 都与旧绑定一致时才会更新会话指纹",
    )
    record = account_record(name)
    connected = _connected_instance_ids(args)
    if record["instance_id"] not in connected:
        raise InvalidInput("该账号绑定的 Chrome Profile 当前未连接")
    identity = _inspect_account_identity(args, record["instance_id"])
    verified = verify_account(name, identity)
    return {**verified, "verified": True}


def cmd_account_unbind(args: argparse.Namespace) -> dict:
    name = require_account_name(args.name)
    require_confirmation(
        args.confirm,
        f"解除账号“{name}”的本地安全路由绑定",
        consequence="只删除本地账号路由记录，不退出登录、不删 Cookie 或 Chrome Profile",
    )
    return unbind_account(name)


def _comment_text(args: argparse.Namespace) -> str:
    inline = getattr(args, "content", None)
    file_path = getattr(args, "content_file", None)
    if bool(inline) == bool(file_path):
        raise InvalidInput("--content 与 --content-file 必须且只能提供一个")
    if file_path:
        return read_utf8_file(file_path, "评论文件", max_bytes=64 * 1024)
    return require_nonempty(inline, "评论内容")


def _publish_text(args: argparse.Namespace, *, short_title: bool = True) -> tuple[str, str]:
    title = read_utf8_file(args.title_file, "标题文件", max_bytes=8 * 1024)
    # The broker accepts at most a 1 MiB JSON params object. 128 KiB keeps even
    # worst-case JSON escaping of control characters safely below that envelope
    # limit while remaining far above the platform's practical text limits.
    content = read_utf8_file(
        args.content_file,
        "正文文件",
        max_bytes=MAX_PUBLISH_TEXT_BYTES,
    )
    if short_title:
        validate_short_title(title)
    return title, content


def _publish_params(args: argparse.Namespace, title: str, content: str) -> dict[str, Any]:
    content, tags = extract_trailing_tags(content, args.tags)
    return {
        "title": title,
        "content": require_nonempty(content, "正文"),
        "tags": tags,
        "schedule_at": validate_schedule(args.schedule_at),
        "visibility": require_choice(args.visibility, VISIBILITIES, "可见范围") or "公开可见",
        "original": bool(getattr(args, "original", False)),
    }


def _read_bundled_json(path: Path, *, max_bytes: int) -> object:
    if path.is_symlink() or not path.is_file():
        raise ValueError("bundled file is missing or not a regular file")
    if path.stat().st_size > max_bytes:
        raise ValueError("bundled file is too large")
    return json.loads(path.read_text(encoding="utf-8"))


def _inspect_bundled_extension(skill_dir: Path) -> dict[str, Any]:
    extension_dir = skill_dir / "extension"
    manifest_path = extension_dir / "manifest.json"
    pairing_path = extension_dir / "pairing.json"
    required_extension_files = (
        "manifest.json",
        "pairing.json",
        "worker.js",
        "page.js",
        "popup.html",
        "popup.js",
    )
    result: dict[str, Any] = {
        "valid": False,
        "manifest_present": manifest_path.is_file() and not manifest_path.is_symlink(),
        "pairing_present": pairing_path.is_file() and not pairing_path.is_symlink(),
        "reason": "bundled_extension_invalid",
    }
    try:
        extension_dir_is_local = (
            extension_dir.is_dir()
            and not extension_dir.is_symlink()
            and extension_dir.resolve().parent == skill_dir.resolve()
        )
    except OSError:
        extension_dir_is_local = False
    if not extension_dir_is_local:
        result["reason"] = "bundled_extension_directory_invalid"
        return result
    if not result["manifest_present"]:
        result["reason"] = "bundled_extension_missing"
        return result
    if not result["pairing_present"]:
        result["reason"] = "bundled_pairing_missing"
        return result
    if any(
        (extension_dir / name).is_symlink() or not (extension_dir / name).is_file()
        for name in required_extension_files
    ):
        result["reason"] = "bundled_extension_files_missing"
        return result
    try:
        manifest = _read_bundled_json(manifest_path, max_bytes=MAX_BUNDLED_JSON_BYTES)
        pairing = _read_bundled_json(pairing_path, max_bytes=1024)
    except (OSError, UnicodeDecodeError, json.JSONDecodeError, ValueError):
        return result
    permissions = manifest.get("permissions") if isinstance(manifest, dict) else None
    background = manifest.get("background") if isinstance(manifest, dict) else None
    content_scripts = manifest.get("content_scripts") if isinstance(manifest, dict) else None
    action = manifest.get("action") if isinstance(manifest, dict) else None

    def valid_content_script(item: object) -> bool:
        if (
            not isinstance(item, dict)
            or set(item) != {"matches", "js", "run_at"}
            or item.get("js") != ["page.js"]
            or item.get("run_at") != "document_idle"
        ):
            return False
        matches = item.get("matches")
        return (
            isinstance(matches, list)
            and all(isinstance(match, str) for match in matches)
            and set(matches)
            == {
                "https://www.xiaohongshu.com/*",
                "https://creator.xiaohongshu.com/*",
            }
        )

    content_script_valid = (
        isinstance(content_scripts, list)
        and len(content_scripts) == 1
        and valid_content_script(content_scripts[0])
    )
    manifest_valid = (
        isinstance(manifest, dict)
        and set(manifest)
        == {
            "manifest_version",
            "minimum_chrome_version",
            "name",
            "version",
            "description",
            "permissions",
            "host_permissions",
            "background",
            "content_scripts",
            "action",
        }
        and manifest.get("manifest_version") == 3
        and manifest.get("minimum_chrome_version") == "116"
        and manifest.get("name") == EXTENSION_DISPLAY_NAME
        and manifest.get("version") == VERSION
        and isinstance(manifest.get("description"), str)
        and isinstance(permissions, list)
        and all(isinstance(permission, str) for permission in permissions)
        and len(permissions) == len(EXTENSION_PERMISSIONS)
        and set(permissions) == set(EXTENSION_PERMISSIONS)
        and manifest.get("host_permissions") == ["https://*.xiaohongshu.com/*"]
        and background == {"service_worker": "worker.js", "type": "module"}
        and content_script_valid
        and action
        == {
            "default_title": EXTENSION_DISPLAY_NAME,
            "default_popup": "popup.html",
        }
    )
    token = (
        pairing.get("token") if isinstance(pairing, dict) and set(pairing) == {"token"} else None
    )
    pairing_valid = isinstance(token, str) and (
        token == "" or re.fullmatch(r"[0-9a-f]{64}", token) is not None
    )
    if not manifest_valid:
        result["reason"] = "bundled_manifest_invalid"
        return result
    if not pairing_valid:
        result["reason"] = "bundled_pairing_invalid"
        return result
    result.update(valid=True, reason="package_valid")
    return result


def _doctor_snapshot(args: argparse.Namespace) -> dict:
    skill_dir = SCRIPT_DIR.parent
    extension_dir = skill_dir / "extension"
    launcher = _launcher_path(skill_dir)
    package = _inspect_bundled_extension(skill_dir)
    status = (
        ensure_broker(args.bridge_url)
        if package["valid"]
        else {"running": False, "extension_connected": False}
    )
    result = {
        "python": sys.version.split()[0],
        "bridge": status,
        "skill_path": str(skill_dir),
        "launcher_path": str(launcher),
        "extension_path": str(extension_dir),
        "extension_manifest_present": package["manifest_present"],
        "extension_pairing_present": package["pairing_present"],
        "package_valid": package["valid"],
        "ready": bool(
            status.get("broker_version") == VERSION
            and status.get("protocol") == PROTOCOL_VERSION
            and status.get("extension_connected")
            and status.get("extension_version") == VERSION
            and not status.get("quarantined")
        ),
    }
    connected = bool(status.get("extension_connected"))
    quarantined = bool(status.get("quarantined"))
    if not package["valid"]:
        state = "package_invalid"
        reason = package["reason"]
        next_action = "reinstall_skill_package"
    elif quarantined:
        state = "bridge_recovery_required"
        reason = status.get("quarantine_reason") or "operation_state_uncertain"
        next_action = "verify_account_state_then_recover_bridge"
    elif result["ready"]:
        state = "ready"
        reason = "extension_connected"
        next_action = "continue"
    elif connected and status.get("extension_version") != VERSION:
        state = "extension_reload_required"
        reason = "extension_version_mismatch"
        next_action = "prepare_extension_install"
    elif status.get("broker_version") != VERSION or status.get("protocol") != PROTOCOL_VERSION:
        state = "bridge_repair_required"
        reason = "broker_version_mismatch"
        next_action = "rerun_onboard"
    else:
        state = "extension_install_required"
        reason = "extension_not_connected_or_incompatible"
        next_action = "prepare_extension_install"
    setup_required = state in {"extension_install_required", "extension_reload_required"}
    prepare_argv = _launcher_argv(skill_dir, "prepare-extension-install")
    result["onboarding"] = {
        "state": state,
        "reason": reason,
        "setup_mode": "direct_guided",
        "ui_control_check_required": False,
        "confirmation_required": quarantined,
        "confirmation_prompt": (
            "先在浏览器和账号中核验上次操作的实际结果，再明确确认是否解除桥接隔离"
            if quarantined
            else None
        ),
        "next_action": next_action,
        "browser": "Google Chrome",
        "extensions_url": "chrome://extensions",
        "extension_name": EXTENSION_DISPLAY_NAME,
        "extension_path": str(extension_dir),
        "expected_version": VERSION,
        "required_permissions": EXTENSION_PERMISSIONS,
        "prepare_argv": prepare_argv,
        "guided_prepare_argv": prepare_argv,
        "manual_user_steps_expected": setup_required,
        "user_message_available_after_prepare": setup_required,
        "manual_steps": [
            "enable_developer_mode",
            "click_load_unpacked",
            "select_extension_path_folder",
            "verify_extension_card_and_enabled_state",
            "run_verification_command",
        ]
        if setup_required
        else [],
        "unsupported_shortcuts": [
            "applescript_without_pregranted_accessibility",
            "editing_chrome_secure_preferences",
            "installing_local_crx_on_macos_or_windows",
            "creating_enterprise_policy_on_an_unmanaged_device",
            "killing_chrome_to_add_load_extension_flags",
        ],
        "verification_command": _launcher_command(skill_dir, "onboard", "--wait-seconds", "15"),
        "verification_argv": _launcher_argv(skill_dir, "onboard", "--wait-seconds", "15"),
        "success_user_message": FIRST_INSTALL_SUCCESS_MESSAGE if result["ready"] else None,
        "first_use_examples": FIRST_USE_EXAMPLES if result["ready"] else [],
        "recovery_request_id": status.get("quarantine_request_id"),
        "recovery_argv_after_confirmation": (
            [
                *_launcher_argv(skill_dir),
                "recover-bridge",
                "--request-id",
                str(status.get("quarantine_request_id")),
                "--confirm",
            ]
            if quarantined and status.get("quarantine_request_id")
            else []
        ),
    }
    return result


def cmd_doctor(args: argparse.Namespace) -> dict:
    return _doctor_snapshot(args)


def cmd_recover_bridge(args: argparse.Namespace) -> dict:
    require_confirmation(
        args.confirm,
        "解除不确定操作的桥接隔离",
        consequence=(
            "只有用户已在浏览器、个人主页、草稿箱或互动状态中核验上次操作结果后，"
            "才能解除桥接隔离并添加 --confirm"
        ),
    )
    if args.request_id is None:
        raise InvalidInput("recover-bridge 必须提供 onboard 返回的 --request-id")
    request_id = require_nonempty(args.request_id, "request_id")
    return recover_broker(args.bridge_url, request_id, confirmed=True)


def cmd_upgrade_bridge(args: argparse.Namespace) -> dict:
    require_confirmation(
        args.confirm,
        "停止旧版桥接并升级认证协议",
        consequence=(
            "只有用户已确认浏览器中没有正在进行的发布、评论、登录或其他账号操作后，"
            "才能停止旧桥接并添加 --confirm"
        ),
    )
    return replace_legacy_broker(args.bridge_url, confirmed=True)


def cmd_onboard(args: argparse.Namespace) -> dict:
    wait_seconds = require_float_range(args.wait_seconds, "扩展连接等待时间", 0, 60)
    started = time.monotonic()
    deadline = started + wait_seconds
    result = _doctor_snapshot(args)
    while not result["ready"] and time.monotonic() < deadline:
        time.sleep(min(0.25, max(0, deadline - time.monotonic())))
        result = _doctor_snapshot(args)
    result["onboarding"]["waited_ms"] = round((time.monotonic() - started) * 1000)
    return result


def _run_open_command(command: list[str], label: str) -> None:
    try:
        completed = subprocess.run(
            command,
            check=False,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=10,
        )
    except (OSError, subprocess.SubprocessError) as exc:
        raise InvalidInput(f"无法{label}", details={"reason": exc.__class__.__name__}) from exc
    if completed.returncode != 0:
        raise InvalidInput(f"无法{label}", details={"returncode": completed.returncode})


def _run_detached_windows_command(command: list[str], label: str) -> None:
    creationflags = getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0) | getattr(
        subprocess, "CREATE_NO_WINDOW", 0
    )
    try:
        subprocess.Popen(
            command,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            close_fds=True,
            creationflags=creationflags,
        )
    except OSError as exc:
        raise InvalidInput(f"无法{label}", details={"reason": exc.__class__.__name__}) from exc


def _open_install_surfaces(extension_dir: Path) -> list[str]:
    package = _inspect_bundled_extension(extension_dir.parent)
    if not package["valid"]:
        raise InvalidInput(
            "包内浏览器扩展不完整，请重新安装完整 Skill 包",
            details={"reason": package["reason"]},
        )
    system = platform.system()
    if system == "Darwin":
        opener = MACOS_OPEN_PATH
        if not opener.is_file():
            raise InvalidInput("系统缺少 open 命令，无法打开安装界面")
        _run_open_command(
            [str(opener), "-a", "Google Chrome", "chrome://extensions"],
            "打开扩展管理页",
        )
        _run_open_command(
            [str(opener), "-R", str(extension_dir)],
            "在 Finder 中定位扩展目录",
        )
        return ["opened_chrome_extensions", "revealed_extension_in_finder"]
    if system == "Windows":
        candidates = [
            Path(os.environ.get(name, "")) / "Google/Chrome/Application/chrome.exe"
            for name in ("PROGRAMFILES", "PROGRAMFILES(X86)", "LOCALAPPDATA")
            if os.environ.get(name)
        ]
        chrome = next((path for path in candidates if path.is_file()), None)
        chrome = chrome or shutil.which("chrome.exe") or shutil.which("chrome")
        explorer = shutil.which("explorer.exe") or shutil.which("explorer")
        if chrome is None or explorer is None:
            raise InvalidInput("无法定位 Google Chrome 或 Windows 文件资源管理器")
        _run_detached_windows_command([str(chrome), "chrome://extensions"], "打开扩展管理页")
        _run_detached_windows_command(
            [explorer, f"/select,{extension_dir}"],
            "在文件资源管理器中定位扩展目录",
        )
        return ["opened_chrome_extensions", "revealed_extension_in_explorer"]
    if system == "Linux":
        browser = next(
            (
                path
                for name in (
                    "google-chrome",
                    "google-chrome-stable",
                    "chromium",
                    "chromium-browser",
                )
                if (path := shutil.which(name))
            ),
            None,
        )
        file_opener = shutil.which("xdg-open")
        if browser is None or file_opener is None:
            raise InvalidInput("无法定位 Chrome/Chromium 或 xdg-open")
        _run_open_command([browser, "chrome://extensions"], "打开扩展管理页")
        _run_open_command(
            [file_opener, str(extension_dir)],
            "在文件管理器中打开扩展目录",
        )
        return ["opened_chrome_extensions", "opened_extension_folder"]
    raise InvalidInput("当前操作系统不支持自动打开扩展安装界面", details={"system": system})


def _install_user_message(extension_dir: Path, system: str) -> str:
    file_manager = {
        "Darwin": "Finder",
        "Windows": "文件资源管理器",
        "Linux": "文件管理器",
    }.get(system, "文件管理器")
    display_path = str(extension_dir).replace("`", "\\`")
    return (
        "我已经成功：\n\n"
        "- **打开 Chrome 扩展管理页**（`chrome://extensions` 已在新标签页打开）\n"
        f"- **在 {file_manager} 中定位了扩展文件夹**（已弹出对应窗口）\n\n"
        "现在需要你本人在 Chrome 中完成最后几步安全操作"
        "（扩展页已打开，请按下面顺序操作）：\n\n"
        "1. 开启右上角 **“开发者模式”**。\n"
        "2. 点击左上角 **“加载已解压的扩展程序”**。\n"
        "3. 在弹出的文件夹选择器中选择：\n\n"
        f"   `{display_path}`\n\n"
        f"   {file_manager} 已定位这个文件夹；也可以尝试把 `extension` 文件夹拖入"
        "已打开的扩展页，若 Chrome 没反应就使用第 2 步。\n"
        f"4. 确认出现 **“{EXTENSION_DISPLAY_NAME}”** v{VERSION} 卡片，且开关处于启用状态。\n\n"
        "如果已经存在同名卡片，先启用它并点击一次“重新加载”。"
        f"若卡片仍不是 v{VERSION}，它可能指向另一个安装路径；请先确认"
        "没有进行中的发布、评论或登录操作，由你本人停用或移除旧卡片，"
        "再用“加载已解压的扩展程序”选择上方本次路径。\n\n"
        "完成后告诉我，我会自动验证连接并继续。"
    )


def cmd_prepare_extension_install(args: argparse.Namespace) -> dict:
    extension_dir = SCRIPT_DIR.parent / "extension"
    system = platform.system()
    actions = _open_install_surfaces(extension_dir)
    skill_dir = SCRIPT_DIR.parent
    return {
        "prepared": True,
        "automatic_install_completed": False,
        "reason": "chrome_requires_final_user_security_steps",
        "actions": actions,
        "extension_path": str(extension_dir),
        "extension_name": EXTENSION_DISPLAY_NAME,
        "expected_version": VERSION,
        "user_message": _install_user_message(extension_dir, system),
        "remaining_user_steps": [
            "在 Chrome 扩展页开启开发者模式",
            "点击“加载已解压的扩展程序”并选择 extension_path 文件夹本身",
            "确认扩展卡片名称和版本正确且已启用，然后回到 Agent 继续连接验收",
        ],
        "verification_argv": _launcher_argv(skill_dir, "onboard", "--wait-seconds", "15"),
    }


def cmd_check_login(args: argparse.Namespace) -> dict:
    status = _rpc(args, "check_login", timeout=45)
    if status.get("logged_in"):
        return status
    qr = _save_qrcode(_rpc(args, "get_qrcode", timeout=45))
    return {
        **status,
        **qr,
        "login_method": "qrcode",
        "hint": "未登录；扫码后运行 wait-login 等待登录结果",
    }


def _save_qrcode(result: dict, output: str | None = None) -> dict:
    redacted = {
        key: value
        for key, value in result.items()
        if key not in {"data_url", "qr_login_url", "qrcode_image_url"}
    }
    data_url = str(result.get("data_url", ""))
    if not data_url:
        return redacted
    if "," not in data_url:
        raise InvalidInput("浏览器返回了无效二维码数据")
    prefix, encoded = data_url.split(",", 1)
    if prefix.lower() != "data:image/png;base64":
        raise InvalidInput("浏览器返回的二维码不是 PNG 数据")
    try:
        raw = base64.b64decode(encoded, validate=True)
    except Exception as exc:
        raise InvalidInput("二维码数据解码失败") from exc
    if len(raw) > 5 * 1024 * 1024 or not raw.startswith(b"\x89PNG\r\n\x1a\n"):
        raise InvalidInput("浏览器返回的二维码 PNG 数据无效")
    if output:
        path = Path(output).expanduser()
        if not path.is_absolute():
            raise InvalidInput("二维码输出路径必须是绝对路径")
        if not path.parent.is_dir():
            raise InvalidInput("二维码输出目录不存在")
        flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL
        if hasattr(os, "O_NOFOLLOW"):
            flags |= os.O_NOFOLLOW
        created = False
        try:
            file_descriptor = os.open(path, flags, 0o600)
            created = True
            with os.fdopen(file_descriptor, "wb") as handle:
                handle.write(raw)
        except FileExistsError as exc:
            raise InvalidInput("二维码输出文件已存在；为避免覆盖，请更换路径") from exc
        except OSError as exc:
            if created:
                with contextlib.suppress(OSError):
                    path.unlink()
            raise InvalidInput(
                "无法安全写入二维码输出文件",
                details={"reason": exc.__class__.__name__},
            ) from exc
    else:
        file_descriptor, raw_path = tempfile.mkstemp(
            prefix="hongshuskill-qrcode-",
            suffix=".png",
        )
        path = Path(raw_path)
        try:
            with os.fdopen(file_descriptor, "wb") as handle:
                handle.write(raw)
        except Exception:
            path.unlink(missing_ok=True)
            raise
    return {**redacted, "qrcode_path": str(path)}


def cmd_get_qrcode(args: argparse.Namespace) -> dict:
    return _save_qrcode(_rpc(args, "get_qrcode", timeout=45), args.output)


def cmd_wait_login(args: argparse.Namespace) -> dict:
    timeout = require_float_range(args.timeout, "登录等待时间", 1, 600)
    return _rpc(args, "wait_login", {"timeout_seconds": timeout}, timeout=timeout + 10)


def cmd_login(args: argparse.Namespace) -> dict:
    timeout = require_float_range(args.timeout, "登录等待时间", 1, 600)
    qr = _save_qrcode(_rpc(args, "get_qrcode", timeout=45), args.output)
    if qr.get("logged_in"):
        return qr
    result = _rpc(args, "wait_login", {"timeout_seconds": timeout}, timeout=timeout + 10)
    return {**result, "qrcode_path": qr.get("qrcode_path")}


def cmd_send_code(args: argparse.Namespace) -> dict:
    require_confirmation(args.confirm, "向已确认的手机号发送登录验证码")
    return _rpc(
        args,
        "send_code",
        {"phone": require_phone(args.phone), "confirmed": True},
        timeout=45,
    )


def cmd_verify_code(args: argparse.Namespace) -> dict:
    return _rpc(args, "verify_code", {"code": require_code(args.code)}, timeout=45)


def cmd_phone_login(args: argparse.Namespace) -> dict:
    phone = require_phone(args.phone)
    if not args.code:
        raise InvalidInput(
            "phone-login 必须提供 --code；请先使用 send-code，再提交本次收到的验证码"
        )
    code = require_code(args.code)
    require_confirmation(
        args.confirm,
        "使用已确认账号提交登录验证码",
    )
    verified = _rpc(args, "verify_code", {"code": code}, timeout=45)
    return {
        "send": {
            "skipped": True,
            "reason": "using_existing_code",
            "phone_masked": phone[:3] + "****" + phone[-4:],
        },
        "verify": verified,
    }


def cmd_delete_cookies(args: argparse.Namespace) -> dict:
    require_confirmation(args.confirm, "退出登录并清除小红书 cookies")
    return _rpc(args, "delete_cookies", {"confirmed": True}, timeout=45)


def cmd_list_feeds(args: argparse.Namespace) -> dict:
    limit = require_int_range(args.limit, "结果数量", 1, 100)
    return _rpc(args, "list_feeds", {"limit": limit}, timeout=60)


def cmd_search_feeds(args: argparse.Namespace) -> dict:
    keyword = require_nonempty(args.keyword, "搜索关键词")
    limit = require_int_range(args.limit, "结果数量", 1, 100)
    params = {
        "keyword": keyword,
        "limit": limit,
        "filters": {
            "sort_by": require_choice(args.sort_by, SORT_OPTIONS, "排序"),
            "note_type": require_choice(args.note_type, NOTE_TYPES, "笔记类型"),
            "publish_time": require_choice(args.publish_time, PUBLISH_TIMES, "发布时间"),
            "search_scope": require_choice(args.search_scope, SEARCH_SCOPES, "搜索范围"),
            "location": require_choice(args.location, LOCATIONS, "位置距离"),
        },
    }
    return _rpc(args, "search_feeds", params, timeout=75)


def cmd_get_feed_detail(args: argparse.Namespace) -> dict:
    feed_id, token = require_feed_pair(args.feed_id, args.xsec_token)
    max_replies = require_int_range(args.max_replies_threshold, "子评论展开阈值", 0, 100)
    max_comments = require_int_range(args.max_comment_items, "评论数量上限", 0, 500)
    params = {
        "feed_id": feed_id,
        "xsec_token": token,
        "xsec_source": require_xsec_source(args.xsec_source),
        "load_all_comments": args.load_all_comments,
        "click_more_replies": args.click_more_replies,
        "max_replies_threshold": max_replies,
        "max_comment_items": max_comments,
        "scroll_speed": args.scroll_speed,
        "keyword": args.source_keyword.strip() if args.source_keyword else "",
    }
    timeout = 240 if args.load_all_comments else 75
    return _rpc(args, "get_feed_detail", params, timeout=timeout)


def cmd_user_profile(args: argparse.Namespace) -> dict:
    user_id = require_user_id(args.user_id)
    token = require_xsec_token(args.xsec_token)
    return _rpc(
        args,
        "user_profile",
        {
            "user_id": user_id,
            "xsec_token": token,
            "xsec_source": require_xsec_source(args.xsec_source),
        },
        timeout=75,
    )


def cmd_inspect_actions(args: argparse.Namespace) -> dict:
    feed_id, token = require_feed_pair(args.feed_id, args.xsec_token)
    if args.comment_id and args.user_id:
        raise InvalidInput("--comment-id 与 --user-id 最多提供一个")
    params = {
        "feed_id": feed_id,
        "xsec_token": token,
        "xsec_source": require_xsec_source(args.xsec_source),
        "comment_id": require_nonempty(args.comment_id, "comment_id") if args.comment_id else None,
        "user_id": require_user_id(args.user_id) if args.user_id else None,
    }
    return _rpc(args, "inspect_actions", params, timeout=90)


def cmd_post_comment(args: argparse.Namespace) -> dict:
    require_confirmation(args.confirm, "发表评论")
    feed_id, token = require_feed_pair(args.feed_id, args.xsec_token)
    return _rpc(
        args,
        "post_comment",
        {
            "feed_id": feed_id,
            "xsec_token": token,
            "xsec_source": require_xsec_source(args.xsec_source),
            "content": _comment_text(args),
            "confirmed": True,
        },
        timeout=75,
    )


def cmd_reply_comment(args: argparse.Namespace) -> dict:
    require_confirmation(args.confirm, "回复评论")
    feed_id, token = require_feed_pair(args.feed_id, args.xsec_token)
    if bool(args.comment_id) == bool(args.user_id):
        raise InvalidInput("--comment-id 与 --user-id 必须且只能提供一个")
    comment_id = require_nonempty(args.comment_id, "comment_id") if args.comment_id else None
    user_id = require_user_id(args.user_id) if args.user_id else None
    return _rpc(
        args,
        "reply_comment",
        {
            "feed_id": feed_id,
            "xsec_token": token,
            "xsec_source": require_xsec_source(args.xsec_source),
            "content": _comment_text(args),
            "comment_id": comment_id,
            "user_id": user_id,
            "confirmed": True,
        },
        timeout=75,
    )


def cmd_like_feed(args: argparse.Namespace) -> dict:
    require_confirmation(args.confirm, "取消点赞" if args.unlike else "点赞")
    feed_id, token = require_feed_pair(args.feed_id, args.xsec_token)
    return _rpc(
        args,
        "set_like",
        {
            "feed_id": feed_id,
            "xsec_token": token,
            "xsec_source": require_xsec_source(args.xsec_source),
            "target": not args.unlike,
            "confirmed": True,
        },
        timeout=75,
    )


def cmd_favorite_feed(args: argparse.Namespace) -> dict:
    require_confirmation(args.confirm, "取消收藏" if args.unfavorite else "收藏")
    feed_id, token = require_feed_pair(args.feed_id, args.xsec_token)
    return _rpc(
        args,
        "set_favorite",
        {
            "feed_id": feed_id,
            "xsec_token": token,
            "xsec_source": require_xsec_source(args.xsec_source),
            "target": not args.unfavorite,
            "confirmed": True,
        },
        timeout=75,
    )


def _image_publish(args: argparse.Namespace, operation: str, *, action: str) -> dict:
    require_confirmation(args.confirm, action)
    title, content = _publish_text(args)
    params = _publish_params(args, title, content)
    params["confirmed"] = True
    with resolve_images(args.images) as media:
        params["images"] = media.paths
        result = _rpc(args, operation, params, timeout=240)
    return {**result, "resolved_images": len(media.paths)}


def cmd_publish(args: argparse.Namespace) -> dict:
    result = _image_publish(
        args,
        "fill_image",
        action="上传图片并生成待确认发布预览",
    )
    return {
        **result,
        "compatibility_command": "publish",
        "preview_only": True,
        "requires_separate_submit": True,
    }


def cmd_fill_publish(args: argparse.Namespace) -> dict:
    return _image_publish(args, "fill_image", action="上传图片并填写发布预览")


def _video_publish(args: argparse.Namespace, operation: str, *, action: str) -> dict:
    require_confirmation(args.confirm, action)
    title, content = _publish_text(args)
    params = _publish_params(args, title, content)
    params["confirmed"] = True
    params["video"] = resolve_video(args.video)
    return _rpc(args, operation, params, timeout=720)


def cmd_publish_video(args: argparse.Namespace) -> dict:
    result = _video_publish(
        args,
        "fill_video",
        action="上传视频并生成待确认发布预览",
    )
    return {
        **result,
        "compatibility_command": "publish-video",
        "preview_only": True,
        "requires_separate_submit": True,
    }


def cmd_fill_publish_video(args: argparse.Namespace) -> dict:
    return _video_publish(args, "fill_video", action="上传视频并填写发布预览")


def cmd_click_publish(args: argparse.Namespace) -> dict:
    require_confirmation(args.confirm, "提交发布")
    return _rpc(
        args,
        "click_publish",
        {"confirmed": True, "preview_id": require_preview_id(args.preview_id)},
        timeout=90,
    )


def cmd_save_draft(args: argparse.Namespace) -> dict:
    require_confirmation(args.confirm, "保存云端草稿")
    return _rpc(
        args,
        "save_draft",
        {"confirmed": True, "preview_id": require_preview_id(args.preview_id)},
        timeout=60,
    )


def cmd_long_article(args: argparse.Namespace) -> dict:
    require_confirmation(args.confirm, "填写长文并创建新草稿")
    title, content = _publish_text(args, short_title=False)
    manager = (
        resolve_images(args.images)
        if args.images
        else contextlib.nullcontext(MediaBundle(paths=[]))
    )
    with manager as media:
        result = _rpc(
            args,
            "fill_long_article",
            {
                "title": title,
                "content": content,
                "images": media.paths,
                "confirmed": True,
            },
            timeout=240,
        )
    return result


def cmd_select_template(args: argparse.Namespace) -> dict:
    require_confirmation(args.confirm, "更改长文草稿排版模板")
    return _rpc(
        args,
        "select_template",
        {
            "name": require_nonempty(args.name, "模板名称"),
            "preview_id": require_preview_id(args.preview_id),
            "confirmed": True,
        },
        timeout=60,
    )


def cmd_next_step(args: argparse.Namespace) -> dict:
    require_confirmation(args.confirm, "进入长文发布页并填写描述")
    content = read_utf8_file(args.content_file, "描述文件", max_bytes=64 * 1024)
    if len(content) > 1000:
        raise InvalidInput(
            "长文发布描述超过 1000 字；为避免静默丢失内容，请缩短后重试",
            details={"length": len(content), "limit": 1000},
        )
    return _rpc(
        args,
        "long_article_next",
        {
            "content": content,
            "preview_id": require_preview_id(args.preview_id),
            "schedule_at": validate_schedule(args.schedule_at),
            "visibility": require_choice(args.visibility, VISIBILITIES, "可见范围") or "公开可见",
            "original": bool(args.original),
            "confirmed": True,
        },
        timeout=90,
    )


def cmd_diagnose_404(args: argparse.Namespace) -> dict:
    return _rpc(args, "diagnostics", {"clear": args.clear}, timeout=30)


def cmd_check_risk(args: argparse.Namespace) -> dict:
    active = bool(args.active_probes)
    probe_urls = args.probe_urls or []
    if active:
        require_confirmation(
            args.confirm,
            "主动风控探测",
            consequence=(
                "主动风控探测会向小红书真实 API 发起少量诊断请求；"
                "请在用户明确确认后重新执行并添加 --confirm"
            ),
        )
        probe_urls = validate_risk_probe_urls(probe_urls)
    return _rpc(
        args,
        "check_risk",
        {
            "probe_urls": probe_urls,
            "active_probes": active,
            "confirmed": bool(active and args.confirm),
        },
        timeout=75 if active else 60,
    )


def cmd_get_netlog(args: argparse.Namespace) -> dict:
    limit = (
        require_int_range(args.limit, "网络日志数量", 1, 500) if args.limit is not None else None
    )
    return _rpc(args, "get_netlog", {"limit": limit}, timeout=30)


def cmd_risk_report(args: argparse.Namespace) -> dict:
    data = _rpc(args, "get_netlog", {"limit": 500}, timeout=30)
    return build_risk_report(
        data.get("entries") or [],
        data.get("risk_events") or [],
    )


def _add_publish_common(parser: argparse.ArgumentParser, *, media: str) -> None:
    parser.add_argument("--title-file", required=True)
    parser.add_argument("--content-file", required=True)
    if media == "images":
        parser.add_argument("--images", nargs="+", required=True)
        parser.add_argument("--original", action="store_true")
    else:
        parser.add_argument("--video", required=True)
    parser.add_argument("--tags", nargs="*")
    parser.add_argument("--schedule-at")
    parser.add_argument("--visibility", default="公开可见")


def _add_feed_pair(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--feed-id", required=True)
    parser.add_argument("--xsec-token", required=True)
    parser.add_argument("--xsec-source", required=True)


def _add_confirmation(
    parser: argparse.ArgumentParser,
    help_text: str = "确认用户已明确授权这次账号写操作",
) -> None:
    parser.add_argument("--confirm", action="store_true", help=help_text)


def build_parser() -> argparse.ArgumentParser:
    parser = HongshuArgumentParser(description="hongshuskill 小红书自动化 CLI")
    parser.add_argument("--bridge-url", default=DEFAULT_BRIDGE_URL)
    parser.add_argument("--account", help="显式选择已绑定的账号名称")
    parser.add_argument("--version", action="version", version=VERSION)
    commands = parser.add_subparsers(dest="command", required=True)

    sub = commands.add_parser("onboard", help="首次使用自检并返回直接扩展安装引导")
    sub.add_argument("--wait-seconds", type=float, default=0.0)
    sub.set_defaults(func=cmd_onboard)
    sub = commands.add_parser(
        "prepare-extension-install",
        help="打开扩展页、定位包内扩展目录并返回用户安装提示",
    )
    sub.set_defaults(func=cmd_prepare_extension_install)
    sub = commands.add_parser("doctor", help="检查本地桥接与扩展")
    sub.set_defaults(func=cmd_doctor)
    sub = commands.add_parser("recover-bridge", help="核验上次操作后解除桥接隔离")
    sub.add_argument("--request-id")
    _add_confirmation(sub)
    sub.set_defaults(func=cmd_recover_bridge)
    sub = commands.add_parser("upgrade-bridge", help="确认空闲后升级旧版桥接")
    _add_confirmation(sub)
    sub.set_defaults(func=cmd_upgrade_bridge)

    sub = commands.add_parser("account-inspect", help="只读检查当前已登录账号的绑定候选信息")
    sub.add_argument("--instance-id")
    sub.set_defaults(func=cmd_account_inspect)
    sub = commands.add_parser("account-add", help="将当前已登录的 Chrome Profile 绑定为命名账号")
    sub.add_argument("--name", required=True)
    sub.add_argument("--instance-id")
    sub.add_argument("--expected-user-id", required=True)
    _add_confirmation(sub, "确认绑定本次检测到的账号和 Chrome Profile")
    sub.set_defaults(func=cmd_account_add)
    sub = commands.add_parser("account-list", help="列出账号绑定和连接状态")
    sub.set_defaults(func=cmd_account_list)
    sub = commands.add_parser("account-verify", help="重新核对已绑定账号的登录会话")
    sub.add_argument("--name", required=True)
    _add_confirmation(sub, "确认账号用户 ID 无误后更新会话指纹")
    sub.set_defaults(func=cmd_account_verify)
    sub = commands.add_parser("account-unbind", help="解除本地账号路由绑定")
    sub.add_argument("--name", required=True)
    _add_confirmation(sub, "确认只解除本地绑定，不删除 Cookie 或 Chrome Profile")
    sub.set_defaults(func=cmd_account_unbind)

    sub = commands.add_parser("check-login", help="检查登录状态")
    sub.set_defaults(func=cmd_check_login)
    sub = commands.add_parser("get-qrcode", help="获取登录二维码")
    sub.add_argument("--output")
    sub.set_defaults(func=cmd_get_qrcode)
    sub = commands.add_parser("wait-login", help="等待扫码登录")
    sub.add_argument("--timeout", type=float, default=120.0)
    sub.set_defaults(func=cmd_wait_login)
    sub = commands.add_parser("login", help="打开二维码并等待登录")
    sub.add_argument("--timeout", type=float, default=120.0)
    sub.add_argument("--output")
    sub.set_defaults(func=cmd_login)
    sub = commands.add_parser("send-code", help="发送手机验证码")
    sub.add_argument("--phone", required=True)
    _add_confirmation(sub)
    sub.set_defaults(func=cmd_send_code)
    sub = commands.add_parser("verify-code", help="提交短信验证码")
    sub.add_argument("--code", required=True)
    sub.set_defaults(func=cmd_verify_code)
    sub = commands.add_parser(
        "phone-login",
        help="兼容命令：提交已获取的短信验证码（不会发送短信）",
    )
    sub.add_argument("--phone", required=True)
    sub.add_argument("--code")
    _add_confirmation(sub)
    sub.set_defaults(func=cmd_phone_login)
    sub = commands.add_parser("delete-cookies", help="退出登录")
    _add_confirmation(sub)
    sub.set_defaults(func=cmd_delete_cookies)

    sub = commands.add_parser("list-feeds", help="读取首页推荐")
    sub.add_argument("--limit", type=int, default=40)
    sub.set_defaults(func=cmd_list_feeds)
    sub = commands.add_parser("search-feeds", help="关键词搜索笔记")
    sub.add_argument("--keyword", required=True)
    sub.add_argument("--sort-by")
    sub.add_argument("--note-type")
    sub.add_argument("--publish-time")
    sub.add_argument("--search-scope")
    sub.add_argument("--location")
    sub.add_argument("--limit", type=int, default=40)
    sub.set_defaults(func=cmd_search_feeds)
    sub = commands.add_parser("get-feed-detail", help="读取笔记详情和评论")
    _add_feed_pair(sub)
    sub.add_argument("--load-all-comments", action="store_true")
    sub.add_argument("--click-more-replies", action="store_true")
    sub.add_argument("--max-replies-threshold", type=int, default=10)
    sub.add_argument("--max-comment-items", type=int, default=0)
    sub.add_argument("--scroll-speed", choices=("slow", "normal", "fast"), default="normal")
    sub.add_argument(
        "--source-keyword",
        "--keyword",
        dest="source_keyword",
        help="该笔记来自搜索时的原关键词，仅用于访问失败时的回退建议",
    )
    sub.set_defaults(func=cmd_get_feed_detail)
    sub = commands.add_parser("user-profile", help="读取用户主页")
    sub.add_argument("--user-id", required=True)
    sub.add_argument("--xsec-token", required=True)
    sub.add_argument("--xsec-source", required=True)
    sub.set_defaults(func=cmd_user_profile)

    sub = commands.add_parser("inspect-actions", help="只读检查笔记互动状态与按钮就绪情况")
    _add_feed_pair(sub)
    sub.add_argument("--comment-id")
    sub.add_argument("--user-id")
    sub.set_defaults(func=cmd_inspect_actions)

    sub = commands.add_parser("post-comment", help="发表评论")
    _add_feed_pair(sub)
    sub.add_argument("--content")
    sub.add_argument("--content-file")
    _add_confirmation(sub)
    sub.set_defaults(func=cmd_post_comment)
    sub = commands.add_parser("reply-comment", help="回复评论")
    _add_feed_pair(sub)
    sub.add_argument("--content")
    sub.add_argument("--content-file")
    sub.add_argument("--comment-id")
    sub.add_argument("--user-id")
    _add_confirmation(sub)
    sub.set_defaults(func=cmd_reply_comment)
    sub = commands.add_parser("like-feed", help="点赞或取消点赞")
    _add_feed_pair(sub)
    sub.add_argument("--unlike", action="store_true")
    _add_confirmation(sub)
    sub.set_defaults(func=cmd_like_feed)
    sub = commands.add_parser("favorite-feed", help="收藏或取消收藏")
    _add_feed_pair(sub)
    sub.add_argument("--unfavorite", action="store_true")
    _add_confirmation(sub)
    sub.set_defaults(func=cmd_favorite_feed)

    sub = commands.add_parser("publish", help="兼容命令：填写图文预览，不直接发布")
    _add_publish_common(sub, media="images")
    _add_confirmation(sub)
    sub.set_defaults(func=cmd_publish)
    sub = commands.add_parser("fill-publish", help="填写图文表单但不发布")
    _add_publish_common(sub, media="images")
    _add_confirmation(sub)
    sub.set_defaults(func=cmd_fill_publish)
    sub = commands.add_parser("publish-video", help="兼容命令：填写视频预览，不直接发布")
    _add_publish_common(sub, media="video")
    _add_confirmation(sub)
    sub.set_defaults(func=cmd_publish_video)
    sub = commands.add_parser("fill-publish-video", help="填写视频表单但不发布")
    _add_publish_common(sub, media="video")
    _add_confirmation(sub)
    sub.set_defaults(func=cmd_fill_publish_video)
    sub = commands.add_parser("click-publish", help="提交当前预览")
    sub.add_argument("--preview-id")
    _add_confirmation(sub)
    sub.set_defaults(func=cmd_click_publish)
    sub = commands.add_parser("save-draft", help="保存当前内容为草稿")
    sub.add_argument("--preview-id")
    _add_confirmation(sub)
    sub.set_defaults(func=cmd_save_draft)
    sub = commands.add_parser("long-article", help="填写长文并进入排版")
    sub.add_argument("--title-file", required=True)
    sub.add_argument("--content-file", required=True)
    sub.add_argument("--images", nargs="*")
    _add_confirmation(sub)
    sub.set_defaults(func=cmd_long_article)
    sub = commands.add_parser("select-template", help="选择长文排版模板")
    sub.add_argument("--name", required=True)
    sub.add_argument("--preview-id")
    _add_confirmation(sub)
    sub.set_defaults(func=cmd_select_template)
    sub = commands.add_parser("next-step", help="进入长文发布页并填写描述")
    sub.add_argument("--content-file", required=True)
    sub.add_argument("--preview-id")
    sub.add_argument("--schedule-at")
    sub.add_argument("--visibility", default="公开可见")
    sub.add_argument("--original", action="store_true")
    _add_confirmation(sub)
    sub.set_defaults(func=cmd_next_step)

    sub = commands.add_parser("diagnose-404", help="读取受阻网络请求诊断")
    sub.add_argument("--clear", action="store_true")
    sub.set_defaults(func=cmd_diagnose_404)
    sub = commands.add_parser("check-risk", help="检查页面和网络风控信号")
    sub.add_argument("--probe-urls", "--probe-url", dest="probe_urls", nargs="*")
    sub.add_argument("--active-probes", action="store_true")
    sub.add_argument("--confirm", action="store_true", help="确认允许本次真实 API 风控探测")
    sub.set_defaults(func=cmd_check_risk)
    sub = commands.add_parser("get-netlog", help="读取隐私精简的网络日志")
    sub.add_argument("--limit", type=int)
    sub.set_defaults(func=cmd_get_netlog)
    sub = commands.add_parser("risk-report", help="生成结构化风控报告")
    sub.set_defaults(func=cmd_risk_report)
    return parser


def main(argv: list[str] | None = None) -> int:
    started = time.monotonic()
    command = "cli"
    try:
        parser = build_parser()
        args = parser.parse_args(argv)
        command = args.command
        data = args.func(args)
        emit_success(command, data, started)
        if command == "check-login" and not data.get("logged_in"):
            return 1
        if command in {"login", "wait-login", "verify-code"} and not data.get("logged_in"):
            return 2
        if command == "phone-login" and not data.get(
            "logged_in", data.get("verify", {}).get("logged_in")
        ):
            return 2
        return 0
    except Exception as exc:
        return emit_error(command, exc, started)


if __name__ == "__main__":
    raise SystemExit(main())
