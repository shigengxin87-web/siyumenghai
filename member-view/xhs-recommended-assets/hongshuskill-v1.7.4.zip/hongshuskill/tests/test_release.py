from __future__ import annotations

import json
import zipfile
from pathlib import Path

from scripts.build_release import build_release, source_versions
from scripts.hongshu import VERSION


def test_release_versions_are_consistent() -> None:
    assert set(source_versions().values()) == {VERSION}


def test_release_archive_is_clean_and_uses_an_empty_pairing_template(tmp_path: Path) -> None:
    output = tmp_path / f"hongshuskill-Windows-v{VERSION}-fixed.zip"
    result = build_release(output, VERSION)

    assert result["version"] == VERSION
    assert result["file_count"] >= 40
    assert len(result["sha256"]) == 64
    with zipfile.ZipFile(output) as archive:
        names = archive.namelist()
        assert all(name.startswith("hongshuskill/") for name in names)
        assert "hongshuskill/scripts/build_release.py" in names
        assert not any(
            marker in name
            for name in names
            for marker in (".venv", "__pycache__", ".pytest_cache", ".ruff_cache")
        )
        assert json.loads(archive.read("hongshuskill/extension/pairing.json")) == {
            "token": ""
        }
