import time

from scripts.hongshu.risk import build_risk_report


def test_risk_report_detects_rate_limit() -> None:
    report = build_risk_report(
        [
            {"status": 200, "url": "https://www.xiaohongshu.com/api/ok"},
            {"status": 429, "url": "https://www.xiaohongshu.com/api/feed"},
        ]
    )
    assert report["risk_level"] == "high"
    assert report["status_counts"]["429"] == 1


def test_empty_risk_report_is_unknown_instead_of_false_safe() -> None:
    report = build_risk_report([])
    assert report["risk_level"] == "unknown"
    assert report["historical_risk_level"] == "unknown"
    assert report["sample_size"] == 0
    assert report["warnings"]


def test_navigation_aborts_do_not_raise_account_risk() -> None:
    report = build_risk_report(
        [
            {
                "status": 0,
                "error": "net::ERR_ABORTED",
                "category": "other",
                "url": "https://edith.xiaohongshu.com/api/im/redmoji/version",
            },
            {
                "status": 0,
                "error": "net::ERR_FAILED",
                "category": "creator",
                "url": "https://creator.xiaohongshu.com/picasso_pages/author-center/worker.js",
            },
            {
                "status": 0,
                "error": "net::ERR_FAILED",
                "category": "telemetry",
                "url": "https://apm-fe.xiaohongshu.com/api/data",
            },
        ]
    )
    assert report["risk_level"] == "safe"
    assert report["ignored_navigation_failures"] == 3
    assert report["recent_failures"] == []


def test_privacy_safe_detection_axes_use_only_hosts_and_paths() -> None:
    report = build_risk_report(
        [
            {
                "status": 200,
                "category": "telemetry",
                "url": "https://t2.xiaohongshu.com/api/v2/collect",
            },
            {
                "status": 200,
                "category": "telemetry",
                "url": "https://apm-fe.xiaohongshu.com/api/data",
            },
            {
                "status": 200,
                "category": "other",
                "url": "https://www.xiaohongshu.com/api/sec/v1/shield/webprofile",
            },
        ]
    )
    assert report["risk_level"] == "safe"
    assert set(report["detection_axes"]) == {
        "privacy_scope",
        "browser_fingerprint",
        "behavior_tracking",
        "apm_monitoring",
    }
    assert report["top_hosts"]["t2.xiaohongshu.com"] == 1
    assert report["detection_axes"]["privacy_scope"]["cookies"] == "not_collected"


def test_old_preserved_risk_is_historical_but_not_current() -> None:
    now_ms = int(time.time() * 1000)
    report = build_risk_report(
        [{"timestamp": now_ms, "status": 200, "url": "https://www.xiaohongshu.com/api/ok"}],
        [
            {
                "timestamp": now_ms - 20 * 60 * 1000,
                "status": 461,
                "url": "https://edith.xiaohongshu.com/api/risk",
            }
        ],
    )
    assert report["risk_level"] == "safe"
    assert report["historical_risk_level"] == "high"
    assert report["active_sample_size"] == 1
    assert report["preserved_risk_event_count"] == 1
    assert report["high_risk_signals"] == []
    assert report["historical_high_risk_signals"]
    assert any("历史高风险" in warning for warning in report["warnings"])


def test_recent_preserved_risk_survives_rolling_log_eviction() -> None:
    now_ms = int(time.time() * 1000)
    report = build_risk_report(
        [{"timestamp": now_ms, "status": 200, "url": "https://www.xiaohongshu.com/api/ok"}],
        [
            {
                "timestamp": now_ms - 60 * 1000,
                "status": 461,
                "url": "https://edith.xiaohongshu.com/api/risk",
            }
        ],
    )
    assert report["risk_level"] == "high"
    assert report["historical_risk_level"] == "high"
    assert report["total_requests"] == 1
    assert report["sample_size"] == 2
    assert report["status_counts"]["461"] == 1


def test_same_event_is_not_double_counted_across_stores() -> None:
    event = {
        "timestamp": int(time.time() * 1000),
        "method": "GET",
        "status": 461,
        "url": "https://edith.xiaohongshu.com/api/risk",
        "error": "",
        "category": "other",
        "tab_id": 7,
    }
    report = build_risk_report([event], [dict(event)])
    assert report["sample_size"] == 1
    assert report["preserved_risk_event_count"] == 1
    assert report["status_counts"]["461"] == 1


def test_records_older_than_historical_window_do_not_create_permanent_risk() -> None:
    old = {
        "timestamp": (time.time() - 25 * 60 * 60) * 1000,
        "status": 461,
        "url": "https://edith.xiaohongshu.com/api/sns/web/v1/feed",
        "category": "feed",
    }

    report = build_risk_report([old], [old])

    assert report["risk_level"] == "unknown"
    assert report["historical_risk_level"] == "unknown"
    assert report["historical_window_hours"] == 24
    assert report["sample_size"] == 0
    assert report["preserved_risk_event_count"] == 0
    assert report["high_risk_signals"] == []
    assert "超过 24 小时" in report["summary"]


def test_malformed_status_and_url_do_not_crash_report() -> None:
    report = build_risk_report(
        [
            {
                "timestamp": time.time() * 1000,
                "status": "oops",
                "url": "http://[broken",
            }
        ]
    )

    assert report["risk_level"] == "safe"
    assert report["status_counts"] == {}
    assert report["top_hosts"] == {"unknown": 1}


def test_non_list_logs_and_far_future_events_are_ignored_with_warnings() -> None:
    report = build_risk_report(
        {"status": 461},
        [
            {
                "timestamp": (time.time() + 60 * 60) * 1000,
                "status": 461,
                "url": "https://edith.xiaohongshu.com/api/risk",
            }
        ],
    )

    assert report["risk_level"] == "unknown"
    assert report["sample_size"] == 0
    assert any("格式损坏" in warning for warning in report["warnings"])
    assert any("时间明显超前" in warning for warning in report["warnings"])
