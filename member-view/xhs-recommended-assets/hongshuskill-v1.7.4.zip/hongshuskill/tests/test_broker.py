from __future__ import annotations

import asyncio
import json
import os
import stat
import time
from collections.abc import Awaitable, Callable
from pathlib import Path

import pytest
from websockets.asyncio.client import ClientConnection, connect
from websockets.asyncio.server import serve

from scripts import bridge_server
from scripts.bridge_server import Broker, _write_inflight_journal
from scripts.hongshu import client
from scripts.hongshu.auth import NonceReplayCache, sign_envelope, verify_envelope

EXTENSION_ID = "imjmjiibghdoemjjlebpgpfkfedlkiic"
TOKEN = bytes.fromhex("42" * 32)
OTHER_TOKEN = bytes.fromhex("24" * 32)
INSTANCE_ID = "12" * 16


def extension_hello() -> dict:
    return {
        "role": "extension",
        "name": "hongshuskill-extension",
        "version": bridge_server.EXTENSION_VERSION,
        "protocol": 2,
        "extension_id": EXTENSION_ID,
        "instance_id": INSTANCE_ID,
    }


async def send_authenticated(
    websocket: ClientConnection,
    payload: dict,
    *,
    token: bytes = TOKEN,
) -> None:
    await websocket.send(json.dumps(sign_envelope(payload, token), ensure_ascii=False))


async def receive_authenticated(
    websocket: ClientConnection,
    *,
    replay_cache: NonceReplayCache | None = None,
) -> dict:
    message = json.loads(await websocket.recv())
    return verify_envelope(message, TOKEN, replay_cache or NonceReplayCache())


async def with_broker(
    scenario: Callable[[Broker, str], Awaitable[None]],
    *,
    broker: Broker | None = None,
) -> None:
    broker = broker or Broker(TOKEN)
    server = await serve(broker.handler, "127.0.0.1", 0)
    port = server.sockets[0].getsockname()[1]
    try:
        await scenario(broker, f"ws://127.0.0.1:{port}")
    finally:
        server.close()
        await server.wait_closed()


async def exchange(
    url: str,
    payload: dict,
    *,
    origin: str | None = None,
    signing_token: bytes | None = TOKEN,
) -> dict:
    kwargs = {"origin": origin} if origin is not None else {}
    async with connect(url, **kwargs) as websocket:
        if signing_token is None:
            await websocket.send(json.dumps(payload))
        else:
            await send_authenticated(websocket, payload, token=signing_token)
        return await receive_authenticated(websocket)


def test_broker_pairs_extension_and_routes_one_authenticated_request() -> None:
    async def scenario(broker: Broker, url: str) -> None:
        async def extension() -> None:
            incoming = NonceReplayCache()
            async with connect(url, origin=f"chrome-extension://{EXTENSION_ID}") as websocket:
                await send_authenticated(websocket, extension_hello())
                paired = await receive_authenticated(websocket, replay_cache=incoming)
                assert paired["ok"] is True
                request = await receive_authenticated(websocket, replay_cache=incoming)
                assert request["id"] != "request-1"
                await send_authenticated(
                    websocket,
                    {
                        "kind": "rpc_result",
                        "id": request["id"],
                        "ok": True,
                        "result": {"echo": request["op"]},
                    },
                )

        extension_task = asyncio.create_task(extension())
        await asyncio.wait_for(broker.extension_ready.wait(), timeout=2)
        response = await exchange(
            url,
            {
                "role": "client",
                "protocol": 2,
                "id": "request-1",
                "op": "check_login",
                "params": {},
                "timeout": 2,
            },
        )
        assert response == {
            "kind": "rpc_result",
            "id": "request-1",
            "ok": True,
            "result": {"echo": "check_login"},
        }
        await extension_task

    asyncio.run(with_broker(scenario))


def test_broker_accepts_authenticated_keepalive_before_rpc_result() -> None:
    async def scenario(broker: Broker, url: str) -> None:
        async def extension() -> None:
            incoming = NonceReplayCache()
            async with connect(url, origin=f"chrome-extension://{EXTENSION_ID}") as websocket:
                await send_authenticated(websocket, extension_hello())
                paired = await receive_authenticated(websocket, replay_cache=incoming)
                assert paired["ok"] is True
                await send_authenticated(
                    websocket,
                    {"kind": "extension_keepalive", "protocol": 2},
                )
                request = await receive_authenticated(websocket, replay_cache=incoming)
                await send_authenticated(
                    websocket,
                    {
                        "kind": "rpc_result",
                        "id": request["id"],
                        "ok": True,
                        "result": {"logged_in": True},
                    },
                )

        extension_task = asyncio.create_task(extension())
        await asyncio.wait_for(broker.extension_ready.wait(), timeout=2)
        response = await exchange(
            url,
            {
                "role": "client",
                "protocol": 2,
                "id": "keepalive-request",
                "op": "check_login",
                "params": {},
                "timeout": 2,
            },
        )
        assert response["ok"] is True
        assert response["result"] == {"logged_in": True}
        await extension_task

    asyncio.run(with_broker(scenario))


def test_broker_routes_named_instances_without_replacing_other_profile() -> None:
    async def scenario(broker: Broker, url: str) -> None:
        requests: dict[str, str] = {}

        async def extension(instance_id: str, label: str) -> None:
            incoming = NonceReplayCache()
            async with connect(url, origin=f"chrome-extension://{EXTENSION_ID}") as websocket:
                await send_authenticated(
                    websocket,
                    {**extension_hello(), "instance_id": instance_id},
                )
                paired = await receive_authenticated(websocket, replay_cache=incoming)
                assert paired["ok"] is True
                request = await receive_authenticated(websocket, replay_cache=incoming)
                requests[label] = request["op"]
                await send_authenticated(
                    websocket,
                    {
                        "kind": "rpc_result",
                        "id": request["id"],
                        "ok": True,
                        "result": {"profile": label},
                    },
                )

        first = "11" * 16
        second = "22" * 16
        tasks = [
            asyncio.create_task(extension(first, "A")),
            asyncio.create_task(extension(second, "B")),
        ]
        for _ in range(40):
            if len(broker.extensions) == 2:
                break
            await asyncio.sleep(0.05)
        assert set(broker.extensions) == {first, second}

        response = await exchange(
            url,
            {
                "role": "client",
                "protocol": 2,
                "id": "route-b",
                "op": "check_login",
                "params": {},
                "timeout": 2,
                "target_instance_id": second,
            },
        )
        assert response["result"] == {"profile": "B"}
        assert requests == {"B": "check_login"}

        response = await exchange(
            url,
            {
                "role": "client",
                "protocol": 2,
                "id": "route-a",
                "op": "check_login",
                "params": {},
                "timeout": 2,
                "target_instance_id": first,
            },
        )
        assert response["result"] == {"profile": "A"}
        await asyncio.gather(*tasks)

    asyncio.run(with_broker(scenario))


def test_native_peer_cannot_forge_extension_authentication() -> None:
    async def scenario(broker: Broker, url: str) -> None:
        unsigned = await exchange(
            url,
            extension_hello(),
            origin=f"chrome-extension://{EXTENSION_ID}",
            signing_token=None,
        )
        assert unsigned["error"]["code"] == "authentication_failed"

        wrong_key = await exchange(
            url,
            extension_hello(),
            origin=f"chrome-extension://{EXTENSION_ID}",
            signing_token=OTHER_TOKEN,
        )
        assert wrong_key["error"]["code"] == "authentication_failed"
        assert broker.extension_ready.is_set() is False

    asyncio.run(with_broker(scenario))


def test_client_requests_also_require_authentication() -> None:
    async def scenario(_broker: Broker, url: str) -> None:
        payload = {
            "role": "client",
            "protocol": 2,
            "id": "unsigned-client",
            "op": "broker_status",
            "params": {},
        }
        rejected = await exchange(url, payload, signing_token=None)
        assert rejected["error"]["code"] == "authentication_failed"

        wrong_key = await exchange(url, payload, signing_token=OTHER_TOKEN)
        assert wrong_key["error"]["code"] == "authentication_failed"

    asyncio.run(with_broker(scenario))


def test_broker_rejects_untrusted_or_malformed_authenticated_peers() -> None:
    async def scenario(_broker: Broker, url: str) -> None:
        wrong_identity = await exchange(
            url,
            {**extension_hello(), "name": "another-extension"},
            origin=f"chrome-extension://{EXTENSION_ID}",
        )
        assert wrong_identity["error"]["code"] == "pairing_rejected"

        mismatched_origin = await exchange(
            url,
            extension_hello(),
            origin="chrome-extension://aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
        )
        assert mismatched_origin["error"]["code"] == "pairing_rejected"

        outdated_extension = await exchange(
            url,
            {**extension_hello(), "version": "1.0.0"},
            origin=f"chrome-extension://{EXTENSION_ID}",
        )
        assert outdated_extension["error"]["code"] == "pairing_rejected"

        first_pair = await exchange(
            url,
            extension_hello(),
            origin=f"chrome-extension://{EXTENSION_ID}",
        )
        assert first_pair["ok"] is True
        other_extension_id = "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
        pinned_rejection = await exchange(
            url,
            {**extension_hello(), "extension_id": other_extension_id},
            origin=f"chrome-extension://{other_extension_id}",
        )
        assert pinned_rejection["error"]["code"] == "pairing_rejected"

        browser_client = await exchange(
            url,
            {
                "role": "client",
                "protocol": 2,
                "id": "browser-client",
                "op": "check_login",
                "params": {},
            },
            origin="https://example.com",
        )
        assert browser_client["error"]["code"] == "origin_rejected"

        wrong_protocol = await exchange(
            url,
            {
                "role": "client",
                "protocol": 99,
                "id": "wrong-protocol",
                "op": "check_login",
                "params": {},
            },
        )
        assert wrong_protocol["error"]["code"] == "protocol_mismatch"

        invalid_params = await exchange(
            url,
            {
                "role": "client",
                "protocol": 2,
                "id": "invalid-params",
                "op": "check_login",
                "params": [],
            },
        )
        assert invalid_params["error"]["code"] == "invalid_request"

        invalid_status_params = await exchange(
            url,
            {
                "role": "client",
                "protocol": 2,
                "id": "invalid-status-params",
                "op": "broker_status",
                "params": None,
            },
        )
        assert invalid_status_params["error"]["code"] == "invalid_request"

        invalid_timeout = await exchange(
            url,
            {
                "role": "client",
                "protocol": 2,
                "id": "invalid-timeout",
                "op": "check_login",
                "params": {},
                "timeout": "nan",
            },
        )
        assert invalid_timeout["error"]["code"] == "invalid_request"

        unknown_operation = await exchange(
            url,
            {
                "role": "client",
                "protocol": 2,
                "id": "unknown-op",
                "op": "arbitrary_javascript",
                "params": {},
            },
        )
        assert unknown_operation["error"]["code"] == "operation_not_allowed"

        unconfirmed_write = await exchange(
            url,
            {
                "role": "client",
                "protocol": 2,
                "id": "unconfirmed-write",
                "op": "post_comment",
                "params": {"content": "test"},
            },
        )
        assert unconfirmed_write["error"]["code"] == "confirmation_required"

        verification_code_is_itself_confirmation = await exchange(
            url,
            {
                "role": "client",
                "protocol": 2,
                "id": "verify-code",
                "op": "verify_code",
                "params": {"code": "123456"},
            },
        )
        assert verification_code_is_itself_confirmation["error"]["code"] == (
            "extension_unavailable"
        )

        unconfirmed_active_probe = await exchange(
            url,
            {
                "role": "client",
                "protocol": 2,
                "id": "active-probe",
                "op": "check_risk",
                "params": {"active_probes": True},
            },
        )
        assert unconfirmed_active_probe["error"]["code"] == "confirmation_required"

        invalid_role = await exchange(url, {"role": "webpage", "protocol": 2, "id": "bad"})
        assert invalid_role["error"]["code"] == "invalid_role"

    asyncio.run(with_broker(scenario))


def test_broker_status_is_authenticated_and_exposes_lifecycle_state() -> None:
    async def scenario(_broker: Broker, url: str) -> None:
        status = await exchange(
            url,
            {
                "role": "client",
                "protocol": 2,
                "id": "status",
                "op": "broker_status",
                "params": {},
            },
        )
        assert status["ok"] is True
        assert status["result"] == {
            "broker": "hongshuskill",
            "protocol": 2,
            "broker_version": bridge_server.EXTENSION_VERSION,
            "broker_pid": os.getpid(),
            "broker_parent_pid": os.getppid(),
            "extension_connected": False,
            "extension_version": None,
            "extension_instances": [],
            "busy": False,
            "busy_operation": None,
            "quarantined": False,
            "quarantine_reason": None,
            "quarantine_request_id": None,
            "quarantine_since_ms": None,
        }

    asyncio.run(with_broker(scenario))


def test_disconnected_client_waiting_for_lock_is_never_forwarded() -> None:
    async def scenario(broker: Broker, url: str) -> None:
        first_seen = asyncio.Event()
        release_first = asyncio.Event()
        second_forwarded = False

        async def extension() -> None:
            nonlocal second_forwarded
            incoming = NonceReplayCache()
            async with connect(url, origin=f"chrome-extension://{EXTENSION_ID}") as websocket:
                await send_authenticated(websocket, extension_hello())
                await receive_authenticated(websocket, replay_cache=incoming)
                first = await receive_authenticated(websocket, replay_cache=incoming)
                first_seen.set()
                await release_first.wait()
                await send_authenticated(
                    websocket,
                    {"kind": "rpc_result", "id": first["id"], "ok": True, "result": {}},
                )
                try:
                    await asyncio.wait_for(
                        receive_authenticated(websocket, replay_cache=incoming),
                        timeout=0.35,
                    )
                    second_forwarded = True
                except TimeoutError:
                    pass

        async def first_client() -> dict:
            return await exchange(
                url,
                {
                    "role": "client",
                    "protocol": 2,
                    "id": "first",
                    "op": "list_feeds",
                    "params": {"limit": 1},
                    "timeout": 3,
                },
            )

        extension_task = asyncio.create_task(extension())
        await broker.extension_ready.wait()
        first_task = asyncio.create_task(first_client())
        await first_seen.wait()
        async with connect(url) as abandoned:
            await send_authenticated(
                abandoned,
                {
                    "role": "client",
                    "protocol": 2,
                    "id": "abandoned",
                    "op": "post_comment",
                    "params": {"content": "must-not-run", "confirmed": True},
                    "timeout": 2,
                },
            )
            await asyncio.sleep(0.1)
        await asyncio.sleep(0.1)
        release_first.set()
        assert (await first_task)["ok"] is True
        await extension_task
        assert second_forwarded is False

    asyncio.run(with_broker(scenario))


def test_timeout_quarantines_and_holds_serialization_until_terminal_result() -> None:
    async def scenario(broker: Broker, url: str) -> None:
        request_seen = asyncio.Event()
        release_terminal = asyncio.Event()

        async def extension() -> None:
            incoming = NonceReplayCache()
            async with connect(url, origin=f"chrome-extension://{EXTENSION_ID}") as websocket:
                await send_authenticated(websocket, extension_hello())
                await receive_authenticated(websocket, replay_cache=incoming)
                request = await receive_authenticated(websocket, replay_cache=incoming)
                request_seen.set()
                await release_terminal.wait()
                await send_authenticated(
                    websocket,
                    {
                        "kind": "rpc_result",
                        "id": request["id"],
                        "ok": True,
                        "result": {"finished": True},
                    },
                )
                await asyncio.sleep(0.1)

        extension_task = asyncio.create_task(extension())
        await broker.extension_ready.wait()
        timed_out = await exchange(
            url,
            {
                "role": "client",
                "protocol": 2,
                "id": "slow-client",
                "op": "list_feeds",
                "params": {"limit": 1},
                "timeout": 1,
            },
        )
        assert timed_out["error"]["code"] == "operation_timeout"
        await request_seen.wait()

        status = await exchange(
            url,
            {"role": "client", "protocol": 2, "id": "status-1", "op": "broker_status"},
        )
        assert status["result"]["busy"] is True
        assert status["result"]["quarantined"] is True

        blocked = await exchange(
            url,
            {
                "role": "client",
                "protocol": 2,
                "id": "blocked",
                "op": "check_login",
                "params": {},
            },
        )
        assert blocked["error"]["code"] == "operation_quarantined"

        recovery_while_busy = await exchange(
            url,
            {
                "role": "client",
                "protocol": 2,
                "id": "recover-busy",
                "op": "broker_recover",
                "params": {
                    "confirmed": True,
                    "expected_request_id": status["result"]["quarantine_request_id"],
                },
            },
        )
        assert recovery_while_busy["error"]["code"] == "broker_busy"

        release_terminal.set()
        await extension_task
        for _ in range(50):
            if not broker.quarantined and broker.busy_request_id is None:
                break
            await asyncio.sleep(0.02)
        assert broker.quarantined is False
        assert broker.busy_request_id is None

    asyncio.run(with_broker(scenario))


def test_duplicate_client_ids_and_late_results_cannot_cross_resolve() -> None:
    async def scenario(broker: Broker, url: str) -> None:
        broker_ids: list[str] = []

        async def extension() -> None:
            incoming = NonceReplayCache()
            async with connect(url, origin=f"chrome-extension://{EXTENSION_ID}") as websocket:
                await send_authenticated(websocket, extension_hello())
                await receive_authenticated(websocket, replay_cache=incoming)
                first = await receive_authenticated(websocket, replay_cache=incoming)
                broker_ids.append(first["id"])
                await send_authenticated(
                    websocket,
                    {
                        "kind": "rpc_result",
                        "id": first["id"],
                        "ok": True,
                        "result": {"value": "first"},
                    },
                )
                second = await receive_authenticated(websocket, replay_cache=incoming)
                broker_ids.append(second["id"])
                await send_authenticated(
                    websocket,
                    {
                        "kind": "rpc_result",
                        "id": first["id"],
                        "ok": True,
                        "result": {"value": "stale"},
                    },
                )
                await send_authenticated(
                    websocket,
                    {
                        "kind": "rpc_result",
                        "id": second["id"],
                        "ok": True,
                        "result": {"value": "second"},
                    },
                )

        extension_task = asyncio.create_task(extension())
        await broker.extension_ready.wait()
        payload = {
            "role": "client",
            "protocol": 2,
            "id": "same-client-id",
            "op": "check_login",
            "params": {},
            "timeout": 2,
        }
        first = await exchange(url, payload)
        await asyncio.sleep(0.05)
        second = await exchange(url, payload)
        await extension_task

        assert first["result"]["value"] == "first"
        assert second["result"]["value"] == "second"
        assert broker_ids[0] != broker_ids[1]

    asyncio.run(with_broker(scenario))


def test_persisted_write_journal_requires_explicit_matching_recovery(tmp_path: Path) -> None:
    journal = tmp_path / "inflight.json"
    request_id = "a" * 32
    _write_inflight_journal(
        journal,
        {
            "operation": "post_comment",
            "id": request_id,
            "generation": 1,
            "started_ms": 1_700_000_000_000,
        },
    )
    broker = Broker(TOKEN, journal_path=journal)

    async def scenario(_broker: Broker, url: str) -> None:
        status = await exchange(
            url,
            {"role": "client", "protocol": 2, "id": "status", "op": "broker_status"},
        )
        assert status["result"]["quarantined"] is True
        assert status["result"]["quarantine_request_id"] == request_id

        mismatch = await exchange(
            url,
            {
                "role": "client",
                "protocol": 2,
                "id": "recover-wrong",
                "op": "broker_recover",
                "params": {"confirmed": True, "expected_request_id": "b" * 32},
            },
        )
        assert mismatch["error"]["code"] == "recovery_request_mismatch"
        assert journal.exists()

        recovered = await exchange(
            url,
            {
                "role": "client",
                "protocol": 2,
                "id": "recover-right",
                "op": "broker_recover",
                "params": {"confirmed": True, "expected_request_id": request_id},
            },
        )
        assert recovered["result"] == {
            "recovered": True,
            "request_id": request_id,
            "previous_reason": "operation_state_uncertain",
        }
        assert journal.exists() is False
        assert broker.quarantined is False

    asyncio.run(with_broker(scenario, broker=broker))


def test_write_journal_is_private_minimal_durable_and_cleared_only_on_terminal(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    journal = tmp_path / "inflight.json"
    fsync_calls: list[Path] = []
    original_fsync_directory = bridge_server._fsync_directory

    def track_fsync(path: Path) -> None:
        fsync_calls.append(path)
        original_fsync_directory(path)

    monkeypatch.setattr(bridge_server, "_fsync_directory", track_fsync)
    broker = Broker(TOKEN, journal_path=journal)

    async def scenario(_broker: Broker, url: str) -> None:
        journal_checked = asyncio.Event()

        async def extension() -> None:
            incoming = NonceReplayCache()
            async with connect(url, origin=f"chrome-extension://{EXTENSION_ID}") as websocket:
                await send_authenticated(websocket, extension_hello())
                await receive_authenticated(websocket, replay_cache=incoming)
                request = await receive_authenticated(websocket, replay_cache=incoming)
                assert journal.exists()
                if os.name != "nt":
                    assert stat.S_IMODE(journal.stat().st_mode) == 0o600
                record = json.loads(journal.read_text(encoding="utf-8"))
                assert set(record) == {"operation", "id", "generation", "started_ms"}
                assert record["operation"] == "post_comment"
                assert record["id"] == request["id"]
                assert "private post body" not in journal.read_text(encoding="utf-8")
                journal_checked.set()
                await send_authenticated(
                    websocket,
                    {"kind": "rpc_result", "id": request["id"], "ok": True, "result": {}},
                )

        extension_task = asyncio.create_task(extension())
        await broker.extension_ready.wait()
        response = await exchange(
            url,
            {
                "role": "client",
                "protocol": 2,
                "id": "write-client",
                "op": "post_comment",
                "params": {"content": "private post body", "confirmed": True},
                "timeout": 2,
            },
        )
        await journal_checked.wait()
        assert response["ok"] is True
        assert journal.exists() is False
        await extension_task

    asyncio.run(with_broker(scenario, broker=broker))
    assert fsync_calls == [tmp_path, tmp_path]


def test_malformed_extension_terminal_cannot_clear_write_journal(tmp_path: Path) -> None:
    journal = tmp_path / "inflight.json"
    broker = Broker(TOKEN, journal_path=journal)

    async def scenario(_broker: Broker, url: str) -> None:
        async def extension() -> None:
            incoming = NonceReplayCache()
            async with connect(url, origin=f"chrome-extension://{EXTENSION_ID}") as websocket:
                await send_authenticated(websocket, extension_hello())
                await receive_authenticated(websocket, replay_cache=incoming)
                request = await receive_authenticated(websocket, replay_cache=incoming)
                await send_authenticated(
                    websocket,
                    {
                        "kind": "rpc_result",
                        "id": request["id"],
                        "ok": True,
                        "result": [],
                    },
                )
                await websocket.wait_closed()

        extension_task = asyncio.create_task(extension())
        await broker.extension_ready.wait()
        response = await exchange(
            url,
            {
                "role": "client",
                "protocol": 2,
                "id": "malformed-terminal",
                "op": "post_comment",
                "params": {"content": "must remain uncertain", "confirmed": True},
                "timeout": 2,
            },
        )
        await extension_task
        assert response["error"]["code"] == "extension_disconnected"
        assert broker.quarantined is True
        assert journal.exists()

    asyncio.run(with_broker(scenario, broker=broker))


def test_uncertain_write_error_retains_journal_until_explicit_recovery(tmp_path: Path) -> None:
    journal = tmp_path / "inflight.json"
    broker = Broker(TOKEN, journal_path=journal)

    async def scenario(_broker: Broker, url: str) -> None:
        async def extension() -> None:
            incoming = NonceReplayCache()
            async with connect(url, origin=f"chrome-extension://{EXTENSION_ID}") as websocket:
                await send_authenticated(websocket, extension_hello())
                await receive_authenticated(websocket, replay_cache=incoming)
                request = await receive_authenticated(websocket, replay_cache=incoming)
                await send_authenticated(
                    websocket,
                    {
                        "kind": "rpc_result",
                        "id": request["id"],
                        "ok": False,
                        "error": {
                            "code": "state_not_persisted",
                            "message": "state could not be confirmed after reload",
                            "details": {},
                        },
                    },
                )

        extension_task = asyncio.create_task(extension())
        await broker.extension_ready.wait()
        response = await exchange(
            url,
            {
                "role": "client",
                "protocol": 2,
                "id": "uncertain-like",
                "op": "set_like",
                "params": {"target": True, "confirmed": True},
                "timeout": 2,
            },
        )
        await extension_task
        for _ in range(100):
            if broker.busy_request_id is None:
                break
            await asyncio.sleep(0.01)
        assert response["error"]["code"] == "state_not_persisted"
        assert broker.quarantined is True
        assert broker.quarantine_reason == "state_not_persisted"
        assert journal.exists()

        request_id = broker.quarantine_request_id
        recovered = await exchange(
            url,
            {
                "role": "client",
                "protocol": 2,
                "id": "recover-uncertain-like",
                "op": "broker_recover",
                "params": {"confirmed": True, "expected_request_id": request_id},
            },
        )
        assert recovered["result"]["recovered"] is True
        assert broker.quarantined is False
        assert journal.exists() is False

    asyncio.run(with_broker(scenario, broker=broker))


def test_late_success_after_write_timeout_still_requires_explicit_recovery(
    tmp_path: Path,
) -> None:
    journal = tmp_path / "inflight.json"
    broker = Broker(TOKEN, journal_path=journal, terminal_grace_seconds=2)

    async def scenario(_broker: Broker, url: str) -> None:
        release_terminal = asyncio.Event()

        async def extension() -> None:
            incoming = NonceReplayCache()
            async with connect(url, origin=f"chrome-extension://{EXTENSION_ID}") as websocket:
                await send_authenticated(websocket, extension_hello())
                await receive_authenticated(websocket, replay_cache=incoming)
                request = await receive_authenticated(websocket, replay_cache=incoming)
                await release_terminal.wait()
                await send_authenticated(
                    websocket,
                    {
                        "kind": "rpc_result",
                        "id": request["id"],
                        "ok": True,
                        "result": {"submitted": True},
                    },
                )

        extension_task = asyncio.create_task(extension())
        await broker.extension_ready.wait()
        timed_out = await exchange(
            url,
            {
                "role": "client",
                "protocol": 2,
                "id": "timed-out-comment",
                "op": "post_comment",
                "params": {"content": "late success", "confirmed": True},
                "timeout": 1,
            },
        )
        assert timed_out["error"]["code"] == "operation_timeout"
        request_id = broker.quarantine_request_id
        assert request_id is not None
        release_terminal.set()
        await extension_task
        for _ in range(100):
            if broker.busy_request_id is None:
                break
            await asyncio.sleep(0.01)
        assert broker.busy_request_id is None
        assert broker.quarantined is True
        assert broker.quarantine_reason == "operation_timeout"
        assert broker.quarantine_request_id == request_id
        assert journal.exists()

        recovered = await exchange(
            url,
            {
                "role": "client",
                "protocol": 2,
                "id": "recover-late-comment",
                "op": "broker_recover",
                "params": {"confirmed": True, "expected_request_id": request_id},
            },
        )
        assert recovered["result"]["recovered"] is True
        assert journal.exists() is False

    asyncio.run(with_broker(scenario, broker=broker))


def test_fractional_rpc_values_round_trip_through_authenticated_broker() -> None:
    async def scenario(broker: Broker, url: str) -> None:
        async def extension() -> None:
            incoming = NonceReplayCache()
            async with connect(url, origin=f"chrome-extension://{EXTENSION_ID}") as websocket:
                await send_authenticated(websocket, extension_hello())
                await receive_authenticated(websocket, replay_cache=incoming)
                request = await receive_authenticated(websocket, replay_cache=incoming)
                assert request["params"]["timeout"] == 7.5
                await send_authenticated(
                    websocket,
                    {
                        "kind": "rpc_result",
                        "id": request["id"],
                        "ok": True,
                        "result": {"duration": 0.25},
                    },
                )

        extension_task = asyncio.create_task(extension())
        await broker.extension_ready.wait()
        response = await exchange(
            url,
            {
                "role": "client",
                "protocol": 2,
                "id": "fractional-values",
                "op": "wait_login",
                "params": {"timeout": 7.5},
                "timeout": 7.5,
            },
        )
        assert response["result"]["duration"] == 0.25
        await extension_task

    asyncio.run(with_broker(scenario))


def test_invalid_or_symlinked_journal_fails_closed_and_is_not_deleted(tmp_path: Path) -> None:
    journal = tmp_path / "inflight.json"
    journal.write_text("not-json\n", encoding="utf-8")
    journal.chmod(0o644)
    with pytest.raises(OSError, match="journal is invalid"):
        Broker(TOKEN, journal_path=journal)
    assert journal.exists()
    if os.name != "nt":
        assert stat.S_IMODE(journal.stat().st_mode) == 0o600

    target = tmp_path / "target.json"
    target.write_text("{}\n", encoding="utf-8")
    journal.unlink()
    try:
        journal.symlink_to(target)
    except OSError as exc:
        if os.name == "nt" and getattr(exc, "winerror", None) == 1314:
            pytest.skip("Windows symlink privilege is unavailable")
        raise
    with pytest.raises(OSError, match="symlink"):
        Broker(TOKEN, journal_path=journal)
    assert target.read_text(encoding="utf-8") == "{}\n"


def test_deadline_expiring_during_write_journaling_never_forwards_operation(
    tmp_path: Path,
) -> None:
    journal = tmp_path / "inflight.json"
    broker = Broker(TOKEN, journal_path=journal)
    original_record = broker._record_inflight_write

    def slow_record(operation: str, request_id: str) -> None:
        original_record(operation, request_id)
        time.sleep(1.05)

    broker._record_inflight_write = slow_record  # type: ignore[method-assign]

    async def scenario(_broker: Broker, url: str) -> None:
        forwarded = False

        async def extension() -> None:
            nonlocal forwarded
            incoming = NonceReplayCache()
            async with connect(url, origin=f"chrome-extension://{EXTENSION_ID}") as websocket:
                await send_authenticated(websocket, extension_hello())
                await receive_authenticated(websocket, replay_cache=incoming)
                try:
                    await asyncio.wait_for(
                        receive_authenticated(websocket, replay_cache=incoming),
                        timeout=0.35,
                    )
                    forwarded = True
                except TimeoutError:
                    pass

        extension_task = asyncio.create_task(extension())
        await broker.extension_ready.wait()
        response = await exchange(
            url,
            {
                "role": "client",
                "protocol": 2,
                "id": "journal-deadline",
                "op": "post_comment",
                "params": {"content": "must not run", "confirmed": True},
                "timeout": 1,
            },
        )
        assert response["error"]["code"] == "operation_queue_timeout"
        assert journal.exists() is False
        assert broker.quarantined is False
        await extension_task
        assert forwarded is False

    asyncio.run(with_broker(scenario, broker=broker))


@pytest.mark.parametrize(
    ("operation", "params", "persistent_write"),
    [
        ("list_feeds", {"limit": 1}, False),
        (
            "post_comment",
            {"content": "silent extension", "confirmed": True},
            True,
        ),
    ],
)
def test_silent_extension_after_timeout_eventually_releases_broker_but_stays_quarantined(
    tmp_path: Path,
    operation: str,
    params: dict,
    persistent_write: bool,
) -> None:
    journal = tmp_path / "inflight.json"
    broker = Broker(TOKEN, journal_path=journal, terminal_grace_seconds=0.15)

    async def scenario(_broker: Broker, url: str) -> None:
        request_seen = asyncio.Event()

        async def extension() -> None:
            incoming = NonceReplayCache()
            async with connect(url, origin=f"chrome-extension://{EXTENSION_ID}") as websocket:
                await send_authenticated(websocket, extension_hello())
                await receive_authenticated(websocket, replay_cache=incoming)
                await receive_authenticated(websocket, replay_cache=incoming)
                request_seen.set()
                await websocket.wait_closed()

        extension_task = asyncio.create_task(extension())
        await broker.extension_ready.wait()
        response = await exchange(
            url,
            {
                "role": "client",
                "protocol": 2,
                "id": f"silent-{operation}",
                "op": operation,
                "params": params,
                "timeout": 1,
            },
        )
        await request_seen.wait()
        assert response["error"]["code"] == "operation_timeout"
        await asyncio.wait_for(extension_task, timeout=2)
        for _ in range(100):
            if broker.busy_request_id is None and not broker.operation_lock.locked():
                break
            await asyncio.sleep(0.01)
        assert broker.busy_request_id is None
        assert broker.pending == {}
        assert broker.operation_lock.locked() is False
        assert broker.extension is None
        assert broker.extension_ready.is_set() is False
        assert broker.quarantined is True
        assert broker.quarantine_request_id is not None
        assert journal.exists() is persistent_write

    asyncio.run(with_broker(scenario, broker=broker))


def test_stale_v2_quarantine_can_recover_before_idle_upgrade(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    journal = tmp_path / "inflight.json"
    request_id = "d" * 32
    _write_inflight_journal(
        journal,
        {
            "operation": "post_comment",
            "id": request_id,
            "generation": 1,
            "started_ms": 1_700_000_000_000,
        },
    )
    broker = Broker(TOKEN, journal_path=journal)
    monkeypatch.setattr(client, "load_or_create_token", lambda: TOKEN)
    monkeypatch.setattr(client, "VERSION", "9.9.9")

    async def scenario(_broker: Broker, url: str) -> None:
        status = await asyncio.to_thread(client.ensure_broker, url)
        assert status["broker_version"] == bridge_server.EXTENSION_VERSION
        assert status["quarantined"] is True
        assert status["quarantine_request_id"] == request_id

        recovered = await asyncio.to_thread(
            client.recover_broker,
            url,
            request_id,
            confirmed=True,
        )
        assert recovered == {
            "recovered": True,
            "request_id": request_id,
            "previous_reason": "operation_state_uncertain",
        }
        assert journal.exists() is False
        assert broker.quarantined is False

        idle_status = await asyncio.to_thread(client.broker_status, url)
        assert idle_status["running"] is True
        assert idle_status["quarantined"] is False
        assert idle_status["busy"] is False

        current_status = {
            **idle_status,
            "broker_version": client.VERSION,
        }
        statuses = iter([idle_status, current_status])
        stops: list[int] = []
        launches: list[object] = []
        monkeypatch.setattr(client, "broker_status", lambda _url: next(statuses))
        monkeypatch.setattr(
            client,
            "_stop_stale_broker",
            lambda port, _script: stops.append(port),
        )
        monkeypatch.setattr(
            client.subprocess,
            "Popen",
            lambda *args, **kwargs: launches.append((args, kwargs)) or object(),
        )

        upgraded = await asyncio.to_thread(client.ensure_broker, url)
        assert upgraded["broker_version"] == client.VERSION
        assert stops == [int(url.rsplit(":", 1)[1])]
        assert len(launches) == 1

    asyncio.run(with_broker(scenario, broker=broker))
