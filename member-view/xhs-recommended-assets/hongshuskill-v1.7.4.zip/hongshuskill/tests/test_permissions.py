from __future__ import annotations

from pathlib import Path

import pytest

from scripts.hongshu import permissions


def test_windows_defers_descriptor_and_path_modes_to_launcher_acl(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    monkeypatch.setattr(permissions, "_is_windows", lambda: True)
    monkeypatch.setattr(
        permissions.os,
        "fchmod",
        lambda _descriptor, _mode: (_ for _ in ()).throw(PermissionError("denied")),
        raising=False,
    )
    target = tmp_path / "private.json"
    target.write_text("{}\n", encoding="utf-8")
    monkeypatch.setattr(
        Path,
        "chmod",
        lambda _path, _mode: (_ for _ in ()).throw(PermissionError("denied")),
    )

    permissions.tighten_file_descriptor(123)
    permissions.tighten_path(target, 0o600)


def test_posix_descriptor_mode_failure_is_not_suppressed(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(permissions, "_is_windows", lambda: False)
    monkeypatch.setattr(
        permissions.os,
        "fchmod",
        lambda _descriptor, _mode: (_ for _ in ()).throw(PermissionError("denied")),
        raising=False,
    )

    with pytest.raises(PermissionError, match="denied"):
        permissions.tighten_file_descriptor(123)
