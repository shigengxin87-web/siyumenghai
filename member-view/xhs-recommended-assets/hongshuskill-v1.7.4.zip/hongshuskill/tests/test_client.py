from __future__ import annotations

import os
from types import SimpleNamespace

import pytest

from scripts.hongshu import client
from scripts.hongshu.errors import (
    BridgeUnavailable,
    BrowserOperationFailed,
    ConfirmationRequired,
    InvalidInput,
    RiskControlActive,
)

TEST_TOKEN = bytes.fromhex("42" * 32)


@pytest.fixture(autouse=True)
def use_isolated_pairing_token(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(client, "load_or_create_token", lambda: TEST_TOKEN)


@pytest.mark.parametrize(
    "url",
    [
        "wss://127.0.0.1:9345",
        "ws://example.com:9345",
        "ws://user:secret@127.0.0.1:9345",
        "ws://127.0.0.1:9345/control?token=secret",
        "ws://127.0.0.1:0",
        "ws://127.0.0.1:",
        "ws://127.0.0.1:99999",
    ],
)
def test_bridge_url_rejects_nonlocal_or_ambiguous_targets(url: str) -> None:
    with pytest.raises(BridgeUnavailable):
        client._validate_bridge_url(url)


@pytest.mark.parametrize(
    ("url", "expected"),
    [
        ("ws://127.0.0.1", "ws://127.0.0.1:9345"),
        ("ws://localhost", "ws://127.0.0.1:9345"),
        ("ws://localhost:9911/", "ws://127.0.0.1:9911"),
        ("ws://[::1]", "ws://127.0.0.1:9345"),
    ],
)
def test_bridge_url_normalizes_all_loopback_spellings_to_the_bound_address(
    url: str,
    expected: str,
) -> None:
    assert client._validate_bridge_url(url)[0] == expected


def test_ensure_broker_reuses_only_the_current_version(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    current = {
        "running": True,
        "broker_version": client.VERSION,
        "protocol": 2,
        "extension_connected": True,
        "extension_version": client.VERSION,
    }
    monkeypatch.setattr(client, "broker_status", lambda _url: current)
    monkeypatch.setattr(
        client,
        "_stop_stale_broker",
        lambda *_args: pytest.fail("current broker must not be stopped"),
    )
    monkeypatch.setattr(
        client.subprocess,
        "Popen",
        lambda *_args, **_kwargs: pytest.fail("current broker must not be relaunched"),
    )

    assert client.ensure_broker() is current


def test_ensure_broker_safely_replaces_a_stale_managed_version(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    statuses = iter(
        [
            {
                "running": True,
                "broker_version": "1.1.1",
                "protocol": 2,
                "extension_connected": True,
            },
            {
                "running": True,
                "broker_version": client.VERSION,
                "protocol": 2,
                "extension_connected": False,
                "extension_version": None,
            },
        ]
    )
    stops: list[tuple[int, object]] = []
    launches: list[tuple[tuple, dict]] = []
    monkeypatch.setattr(client, "broker_status", lambda _url: next(statuses))
    monkeypatch.setattr(
        client,
        "_stop_stale_broker",
        lambda port, script: stops.append((port, script)),
    )
    monkeypatch.setattr(
        client.subprocess,
        "Popen",
        lambda *args, **kwargs: launches.append((args, kwargs)) or SimpleNamespace(pid=123),
    )

    result = client.ensure_broker()

    assert result["broker_version"] == client.VERSION
    assert stops and stops[0][0] == 9345
    assert launches and "bridge_server.py" in str(launches[0][0][0])


def test_windows_stale_broker_stop_accepts_systemerror_only_after_port_is_free(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    calls: list[tuple[int, int]] = []
    monkeypatch.setattr(client, "_managed_broker_pid", lambda *_args: 1234)

    def fake_kill(pid: int, signal_number: int) -> None:
        calls.append((pid, signal_number))
        if signal_number == 0:
            raise SystemError("Windows process handle is already gone")

    monkeypatch.setattr(client.os, "kill", fake_kill)
    monkeypatch.setattr(client, "_loopback_port_occupied", lambda _port: False)

    client._stop_stale_broker(9345, client.Path("bridge_server.py"))

    assert calls == [(1234, client.signal.SIGTERM), (1234, 0)]


def test_windows_stale_broker_stop_fails_closed_if_systemerror_port_is_occupied(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(client, "_managed_broker_pid", lambda *_args: 1234)

    def fake_kill(_pid: int, signal_number: int) -> None:
        if signal_number == 0:
            raise SystemError("ambiguous Windows process state")

    monkeypatch.setattr(client.os, "kill", fake_kill)
    monkeypatch.setattr(client, "_loopback_port_occupied", lambda _port: True)

    with pytest.raises(BridgeUnavailable):
        client._stop_stale_broker(9345, client.Path("bridge_server.py"))


def test_stale_broker_identity_check_refuses_an_unrelated_process(
    tmp_path, monkeypatch: pytest.MonkeyPatch
) -> None:
    pid_file = tmp_path / "bridge.pid"
    pid_file.write_text("123", encoding="ascii")
    monkeypatch.setattr(client, "_is_windows", lambda: False)
    monkeypatch.setattr(client.os, "getuid", lambda: 1000, raising=False)
    monkeypatch.setattr(client, "_broker_pid_paths", lambda _port: (pid_file,))
    monkeypatch.setattr(
        client.subprocess,
        "run",
        lambda *_args, **_kwargs: SimpleNamespace(
            returncode=0,
            stdout="1000 /usr/bin/python unrelated.py --port 9345\n",
        ),
    )

    with pytest.raises(BridgeUnavailable) as caught:
        client._managed_broker_pid(9345, tmp_path / "bridge_server.py")
    assert caught.value.details["remote_code"] == "bridge_identity_unverified"
    assert "command" not in caught.value.details


def test_windows_stale_broker_identity_uses_owner_sid_and_command_line(
    tmp_path, monkeypatch: pytest.MonkeyPatch
) -> None:
    pid_file = tmp_path / "bridge.pid"
    pid_file.write_text("123", encoding="ascii")
    bridge_script = tmp_path / "bridge_server.py"
    bridge_script.touch()
    monkeypatch.setattr(client, "_is_windows", lambda: True)
    monkeypatch.setattr(client, "_broker_pid_paths", lambda _port: (pid_file,))
    monkeypatch.setattr(
        client,
        "_windows_process_snapshot",
        lambda _pid: {
            "owner_sid": "S-1-5-21-1000",
            "current_sid": "S-1-5-21-1000",
            "command_line": f'python.exe "{bridge_script.resolve()}" --port 9345',
            "executable_path": r"C:\Python\python.exe",
        },
    )

    assert client._managed_broker_pid(9345, bridge_script) == 123


@pytest.mark.parametrize("unsafe_kind", ["symlink", "oversized", "world_writable"])
def test_stale_broker_identity_check_ignores_unsafe_pid_files(
    tmp_path,
    monkeypatch: pytest.MonkeyPatch,
    unsafe_kind: str,
) -> None:
    pid_file = tmp_path / "bridge.pid"
    monkeypatch.setattr(client, "_is_windows", lambda: False)
    monkeypatch.setattr(client.os, "getuid", lambda: 0, raising=False)
    if unsafe_kind == "symlink":
        target = tmp_path / "target.pid"
        target.write_text("123", encoding="ascii")
        try:
            pid_file.symlink_to(target)
        except OSError as exc:
            if os.name == "nt" and getattr(exc, "winerror", None) == 1314:
                pytest.skip("Windows symlink privilege is unavailable")
            raise
    elif unsafe_kind == "oversized":
        pid_file.write_text("1" * 65, encoding="ascii")
    else:
        pid_file.write_text("123", encoding="ascii")
        pid_file.chmod(0o666)
    monkeypatch.setattr(client, "_broker_pid_paths", lambda _port: (pid_file,))
    monkeypatch.setattr(
        client.subprocess,
        "run",
        lambda *_args, **_kwargs: pytest.fail("unsafe PID file must not invoke ps"),
    )

    with pytest.raises(BridgeUnavailable) as caught:
        client._managed_broker_pid(9345, tmp_path / "bridge_server.py")
    assert caught.value.details["remote_code"] == "bridge_identity_unverified"


def test_remote_risk_error_is_preserved_for_the_cli(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(
        client,
        "ensure_broker",
        lambda _url: {"running": True, "extension_connected": True},
    )

    async def fake_exchange(_url: str, payload: dict, _timeout: float) -> dict:
        return {
            "kind": "rpc_result",
            "id": payload["id"],
            "ok": False,
            "error": {
                "code": "risk_control_active",
                "message": "最近 15 分钟观察到平台高风险响应",
                "details": {"status": 461, "retry_after_seconds": 120},
            },
        }

    monkeypatch.setattr(client, "_exchange", fake_exchange)
    with pytest.raises(RiskControlActive) as caught:
        client.call("set_like", {"confirmed": True})
    assert caught.value.code == "risk_control_active"
    assert caught.value.details == {
        "remote_code": "risk_control_active",
        "status": 461,
        "retry_after_seconds": 120,
    }


@pytest.mark.parametrize(
    ("remote_code", "operation"),
    [
        ("extension_disconnected", "post_comment"),
        ("bridge_failure", "send_code"),
        ("operation_timeout", "click_publish"),
        ("operation_state_uncertain", "save_draft"),
        ("state_not_changed", "set_like"),
        ("state_not_persisted", "set_favorite"),
        ("comment_submission_unconfirmed", "post_comment"),
        ("submission_unconfirmed", "click_publish"),
        ("submission_state_uncertain", "save_draft"),
        ("publish_submission_uncertain", "click_publish"),
        ("draft_submission_uncertain", "save_draft"),
        ("logout_unconfirmed", "delete_cookies"),
    ],
)
def test_interrupted_remote_writes_are_reported_as_uncertain(
    monkeypatch: pytest.MonkeyPatch,
    remote_code: str,
    operation: str,
) -> None:
    monkeypatch.setattr(
        client,
        "ensure_broker",
        lambda _url: {"running": True, "extension_connected": True},
    )

    async def fake_exchange(_url: str, payload: dict, _timeout: float) -> dict:
        return {
            "kind": "rpc_result",
            "id": payload["id"],
            "ok": False,
            "error": {"code": remote_code, "message": "connection interrupted"},
        }

    monkeypatch.setattr(client, "_exchange", fake_exchange)
    with pytest.raises(BrowserOperationFailed) as caught:
        client.call(operation, {"confirmed": True})
    assert caught.value.details == {
        "cause_code": remote_code,
        "remote_code": "operation_state_uncertain",
        "operation": operation,
    }


@pytest.mark.parametrize(
    ("reported_cause", "expected_cause"),
    [
        ("browser_operation_failed", "browser_operation_failed"),
        ("specific_backend_failure", "specific_backend_failure"),
        ("INVALID CODE", "operation_state_uncertain"),
        (123, "operation_state_uncertain"),
    ],
)
def test_uncertain_remote_error_preserves_only_a_valid_specific_cause_code(
    monkeypatch: pytest.MonkeyPatch,
    reported_cause: object,
    expected_cause: str,
) -> None:
    monkeypatch.setattr(
        client,
        "ensure_broker",
        lambda _url: {"running": True, "extension_connected": True},
    )

    async def fake_exchange(_url: str, payload: dict, _timeout: float) -> dict:
        return {
            "kind": "rpc_result",
            "id": payload["id"],
            "ok": False,
            "error": {
                "code": "operation_state_uncertain",
                "message": "operation outcome is uncertain",
                "details": {
                    "cause_code": reported_cause,
                    "diagnostic": "safe",
                },
            },
        }

    monkeypatch.setattr(client, "_exchange", fake_exchange)
    with pytest.raises(BrowserOperationFailed) as caught:
        client.call("post_comment", {"content": "test", "confirmed": True})
    assert caught.value.details == {
        "cause_code": expected_cause,
        "diagnostic": "safe",
        "remote_code": "operation_state_uncertain",
        "operation": "post_comment",
    }


def test_local_transport_failure_is_uncertain_only_for_writes(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(
        client,
        "ensure_broker",
        lambda _url: {"running": True, "extension_connected": True},
    )

    async def fake_exchange(_url: str, _payload: dict, _timeout: float) -> dict:
        raise OSError("socket closed")

    monkeypatch.setattr(client, "_exchange", fake_exchange)
    with pytest.raises(BrowserOperationFailed) as write_error:
        client.call("reply_comment", {"confirmed": True})
    assert write_error.value.details == {
        "remote_code": "operation_state_uncertain",
        "operation": "reply_comment",
        "cause": "OSError",
    }

    with pytest.raises(BridgeUnavailable):
        client.call("search_feeds", {"keyword": "咖啡"})


def test_broker_status_requires_a_typed_protocol_v2_response_and_exposes_recovery_id(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    request_id = "a" * 32

    async def fake_exchange(_url: str, payload: dict, _timeout: float) -> dict:
        return {
            "kind": "rpc_result",
            "id": payload["id"],
            "ok": True,
            "result": {
                "broker": "hongshuskill",
                "protocol": 2,
                "broker_version": client.VERSION,
                "extension_connected": False,
                "extension_version": None,
                "busy": False,
                "quarantined": True,
                "quarantine_reason": "operation_state_uncertain",
                "quarantine_request_id": request_id,
                "quarantine_since_ms": 1_700_000_000_000,
            },
        }

    monkeypatch.setattr(client, "_exchange", fake_exchange)
    status = client.broker_status("ws://localhost")
    assert status["running"] is True
    assert status["quarantine_request_id"] == request_id

    async def malformed_exchange(_url: str, payload: dict, _timeout: float) -> dict:
        return {"id": payload["id"], "ok": True, "result": {"broker": "hongshuskill"}}

    monkeypatch.setattr(client, "_exchange", malformed_exchange)
    assert client.broker_status()["running"] is False


def test_legacy_broker_is_never_stopped_without_explicit_upgrade_confirmation(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(
        client,
        "broker_status",
        lambda _url: {"running": False, "extension_connected": False},
    )
    monkeypatch.setattr(
        client,
        "_legacy_broker_status",
        lambda _url: {"running": True, "protocol": 1, "broker_version": "1.4.0"},
    )
    monkeypatch.setattr(client, "_managed_broker_pid", lambda *_args: 1234)
    monkeypatch.setattr(
        client.subprocess,
        "Popen",
        lambda *_args, **_kwargs: pytest.fail("legacy broker must not be auto-replaced"),
    )

    with pytest.raises(BridgeUnavailable) as caught:
        client.ensure_broker("ws://localhost")
    assert caught.value.details["remote_code"] == "bridge_upgrade_deferred"
    assert caught.value.details["pid"] == 1234


def test_unidentified_occupied_port_is_never_spawned_over_or_stopped(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(
        client,
        "broker_status",
        lambda _url: {"running": False, "extension_connected": False},
    )
    monkeypatch.setattr(client, "_legacy_broker_status", lambda _url: {"running": False})
    monkeypatch.setattr(client, "_loopback_port_occupied", lambda _port: True)
    monkeypatch.setattr(
        client.subprocess,
        "Popen",
        lambda *_args, **_kwargs: pytest.fail(
            "occupied unidentified port must not be spawned over"
        ),
    )
    monkeypatch.setattr(
        client,
        "_stop_stale_broker",
        lambda *_args: pytest.fail("unidentified service must not be stopped"),
    )

    with pytest.raises(BridgeUnavailable) as caught:
        client.ensure_broker("ws://localhost:9345")
    assert caught.value.details == {
        "remote_code": "bridge_identity_unverified",
        "port": 9345,
    }


def test_signed_stale_broker_is_not_stopped_while_busy(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(
        client,
        "broker_status",
        lambda _url: {
            "running": True,
            "protocol": 2,
            "broker_version": "0.0.1",
            "busy": True,
            "quarantined": False,
        },
    )
    monkeypatch.setattr(
        client,
        "_stop_stale_broker",
        lambda *_args: pytest.fail("busy broker must not be stopped"),
    )

    with pytest.raises(BridgeUnavailable) as caught:
        client.ensure_broker()
    assert caught.value.details["busy"] is True


def test_compatible_stale_quarantined_broker_remains_reachable_for_recovery(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    request_id = "c" * 32
    quarantined = {
        "running": True,
        "protocol": 2,
        "broker_version": "0.0.1",
        "extension_connected": False,
        "busy": False,
        "busy_operation": None,
        "quarantined": True,
        "quarantine_reason": "operation_state_uncertain",
        "quarantine_request_id": request_id,
        "quarantine_since_ms": 1_700_000_000_000,
    }
    monkeypatch.setattr(client, "broker_status", lambda _url: quarantined)
    monkeypatch.setattr(
        client,
        "_stop_stale_broker",
        lambda *_args: pytest.fail("quarantined compatible broker must not be stopped"),
    )
    monkeypatch.setattr(
        client.subprocess,
        "Popen",
        lambda *_args, **_kwargs: pytest.fail("quarantined broker must not be relaunched"),
    )

    assert client.ensure_broker() is quarantined


def test_replace_legacy_broker_requires_confirmation_and_rechecks_identity(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    with pytest.raises(ConfirmationRequired):
        client.replace_legacy_broker(confirmed=False)
    with pytest.raises(ConfirmationRequired):
        client.replace_legacy_broker(confirmed=1)  # type: ignore[arg-type]

    calls: list[str] = []
    monkeypatch.setattr(
        client,
        "_legacy_broker_status",
        lambda _url: {"running": True, "protocol": 1, "broker_version": "1.4.0"},
    )
    monkeypatch.setattr(
        client,
        "_managed_broker_pid",
        lambda *_args: calls.append("identity") or 1234,
    )
    monkeypatch.setattr(
        client,
        "_stop_stale_broker",
        lambda *_args: calls.append("stop"),
    )
    monkeypatch.setattr(
        client,
        "ensure_broker",
        lambda url: calls.append(f"ensure:{url}") or {"running": True, "protocol": 2},
    )

    result = client.replace_legacy_broker("ws://localhost", confirmed=True)
    assert result == {"running": True, "protocol": 2}
    assert calls == ["identity", "stop", "ensure:ws://127.0.0.1:9345"]


def test_recover_broker_has_an_explicit_matching_confirmation_contract(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    request_id = "b" * 32
    with pytest.raises(ConfirmationRequired):
        client.recover_broker(client.DEFAULT_BRIDGE_URL, request_id, confirmed=False)
    with pytest.raises(ConfirmationRequired):
        client.recover_broker(
            client.DEFAULT_BRIDGE_URL,
            request_id,
            confirmed="yes",  # type: ignore[arg-type]
        )
    with pytest.raises(InvalidInput):
        client.recover_broker(client.DEFAULT_BRIDGE_URL, "not-an-id", confirmed=True)

    captured: dict = {}

    def fake_call(operation: str, params: dict, **kwargs) -> dict:
        captured.update({"operation": operation, "params": params, **kwargs})
        return {"recovered": True, "request_id": request_id}

    monkeypatch.setattr(client, "call", fake_call)
    result = client.recover_broker(client.DEFAULT_BRIDGE_URL, request_id, confirmed=True)
    assert result["recovered"] is True
    assert captured == {
        "operation": "broker_recover",
        "params": {"expected_request_id": request_id, "confirmed": True},
        "url": client.DEFAULT_BRIDGE_URL,
        "timeout": 15,
    }


def test_call_accepts_fractional_deadlines_and_rejects_malformed_response_schemas(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(
        client,
        "ensure_broker",
        lambda _url: {"running": True, "extension_connected": True},
    )
    seen: dict = {}

    async def success(_url: str, payload: dict, _timeout: float) -> dict:
        seen.update(payload)
        return {
            "kind": "rpc_result",
            "id": payload["id"],
            "ok": True,
            "result": {"duration": 0.25},
        }

    monkeypatch.setattr(client, "_exchange", success)
    assert client.call("check_login", timeout=7.5) == {"duration": 0.25}
    assert seen["timeout"] == 7.5

    async def malformed(_url: str, payload: dict, _timeout: float) -> dict:
        return {"kind": "rpc_result", "id": payload["id"], "ok": True, "result": []}

    monkeypatch.setattr(client, "_exchange", malformed)
    with pytest.raises(BridgeUnavailable):
        client.call("check_login")

    async def malformed_error(_url: str, payload: dict, _timeout: float) -> dict:
        return {
            "kind": "rpc_result",
            "id": payload["id"],
            "ok": False,
            "error": {"code": "bridge_failure", "message": "failed", "details": []},
        }

    monkeypatch.setattr(client, "_exchange", malformed_error)
    with pytest.raises(BridgeUnavailable):
        client.call("check_login")


def test_call_rejects_oversized_params_before_starting_the_broker(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    object_overhead = len(b'{"value":""}')
    exact_value = "x" * (client.MAX_PARAMS_BYTES - object_overhead)
    broker_calls: list[str] = []
    monkeypatch.setattr(client, "ensure_broker", lambda url: broker_calls.append(url) or {})

    async def success(_url: str, payload: dict, _timeout: float) -> dict:
        return {
            "kind": "rpc_result",
            "id": payload["id"],
            "ok": True,
            "result": {},
        }

    monkeypatch.setattr(client, "_exchange", success)
    assert client.call("check_login", {"value": exact_value}) == {}
    assert len(broker_calls) == 1

    broker_calls.clear()
    with pytest.raises(InvalidInput) as caught:
        client.call("check_login", {"value": exact_value + "x"})
    assert caught.value.details == {
        "actual_bytes": client.MAX_PARAMS_BYTES + 1,
        "max_bytes": client.MAX_PARAMS_BYTES,
    }
    assert broker_calls == []


def test_remote_error_details_are_bounded_and_sensitive_values_are_redacted(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(
        client,
        "ensure_broker",
        lambda _url: {"running": True, "extension_connected": True},
    )
    secret = "a" * 64

    async def fake_exchange(_url: str, payload: dict, _timeout: float) -> dict:
        return {
            "kind": "rpc_result",
            "id": payload["id"],
            "ok": False,
            "error": {
                "code": "browser_operation_failed",
                "message": f"remote token {secret}",
                "details": {
                    "token": secret,
                    "content": "private post body",
                    "large_value": "x" * (client.MAX_DETAIL_STRING_LENGTH + 1),
                    "status": 500,
                },
            },
        }

    monkeypatch.setattr(client, "_exchange", fake_exchange)
    with pytest.raises(BrowserOperationFailed) as caught:
        client.call("check_login")
    assert "[redacted]" in caught.value.message
    assert caught.value.details == {
        "remote_code": "browser_operation_failed",
        "token": "[redacted]",
        "content": "[redacted]",
        "large_value": f"[omitted: {client.MAX_DETAIL_STRING_LENGTH + 1} characters]",
        "status": 500,
    }


def test_keyboard_interrupt_is_reported_as_uncertain_only_after_write_intent(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(
        client,
        "ensure_broker",
        lambda _url: {"running": True, "extension_connected": True},
    )

    async def interrupted(_url: str, _payload: dict, _timeout: float) -> dict:
        raise KeyboardInterrupt

    monkeypatch.setattr(client, "_exchange", interrupted)
    with pytest.raises(BrowserOperationFailed) as caught:
        client.call("post_comment", {"content": "test", "confirmed": True})
    assert caught.value.details == {
        "remote_code": "operation_state_uncertain",
        "operation": "post_comment",
        "cause": "KeyboardInterrupt",
    }

    with pytest.raises(KeyboardInterrupt):
        client.call("check_login")
