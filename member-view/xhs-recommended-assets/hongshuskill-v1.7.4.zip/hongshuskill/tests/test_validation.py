from __future__ import annotations

from datetime import UTC, datetime, timedelta
from pathlib import Path

import pytest

from scripts.hongshu.errors import ConfirmationRequired, InvalidInput
from scripts.hongshu.validation import (
    extract_trailing_tags,
    normalize_tags,
    read_utf8_file,
    require_confirmation,
    require_feed_pair,
    require_float_range,
    require_int_range,
    require_phone,
    require_xsec_token,
    resolve_images,
    title_units,
    validate_risk_probe_urls,
    validate_schedule,
    validate_short_title,
)


def test_title_units_match_half_width_rule() -> None:
    assert title_units("hello") == 3
    assert title_units("你好hello") == 5
    assert title_units("AB中文") == 3
    assert title_units("💇‍♀️") == 5


def test_short_title_rejects_over_limit() -> None:
    with pytest.raises(InvalidInput, match="超过 20"):
        validate_short_title("这是一条明显超过二十个全角单位的小红书标题用于校验")


def test_confirmation_is_enforced_in_code() -> None:
    with pytest.raises(ConfirmationRequired):
        require_confirmation(False, "发表评论")
    require_confirmation(True, "发表评论")


def test_text_files_must_be_absolute_and_utf8(tmp_path: Path) -> None:
    path = tmp_path / "content.txt"
    path.write_text("正文", encoding="utf-8")
    assert read_utf8_file(str(path), "正文文件") == "正文"
    with pytest.raises(InvalidInput, match="绝对路径"):
        read_utf8_file("content.txt", "正文文件")


def test_feed_pair_requires_both_valid_values() -> None:
    assert require_feed_pair("6a7529a1000000002402f2be", "token-token-token=")
    with pytest.raises(InvalidInput):
        require_feed_pair("bad", "short")


def test_xsec_token_rejects_whitespace_and_unbounded_values() -> None:
    assert require_xsec_token("token-token-token=") == "token-token-token="
    with pytest.raises(InvalidInput):
        require_xsec_token("token with whitespace")
    with pytest.raises(InvalidInput):
        require_xsec_token("x" * 513)


def test_active_risk_probe_urls_are_xhs_https_api_only_and_deduplicated() -> None:
    first = "https://www.xiaohongshu.com/api/sns/web/v1/test?fixture=1"
    second = "https://edith.xiaohongshu.com:443/api/sns/web/v2/test"
    assert validate_risk_probe_urls([first, first, second]) == [first, second]


@pytest.mark.parametrize(
    "url",
    [
        "http://www.xiaohongshu.com/api/test",
        "https://example.com/api/test",
        "https://evilxiaohongshu.com/api/test",
        "https://user:password@www.xiaohongshu.com/api/test",
        "https://www.xiaohongshu.com:444/api/test",
        "https://www.xiaohongshu.com/explore/test",
        "https://www.xiaohongshu.com/api/test#fragment",
    ],
)
def test_active_risk_probe_urls_reject_unsafe_targets(url: str) -> None:
    with pytest.raises(InvalidInput, match="小红书 HTTPS API"):
        validate_risk_probe_urls([url])


def test_active_risk_probe_urls_limit_request_count() -> None:
    urls = [f"https://www.xiaohongshu.com/api/test/{index}" for index in range(11)]
    with pytest.raises(InvalidInput, match="最多支持 10"):
        validate_risk_probe_urls(urls)


def test_numeric_ranges_reject_nonfinite_and_out_of_bounds_values() -> None:
    assert require_int_range(40, "结果数量", 1, 100) == 40
    assert require_float_range(120.0, "等待时间", 1, 600) == 120.0
    with pytest.raises(InvalidInput):
        require_int_range(0, "结果数量", 1, 100)
    with pytest.raises(InvalidInput) as caught:
        require_float_range(float("nan"), "等待时间", 1, 600)
    assert caught.value.details["value"] == "nan"


def test_phone_validation_rejects_impossible_mobile_prefix() -> None:
    assert require_phone("138 0013 8000") == "13800138000"
    with pytest.raises(InvalidInput):
        require_phone("10000000000")


def test_tags_are_deduplicated_and_limited_to_platform_maximum() -> None:
    tags = ["#重复", "重复", *[f"标签{i}" for i in range(20)]]
    result = normalize_tags(tags)
    assert result[0] == "重复"
    assert len(result) == 10


def test_final_hashtag_line_is_removed_and_merged_into_structured_tags() -> None:
    content, tags = extract_trailing_tags("正文第一段\n\n#咖啡 #周末 #咖啡\n", ["已有"])
    assert content == "正文第一段"
    assert tags == ["已有", "咖啡", "周末"]


def test_mixed_final_line_remains_part_of_content() -> None:
    original = "正文\n这一行有说明 #咖啡"
    content, tags = extract_trailing_tags(original, ["已有"])
    assert content == original
    assert tags == ["已有"]


def test_schedule_rejects_past_timezone_aware_value() -> None:
    past = (datetime.now(UTC) - timedelta(minutes=1)).isoformat()
    with pytest.raises(InvalidInput, match="晚于当前时间"):
        validate_schedule(past)


def test_schedule_requires_time_and_normalizes_timezone_to_local_minutes() -> None:
    with pytest.raises(InvalidInput, match="小时和分钟"):
        validate_schedule("2099-08-10")
    source = datetime.now(UTC) + timedelta(days=2, seconds=37)
    expected = source.astimezone().replace(tzinfo=None).isoformat(timespec="minutes")
    assert validate_schedule(source.isoformat()) == expected


def test_image_count_is_limited_before_file_resolution() -> None:
    with (
        pytest.raises(InvalidInput, match="最多支持 18 张"),
        resolve_images([f"/missing/{index}.jpg" for index in range(19)]),
    ):
        pass


@pytest.mark.parametrize("suffix", [".jpg", ".jpeg", ".png", ".gif", ".webp", ".bmp", ".svg"])
def test_reference_image_formats_are_accepted_for_local_uploads(
    tmp_path: Path,
    suffix: str,
) -> None:
    path = tmp_path / f"fixture{suffix}"
    path.write_bytes(b"fixture-image")
    with resolve_images([str(path)]) as media:
        assert media.paths == [str(path.resolve())]


@pytest.mark.parametrize(
    "url",
    [
        "http://127.0.0.1/image.jpg",
        "http://[::1]/image.jpg",
        "http://user:password@example.com/image.jpg",
        "https://example.com/image.jpg",
        "https://example.com:99999/image.jpg",
    ],
)
def test_remote_images_are_rejected_before_any_network_access(url: str) -> None:
    with pytest.raises(InvalidInput, match="必须先下载到本地") as captured, resolve_images([url]):
        pass
    assert captured.value.details == {"remote_images_supported": False}


def test_malformed_remote_image_url_is_a_typed_input_error() -> None:
    with (
        pytest.raises(InvalidInput, match="格式不正确"),
        resolve_images(["http://[broken/image.jpg"]),
    ):
        pass


def test_text_file_size_is_checked_before_reading(tmp_path: Path) -> None:
    path = tmp_path / "oversized.txt"
    path.write_bytes(b"x" * 9)
    with pytest.raises(InvalidInput, match="大小上限") as captured:
        read_utf8_file(str(path), "正文文件", max_bytes=8)
    assert captured.value.details["size_bytes"] == 9


def test_schedule_rejects_hour_only_and_current_minute_values() -> None:
    with pytest.raises(InvalidInput, match="小时和分钟"):
        validate_schedule("2099-08-10T20")
    current_minute_with_future_seconds = (
        datetime.now().replace(second=59, microsecond=999999).isoformat()
    )
    with pytest.raises(InvalidInput, match="晚于当前时间"):
        validate_schedule(current_minute_with_future_seconds)
