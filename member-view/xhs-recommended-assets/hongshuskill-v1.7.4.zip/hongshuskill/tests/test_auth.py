from __future__ import annotations

import contextlib
import json
import os
import stat
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import pytest

from scripts.hongshu import auth

TOKEN = bytes(range(32))
NONCE = "00112233445566778899aabbccddeeff"
TIMESTAMP_MS = 1_700_000_000_123


def test_pairing_token_is_generated_once_atomically_and_made_private(tmp_path: Path) -> None:
    pairing = tmp_path / "pairing.json"
    pairing.write_text('{"token":""}\n', encoding="utf-8")
    pairing.chmod(0o644)

    with ThreadPoolExecutor(max_workers=8) as executor:
        tokens = list(executor.map(lambda _index: auth.load_or_create_token(pairing), range(8)))

    assert len(set(tokens)) == 1
    assert len(tokens[0]) == 32
    if os.name != "nt":
        assert stat.S_IMODE(pairing.stat().st_mode) == 0o600
    persisted = json.loads(pairing.read_text(encoding="utf-8"))["token"]
    assert bytes.fromhex(persisted) == tokens[0]


def test_pairing_token_rejects_symlinks_and_files_owned_by_another_user(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    target = tmp_path / "target.json"
    target.write_text('{"token":""}\n', encoding="utf-8")
    symlink = tmp_path / "pairing.json"
    try:
        symlink.symlink_to(target)
    except OSError as exc:
        if os.name == "nt" and getattr(exc, "winerror", None) == 1314:
            pytest.skip("Windows symlink privilege is unavailable")
        raise
    with pytest.raises(auth.EnvelopeAuthenticationError, match="symlink"):
        auth.load_or_create_token(symlink)

    monkeypatch.setattr(auth, "_pairing_lock", lambda _path: contextlib.nullcontext())
    monkeypatch.setattr(auth.os, "getuid", lambda: target.stat().st_uid + 1)
    with pytest.raises(auth.EnvelopeAuthenticationError, match="another user"):
        auth.load_or_create_token(target)


def test_pairing_token_rejects_non_regular_files_without_blocking(tmp_path: Path) -> None:
    if not hasattr(auth.os, "mkfifo"):
        pytest.skip("FIFO creation is unavailable on this platform")
    pairing = tmp_path / "pairing.json"
    auth.os.mkfifo(pairing)
    with pytest.raises(auth.EnvelopeAuthenticationError, match="regular file"):
        auth.load_or_create_token(pairing)


def test_authenticated_envelope_has_a_stable_cross_runtime_vector() -> None:
    envelope = {
        "role": "client",
        "protocol": 2,
        "id": "request-1",
        "op": "broker_status",
        "params": {},
        "timeout": 5.0,
    }
    signed = auth.sign_envelope(
        envelope,
        TOKEN,
        nonce=NONCE,
        timestamp_ms=TIMESTAMP_MS,
    )

    assert signed["timeout"] == 5
    assert signed["auth"] == {
        "nonce": NONCE,
        "timestamp_ms": TIMESTAMP_MS,
        "mac": "a1405c49cdc18e73afdc278904b7adb076191c7e4b618da7ea109f0388381080",
    }
    assert auth.verify_envelope(
        signed,
        TOKEN,
        auth.NonceReplayCache(),
        now_ms=TIMESTAMP_MS,
    ) == {**envelope, "timeout": 5}


def test_authentication_binds_nonce_timestamp_and_body_and_rejects_replay() -> None:
    signed = auth.sign_envelope(
        {"kind": "rpc_result", "id": "request-1", "ok": True, "result": {}},
        TOKEN,
        nonce=NONCE,
        timestamp_ms=TIMESTAMP_MS,
    )

    for mutation in ("body", "nonce", "timestamp"):
        tampered = json.loads(json.dumps(signed))
        if mutation == "body":
            tampered["ok"] = False
        elif mutation == "nonce":
            tampered["auth"]["nonce"] = "f" * 32
        else:
            tampered["auth"]["timestamp_ms"] += 1
        with pytest.raises(auth.EnvelopeAuthenticationError, match="MAC"):
            auth.verify_envelope(
                tampered,
                TOKEN,
                auth.NonceReplayCache(),
                now_ms=TIMESTAMP_MS,
            )

    replay_cache = auth.NonceReplayCache()
    auth.verify_envelope(signed, TOKEN, replay_cache, now_ms=TIMESTAMP_MS)
    with pytest.raises(auth.EnvelopeAuthenticationError, match="already used"):
        auth.verify_envelope(signed, TOKEN, replay_cache, now_ms=TIMESTAMP_MS)


def test_authentication_rejects_stale_messages_and_unsafe_numbers() -> None:
    signed = auth.sign_envelope(
        {"ok": True},
        TOKEN,
        nonce=NONCE,
        timestamp_ms=TIMESTAMP_MS,
    )
    with pytest.raises(auth.EnvelopeAuthenticationError, match="time window"):
        auth.verify_envelope(
            signed,
            TOKEN,
            auth.NonceReplayCache(),
            now_ms=TIMESTAMP_MS + auth.AUTH_WINDOW_MS + 1,
        )

    for value in (float("nan"), float("inf"), auth.MAX_SAFE_INTEGER + 1):
        with pytest.raises(auth.EnvelopeAuthenticationError):
            auth.sign_envelope({"value": value}, TOKEN)


def test_fractional_numbers_have_a_stable_cross_runtime_vector() -> None:
    envelope = {
        "role": "client",
        "protocol": 2,
        "id": "request-1",
        "op": "wait_login",
        "params": {"timeout": 7.5, "signals": {"deviceMemory": 0.25}},
        "timeout": 7.5,
    }
    canonical = (
        '{"id":"request-1","op":"wait_login","params":{"signals":'
        '{"deviceMemory":2.5000000000000000e-1},"timeout":7.5000000000000000e+0},'
        '"protocol":2,"role":"client","timeout":7.5000000000000000e+0}'
    )

    assert auth.canonical_envelope(envelope).decode("utf-8") == canonical
    signed = auth.sign_envelope(
        envelope,
        TOKEN,
        nonce=NONCE,
        timestamp_ms=TIMESTAMP_MS,
    )
    assert signed["params"]["signals"]["deviceMemory"] == 0.25
    assert signed["auth"]["mac"] == (
        "2b86cd53083e2687ec77eec062993dfd1bbe6d0534bb904337f2c22aed2e1bfb"
    )


def test_canonical_strings_sort_by_codepoint_and_reject_unpaired_surrogates() -> None:
    canonical = auth.canonical_envelope(
        {"\U0001f600": "astral", "\ue000": "bmp", "line": "\u2028\u2029\n"}
    ).decode("utf-8")
    expected = (
        '{"line":"\u2028\u2029\\n","' + chr(0xE000) + '":"bmp","' + chr(0x1F600) + '":"astral"}'
    )
    assert canonical == expected

    with pytest.raises(auth.EnvelopeAuthenticationError, match="valid Unicode"):
        auth.sign_envelope({"value": "\ud800"}, TOKEN)
    with pytest.raises(auth.EnvelopeAuthenticationError, match="valid Unicode"):
        auth.sign_envelope({"\udc00": "value"}, TOKEN)


def test_authenticated_envelope_enforces_depth_node_and_string_budgets() -> None:
    nested: object = "leaf"
    for _ in range(auth.MAX_JSON_DEPTH + 1):
        nested = [nested]
    with pytest.raises(auth.EnvelopeAuthenticationError, match="nesting"):
        auth.sign_envelope({"value": nested}, TOKEN)

    with pytest.raises(auth.EnvelopeAuthenticationError, match="string exceeds"):
        auth.sign_envelope({"value": "x" * (auth.MAX_JSON_STRING_BYTES + 1)}, TOKEN)

    monkeypatch_nodes = auth.MAX_JSON_NODES
    auth.MAX_JSON_NODES = 4
    try:
        with pytest.raises(auth.EnvelopeAuthenticationError, match="too many values"):
            auth.sign_envelope({"value": [1, 2, 3]}, TOKEN)
    finally:
        auth.MAX_JSON_NODES = monkeypatch_nodes
