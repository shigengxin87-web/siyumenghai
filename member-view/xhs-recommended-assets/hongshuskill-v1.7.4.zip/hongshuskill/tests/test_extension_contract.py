from __future__ import annotations

import json
import os
import re
import subprocess
import sys
import tomllib
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
EXTENSION = ROOT / "extension"
PROJECT_VERSION = tomllib.loads((ROOT / "pyproject.toml").read_text(encoding="utf-8"))[
    "project"
]["version"]

WORKER_OPERATIONS = {
    "account_identity",
    "check_login",
    "get_qrcode",
    "wait_login",
    "send_code",
    "verify_code",
    "delete_cookies",
    "list_feeds",
    "search_feeds",
    "get_feed_detail",
    "user_profile",
    "inspect_actions",
    "post_comment",
    "reply_comment",
    "set_like",
    "set_favorite",
    "fill_image",
    "publish_image",
    "fill_video",
    "publish_video",
    "click_publish",
    "save_draft",
    "fill_long_article",
    "select_template",
    "long_article_next",
    "diagnostics",
    "get_netlog",
    "check_risk",
}

PAGE_OPERATIONS = {
    "ping",
    "check_login",
    "note_access",
    "get_qrcode",
    "prepare_phone",
    "send_code_target",
    "wait_code_sent",
    "prepare_verify_code",
    "wait_verify_code",
    "apply_filters",
    "dom_feeds",
    "dom_note_content",
    "load_comments",
    "dom_detail",
    "dom_profile",
    "comment_open_target",
    "prepare_comment",
    "wait_comment_sent",
    "reply_target",
    "interaction_state",
    "interaction_target",
    "action_readiness",
    "prepare_publish_tab",
    "wait_upload",
    "fill_publish_form",
    "publish_setting_rect",
    "wait_publish_settings",
    "target_rect",
    "observe_submission",
    "prepare_long_article",
    "long_draft_snapshot",
    "prepare_long_images",
    "wait_long_images",
    "format_long_article",
    "select_template",
    "long_next",
    "active_risk_probes",
    "risk_signals",
}


def operation_keys(source: str, marker: str, *, indent: int = 2) -> set[str]:
    body = source.split(marker, 1)[1]
    prefix = " " * indent
    return set(re.findall(rf"^{prefix}([a-z_]+):", body, flags=re.MULTILINE))


def test_manifest_limits_permissions_to_the_required_xiaohongshu_surface() -> None:
    manifest = json.loads((EXTENSION / "manifest.json").read_text(encoding="utf-8"))
    assert manifest["manifest_version"] == 3
    assert manifest["minimum_chrome_version"] == "116"
    assert manifest["version"] == PROJECT_VERSION
    assert set(manifest["permissions"]) == {
        "alarms",
        "cookies",
        "debugger",
        "scripting",
        "storage",
        "tabs",
        "webRequest",
    }
    assert "<all_urls>" not in manifest["host_permissions"]
    assert manifest["host_permissions"] == ["https://*.xiaohongshu.com/*"]
    assert all(
        host.startswith("https://") and ("xiaohongshu.com" in host or "xhscdn.com" in host)
        for host in manifest["host_permissions"]
    )


def test_skill_uses_dependency_locked_platform_launchers() -> None:
    launcher = ROOT / "scripts" / "run-hongshu"
    assert launcher.is_file()
    assert os.access(launcher, os.X_OK)
    source = launcher.read_text(encoding="utf-8")
    assert "command -v uv" in source
    assert "uv run --quiet --frozen --no-dev --project" in source
    assert "UV_PROJECT_ENVIRONMENT" in source
    assert "skill_key=$(printf '%s' \"$skill_dir\" | cksum" in source
    assert 'runtime_root="$runtime_parent/hongshuskill-runtime"' in source
    assert 'runtime_dir="$runtime_root/$skill_key"' in source
    assert 'if [ -L "$target_dir" ]' in source
    assert 'ensure_private_directory "$venv_dir"' not in source
    assert "runtime_platform_unsupported" in source
    assert '"runtime_dependency_missing"' in source
    assert 'capture_dir=$(mktemp -d "$runtime_dir/launch.XXXXXXXX"' in source
    assert 'started_file="$capture_dir/cli-started"' in source
    assert 'cat "$stdout_file"' in source
    assert 'cat "$stderr_file" >&2' in source
    assert '"runtime_launch_failed"' in source
    assert '"$skill_dir/scripts/cli.py" "$@"' in source

    windows_launcher = ROOT / "scripts" / "run-hongshu.ps1"
    assert windows_launcher.is_file()
    assert windows_launcher.read_bytes().startswith(b"\xef\xbb\xbf")
    windows_source = windows_launcher.read_text(encoding="utf-8")
    assert "Get-Command uv -CommandType Application" in windows_source
    assert "UV_PROJECT_ENVIRONMENT" in windows_source
    assert "SHA256" in windows_source
    assert "FileAttributes]::ReparsePoint" in windows_source
    assert "SetAccessRuleProtection($true, $false)" in windows_source
    assert "$directory.SetAccessControl($security)" in windows_source
    assert "Protect-PrivateDirectory $extensionDir" in windows_source
    assert "Protect-PrivateDirectory $venvDir" not in windows_source
    assert "SpecialFolder]::LocalApplicationData" in windows_source
    assert 'Join-Path $venvDir "pyvenv.cfg"' in windows_source
    assert "Microsoft.PowerShell.Utility\\Write-Output -NoEnumerate" in windows_source
    assert "[Console]::Out.Write" not in windows_source
    assert "[Console]::Error.Write" not in windows_source
    assert "$script:NestedInvocation" in windows_source
    assert "$PSDefaultParameterValues['Out-File:Encoding'] = 'utf8'" in windows_source
    assert "$PSDefaultParameterValues['Out-File:Width'] = 16777216" in windows_source
    assert windows_source.count('$ErrorActionPreference = "Continue"') == 2
    assert windows_source.count("$ErrorActionPreference = $launcherErrorAction") == 2
    assert '"sync", "--quiet", "--frozen", "--no-dev", "--project"' in windows_source
    assert (
        '"run", "--quiet", "--frozen", "--no-dev", "--no-sync", "--project"'
        in windows_source
    )
    assert '"runtime_dependency_missing"' in windows_source
    assert '"runtime_launch_failed"' in windows_source
    assert '"python", $bootstrapPath, $cliStarted, $cliPath' in windows_source
    assert ") + $args" in windows_source
    assert "Invoke-CapturedProcess" in windows_source
    assert 'Join-Path $captureDir "cli-started"' in windows_source
    assert "(Get-Item -LiteralPath $cliStarted).Length -eq 0" in windows_source
    assert not (ROOT / ".venv").exists()


@pytest.mark.skipif(os.name != "nt", reason="Windows PowerShell launcher contract")
def test_windows_launcher_output_is_capturable_and_call_operator_returns(
    tmp_path: Path,
) -> None:
    launcher = str(ROOT / "scripts" / "run-hongshu.ps1").replace("'", "''")
    redirected = str(tmp_path / "redirected.json").replace("'", "''")
    command = rf"""
[Console]::OutputEncoding = [Text.UTF8Encoding]::new($false)
$env:TEMP = 'C:\tmp'
$env:TMP = 'C:\tmp'
$captured = & '{launcher}' --version
$captureCode = $LASTEXITCODE
& '{launcher}' --version *> '{redirected}'
$redirectCode = $LASTEXITCODE
$invalid = & '{launcher}' definitely-not-a-command
$invalidCode = $LASTEXITCODE
[ordered]@{{
    after = $true
    captured = (@($captured) -join '').Trim()
    capture_code = $captureCode
    temp_after = $env:TEMP
    redirected = ([IO.File]::ReadAllText('{redirected}')).Trim()
    redirect_code = $redirectCode
    invalid = (@($invalid) -join '').Trim()
    invalid_code = $invalidCode
}} | ConvertTo-Json -Compress
"""
    completed = subprocess.run(
        ["powershell.exe", "-NoProfile", "-Command", command],
        capture_output=True,
        text=True,
        encoding="utf-8",
        timeout=30,
        check=False,
    )

    assert completed.returncode == 0, completed.stderr
    result = json.loads(completed.stdout)
    assert result["after"] is True
    assert result["captured"] == PROJECT_VERSION
    assert result["capture_code"] == 0
    assert result["temp_after"] == r"C:\tmp"
    assert result["redirected"] == PROJECT_VERSION
    assert result["redirect_code"] == 0
    invalid = json.loads(result["invalid"])
    assert invalid["ok"] is False
    assert result["invalid_code"] == 2

    external = subprocess.run(
        [
            "powershell.exe",
            "-NoProfile",
            "-ExecutionPolicy",
            "Bypass",
            "-File",
            str(ROOT / "scripts" / "run-hongshu.ps1"),
            "definitely-not-a-command",
        ],
        capture_output=True,
        text=True,
        encoding="utf-8",
        timeout=30,
        check=False,
    )
    assert external.returncode == 2
    assert json.loads(external.stdout)["ok"] is False


def test_windows_cli_bootstrap_marks_handoff_and_preserves_cli_exit_code(tmp_path: Path) -> None:
    bootstrap = ROOT / "scripts" / "launch_cli.py"
    marker = tmp_path / "cli-started"
    fake_cli = tmp_path / "fake_cli.py"
    fake_cli.write_text(
        "import sys\n"
        'print("cli stdout")\n'
        'print("cli stderr", file=sys.stderr)\n'
        "raise SystemExit(7)\n",
        encoding="utf-8",
    )

    completed = subprocess.run(
        [sys.executable, str(bootstrap), str(marker), str(fake_cli), "arg"],
        check=False,
        capture_output=True,
        text=True,
    )

    assert completed.returncode == 7
    assert completed.stdout == "cli stdout\n"
    assert completed.stderr == "cli stderr\n"
    assert marker.read_text(encoding="ascii") == "started\n"
    documentation = "\n".join(
        path.read_text(encoding="utf-8")
        for path in [ROOT / "SKILL.md", *(ROOT / "references").glob("*.md")]
    )
    assert "python scripts/cli.py" not in documentation
    assert "./scripts/run-hongshu doctor" in documentation


def test_skill_trigger_metadata_and_release_documentation_are_explicit() -> None:
    skill = (ROOT / "SKILL.md").read_text(encoding="utf-8")
    metadata = (ROOT / "agents" / "openai.yaml").read_text(encoding="utf-8")
    commands = (ROOT / "references" / "commands.md").read_text(encoding="utf-8")
    extension_setup = (ROOT / "references" / "extension-setup.md").read_text(encoding="utf-8")
    windows_first_run = (ROOT / "references" / "windows-first-run.md").read_text(encoding="utf-8")
    workflows = (ROOT / "references" / "workflows.md").read_text(encoding="utf-8")

    frontmatter = skill.split("---", 2)[1]
    assert "`$hongshuskill`" in frontmatter
    assert "不要因泛化的小红书" in frontmatter
    assert "allow_implicit_invocation: false" in metadata

    short_match = re.search(r'^  short_description: "([^"]+)"$', metadata, flags=re.MULTILINE)
    prompt_match = re.search(r'^  default_prompt: "([^"]+)"$', metadata, flags=re.MULTILINE)
    assert short_match is not None
    assert 25 <= len(short_match.group(1)) <= 64
    assert prompt_match is not None
    assert "$hongshuskill" in prompt_match.group(1)
    assert prompt_match.group(1).count("。") == 1

    for document in (skill, commands, extension_setup):
        assert "Windows 10/11" in document
        assert "Windows 尚未支持" not in document
    assert "run-hongshu.ps1" in skill
    assert "run-hongshu.ps1" in commands
    assert "run-hongshu.ps1" in extension_setup
    assert "references/windows-first-run.md" in skill
    assert "必须先完整读取" in skill
    assert "发给 Windows 用户的教程" in skill
    assert "Windows 终端或 PowerShell" in windows_first_run
    assert "不需要懂编程，也不需要管理员权限" in windows_first_run
    assert "用鼠标右键单击压缩包，选择“全部解压缩”" in windows_first_run
    assert "不要直接在压缩包预览窗口里运行文件" in windows_first_run
    assert "这就是地址栏" in windows_first_run
    assert "按 `Ctrl+A` 选中地址栏里的全部文字" in windows_first_run
    assert "系统会弹出一个蓝色或黑色窗口" in windows_first_run
    assert "看到 `hongshuskill>` 才表示位置正确" in windows_first_run
    assert "以 `{` 开头、以 `}` 结尾的 JSON 内容" in windows_first_run
    assert "winget install --id=astral-sh.uv -e" in windows_first_run
    assert (
        "powershell.exe -NoProfile -ExecutionPolicy Bypass "
        "-File .\\scripts\\run-hongshu.ps1 onboard"
    ) in windows_first_run
    assert "不是输入在 Chrome、小红书网页或 ChatGPT 输入框里" in windows_first_run
    if len(extension_setup.splitlines()) > 100:
        assert "## 目录" in extension_setup

    assert "./scripts/run-hongshu publish-video" in commands
    assert "login [--timeout 120] [--output /absolute/path/qrcode.png]" in commands
    assert "--user-id USER_ID" in commands
    assert "click-publish --preview-id PREVIEW_ID --confirm" in skill
    assert "click-publish --preview-id PREVIEW_ID --confirm" in commands
    assert "click-publish --preview-id PREVIEW_ID --confirm" in workflows
    assert "save-draft --preview-id PREVIEW_ID --confirm" in commands
    assert "select-template --preview-id PREVIEW_ID --confirm" in skill
    assert "next-step --preview-id PREVIEW_ID ... --confirm" in skill
    assert "https://example.com/2.webp" not in commands
    assert "不将远程 URL 传给 CLI" in workflows


@pytest.mark.skipif(os.name == "nt", reason="POSIX launcher behavior")
def test_launcher_sanitizes_uv_bootstrap_failures(tmp_path: Path) -> None:
    fake_bin = tmp_path / "bin"
    runtime_parent = tmp_path / "runtime"
    fake_bin.mkdir()
    runtime_parent.mkdir()
    fake_uv = fake_bin / "uv"
    fake_uv.write_text(
        "#!/bin/sh\nprintf 'private path: /Users/example/secret\\n' >&2\nexit 42\n",
        encoding="utf-8",
    )
    fake_uv.chmod(0o700)

    completed = subprocess.run(
        [ROOT / "scripts" / "run-hongshu", "--version"],
        capture_output=True,
        check=False,
        env={
            **os.environ,
            "PATH": f"{fake_bin}:/usr/bin:/bin",
            "TMPDIR": str(runtime_parent),
        },
        text=True,
        timeout=10,
    )

    assert completed.returncode == 2
    assert completed.stdout == ""
    payload = json.loads(completed.stderr)
    assert payload["error"]["code"] == "runtime_launch_failed"
    assert "private path" not in completed.stderr
    assert not list(runtime_parent.rglob("launch.*"))


@pytest.mark.skipif(os.name == "nt", reason="POSIX launcher behavior")
def test_launcher_preserves_started_cli_streams_and_exit_code(tmp_path: Path) -> None:
    fake_bin = tmp_path / "bin"
    runtime_parent = tmp_path / "runtime"
    fake_bin.mkdir()
    runtime_parent.mkdir()
    fake_uv = fake_bin / "uv"
    fake_python = fake_bin / "python"
    fake_uv.write_text(
        "#!/bin/sh\n"
        'while [ "$#" -gt 0 ]; do\n'
        '  if [ "$1" = sh ]; then exec "$@"; fi\n'
        "  shift\n"
        "done\n"
        "exit 99\n",
        encoding="utf-8",
    )
    fake_python.write_text(
        "#!/bin/sh\nprintf 'cli stdout\\n'\nprintf 'cli stderr\\n' >&2\nexit 7\n",
        encoding="utf-8",
    )
    fake_uv.chmod(0o700)
    fake_python.chmod(0o700)

    completed = subprocess.run(
        [ROOT / "scripts" / "run-hongshu", "ignored-command"],
        capture_output=True,
        check=False,
        env={
            **os.environ,
            "PATH": f"{fake_bin}:/usr/bin:/bin",
            "TMPDIR": str(runtime_parent),
        },
        text=True,
        timeout=10,
    )

    assert completed.returncode == 7
    assert completed.stdout == "cli stdout\n"
    assert completed.stderr == "cli stderr\n"
    assert not list(runtime_parent.rglob("launch.*"))


def test_extension_exposes_only_fixed_high_level_operations() -> None:
    worker = (EXTENSION / "worker.js").read_text(encoding="utf-8")
    page = (EXTENSION / "page.js").read_text(encoding="utf-8")
    assert operation_keys(worker, "const OPERATIONS = {") == WORKER_OPERATIONS
    assert operation_keys(page, "const operations = {", indent=4) == PAGE_OPERATIONS
    for source in (worker, page):
        assert not re.search(r"\beval\s*\(", source)
        assert "new Function" not in source
    assert worker.count("await requireWriteAllowed(params,") == 15
    assert "const HIGH_RISK_STATUSES = new Set([429, 461, 999])" in worker


def test_every_page_operation_is_reachable_only_through_the_worker() -> None:
    worker = (EXTENSION / "worker.js").read_text(encoding="utf-8")
    calls = set(re.findall(r'pageCall\([^,]+,\s*"([a-z_]+)"', worker))
    assert calls <= PAGE_OPERATIONS
    assert PAGE_OPERATIONS - {"ping"} <= calls


def test_bridge_and_network_log_contracts_are_local_and_privacy_reduced() -> None:
    worker = (EXTENSION / "worker.js").read_text(encoding="utf-8")
    page = (EXTENSION / "page.js").read_text(encoding="utf-8")
    bridge = (ROOT / "scripts" / "bridge_server.py").read_text(encoding="utf-8")
    cli = (ROOT / "scripts" / "cli.py").read_text(encoding="utf-8")
    package = (ROOT / "scripts" / "hongshu" / "__init__.py").read_text(encoding="utf-8")
    assert 'const BRIDGE_URL = "ws://127.0.0.1:9345"' in worker
    assert f'const EXTENSION_VERSION = "{PROJECT_VERSION}"' in worker
    assert f'EXTENSION_VERSION = "{PROJECT_VERSION}"' in bridge
    assert f'VERSION = "{PROJECT_VERSION}"' in package
    creator_url = "https://creator.xiaohongshu.com/publish/publish?source=official"
    assert f'const CREATOR_URL = "{creator_url}"' in worker
    assert "9333" not in worker
    assert "safeUrl = privacySafeUrl(details.url)" in worker
    assert "return `${parsed.origin}${parsed.pathname}`" in worker
    assert "details.requestBody" not in worker
    assert "details.requestHeaders" not in worker
    assert "details.responseHeaders" not in worker
    assert "const RISK_WINDOW_MINUTES = 15" in worker
    assert "const MAX_RISK_EVENTS = 200" in worker
    assert 'chrome.storage.local.get(["network_entries", "risk_events"])' in worker
    assert "risk_events: riskEvents.slice(-MAX_RISK_EVENTS)" in worker
    assert "let storageLoadPromise = null" in worker
    assert "let storageWriteQueue = Promise.resolve()" in worker
    assert "riskEvents = pruneRiskEvents(riskEvents)" in worker
    assert "riskEvents = riskEvents.filter((item) => item.status !== 404)" in worker
    assert "recordPageRiskSignal" in worker
    assert "await requireRiskClear(target ===" in worker
    assert "const riskPattern = /违反|违规|禁止发笔记" in page
    assert "BarcodeDetector" not in page
    assert "qr_login_url" not in page
    assert "data_url: dataUrl" in page
    assert 'if key not in {"data_url", "qr_login_url", "qrcode_image_url"}' in cli
    assert '"qrcode_path": str(path)' in cli
    assert "item.timestamp >= cutoff" in worker
