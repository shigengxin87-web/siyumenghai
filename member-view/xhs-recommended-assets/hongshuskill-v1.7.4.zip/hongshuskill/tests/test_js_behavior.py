from __future__ import annotations

import shutil
import subprocess
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]


def test_extension_javascript_behavior() -> None:
    node = shutil.which("node")
    if node is None:
        pytest.skip("Node.js is not available")
    result = subprocess.run(
        [node, "--test", str(ROOT / "tests/js/extension_behavior.test.mjs")],
        cwd=ROOT,
        capture_output=True,
        check=False,
        text=True,
        timeout=30,
    )
    assert result.returncode == 0, f"{result.stdout}\n{result.stderr}"
