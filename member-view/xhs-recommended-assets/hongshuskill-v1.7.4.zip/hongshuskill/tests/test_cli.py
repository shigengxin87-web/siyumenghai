from __future__ import annotations

import json
import os
import stat
import sys
from datetime import datetime, timedelta
from pathlib import Path

import pytest

import scripts.cli as cli
from scripts.cli import build_parser, main

EXPECTED_COMMANDS = {
    "onboard",
    "prepare-extension-install",
    "doctor",
    "recover-bridge",
    "upgrade-bridge",
    "check-login",
    "login",
    "get-qrcode",
    "wait-login",
    "phone-login",
    "send-code",
    "verify-code",
    "delete-cookies",
    "list-feeds",
    "search-feeds",
    "get-feed-detail",
    "user-profile",
    "inspect-actions",
    "post-comment",
    "reply-comment",
    "like-feed",
    "favorite-feed",
    "publish",
    "publish-video",
    "fill-publish",
    "fill-publish-video",
    "click-publish",
    "save-draft",
    "long-article",
    "select-template",
    "next-step",
    "diagnose-404",
    "check-risk",
    "get-netlog",
    "risk-report",
}


def test_all_compatibility_commands_are_registered() -> None:
    parser = build_parser()
    subparsers = next(action for action in parser._actions if action.dest == "command")
    assert set(subparsers.choices) >= EXPECTED_COMMANDS
    assert "不会发送短信" in parser.format_help()


@pytest.mark.parametrize(
    "argv",
    [
        [],
        ["not-a-command"],
        ["search-feeds"],
        ["list-feeds", "--limit", "not-a-number"],
    ],
)
def test_argument_parser_failures_use_the_json_error_envelope(
    argv: list[str],
    capsys: pytest.CaptureFixture[str],
) -> None:
    assert main(argv) == 2
    captured = capsys.readouterr()
    assert captured.out == ""
    payload = json.loads(captured.err)
    assert payload["ok"] is False
    assert payload["command"] == "cli"
    assert payload["error"]["code"] == "invalid_input"


def test_unexpected_errors_do_not_reflect_sensitive_exception_text(
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    secret = "web_session=must-not-appear /Users/private/path"
    monkeypatch.setattr(
        cli,
        "ensure_broker",
        lambda _url: (_ for _ in ()).throw(RuntimeError(secret)),
    )

    assert main(["doctor"]) == 2
    captured = capsys.readouterr()
    assert captured.out == ""
    assert secret not in captured.err
    assert "must-not-appear" not in captured.err
    payload = json.loads(captured.err)
    assert payload["error"] == {
        "code": "unexpected_error",
        "message": "执行遇到未预期错误；未输出异常详情",
        "details": {"exception_type": "RuntimeError"},
    }


def test_doctor_reports_the_bundled_extension_and_pairing_state(
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    monkeypatch.setattr(
        cli,
        "ensure_broker",
        lambda _url: {
            "running": True,
            "broker_version": cli.VERSION,
            "extension_connected": True,
            "extension_version": cli.VERSION,
            "protocol": cli.PROTOCOL_VERSION,
        },
    )
    assert main(["doctor"]) == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["data"]["ready"] is True
    assert payload["data"]["extension_manifest_present"] is True
    assert payload["data"]["extension_pairing_present"] is True
    assert payload["data"]["package_valid"] is True
    extension_path = Path(payload["data"]["extension_path"])
    assert extension_path.name == "extension"
    assert extension_path.parent.name == "hongshuskill"
    assert payload["data"]["onboarding"]["state"] == "ready"
    assert payload["data"]["onboarding"]["confirmation_required"] is False
    onboarding = payload["data"]["onboarding"]
    assert onboarding["first_use_examples"] == cli.FIRST_USE_EXAMPLES
    assert onboarding["success_user_message"] == cli.FIRST_INSTALL_SUCCESS_MESSAGE
    assert "1. 帮我抓取5篇关于运营起号" in onboarding["success_user_message"]
    assert "2. 帮我找到5篇关于运营创业" in onboarding["success_user_message"]
    assert "3. 帮我抓取5篇运营创业" in onboarding["success_user_message"]


def test_doctor_reports_package_invalid_before_starting_the_broker(
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    monkeypatch.setattr(
        cli,
        "_inspect_bundled_extension",
        lambda _skill_dir: {
            "valid": False,
            "manifest_present": True,
            "pairing_present": False,
            "reason": "bundled_pairing_missing",
        },
    )
    monkeypatch.setattr(
        cli,
        "ensure_broker",
        lambda _url: pytest.fail("invalid package must not start a broker"),
    )

    assert main(["doctor"]) == 0
    data = json.loads(capsys.readouterr().out)["data"]
    assert data["ready"] is False
    assert data["package_valid"] is False
    assert data["onboarding"]["state"] == "package_invalid"
    assert data["onboarding"]["reason"] == "bundled_pairing_missing"


def test_bundled_extension_check_rejects_bad_pairing_without_exposing_it(
    tmp_path: Path,
) -> None:
    extension = tmp_path / "extension"
    extension.mkdir()
    manifest = json.loads((cli.SCRIPT_DIR.parent / "extension" / "manifest.json").read_text())
    (extension / "manifest.json").write_text(json.dumps(manifest), encoding="utf-8")
    (extension / "pairing.json").write_text('{"token":"not-a-token"}', encoding="utf-8")
    for name in ("worker.js", "page.js", "popup.html", "popup.js"):
        (extension / name).write_text("fixture", encoding="utf-8")

    result = cli._inspect_bundled_extension(tmp_path)
    assert result == {
        "valid": False,
        "manifest_present": True,
        "pairing_present": True,
        "reason": "bundled_pairing_invalid",
    }
    assert "not-a-token" not in json.dumps(result)


def test_doctor_rejects_extension_directory_symlink_before_starting_broker(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    skill_dir = tmp_path / "skill"
    scripts_dir = skill_dir / "scripts"
    scripts_dir.mkdir(parents=True)
    try:
        (skill_dir / "extension").symlink_to(cli.SCRIPT_DIR.parent / "extension")
    except OSError as exc:
        if os.name == "nt" and getattr(exc, "winerror", None) == 1314:
            pytest.skip("Windows symlink privilege is unavailable")
        raise
    monkeypatch.setattr(cli, "SCRIPT_DIR", scripts_dir)
    monkeypatch.setattr(
        cli,
        "ensure_broker",
        lambda _url: pytest.fail("unsafe package must not start a broker"),
    )

    assert main(["doctor"]) == 0
    data = json.loads(capsys.readouterr().out)["data"]
    assert data["package_valid"] is False
    assert data["onboarding"]["state"] == "package_invalid"
    assert data["onboarding"]["reason"] == "bundled_extension_directory_invalid"


@pytest.mark.parametrize("variant", ["extra_content_script", "external_entrypoint"])
def test_bundled_extension_check_rejects_extra_manifest_capabilities(
    tmp_path: Path,
    variant: str,
) -> None:
    extension = tmp_path / "extension"
    extension.mkdir()
    manifest = json.loads((cli.SCRIPT_DIR.parent / "extension" / "manifest.json").read_text())
    if variant == "extra_content_script":
        manifest["content_scripts"].append(
            {
                "matches": ["<all_urls>"],
                "js": ["page.js"],
                "run_at": "document_idle",
            }
        )
    else:
        manifest["externally_connectable"] = {"matches": ["<all_urls>"]}
    (extension / "manifest.json").write_text(json.dumps(manifest), encoding="utf-8")
    (extension / "pairing.json").write_text('{"token":""}', encoding="utf-8")
    for name in ("worker.js", "page.js", "popup.html", "popup.js"):
        (extension / name).write_text("fixture", encoding="utf-8")

    result = cli._inspect_bundled_extension(tmp_path)
    assert result["valid"] is False
    assert result["reason"] == "bundled_manifest_invalid"


def test_doctor_routes_persisted_uncertain_operation_to_explicit_recovery(
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    request_id = "a" * 32
    monkeypatch.setattr(
        cli,
        "ensure_broker",
        lambda _url: {
            "running": True,
            "broker_version": cli.VERSION,
            "protocol": cli.PROTOCOL_VERSION,
            "extension_connected": True,
            "extension_version": cli.VERSION,
            "quarantined": True,
            "quarantine_reason": "operation_state_uncertain",
            "quarantine_request_id": request_id,
        },
    )

    assert main(["doctor"]) == 0
    data = json.loads(capsys.readouterr().out)["data"]
    onboarding = data["onboarding"]
    assert data["ready"] is False
    assert onboarding["state"] == "bridge_recovery_required"
    assert onboarding["confirmation_required"] is True
    assert "核验上次操作" in onboarding["confirmation_prompt"]
    assert onboarding["recovery_request_id"] == request_id
    assert onboarding["recovery_argv_after_confirmation"][-4:] == [
        "recover-bridge",
        "--request-id",
        request_id,
        "--confirm",
    ]


def test_bridge_recovery_and_legacy_upgrade_require_confirmation_before_mutation(
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    monkeypatch.setattr(
        cli,
        "recover_broker",
        lambda *_args, **_kwargs: (_ for _ in ()).throw(
            AssertionError("recovery must not run before confirmation")
        ),
    )
    monkeypatch.setattr(
        cli,
        "replace_legacy_broker",
        lambda *_args, **_kwargs: (_ for _ in ()).throw(
            AssertionError("upgrade must not run before confirmation")
        ),
    )

    assert main(["recover-bridge", "--request-id", "a" * 32]) == 5
    assert json.loads(capsys.readouterr().err)["error"]["code"] == "confirmation_required"
    assert main(["upgrade-bridge"]) == 5
    assert json.loads(capsys.readouterr().err)["error"]["code"] == "confirmation_required"


def test_confirmed_bridge_recovery_and_upgrade_route_to_client_helpers(
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    calls: list[tuple[str, str, bool]] = []
    request_id = "b" * 32
    monkeypatch.setattr(
        cli,
        "recover_broker",
        lambda url, expected_request_id, *, confirmed: (
            calls.append(("recover", expected_request_id, confirmed)) or {"recovered": True}
        ),
    )
    monkeypatch.setattr(
        cli,
        "replace_legacy_broker",
        lambda url, *, confirmed: calls.append(("upgrade", url, confirmed)) or {"running": True},
    )

    assert main(["recover-bridge", "--request-id", request_id, "--confirm"]) == 0
    assert main(["upgrade-bridge", "--confirm"]) == 0
    capsys.readouterr()
    assert calls == [
        ("recover", request_id, True),
        ("upgrade", "ws://127.0.0.1:9345", True),
    ]


def test_onboard_returns_direct_guided_setup_without_capability_check_or_confirmation(
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    monkeypatch.setattr(
        cli,
        "ensure_broker",
        lambda _url: {
            "running": True,
            "broker_version": cli.VERSION,
            "extension_connected": False,
            "extension_version": None,
            "protocol": cli.PROTOCOL_VERSION,
        },
    )

    assert main(["onboard"]) == 0
    data = json.loads(capsys.readouterr().out)["data"]
    onboarding = data["onboarding"]
    assert data["ready"] is False
    assert Path(data["skill_path"]).name == "hongshuskill"
    launcher_path = Path(data["launcher_path"])
    expected_launcher = "run-hongshu.ps1" if os.name == "nt" else "run-hongshu"
    assert launcher_path.name == expected_launcher
    assert launcher_path.parent.name == "scripts"
    assert onboarding["state"] == "extension_install_required"
    assert onboarding["setup_mode"] == "direct_guided"
    assert onboarding["ui_control_check_required"] is False
    assert onboarding["confirmation_required"] is False
    assert onboarding["confirmation_prompt"] is None
    assert onboarding["next_action"] == "prepare_extension_install"
    assert onboarding["extensions_url"] == "chrome://extensions"
    onboarding_extension = Path(onboarding["extension_path"])
    assert onboarding_extension.name == "extension"
    assert onboarding_extension.parent.name == "hongshuskill"
    assert onboarding["extension_name"] == "Hongshu Local Companion"
    assert onboarding["expected_version"] == cli.VERSION
    assert onboarding["manual_user_steps_expected"] is True
    assert onboarding["user_message_available_after_prepare"] is True
    assert onboarding["prepare_argv"][-1] == "prepare-extension-install"
    assert onboarding["guided_prepare_argv"] == onboarding["prepare_argv"]
    assert "ui_control" not in onboarding
    assert onboarding["verification_command"].endswith("onboard --wait-seconds 15")
    assert onboarding["verification_argv"][-3:] == ["onboard", "--wait-seconds", "15"]
    assert set(onboarding["required_permissions"]) == {
        "alarms",
        "tabs",
        "scripting",
        "debugger",
        "cookies",
        "webRequest",
        "storage",
    }


def test_prepare_extension_install_opens_chrome_and_reveals_bundled_folder_on_macos(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    calls: list[tuple[list[str], str]] = []
    opener = tmp_path / "open"
    opener.touch()
    monkeypatch.setattr(cli.platform, "system", lambda: "Darwin")
    monkeypatch.setattr(cli, "MACOS_OPEN_PATH", opener)
    monkeypatch.setattr(
        cli,
        "_run_open_command",
        lambda command, label: calls.append((command, label)),
    )

    assert main(["prepare-extension-install"]) == 0
    data = json.loads(capsys.readouterr().out)["data"]
    assert data["prepared"] is True
    assert data["automatic_install_completed"] is False
    extension_path = Path(data["extension_path"])
    assert extension_path.name == "extension"
    assert extension_path.parent.name == "hongshuskill"
    assert data["extension_name"] == "Hongshu Local Companion"
    assert data["expected_version"] == cli.VERSION
    assert "**打开 Chrome 扩展管理页**" in data["user_message"]
    assert "**在 Finder 中定位了扩展文件夹**" in data["user_message"]
    assert data["extension_path"] in data["user_message"]
    assert f"Hongshu Local Companion”** v{cli.VERSION}" in data["user_message"]
    assert "开发者模式" in data["user_message"]
    assert "加载已解压的扩展程序" in data["user_message"]
    assert "可能指向另一个安装路径" in data["user_message"]
    assert "由你本人停用或移除旧卡片" in data["user_message"]
    assert calls[0][0] == [
        str(opener),
        "-a",
        "Google Chrome",
        "chrome://extensions",
    ]
    assert calls[1][0][:2] == [str(opener), "-R"]
    revealed_path = Path(calls[1][0][2])
    assert revealed_path.name == "extension"
    assert revealed_path.parent.name == "hongshuskill"


def test_linux_install_surfaces_use_bounded_silent_commands(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    calls: list[tuple[list[str], str]] = []
    monkeypatch.setattr(cli.platform, "system", lambda: "Linux")
    monkeypatch.setattr(
        cli.shutil,
        "which",
        lambda name: f"/usr/bin/{name}" if name in {"google-chrome", "xdg-open"} else None,
    )
    monkeypatch.setattr(
        cli,
        "_run_open_command",
        lambda command, label: calls.append((command, label)),
    )

    actions = cli._open_install_surfaces(cli.SCRIPT_DIR.parent / "extension")
    assert actions == ["opened_chrome_extensions", "opened_extension_folder"]
    assert calls[0][0] == ["/usr/bin/google-chrome", "chrome://extensions"]
    assert calls[1][0] == [
        "/usr/bin/xdg-open",
        str(cli.SCRIPT_DIR.parent / "extension"),
    ]


def test_install_user_message_uses_the_windows_file_manager_and_runtime_path() -> None:
    extension_dir = Path(r"C:\Users\Alice\.workbuddy\skills\hongshuskill\extension")

    message = cli._install_user_message(extension_dir, "Windows")

    assert "**在 文件资源管理器 中定位了扩展文件夹**" in message
    assert str(extension_dir) in message
    assert f"v{cli.VERSION}" in message


def test_windows_onboard_returns_complete_powershell_argv(
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    monkeypatch.setattr(cli.platform, "system", lambda: "Windows")
    monkeypatch.setattr(
        cli.shutil, "which", lambda name: r"C:\Tools\pwsh.exe" if name == "pwsh.exe" else None
    )
    monkeypatch.setattr(
        cli,
        "ensure_broker",
        lambda _url: {
            "running": True,
            "broker_version": cli.VERSION,
            "extension_connected": False,
            "extension_version": None,
            "protocol": cli.PROTOCOL_VERSION,
        },
    )

    assert main(["onboard"]) == 0
    data = json.loads(capsys.readouterr().out)["data"]
    onboarding = data["onboarding"]
    assert data["launcher_path"].endswith("run-hongshu.ps1")
    assert onboarding["prepare_argv"][:6] == [
        r"C:\Tools\pwsh.exe",
        "-NoProfile",
        "-NonInteractive",
        "-ExecutionPolicy",
        "Bypass",
        "-File",
    ]
    assert onboarding["prepare_argv"][-1] == "prepare-extension-install"
    assert onboarding["verification_argv"][-3:] == ["onboard", "--wait-seconds", "15"]
    assert "run-hongshu.ps1" in onboarding["verification_command"]


def test_windows_install_surfaces_use_chrome_and_explorer(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    program_files = tmp_path / "Program Files"
    chrome = program_files / "Google/Chrome/Application/chrome.exe"
    chrome.parent.mkdir(parents=True)
    chrome.touch()
    calls: list[tuple[list[str], str]] = []
    monkeypatch.setattr(cli.platform, "system", lambda: "Windows")
    monkeypatch.setenv("PROGRAMFILES", str(program_files))
    monkeypatch.delenv("PROGRAMFILES(X86)", raising=False)
    monkeypatch.delenv("LOCALAPPDATA", raising=False)
    monkeypatch.setattr(
        cli.shutil,
        "which",
        lambda name: r"C:\Windows\explorer.exe" if name == "explorer.exe" else None,
    )
    monkeypatch.setattr(
        cli,
        "_run_detached_windows_command",
        lambda command, label: calls.append((command, label)),
    )

    actions = cli._open_install_surfaces(cli.SCRIPT_DIR.parent / "extension")

    assert actions == ["opened_chrome_extensions", "revealed_extension_in_explorer"]
    assert calls[0][0] == [str(chrome), "chrome://extensions"]
    assert calls[1][0][0] == r"C:\Windows\explorer.exe"
    assert calls[1][0][1].startswith("/select,")


def test_onboard_waits_for_the_extension_to_connect(
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    statuses = iter(
        [
            {
                "running": True,
                "broker_version": cli.VERSION,
                "extension_connected": False,
                "extension_version": None,
                "protocol": cli.PROTOCOL_VERSION,
            },
            {
                "running": True,
                "broker_version": cli.VERSION,
                "extension_connected": True,
                "extension_version": cli.VERSION,
                "protocol": cli.PROTOCOL_VERSION,
            },
        ]
    )
    monkeypatch.setattr(cli, "ensure_broker", lambda _url: next(statuses))
    monkeypatch.setattr(cli.time, "sleep", lambda _seconds: None)

    assert main(["onboard", "--wait-seconds", "1"]) == 0
    data = json.loads(capsys.readouterr().out)["data"]
    assert data["ready"] is True
    assert data["onboarding"]["state"] == "ready"
    assert data["onboarding"]["confirmation_required"] is False


def test_doctor_rejects_a_connected_but_stale_extension_version(
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    monkeypatch.setattr(
        cli,
        "ensure_broker",
        lambda _url: {
            "running": True,
            "broker_version": cli.VERSION,
            "extension_connected": True,
            "extension_version": "1.0.0",
            "protocol": cli.PROTOCOL_VERSION,
        },
    )

    assert main(["doctor"]) == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["data"]["ready"] is False
    assert payload["data"]["bridge"]["extension_version"] == "1.0.0"
    assert payload["data"]["onboarding"]["state"] == "extension_reload_required"
    assert payload["data"]["onboarding"]["confirmation_required"] is False


def test_onboard_routes_a_stale_extension_to_the_same_direct_guided_setup(
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    monkeypatch.setattr(
        cli,
        "ensure_broker",
        lambda _url: {
            "running": True,
            "broker_version": cli.VERSION,
            "extension_connected": True,
            "extension_version": "1.2.9",
            "protocol": cli.PROTOCOL_VERSION,
        },
    )

    assert main(["onboard"]) == 0
    onboarding = json.loads(capsys.readouterr().out)["data"]["onboarding"]
    assert onboarding["state"] == "extension_reload_required"
    assert onboarding["confirmation_required"] is False
    assert onboarding["manual_user_steps_expected"] is True
    assert onboarding["next_action"] == "prepare_extension_install"


def test_doctor_rejects_a_stale_broker_even_with_a_current_extension(
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    monkeypatch.setattr(
        cli,
        "ensure_broker",
        lambda _url: {
            "running": True,
            "broker_version": "1.1.1",
            "extension_connected": True,
            "extension_version": cli.VERSION,
            "protocol": cli.PROTOCOL_VERSION,
        },
    )

    assert main(["doctor"]) == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["data"]["ready"] is False
    assert payload["data"]["bridge"]["broker_version"] == "1.1.1"


def test_qr_wait_verify_and_logout_commands_route_complete_auth_flows(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    calls: list[tuple[str, dict | None, float]] = []

    def fake_rpc(_args, operation: str, params: dict | None = None, timeout: float = 90.0):
        calls.append((operation, params, timeout))
        if operation == "get_qrcode":
            return {
                "logged_in": False,
                "data_url": "data:image/png;base64,iVBORw0KGgo=",
                "qr_login_url": "https://www.xiaohongshu.com/login?qr=fixture",
            }
        if operation in {"wait_login", "verify_code"}:
            return {"logged_in": True}
        return {"success": True}

    monkeypatch.setattr(cli, "_rpc", fake_rpc)
    first_qr = tmp_path / "first.png"
    login_qr = tmp_path / "login.png"
    assert main(["get-qrcode", "--output", str(first_qr)]) == 0
    assert main(["wait-login", "--timeout", "7"]) == 0
    assert main(["login", "--timeout", "8", "--output", str(login_qr)]) == 0
    assert main(["verify-code", "--code", "123456"]) == 0
    assert main(["delete-cookies", "--confirm"]) == 0
    capsys.readouterr()
    assert first_qr.read_bytes() == b"\x89PNG\r\n\x1a\n"
    assert login_qr.read_bytes() == b"\x89PNG\r\n\x1a\n"
    if os.name != "nt":
        assert stat.S_IMODE(first_qr.stat().st_mode) == 0o600
        assert stat.S_IMODE(login_qr.stat().st_mode) == 0o600
    assert calls == [
        ("get_qrcode", None, 45),
        ("wait_login", {"timeout_seconds": 7.0}, 17.0),
        ("get_qrcode", None, 45),
        ("wait_login", {"timeout_seconds": 8.0}, 18.0),
        ("verify_code", {"code": "123456"}, 45),
        ("delete_cookies", {"confirmed": True}, 45),
    ]


def test_default_qr_files_are_private_and_unique(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(cli.tempfile, "tempdir", str(tmp_path))
    payload = {
        "data_url": "data:image/png;base64,iVBORw0KGgo=",
        "qr_login_url": "https://www.xiaohongshu.com/login?token=secret",
        "logged_in": False,
    }

    first_result = cli._save_qrcode(payload)
    second_result = cli._save_qrcode(payload)
    first = Path(first_result["qrcode_path"])
    second = Path(second_result["qrcode_path"])

    assert first != second
    assert first.parent == tmp_path
    assert second.parent == tmp_path
    assert first.read_bytes() == b"\x89PNG\r\n\x1a\n"
    if os.name != "nt":
        assert stat.S_IMODE(first.stat().st_mode) == 0o600
    assert "data_url" not in first_result
    assert "qrcode_image_url" not in first_result
    assert "qr_login_url" not in first_result


def test_explicit_qr_output_never_overwrites_an_existing_file(tmp_path: Path) -> None:
    output = tmp_path / "existing.png"
    output.write_text("keep me", encoding="utf-8")

    with pytest.raises(cli.InvalidInput, match="已存在"):
        cli._save_qrcode(
            {"data_url": "data:image/png;base64,iVBORw0KGgo=", "logged_in": False},
            str(output),
        )

    assert output.read_text(encoding="utf-8") == "keep me"


@pytest.mark.parametrize(
    "data_url",
    [
        "data:text/plain;base64,iVBORw0KGgo=",
        "data:image/png;base64,not-valid-base64!",
        "data:image/png;base64,cG5n",
    ],
)
def test_qr_output_rejects_non_png_or_malformed_data(data_url: str) -> None:
    with pytest.raises(cli.InvalidInput):
        cli._save_qrcode({"data_url": data_url})


def test_read_and_diagnostic_commands_route_to_fixed_operations(
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    calls: list[tuple[str, dict | None, float]] = []

    def fake_rpc(_args, operation: str, params: dict | None = None, timeout: float = 90.0):
        calls.append((operation, params, timeout))
        if operation == "check_login":
            return {"logged_in": True}
        return {"success": True}

    monkeypatch.setattr(cli, "_rpc", fake_rpc)
    assert main(["check-login"]) == 0
    assert main(["list-feeds", "--limit", "6"]) == 0
    assert (
        main(
            [
                "user-profile",
                "--user-id",
                "user-12345678",
                "--xsec-token",
                "profile-token-123",
                "--xsec-source",
                "pc_search",
            ]
        )
        == 0
    )
    assert main(["diagnose-404", "--clear"]) == 0
    assert main(["check-risk", "--probe-url", "https://example.com/a"]) == 0
    assert main(["get-netlog", "--limit", "5"]) == 0
    capsys.readouterr()
    assert calls == [
        ("check_login", None, 45),
        ("list_feeds", {"limit": 6}, 60),
        (
            "user_profile",
            {
                "user_id": "user-12345678",
                "xsec_token": "profile-token-123",
                "xsec_source": "pc_search",
            },
            75,
        ),
        ("diagnostics", {"clear": True}, 30),
        (
            "check_risk",
            {
                "probe_urls": ["https://example.com/a"],
                "active_probes": False,
                "confirmed": False,
            },
            60,
        ),
        ("get_netlog", {"limit": 5}, 30),
    ]


def test_active_risk_probes_require_confirmation_before_rpc(
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    def unexpected_rpc(*_args, **_kwargs):
        raise AssertionError("confirmation gate must run before RPC")

    monkeypatch.setattr(cli, "_rpc", unexpected_rpc)
    assert main(["check-risk", "--active-probes"]) == 5
    payload = json.loads(capsys.readouterr().err)
    assert payload["error"]["code"] == "confirmation_required"
    assert "真实 API" in payload["error"]["message"]


def test_active_risk_probes_route_only_validated_xhs_api_urls(
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    calls: list[tuple[str, dict | None, float]] = []

    def fake_rpc(_args, operation: str, params: dict | None = None, timeout: float = 90.0):
        calls.append((operation, params, timeout))
        return {"risk_level": "safe"}

    monkeypatch.setattr(cli, "_rpc", fake_rpc)
    probe = "https://edith.xiaohongshu.com/api/sns/web/v1/test?fixture=1"
    assert (
        main(
            [
                "check-risk",
                "--active-probes",
                "--probe-url",
                probe,
                "--confirm",
            ]
        )
        == 0
    )
    capsys.readouterr()
    assert calls == [
        (
            "check_risk",
            {"probe_urls": [probe], "active_probes": True, "confirmed": True},
            75,
        )
    ]


def test_original_command_option_surface_remains_compatible() -> None:
    expected = {
        "check-login": set(),
        "login": set(),
        "get-qrcode": set(),
        "wait-login": {"timeout"},
        "phone-login": {"phone", "code"},
        "send-code": {"phone"},
        "verify-code": {"code"},
        "delete-cookies": set(),
        "list-feeds": set(),
        "search-feeds": {
            "keyword",
            "sort_by",
            "note_type",
            "publish_time",
            "search_scope",
            "location",
        },
        "get-feed-detail": {
            "feed_id",
            "xsec_token",
            "xsec_source",
            "load_all_comments",
            "click_more_replies",
            "max_replies_threshold",
            "max_comment_items",
            "scroll_speed",
            "source_keyword",
        },
        "user-profile": {"user_id", "xsec_token", "xsec_source"},
        "post-comment": {"feed_id", "xsec_token", "xsec_source", "content"},
        "reply-comment": {
            "feed_id",
            "xsec_token",
            "xsec_source",
            "content",
            "comment_id",
            "user_id",
        },
        "like-feed": {"feed_id", "xsec_token", "xsec_source", "unlike"},
        "favorite-feed": {"feed_id", "xsec_token", "xsec_source", "unfavorite"},
        "publish": {
            "title_file",
            "content_file",
            "images",
            "tags",
            "schedule_at",
            "original",
            "visibility",
        },
        "publish-video": {
            "title_file",
            "content_file",
            "video",
            "tags",
            "schedule_at",
            "visibility",
        },
        "fill-publish": {
            "title_file",
            "content_file",
            "images",
            "tags",
            "schedule_at",
            "original",
            "visibility",
        },
        "fill-publish-video": {
            "title_file",
            "content_file",
            "video",
            "tags",
            "schedule_at",
            "visibility",
        },
        "click-publish": set(),
        "save-draft": set(),
        "long-article": {"title_file", "content_file", "images"},
        "select-template": {"name"},
        "next-step": {"content_file", "schedule_at", "visibility", "original"},
        "diagnose-404": {"clear"},
        "check-risk": {"probe_urls"},
        "get-netlog": {"limit"},
        "risk-report": set(),
    }
    parser = build_parser()
    subparsers = next(action for action in parser._actions if action.dest == "command")
    for command, required_dests in expected.items():
        actual_dests = {action.dest for action in subparsers.choices[command]._actions}
        assert required_dests <= actual_dests, command


FEED_PAIR = [
    "--feed-id",
    "6a7529a1000000002402f2be",
    "--xsec-token",
    "token-token-token=",
    "--xsec-source",
    "pc_search",
]


@pytest.mark.parametrize(
    "argv",
    [
        pytest.param(["send-code", "--phone", "13800138000"], id="send-sms"),
        pytest.param(
            ["phone-login", "--phone", "13800138000", "--code", "123456"],
            id="phone-login",
        ),
        pytest.param(["delete-cookies"], id="logout"),
        pytest.param(["post-comment", *FEED_PAIR, "--content", "测试"], id="comment"),
        pytest.param(
            ["reply-comment", *FEED_PAIR, "--content", "测试", "--comment-id", "comment-1"],
            id="reply",
        ),
        pytest.param(["like-feed", *FEED_PAIR], id="like"),
        pytest.param(["favorite-feed", *FEED_PAIR], id="favorite"),
        pytest.param(
            [
                "publish",
                "--title-file",
                "/missing/title.txt",
                "--content-file",
                "/missing/content.txt",
                "--images",
                "/missing/image.png",
            ],
            id="publish-image",
        ),
        pytest.param(
            [
                "fill-publish",
                "--title-file",
                "/missing/title.txt",
                "--content-file",
                "/missing/content.txt",
                "--images",
                "/missing/image.png",
            ],
            id="preview-image",
        ),
        pytest.param(
            [
                "publish-video",
                "--title-file",
                "/missing/title.txt",
                "--content-file",
                "/missing/content.txt",
                "--video",
                "/missing/video.mp4",
            ],
            id="publish-video",
        ),
        pytest.param(
            [
                "fill-publish-video",
                "--title-file",
                "/missing/title.txt",
                "--content-file",
                "/missing/content.txt",
                "--video",
                "/missing/video.mp4",
            ],
            id="preview-video",
        ),
        pytest.param(["click-publish"], id="submit-preview"),
        pytest.param(["save-draft"], id="save-draft"),
        pytest.param(
            [
                "long-article",
                "--title-file",
                "/missing/title.txt",
                "--content-file",
                "/missing/content.txt",
            ],
            id="long-article",
        ),
        pytest.param(["select-template", "--name", "理性现代"], id="long-template"),
        pytest.param(
            ["next-step", "--content-file", "/missing/content.txt"],
            id="long-description",
        ),
    ],
)
def test_account_writes_cannot_run_without_confirmation(
    argv: list[str], monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]
) -> None:
    def unexpected_rpc(*_args, **_kwargs):
        raise AssertionError("confirmation gate must run before RPC")

    monkeypatch.setattr(cli, "_rpc", unexpected_rpc)
    status = main(argv)
    captured = capsys.readouterr()
    assert status == 5
    payload = json.loads(captured.err)
    assert payload["error"]["code"] == "confirmation_required"
    assert payload["error"]["details"]["required_flag"] == "--confirm"


def test_auth_and_search_commands_map_to_fixed_browser_operations(
    monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]
) -> None:
    calls: list[tuple[str, dict | None, float]] = []

    def fake_rpc(_args, operation: str, params: dict | None = None, timeout: float = 90.0):
        calls.append((operation, params, timeout))
        return {"logged_in": True} if operation == "send_code" else {"feeds": []}

    monkeypatch.setattr(cli, "_rpc", fake_rpc)
    assert main(["send-code", "--phone", "138 0013 8000", "--confirm"]) == 0
    assert (
        main(
            [
                "search-feeds",
                "--keyword",
                " 咖啡 ",
                "--sort-by",
                "最新",
                "--note-type",
                "图文",
                "--publish-time",
                "一周内",
                "--search-scope",
                "未看过",
                "--location",
                "同城",
                "--limit",
                "5",
            ]
        )
        == 0
    )
    capsys.readouterr()
    assert calls == [
        ("send_code", {"phone": "13800138000", "confirmed": True}, 45),
        (
            "search_feeds",
            {
                "keyword": "咖啡",
                "limit": 5,
                "filters": {
                    "sort_by": "最新",
                    "note_type": "图文",
                    "publish_time": "一周内",
                    "search_scope": "未看过",
                    "location": "同城",
                },
            },
            75,
        ),
    ]


def test_detail_options_and_interaction_targets_are_preserved(
    monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]
) -> None:
    calls: list[tuple[str, dict | None, float]] = []

    def fake_rpc(_args, operation: str, params: dict | None = None, timeout: float = 90.0):
        calls.append((operation, params, timeout))
        return {"success": True}

    monkeypatch.setattr(cli, "_rpc", fake_rpc)
    assert (
        main(
            [
                "get-feed-detail",
                *FEED_PAIR,
                "--load-all-comments",
                "--click-more-replies",
                "--max-replies-threshold",
                "4",
                "--max-comment-items",
                "12",
                "--scroll-speed",
                "fast",
                "--keyword",
                "咖啡",
            ]
        )
        == 0
    )
    assert main(["like-feed", *FEED_PAIR, "--confirm"]) == 0
    assert main(["favorite-feed", *FEED_PAIR, "--unfavorite", "--confirm"]) == 0
    capsys.readouterr()
    assert calls[0] == (
        "get_feed_detail",
        {
            "feed_id": "6a7529a1000000002402f2be",
            "xsec_token": "token-token-token=",
            "xsec_source": "pc_search",
            "load_all_comments": True,
            "click_more_replies": True,
            "max_replies_threshold": 4,
            "max_comment_items": 12,
            "scroll_speed": "fast",
            "keyword": "咖啡",
        },
        240,
    )
    assert calls[1][0:2] == (
        "set_like",
        {
            "feed_id": "6a7529a1000000002402f2be",
            "xsec_token": "token-token-token=",
            "xsec_source": "pc_search",
            "target": True,
            "confirmed": True,
        },
    )
    assert calls[2][0:2] == (
        "set_favorite",
        {
            "feed_id": "6a7529a1000000002402f2be",
            "xsec_token": "token-token-token=",
            "xsec_source": "pc_search",
            "target": False,
            "confirmed": True,
        },
    )


def test_read_only_action_inspection_maps_optional_reply_target(
    monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]
) -> None:
    calls: list[tuple[str, dict | None, float]] = []

    def fake_rpc(_args, operation: str, params: dict | None = None, timeout: float = 90.0):
        calls.append((operation, params, timeout))
        return {"comment_available": True, "reply": {"available": True}}

    monkeypatch.setattr(cli, "_rpc", fake_rpc)
    assert main(["inspect-actions", *FEED_PAIR, "--comment-id", "comment-123"]) == 0
    capsys.readouterr()
    assert calls == [
        (
            "inspect_actions",
            {
                "feed_id": "6a7529a1000000002402f2be",
                "xsec_token": "token-token-token=",
                "xsec_source": "pc_search",
                "comment_id": "comment-123",
                "user_id": None,
            },
            90,
        )
    ]


def test_action_inspection_rejects_two_reply_targets(
    monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]
) -> None:
    def unexpected_rpc(*_args, **_kwargs):
        raise AssertionError("invalid input must not reach RPC")

    monkeypatch.setattr(cli, "_rpc", unexpected_rpc)
    status = main(
        [
            "inspect-actions",
            *FEED_PAIR,
            "--comment-id",
            "comment-123",
            "--user-id",
            "60c0ace0000000002002c6ca",
        ]
    )
    payload = json.loads(capsys.readouterr().err)
    assert status == 2
    assert payload["error"]["code"] == "invalid_input"


@pytest.mark.parametrize(
    "argv",
    [
        ["wait-login", "--timeout", "nan"],
        ["list-feeds", "--limit", "0"],
        ["search-feeds", "--keyword", "咖啡", "--limit", "101"],
        ["get-feed-detail", *FEED_PAIR, "--max-comment-items", "-1"],
        ["get-netlog", "--limit", "0"],
    ],
)
def test_invalid_numeric_ranges_do_not_reach_browser(
    argv: list[str], monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]
) -> None:
    def unexpected_rpc(*_args, **_kwargs):
        raise AssertionError("invalid numeric input must not reach RPC")

    monkeypatch.setattr(cli, "_rpc", unexpected_rpc)
    status = main(argv)
    payload = json.loads(capsys.readouterr().err)
    assert status == 2
    assert payload["error"]["code"] == "invalid_input"


def test_risk_report_combines_rolling_and_preserved_events(
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    preserved = {"status": 461, "url": "https://edith.xiaohongshu.com/api/risk"}

    def fake_rpc(_args, operation: str, params: dict | None = None, timeout: float = 90.0):
        assert operation == "get_netlog"
        assert params == {"limit": 500}
        assert timeout == 30
        return {
            "entries": [{"status": 200, "url": "https://www.xiaohongshu.com/api/ok"}],
            "risk_events": [preserved],
        }

    monkeypatch.setattr(cli, "_rpc", fake_rpc)
    assert main(["risk-report"]) == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["data"]["risk_level"] == "high"
    assert payload["data"]["preserved_risk_event_count"] == 1
    assert payload["data"]["status_counts"]["461"] == 1


def test_noninteractive_phone_login_requires_code_before_sending_sms(
    monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]
) -> None:
    monkeypatch.setattr(sys.stdin, "isatty", lambda: False)

    def unexpected_rpc(*_args, **_kwargs):
        raise AssertionError("missing code must be rejected before sending SMS")

    monkeypatch.setattr(cli, "_rpc", unexpected_rpc)
    status = main(["phone-login", "--phone", "13800138000", "--confirm"])
    payload = json.loads(capsys.readouterr().err)
    assert status == 2
    assert payload["error"]["code"] == "invalid_input"
    assert "send-code" in payload["error"]["message"]


def test_phone_login_with_existing_code_does_not_resend_sms(
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    calls: list[tuple[str, dict | None, float]] = []

    def fake_rpc(_args, operation: str, params: dict | None = None, timeout: float = 90.0):
        calls.append((operation, params, timeout))
        return {"logged_in": True}

    monkeypatch.setattr(cli, "_rpc", fake_rpc)
    assert (
        main(
            [
                "phone-login",
                "--phone",
                "13800138000",
                "--code",
                "123456",
                "--confirm",
            ]
        )
        == 0
    )
    payload = json.loads(capsys.readouterr().out)
    assert calls == [("verify_code", {"code": "123456"}, 45)]
    assert payload["data"]["send"]["skipped"] is True
    assert payload["data"]["send"]["phone_masked"] == "138****8000"


def test_image_and_video_preview_routes_resolve_local_media(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    title = tmp_path / "title.txt"
    content = tmp_path / "content.txt"
    image = tmp_path / "cover.png"
    video = tmp_path / "clip.mp4"
    title.write_text("周末咖啡", encoding="utf-8")
    content.write_text("一杯手冲的记录。", encoding="utf-8")
    image.write_bytes(b"png-placeholder")
    video.write_bytes(b"mp4-placeholder")
    schedule = (datetime.now() + timedelta(days=1)).isoformat(timespec="minutes")
    calls: list[tuple[str, dict | None, float]] = []

    def fake_rpc(_args, operation: str, params: dict | None = None, timeout: float = 90.0):
        calls.append((operation, params, timeout))
        return {"preview_only": True}

    monkeypatch.setattr(cli, "_rpc", fake_rpc)
    assert (
        main(
            [
                "fill-publish",
                "--title-file",
                str(title),
                "--content-file",
                str(content),
                "--images",
                str(image),
                "--tags",
                "#咖啡",
                "咖啡",
                "周末",
                "--schedule-at",
                schedule,
                "--visibility",
                "仅自己可见",
                "--original",
                "--confirm",
            ]
        )
        == 0
    )
    assert (
        main(
            [
                "fill-publish-video",
                "--title-file",
                str(title),
                "--content-file",
                str(content),
                "--video",
                str(video),
                "--confirm",
            ]
        )
        == 0
    )
    capsys.readouterr()
    assert calls[0][0] == "fill_image"
    assert calls[0][1] == {
        "title": "周末咖啡",
        "content": "一杯手冲的记录。",
        "tags": ["咖啡", "周末"],
        "schedule_at": schedule,
        "visibility": "仅自己可见",
        "original": True,
        "confirmed": True,
        "images": [str(image)],
    }
    assert calls[0][2] == 240
    assert calls[1][0] == "fill_video"
    assert calls[1][1]["video"] == str(video)
    assert calls[1][1]["original"] is False
    assert calls[1][1]["confirmed"] is True
    assert calls[1][2] == 720


def test_compatibility_publish_commands_create_preview_without_direct_submit(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    title = tmp_path / "title.txt"
    content = tmp_path / "content.txt"
    image = tmp_path / "cover.png"
    video = tmp_path / "clip.mp4"
    title.write_text("预览标题", encoding="utf-8")
    content.write_text("预览正文", encoding="utf-8")
    image.write_bytes(b"image")
    video.write_bytes(b"video")
    calls: list[str] = []

    def fake_rpc(_args, operation: str, _params=None, timeout: float = 90.0):
        calls.append(operation)
        return {"preview_id": "p" * 32, "preview_only": True, "timeout": timeout}

    monkeypatch.setattr(cli, "_rpc", fake_rpc)
    assert (
        main(
            [
                "publish",
                "--title-file",
                str(title),
                "--content-file",
                str(content),
                "--images",
                str(image),
                "--confirm",
            ]
        )
        == 0
    )
    image_result = json.loads(capsys.readouterr().out)["data"]
    assert (
        main(
            [
                "publish-video",
                "--title-file",
                str(title),
                "--content-file",
                str(content),
                "--video",
                str(video),
                "--confirm",
            ]
        )
        == 0
    )
    video_result = json.loads(capsys.readouterr().out)["data"]
    assert calls == ["fill_image", "fill_video"]
    assert image_result["requires_separate_submit"] is True
    assert video_result["requires_separate_submit"] is True


def test_preview_stage_commands_bind_the_returned_preview_id(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    description = tmp_path / "description.txt"
    description.write_text("长文描述", encoding="utf-8")
    preview_id = "preview_1234567890abcdef"
    calls: list[tuple[str, dict | None]] = []

    def fake_rpc(_args, operation: str, params: dict | None = None, timeout: float = 90.0):
        calls.append((operation, params))
        return {"success": True, "timeout": timeout}

    monkeypatch.setattr(cli, "_rpc", fake_rpc)
    assert main(["click-publish", "--preview-id", preview_id, "--confirm"]) == 0
    assert main(["save-draft", "--preview-id", preview_id, "--confirm"]) == 0
    assert (
        main(
            [
                "select-template",
                "--name",
                "理性现代",
                "--preview-id",
                preview_id,
                "--confirm",
            ]
        )
        == 0
    )
    assert (
        main(
            [
                "next-step",
                "--content-file",
                str(description),
                "--preview-id",
                preview_id,
                "--visibility",
                "仅自己可见",
                "--original",
                "--confirm",
            ]
        )
        == 0
    )
    capsys.readouterr()
    assert calls == [
        ("click_publish", {"confirmed": True, "preview_id": preview_id}),
        ("save_draft", {"confirmed": True, "preview_id": preview_id}),
        (
            "select_template",
            {"name": "理性现代", "preview_id": preview_id, "confirmed": True},
        ),
        (
            "long_article_next",
            {
                "content": "长文描述",
                "preview_id": preview_id,
                "schedule_at": None,
                "visibility": "仅自己可见",
                "original": True,
                "confirmed": True,
            },
        ),
    ]


def test_long_description_is_rejected_instead_of_silently_truncated(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    description = tmp_path / "description.txt"
    description.write_text("描" * 1001, encoding="utf-8")
    monkeypatch.setattr(
        cli,
        "_rpc",
        lambda *_args, **_kwargs: pytest.fail("超长描述不得进入浏览器"),
    )
    status = main(
        [
            "next-step",
            "--content-file",
            str(description),
            "--preview-id",
            "preview_1234567890abcdef",
            "--confirm",
        ]
    )
    payload = json.loads(capsys.readouterr().err)
    assert status == 2
    assert payload["error"]["details"] == {"length": 1001, "limit": 1000}


def test_publish_body_limit_stays_below_the_broker_params_envelope(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    title = tmp_path / "title.txt"
    content = tmp_path / "content.txt"
    image = tmp_path / "cover.png"
    title.write_text("标题", encoding="utf-8")
    # A control character expands to six bytes in JSON. This is the worst case
    # relevant to the UTF-8 file limit and must still fit the 1 MiB broker cap.
    content.write_bytes(b"\x01" * cli.MAX_PUBLISH_TEXT_BYTES)
    image.write_bytes(b"image")
    observed: dict = {}

    def fake_rpc(_args, _operation: str, params: dict | None = None, **_kwargs):
        observed.update(params or {})
        return {"preview_id": "p" * 32}

    monkeypatch.setattr(cli, "_rpc", fake_rpc)
    assert (
        main(
            [
                "fill-publish",
                "--title-file",
                str(title),
                "--content-file",
                str(content),
                "--images",
                str(image),
                "--confirm",
            ]
        )
        == 0
    )
    capsys.readouterr()
    encoded = json.dumps(
        observed,
        ensure_ascii=False,
        allow_nan=False,
        separators=(",", ":"),
    ).encode("utf-8")
    assert len(encoded) < 1024 * 1024

    content.write_bytes(b"x" * (cli.MAX_PUBLISH_TEXT_BYTES + 1))
    assert (
        main(
            [
                "fill-publish",
                "--title-file",
                str(title),
                "--content-file",
                str(content),
                "--images",
                str(image),
                "--confirm",
            ]
        )
        == 2
    )
    payload = json.loads(capsys.readouterr().err)
    assert payload["error"]["code"] == "invalid_input"
    assert payload["error"]["details"]["max_bytes"] == cli.MAX_PUBLISH_TEXT_BYTES


def test_hashtag_only_publish_body_is_rejected_after_topic_extraction(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    title = tmp_path / "title.txt"
    content = tmp_path / "content.txt"
    image = tmp_path / "cover.png"
    title.write_text("标题", encoding="utf-8")
    content.write_text("#咖啡 #周末", encoding="utf-8")
    image.write_bytes(b"png-placeholder")

    def unexpected_rpc(*_args, **_kwargs):
        raise AssertionError("empty body must not reach RPC")

    monkeypatch.setattr(cli, "_rpc", unexpected_rpc)
    status = main(
        [
            "fill-publish",
            "--title-file",
            str(title),
            "--content-file",
            str(content),
            "--images",
            str(image),
            "--confirm",
        ]
    )
    payload = json.loads(capsys.readouterr().err)
    assert status == 2
    assert payload["error"]["code"] == "invalid_input"
    assert "正文不能为空" in payload["error"]["message"]
