import assert from "node:assert/strict";
import { webcrypto } from "node:crypto";
import { readFile } from "node:fs/promises";
import test from "node:test";
import vm from "node:vm";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const HERE = dirname(fileURLToPath(import.meta.url));
const ROOT = resolve(HERE, "../..");

function eventHook() {
  return { addListener() {}, removeListener() {} };
}

function workerContext() {
  class FakeWebSocket {
    static CONNECTING = 0;
    static OPEN = 1;

    constructor() {
      this.readyState = FakeWebSocket.CONNECTING;
    }

    addEventListener() {}
    close() {}
    send() {}
  }

  const localStorage = {};
  const sessionStorage = {};
  const tabs = new Map();
  let nextTabId = 1;
  let reloadCount = 0;
  const chrome = {
    __test: {
      tabCount() { return tabs.size; },
      reloadCount() { return reloadCount; },
      sessionStorage,
      async pageHandler(_tabId, message) {
        if (message.operation === "ping") return { ready: true };
        return {};
      },
      async scriptHandler() { return null; },
      async debuggerHandler(_target, method, params) {
        if (method === "DOM.getDocument") return { root: { nodeId: 1 } };
        if (method === "DOM.querySelector") return { nodeId: 2 };
        if (method === "DOM.getBoxModel") {
          return { model: { border: [0, 0, 10, 0, 10, 10, 0, 10] } };
        }
        if (method === "DOM.resolveNode") return { object: { objectId: "object-1" } };
        if (
          method === "Runtime.callFunctionOn"
          && /selector_matches/.test(params?.functionDeclaration || "")
        ) {
          return {
            result: {
              value: {
                connected: true,
                selector_matches: true,
                visible: true,
                disabled: false,
                trapped: false,
              },
            },
          };
        }
        return {};
      },
    },
    runtime: {
      id: "fixture-extension-id",
      getURL(path) { return `chrome-extension://fixture-extension-id/${path}`; },
      onStartup: eventHook(),
      onInstalled: eventHook(),
      onMessage: eventHook(),
    },
    alarms: { create() {}, onAlarm: eventHook() },
    storage: {
      local: {
        async get(key) {
          if (Array.isArray(key)) {
            return Object.fromEntries(key.map((item) => [item, localStorage[item]]));
          }
          return { [key]: localStorage[key] };
        },
        async set(values) {
          Object.assign(localStorage, values);
        },
      },
      session: {
        async get(key) { return { [key]: sessionStorage[key] }; },
        async set(values) { Object.assign(sessionStorage, values); },
        async remove(key) { delete sessionStorage[key]; },
      },
    },
    webRequest: {
      onCompleted: eventHook(),
      onErrorOccurred: eventHook(),
    },
    scripting: {
      async executeScript(options) {
        return [{ result: await chrome.__test.scriptHandler(options) }];
      },
    },
    tabs: {
      onUpdated: eventHook(),
      async query() { return Array.from(tabs.values(), (tab) => ({ ...tab })); },
      async create({ url, active }) {
        const tab = { id: nextTabId++, url, active, status: "complete" };
        tabs.set(tab.id, tab);
        return { ...tab };
      },
      async get(tabId) {
        const tab = tabs.get(tabId);
        if (!tab) throw new Error("tab missing");
        return { ...tab };
      },
      async update(tabId, values) {
        const tab = tabs.get(tabId);
        if (!tab) throw new Error("tab missing");
        Object.assign(tab, values, { status: "complete" });
        return { ...tab };
      },
      async reload(tabId) {
        const tab = tabs.get(tabId);
        if (!tab) throw new Error("tab missing");
        reloadCount += 1;
        tab.status = "complete";
      },
      async sendMessage(tabId, message) {
        try {
          const result = await chrome.__test.pageHandler(tabId, message);
          return { ok: true, result };
        } catch (error) {
          return {
            ok: false,
            error: { code: error?.code || "fixture_error", message: error?.message || String(error) },
          };
        }
      },
    },
    debugger: {
      onEvent: eventHook(),
      async attach() {},
      async detach() {},
      async sendCommand(target, method, params) {
        return chrome.__test.debuggerHandler(target, method, params);
      },
    },
    cookies: {
      async getAll() {
        return [{
          domain: ".xiaohongshu.com",
          name: "web_session",
          value: "fixture-account-session",
          path: "/",
          secure: true,
          storeId: "0",
        }];
      },
      async remove() { return {}; },
    },
  };
  return vm.createContext({
    chrome,
    crypto: webcrypto,
    fetch: async () => ({
      ok: true,
      async json() {
        return { token: "00".repeat(32) };
      },
    }),
    TextEncoder,
    WebSocket: FakeWebSocket,
    URL,
    URLSearchParams,
    clearTimeout,
    console,
    setTimeout,
  });
}

async function loadWorker() {
  const source = await readFile(resolve(ROOT, "extension/worker.js"), "utf8");
  const context = workerContext();
  const exports = `
    globalThis.__workerTest = {
      OPERATIONS,
      authenticationPayload,
      canonicalJson,
      currentAccountFingerprint,
      enqueueConnectionMessage,
      executeSerializedRequest,
      mergeCommentCollections,
      mergeDomNoteContent,
      noteUrl,
      normalizeDetail,
      normalizeFeeds,
      privacySafeErrorDetails,
      privacySafeText,
      privacySafeUrl,
      debuggerClick,
      persistNetworkEntries,
      recentHighRiskSignals,
      requireConfirmed,
      requireRiskClear,
      sanitizedNetworkEntry,
      stateSnapshot,
      signedEnvelope,
      sendRpcResponseIfCurrent,
      sendBridgeKeepaliveIfCurrent,
      validateClickTarget,
      verifySignedEnvelope,
      waitForStateRefresh,
      async setNetworkEntries(entries) {
        await loadStorage();
        const preserved = entries.filter((item) => [401, 403, 404, 429, 461, 999].includes(item.status));
        await chrome.storage.local.set({ network_entries: entries, risk_events: preserved });
        networkEntries = entries;
        riskEvents = preserved;
        storageLoaded = true;
      },
      setRollingEntries(entries) {
        networkEntries = entries;
      },
      addRiskEvent(entry) {
        riskEvents.push(entry);
        riskEvents = pruneRiskEvents(riskEvents);
      },
    };
  `;
  vm.runInContext(`${source}\n${exports}`, context, { filename: "worker.js" });
  return context;
}

function plain(value) {
  return JSON.parse(JSON.stringify(value));
}

function fixturePublishFormSnapshot(overrides = {}) {
  return {
    title_hash: "1".repeat(64),
    content_hash: "2".repeat(64),
    tags_hash: "3".repeat(64),
    title_length: 2,
    content_length: 2,
    tag_count: 0,
    ...overrides,
  };
}

function fixturePublishSettings(message, overrides = {}) {
  const visibility = message?.params?.visibility || "公开可见";
  const original = Boolean(message?.params?.original);
  const scheduleAt = message?.params?.schedule_at || null;
  const type = message?.params?.media_type || "images";
  const count = Number.isInteger(message?.params?.media_expected)
    ? message.params.media_expected
    : (type === "video" ? 1 : type === "long_article" ? 0 : 1);
  const settings = { visibility, original, schedule_at: scheduleAt };
  return {
    ...settings,
    snapshot: {
      route: "https://creator.xiaohongshu.com/publish/publish",
      form: fixturePublishFormSnapshot(),
      media: { type, count, ready: true, identity: "4".repeat(64) },
      settings,
      ...overrides,
    },
  };
}

function fixtureLongDraftSnapshot(template = "") {
  return {
    title_hash: "1".repeat(64),
    content_hash: "2".repeat(64),
    title_length: 4,
    content_length: 4,
    media: { count: 0, identity: "3".repeat(64) },
    template,
  };
}

function fixtureSelector(key, attribute = "click", nonce = "0".repeat(24)) {
  return `[data-hongshuskill-${attribute}="${key}-${nonce}"]`;
}

function fixtureTarget(key) {
  return { selector: fixtureSelector(key) };
}

function installPublishFixture(context, {
  settingsForCall = null,
  observeSubmission = { success: true, status: "submitted" },
} = {}) {
  const state = { settingsCalls: 0, targetRequests: 0 };
  context.chrome.__test.pageHandler = async (_tabId, message) => {
    if (message.operation === "ping") return { ready: true };
    if (message.operation === "risk_signals") return {};
    if (message.operation === "prepare_publish_tab") {
      return { ready: true, input_selector: "input[data-hongshuskill-upload='fixture']" };
    }
    if (message.operation === "wait_upload") return { uploaded: true };
    if (message.operation === "fill_publish_form") return { status: "filled" };
    if (message.operation === "publish_setting_rect") return { skip: true };
    if (message.operation === "wait_publish_settings") {
      state.settingsCalls += 1;
      return settingsForCall
        ? settingsForCall(state.settingsCalls, message)
        : fixturePublishSettings(message);
    }
    if (message.operation === "target_rect") {
      state.targetRequests += 1;
      return fixtureTarget(message.params.target === "draft" ? "submit-draft" : "submit-publish");
    }
    if (message.operation === "observe_submission") return observeSubmission;
    return {};
  };
  return state;
}

test("worker normalizes feed and detail state", async () => {
  const context = await loadWorker();
  const { normalizeDetail, normalizeFeeds } = context.__workerTest;
  const feeds = plain(normalizeFeeds([
    [{ id: "note-1", xsecToken: "token-1", xsecSource: "pc_search", noteCard: {
      displayTitle: "标题",
      user: {
        userId: "user-1",
        nickname: "作者",
        xsecToken: "author-token",
        xsecSource: "pc_search",
      },
      interactInfo: { likedCount: "12", commentCount: 0 },
    } }],
    [{ modelType: "hot_query", id: "ignored" }],
  ], 10));
  assert.equal(feeds.length, 1);
  assert.equal(feeds[0].feed_id, "note-1");
  assert.equal(feeds[0].author.nickname, "作者");
  assert.equal(feeds[0].metrics.likes, "12");
  assert.equal(feeds[0].metrics.comments, 0);
  assert.equal(feeds[0].xsec_source, "pc_search");
  assert.equal(feeds[0].author.xsec_token, "author-token");
  assert.equal(feeds[0].author.xsec_source, "pc_search");

  const detail = plain(normalizeDetail({
    note: {
      noteId: "note-1",
      desc: "正文",
      tagList: [{ name: "咖啡" }, "#周末", {}],
      user: { userId: "user-1" },
      interactInfo: { liked: true, collected: false },
    },
    comments: { list: [{ id: "comment-1", content: "好看" }] },
  }, "note-1"));
  assert.equal(detail.note.body, "正文");
  assert.deepEqual(detail.note.tags, ["#咖啡", "#周末"]);
  assert.equal(detail.note.metrics.liked, true);
  assert.equal(detail.comments[0].comment_id, "comment-1");
});

test("note URLs preserve the reference feed-token source contract", async () => {
  const context = await loadWorker();
  const url = new URL(context.__workerTest.noteUrl("note/unsafe", "token+=fixture"));
  assert.equal(url.pathname, "/explore/note%2Funsafe");
  assert.equal(url.searchParams.get("xsec_token"), "token+=fixture");
  assert.equal(url.searchParams.get("xsec_source"), "pc_feed");
  const searchUrl = new URL(context.__workerTest.noteUrl("note-1", "token-1", "pc_search"));
  assert.equal(searchUrl.searchParams.get("xsec_source"), "pc_search");
});

test("canonical authentication JSON matches cross-language integer and binary64 vectors", async () => {
  const context = await loadWorker();
  const { authenticationPayload, canonicalJson } = context.__workerTest;
  assert.equal(canonicalJson(-0), "0");
  assert.equal(canonicalJson(0.25), "2.5000000000000000e-1");
  assert.equal(canonicalJson(0.1), "1.0000000000000001e-1");
  assert.equal(canonicalJson(1e-7), "9.9999999999999995e-8");
  assert.equal(canonicalJson(1e-6), "9.9999999999999995e-7");
  assert.equal(canonicalJson(1.5), "1.5000000000000000e+0");
  assert.equal(canonicalJson(Number.MIN_VALUE), "4.9406564584124654e-324");
  assert.throws(() => canonicalJson(Number.POSITIVE_INFINITY), /non-finite|\u975e\u6709\u9650/);
  assert.throws(() => canonicalJson(Number.MAX_SAFE_INTEGER + 1), /safe|\u5b89\u5168/);

  const envelope = {
    role: "client",
    protocol: 2,
    id: "request-1",
    op: "wait_login",
    params: { timeout: 7.5, signals: { deviceMemory: 0.25 } },
    timeout: 7.5,
  };
  const expectedCanonical = "{\"id\":\"request-1\",\"op\":\"wait_login\",\"params\":{\"signals\":{\"deviceMemory\":2.5000000000000000e-1},\"timeout\":7.5000000000000000e+0},\"protocol\":2,\"role\":\"client\",\"timeout\":7.5000000000000000e+0}";
  assert.equal(canonicalJson(envelope), expectedCanonical);
  const key = await webcrypto.subtle.importKey(
    "raw",
    Uint8Array.from({ length: 32 }, (_, index) => index),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"],
  );
  const payload = authenticationPayload(
    envelope,
    1700000000123,
    "00112233445566778899aabbccddeeff",
  );
  const mac = await webcrypto.subtle.sign("HMAC", key, new TextEncoder().encode(payload));
  assert.equal(
    Buffer.from(mac).toString("hex"),
    "2b86cd53083e2687ec77eec062993dfd1bbe6d0534bb904337f2c22aed2e1bfb",
  );
});

test("canonical authentication JSON sorts Unicode code points and rejects lone surrogates", async () => {
  const context = await loadWorker();
  const { canonicalJson } = context.__workerTest;
  assert.equal(canonicalJson({ "😀": 1, "": 2 }), "{\"\":2,\"😀\":1}");
  assert.equal(canonicalJson("line\n\u0001\u2028\u2029😀"), JSON.stringify("line\n\u0001\u2028\u2029😀"));
  assert.throws(() => canonicalJson("\ud800"), /Unicode/);
  assert.throws(() => canonicalJson({ "\udc00": true }), /Unicode/);
});

test("signed envelopes bind timestamp and nonce and consume replay nonces only after MAC success", async () => {
  const context = await loadWorker();
  const { signedEnvelope, verifySignedEnvelope } = context.__workerTest;
  const key = await webcrypto.subtle.importKey(
    "raw",
    Uint8Array.from({ length: 32 }, (_, index) => index),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign", "verify"],
  );
  const now = 1700000000123;
  const envelope = { kind: "rpc_request", protocol: 2, id: "a".repeat(32), op: "check_login", params: {} };
  const signed = await signedEnvelope(envelope, key, now);
  const state = { key, receivedNonces: new Map() };
  assert.deepEqual(plain(await verifySignedEnvelope(signed, state, now)), envelope);
  await assert.rejects(
    () => verifySignedEnvelope(signed, state, now),
    (error) => error?.code === "authentication_failed" && /nonce/.test(error.message),
  );

  const tampered = await signedEnvelope(envelope, key, now);
  tampered.auth.nonce = "f".repeat(32);
  const untouched = { key, receivedNonces: new Map() };
  await assert.rejects(
    () => verifySignedEnvelope(tampered, untouched, now),
    (error) => error?.code === "authentication_failed" && /\u7b7e\u540d/.test(error.message),
  );
  assert.equal(untouched.receivedNonces.size, 0);

  const stale = await signedEnvelope(envelope, key, now - 60001);
  await assert.rejects(
    () => verifySignedEnvelope(stale, { key, receivedNonces: new Map() }, now),
    (error) => error?.code === "authentication_failed" && /\u8fc7\u671f/.test(error.message),
  );
});

test("per-connection message queue closes the concurrent replay window", async () => {
  const context = await loadWorker();
  const { enqueueConnectionMessage, signedEnvelope, verifySignedEnvelope } = context.__workerTest;
  const key = await webcrypto.subtle.importKey(
    "raw",
    Uint8Array.from({ length: 32 }, (_, index) => index),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign", "verify"],
  );
  const now = Date.now();
  const signed = await signedEnvelope({ ok: true, kind: "paired", protocol: 2 }, key, now);
  const state = { key, receivedNonces: new Map(), messageQueue: Promise.resolve() };
  const attempts = await Promise.allSettled([
    enqueueConnectionMessage(state, () => verifySignedEnvelope(signed, state, now)),
    enqueueConnectionMessage(state, () => verifySignedEnvelope(signed, state, now)),
  ]);
  assert.deepEqual(attempts.map((item) => item.status), ["fulfilled", "rejected"]);
  assert.match(attempts[1].reason.message, /nonce/);
});

test("an old socket result is never delivered through a replacement connection", async () => {
  const context = await loadWorker();
  const key = await webcrypto.subtle.importKey(
    "raw",
    Uint8Array.from({ length: 32 }, (_, index) => index),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign", "verify"],
  );
  const oldSent = [];
  const newSent = [];
  const oldConnection = { readyState: 1, send(value) { oldSent.push(value); } };
  const newConnection = { readyState: 1, send(value) { newSent.push(value); } };
  const state = { key, paired: true };
  const response = { kind: "rpc_result", id: "a".repeat(32), ok: true, result: {} };
  assert.equal(await context.__workerTest.sendRpcResponseIfCurrent(
    oldConnection,
    state,
    response,
    newConnection,
  ), false);
  assert.deepEqual(oldSent, []);
  assert.deepEqual(newSent, []);
  assert.equal(await context.__workerTest.sendRpcResponseIfCurrent(
    newConnection,
    state,
    response,
    newConnection,
  ), true);
  assert.equal(newSent.length, 1);
  assert.equal(JSON.parse(newSent[0]).kind, "rpc_result");
});

test("bridge keepalive is signed and only sent on the current paired socket", async () => {
  const context = await loadWorker();
  const key = await webcrypto.subtle.importKey(
    "raw",
    Uint8Array.from({ length: 32 }, (_, index) => index),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign", "verify"],
  );
  const sent = [];
  const connection = { readyState: 1, send(value) { sent.push(value); } };
  const state = { key, paired: true };
  assert.equal(await context.__workerTest.sendBridgeKeepaliveIfCurrent(
    connection,
    state,
    connection,
  ), true);
  assert.equal(sent.length, 1);
  const envelope = JSON.parse(sent[0]);
  assert.equal(envelope.kind, "extension_keepalive");
  assert.equal(envelope.protocol, 2);
  assert.match(envelope.auth.mac, /^[0-9a-f]{64}$/);
  assert.equal(await context.__workerTest.sendBridgeKeepaliveIfCurrent(
    connection,
    state,
    { readyState: 1 },
  ), false);
  assert.equal(sent.length, 1);
});

test("RPC execution is globally serialized and duplicate ids reuse the cached result", async () => {
  const context = await loadWorker();
  const operations = context.__workerTest.OPERATIONS;
  let active = 0;
  let maxActive = 0;
  let calls = 0;
  operations.__fixture_serial = async ({ value }) => {
    calls += 1;
    active += 1;
    maxActive = Math.max(maxActive, active);
    await new Promise((resolvePromise) => setTimeout(resolvePromise, 5));
    active -= 1;
    return { value };
  };
  const first = { id: "1".repeat(32), op: "__fixture_serial", params: { value: "first" } };
  const second = { id: "2".repeat(32), op: "__fixture_serial", params: { value: "second" } };
  const [firstResult, secondResult] = await Promise.all([
    context.__workerTest.executeSerializedRequest(first),
    context.__workerTest.executeSerializedRequest(second),
  ]);
  assert.equal(maxActive, 1);
  assert.equal(firstResult.result.value, "first");
  assert.equal(secondResult.result.value, "second");
  const duplicate = await context.__workerTest.executeSerializedRequest(first);
  assert.deepEqual(plain(duplicate), plain(firstResult));
  assert.equal(calls, 2);
  const conflict = await context.__workerTest.executeSerializedRequest({
    ...first,
    params: { value: "changed" },
  });
  assert.equal(conflict.ok, false);
  assert.equal(conflict.error.code, "rpc_id_conflict");
});

test("RPC errors always use the broker terminal error schema", async () => {
  const context = await loadWorker();
  const operations = context.__workerTest.OPERATIONS;
  operations.__fixture_dom_exception = async () => {
    const error = new DOMException("", "DataCloneError");
    error.details = ["not-an-object"];
    throw error;
  };
  operations.__fixture_invalid_code = async () => {
    const error = new Error("x".repeat(700));
    error.code = "BAD-CODE";
    error.details = "not-an-object";
    throw error;
  };
  operations.__fixture_invalid_result = async () => ({ nested: { text: "\ud800" } });
  operations.__fixture_primitive_result = async () => true;
  const domFailure = plain(await context.__workerTest.executeSerializedRequest({
    id: "3".repeat(32),
    op: "__fixture_dom_exception",
    params: {},
  }));
  assert.equal(domFailure.ok, false);
  assert.equal(domFailure.error.code, "browser_operation_failed");
  assert.equal(typeof domFailure.error.message, "string");
  assert.ok(domFailure.error.message.length > 0 && domFailure.error.message.length <= 512);
  assert.deepEqual(domFailure.error.details, {});

  const invalidCode = plain(await context.__workerTest.executeSerializedRequest({
    id: "4".repeat(32),
    op: "__fixture_invalid_code",
    params: {},
  }));
  assert.equal(invalidCode.error.code, "browser_operation_failed");
  assert.equal(invalidCode.error.message.length, 512);
  assert.deepEqual(invalidCode.error.details, {});

  const invalidResult = plain(await context.__workerTest.executeSerializedRequest({
    id: "5".repeat(32),
    op: "__fixture_invalid_result",
    params: {},
  }));
  assert.equal(invalidResult.ok, false);
  assert.equal(invalidResult.error.code, "browser_operation_failed");
  assert.doesNotThrow(() => context.__workerTest.canonicalJson(invalidResult));

  const primitiveResult = plain(await context.__workerTest.executeSerializedRequest({
    id: "6".repeat(32),
    op: "__fixture_primitive_result",
    params: {},
  }));
  assert.equal(primitiveResult.ok, false);
  assert.equal(primitiveResult.error.code, "invalid_operation_result");
});

test("detail snapshots never substitute a different note for the requested feed", async () => {
  const context = await loadWorker();
  context.window = {
    __INITIAL_STATE__: {
      note: {
        noteDetailMap: {
          "note-other": { note: { noteId: "note-other", title: "其他笔记" } },
        },
      },
    },
  };
  context.chrome.__test.scriptHandler = async (options) => (
    options.func(...options.args)
  );

  const missing = await context.__workerTest.stateSnapshot(1, "detail", "note-requested");
  assert.equal(missing, null);
  const exact = plain(await context.__workerTest.stateSnapshot(1, "detail", "note-other"));
  assert.equal(exact.note.noteId, "note-other");
});

test("loaded DOM comments are merged without losing richer state fields", async () => {
  const context = await loadWorker();
  const { mergeCommentCollections } = context.__workerTest;
  const merged = plain(mergeCommentCollections([
    {
      comment_id: "comment-1",
      content: "初始正文",
      created_at: 123,
      author: { user_id: "user-1", nickname: "作者" },
      replies: [{ comment_id: "reply-1", content: "初始回复", author: {} }],
    },
  ], [
    {
      comment_id: "comment-1",
      content: "DOM 正文",
      date: "今天",
      author: { user_id: "user-1", nickname: "" },
      replies: [
        { comment_id: "reply-1", content: "DOM 回复", author: {} },
        { comment_id: "reply-2", content: "新展开回复", author: {} },
      ],
    },
    { comment_id: "comment-2", content: "滚动后出现", author: {}, replies: [] },
  ]));
  assert.equal(merged.length, 2);
  assert.equal(merged[0].content, "初始正文");
  assert.equal(merged[0].date, "今天");
  assert.equal(merged[0].author.nickname, "作者");
  assert.deepEqual(merged[0].replies.map((item) => item.comment_id), ["reply-1", "reply-2"]);
  assert.equal(merged[1].comment_id, "comment-2");
});

test("an empty DOM snapshot never erases richer initial-state note content", async () => {
  const context = await loadWorker();
  const note = { body: "状态正文", tags: ["#旧标签"] };
  assert.equal(context.__workerTest.mergeDomNoteContent(note, { body: "", tags: [] }), false);
  assert.deepEqual(plain(note), { body: "状态正文", tags: ["#旧标签"] });
  assert.equal(context.__workerTest.mergeDomNoteContent(note, {
    body: "页面正文",
    tags: ["#新标签"],
  }), true);
  assert.deepEqual(plain(note), { body: "页面正文", tags: ["#新标签"] });
});

test("filtered search waits for a changed initial-state snapshot", async () => {
  const context = await loadWorker();
  context.chrome.scripting.executeScript = async () => [{ result: [{ id: "new-result" }] }];
  const result = await context.__workerTest.waitForStateRefresh(
    1,
    "search",
    "",
    [{ id: "old-result" }],
    500,
  );
  assert.equal(result.changed, true);
  assert.deepEqual(plain(result.value), [{ id: "new-result" }]);
});

test("repeated searches reload the same URL so stale filters cannot carry over", async () => {
  const context = await loadWorker();
  context.setTimeout = (callback) => { callback(); return 0; };
  context.chrome.__test.scriptHandler = async ({ args: [kind] }) => (
    kind === "search"
      ? [{ id: "search-result", xsecToken: "token-1", noteCard: { displayTitle: "结果" } }]
      : null
  );
  context.chrome.__test.pageHandler = async (_tabId, message) => {
    if (message.operation === "ping") return { ready: true };
    if (message.operation === "check_login") return { logged_in: true };
    if (message.operation === "apply_filters") return { applied: [] };
    return {};
  };
  const params = { keyword: "咖啡", filters: {}, limit: 2 };
  await context.__workerTest.OPERATIONS.search_feeds(params);
  await context.__workerTest.OPERATIONS.search_feeds(params);
  assert.equal(context.chrome.__test.reloadCount(), 1);
});

test("network logging strips secrets from query strings", async () => {
  const context = await loadWorker();
  const entry = plain(context.__workerTest.sanitizedNetworkEntry({
    url: "https://edith.xiaohongshu.com/api/sns/web/v1/feed?xsec_token=secret&note_id=123",
    method: "POST",
    statusCode: 461,
    tabId: 7,
  }));
  assert.equal(entry.url, "https://edith.xiaohongshu.com/api/sns/web/v1/feed");
  assert.equal(JSON.stringify(entry).includes("secret"), false);
  assert.equal(entry.status, 461);
  assert.equal(
    context.__workerTest.privacySafeUrl(
      "https://www.xiaohongshu.com/explore/note-1?xsec_token=secret#comments",
    ),
    "https://www.xiaohongshu.com/explore/note-1",
  );
  assert.equal(
    context.__workerTest.privacySafeText(
      "navigation failed: https://www.xiaohongshu.com/explore/note-1?xsec_token=secret",
    ),
    "navigation failed: https://www.xiaohongshu.com/explore/note-1",
  );
  assert.equal(
    context.__workerTest.privacySafeUrl("data:text/plain,secret"),
    "invalid-url",
  );
  assert.deepEqual(
    plain(context.__workerTest.privacySafeErrorDetails({
      url: "https://www.xiaohongshu.com/explore/note-1?xsec_token=secret",
      nested: ["https://example.com/image.png?signature=secret"],
    })),
    {
      url: "https://www.xiaohongshu.com/explore/note-1",
      nested: ["https://example.com/image.png"],
    },
  );
});

test("every state-changing worker operation rejects missing confirmation first", async () => {
  const context = await loadWorker();
  const operations = context.__workerTest.OPERATIONS;
  const guarded = [
    "send_code",
    "delete_cookies",
    "post_comment",
    "reply_comment",
    "set_like",
    "set_favorite",
    "fill_image",
    "publish_image",
    "fill_video",
    "publish_video",
    "click_publish",
    "save_draft",
    "fill_long_article",
    "select_template",
    "long_article_next",
  ];
  for (const operation of guarded) {
    await assert.rejects(
      () => operations[operation]({}),
      (error) => error?.code === "confirmation_required",
      operation,
    );
  }
});

test("recent high-risk responses block even confirmed writes", async () => {
  const context = await loadWorker();
  await context.__workerTest.setNetworkEntries([{
    timestamp: Date.now(),
    status: 461,
    url: "https://edith.xiaohongshu.com/api/sns/h5/v1/note_info",
  }]);
  await assert.rejects(
    () => context.__workerTest.OPERATIONS.set_like({ confirmed: true, target: true }),
    (error) => (
      error?.code === "risk_control_active"
      && error?.details?.status === 461
      && error?.details?.retry_after_seconds > 0
    ),
  );
  await assert.rejects(
    () => context.__workerTest.OPERATIONS.verify_code({ code: "123456" }),
    (error) => error?.code === "risk_control_active" && error?.details?.status === 461,
  );
});

test("normal telemetry cannot evict a preserved high-risk gate", async () => {
  const context = await loadWorker();
  const risk = {
    timestamp: Date.now(),
    status: 461,
    url: "https://edith.xiaohongshu.com/api/sns/h5/v1/note_info",
  };
  await context.__workerTest.setNetworkEntries([risk]);
  context.__workerTest.setRollingEntries(Array.from({ length: 500 }, (_, index) => ({
    timestamp: Date.now() + index,
    status: 200,
    url: "https://edith.xiaohongshu.com/api/sns/web/unread_count",
  })));
  await assert.rejects(
    () => context.__workerTest.OPERATIONS.set_like({ confirmed: true, target: true }),
    (error) => error?.code === "risk_control_active",
  );
  const log = await context.__workerTest.OPERATIONS.get_netlog({ limit: 20 });
  assert.equal(log.entries.length, 20);
  assert.equal(log.risk_event_count, 1);
  assert.equal(log.risk_events[0].status, 461);
});

test("overlapping storage writes preserve the newest risk snapshot", async () => {
  const context = await loadWorker();
  await context.__workerTest.setNetworkEntries([]);
  let releaseFirst;
  const firstGate = new Promise((resolve) => { releaseFirst = resolve; });
  const snapshots = [];
  context.chrome.storage.local.set = async (values) => {
    snapshots.push(plain(values));
    if (snapshots.length === 1) await firstGate;
  };

  context.__workerTest.addRiskEvent({ timestamp: Date.now(), status: 461, url: "https://x/a" });
  const first = context.__workerTest.persistNetworkEntries();
  await new Promise((resolve) => setTimeout(resolve, 0));
  context.__workerTest.addRiskEvent({ timestamp: Date.now() + 1, status: 999, url: "https://x/b" });
  const second = context.__workerTest.persistNetworkEntries();
  await new Promise((resolve) => setTimeout(resolve, 0));
  assert.equal(snapshots.length, 1);

  releaseFirst();
  await Promise.all([first, second]);
  assert.equal(snapshots.length, 2);
  assert.deepEqual(snapshots[1].risk_events.map((item) => item.status), [461, 999]);
});

test("clearing 404 diagnostics cannot clear a high-risk write gate", async () => {
  const context = await loadWorker();
  await context.__workerTest.setNetworkEntries([
    {
      timestamp: Date.now(),
      status: 404,
      url: "https://edith.xiaohongshu.com/api/missing",
    },
    {
      timestamp: Date.now(),
      status: 461,
      url: "https://edith.xiaohongshu.com/api/risk",
    },
  ]);
  const diagnostics = await context.__workerTest.OPERATIONS.diagnostics({ clear: true });
  assert.equal(diagnostics.count, 1);
  assert.equal(diagnostics.entries[0].status, 404);
  assert.equal(diagnostics.entries[0].diagnosis.cause_category, "resource_not_found");
  assert.equal(diagnostics.entries[0].diagnosis.confidence, "low");
  const log = await context.__workerTest.OPERATIONS.get_netlog({});
  assert.equal(log.risk_event_count, 1);
  assert.equal(log.risk_events[0].status, 461);
  await assert.rejects(
    () => context.__workerTest.OPERATIONS.set_like({ confirmed: true, target: true }),
    (error) => error?.code === "risk_control_active",
  );
});

test("risk check classifies recent platform responses without visiting probe URLs", async () => {
  const context = await loadWorker();
  context.setTimeout = (callback) => { callback(); return 0; };
  await context.__workerTest.setNetworkEntries([{
    timestamp: Date.now(),
    status: 461,
    url: "https://edith.xiaohongshu.com/api/sns/h5/v1/note_info",
    error: "",
  }]);
  context.chrome.__test.pageHandler = async (_tabId, message) => {
    if (message.operation === "ping") return { ready: true };
    if (message.operation === "risk_signals") {
      return {
        verification_required: false,
        captcha_visible: false,
        page_is_404: false,
        risk_block_visible: false,
        page_markers: [],
        access_error_visible: false,
        fingerprint_issues: [],
      };
    }
    return {};
  };
  const report = await context.__workerTest.OPERATIONS.check_risk({
    probe_urls: ["https://example.com/should-not-be-fetched?token=do-not-echo"],
  });
  assert.equal(report.risk_level, "high");
  assert.deepEqual(plain(report.probe_urls_skipped), ["https://example.com/should-not-be-fetched"]);
  assert.equal(report.recent_network_failures[0].status, 461);
  assert.equal(report.page_scanned, false);
  assert.equal(context.chrome.__test.tabCount(), 0);
});

test("active risk probes require confirmation before opening a tab", async () => {
  const context = await loadWorker();
  await context.__workerTest.setNetworkEntries([]);
  await assert.rejects(
    () => context.__workerTest.OPERATIONS.check_risk({ active_probes: true }),
    (error) => error?.code === "confirmation_required",
  );
  assert.equal(context.chrome.__test.tabCount(), 0);
});

test("active risk probes sanitize evidence and classify direct platform blocks", async () => {
  const context = await loadWorker();
  await context.__workerTest.setNetworkEntries([]);
  let activeCalls = 0;
  context.chrome.__test.pageHandler = async (_tabId, message) => {
    if (message.operation === "ping") return { ready: true };
    if (message.operation === "risk_signals") {
      return {
        url: "https://www.xiaohongshu.com/explore?session=do-not-echo",
        verification_required: false,
        captcha_visible: false,
        page_is_404: false,
        risk_block_visible: false,
        page_markers: [],
        access_error_visible: false,
        fingerprint_issues: [],
      };
    }
    if (message.operation === "active_risk_probes") {
      activeCalls += 1;
      assert.deepEqual(plain(message.params.probe_urls), [
        "https://edith.xiaohongshu.com/api/custom?token=do-not-echo",
      ]);
      return {
        results: [{
          url: "https://edith.xiaohongshu.com/api/custom?token=do-not-echo",
          method: "GET",
          status: 461,
          ok: false,
          xhs_code: -9001,
          xhs_msg: "blocked https://www.xiaohongshu.com/api/test?token=do-not-echo",
          risk_blocked: true,
          elapsed_ms: 12.4,
        }],
      };
    }
    return {};
  };
  const report = plain(await context.__workerTest.OPERATIONS.check_risk({
    active_probes: true,
    confirmed: true,
    probe_urls: ["https://edith.xiaohongshu.com/api/custom?token=do-not-echo"],
  }));
  assert.equal(activeCalls, 1);
  assert.equal(context.chrome.__test.tabCount(), 1);
  assert.equal(report.active_probes_requested, true);
  assert.equal(report.active_probes_executed, true);
  assert.equal(report.risk_level, "high");
  assert.equal(report.api_probes[0].url, "https://edith.xiaohongshu.com/api/custom");
  assert.equal(Object.hasOwn(report.api_probes[0], "xhs_msg"), false);
  assert.equal(report.page.url, "https://www.xiaohongshu.com/explore");
  assert.equal(JSON.stringify(report).includes("do-not-echo"), false);
});

test("active risk probes do not navigate or probe while a recent high-risk gate exists", async () => {
  const context = await loadWorker();
  await context.__workerTest.setNetworkEntries([{
    timestamp: Date.now(),
    status: 461,
    url: "https://edith.xiaohongshu.com/api/risk",
  }]);
  let activeCalls = 0;
  context.chrome.__test.pageHandler = async (_tabId, message) => {
    if (message.operation === "active_risk_probes") activeCalls += 1;
    return message.operation === "ping" ? { ready: true } : {};
  };
  const report = plain(await context.__workerTest.OPERATIONS.check_risk({
    active_probes: true,
    confirmed: true,
    probe_urls: [],
  }));
  assert.equal(activeCalls, 0);
  assert.equal(context.chrome.__test.tabCount(), 0);
  assert.equal(report.active_probes_executed, false);
  assert.equal(report.active_probe_blocked_reason, "recent_high_risk_event");
  assert.equal(report.risk_level, "high");
});

test("active risk probes stop when the diagnostic page exposes verification", async () => {
  const context = await loadWorker();
  await context.__workerTest.setNetworkEntries([]);
  let activeCalls = 0;
  context.chrome.__test.pageHandler = async (_tabId, message) => {
    if (message.operation === "ping") return { ready: true };
    if (message.operation === "risk_signals") {
      return {
        url: "https://www.xiaohongshu.com/explore",
        verification_required: true,
        captcha_visible: false,
        page_is_404: false,
        risk_block_visible: false,
        page_markers: ["安全验证"],
        access_error_visible: false,
        fingerprint_issues: [],
      };
    }
    if (message.operation === "active_risk_probes") activeCalls += 1;
    return {};
  };
  const report = plain(await context.__workerTest.OPERATIONS.check_risk({
    active_probes: true,
    confirmed: true,
    probe_urls: [],
  }));
  assert.equal(activeCalls, 0);
  assert.equal(report.active_probes_executed, false);
  assert.equal(report.active_probe_blocked_reason, "page_risk_signal");
  assert.equal(report.risk_level, "high");
});

test("worker independently rejects unsafe active probe targets", async () => {
  const context = await loadWorker();
  await context.__workerTest.setNetworkEntries([]);
  await assert.rejects(
    () => context.__workerTest.OPERATIONS.check_risk({
      active_probes: true,
      confirmed: true,
      probe_urls: ["https://example.com/api/probe?secret=do-not-echo"],
    }),
    (error) => error?.code === "invalid_input"
      && !String(error?.message).includes("do-not-echo"),
  );
  assert.equal(context.chrome.__test.tabCount(), 0);
});

test("an isolated missing-content page is not misclassified as account-high risk", async () => {
  const context = await loadWorker();
  await context.__workerTest.setNetworkEntries([]);
  await context.chrome.tabs.create({
    url: "https://www.xiaohongshu.com/explore/missing-note",
    active: false,
  });
  context.chrome.__test.pageHandler = async (_tabId, message) => {
    if (message.operation === "ping") return { ready: true };
    if (message.operation === "risk_signals") {
      return {
        url: "https://www.xiaohongshu.com/explore/missing-note?xsec_token=secret",
        verification_required: false,
        captcha_visible: false,
        page_is_404: true,
        risk_block_visible: false,
        page_markers: [],
        access_error_visible: false,
        fingerprint_issues: [],
      };
    }
    return {};
  };
  const report = await context.__workerTest.OPERATIONS.check_risk({ probe_urls: [] });
  assert.equal(report.risk_level, "low");
  assert.equal(report.page_scanned, true);
  assert.equal(report.page.url.includes("xsec_token"), false);
});

test("an explicit visible account restriction is classified as high risk before a write", async () => {
  const context = await loadWorker();
  await context.__workerTest.setNetworkEntries([]);
  await context.chrome.tabs.create({
    url: "https://creator.xiaohongshu.com/publish/publish",
    active: false,
  });
  context.chrome.__test.pageHandler = async (_tabId, message) => {
    if (message.operation === "ping") return { ready: true };
    if (message.operation === "risk_signals") {
      return {
        url: "https://creator.xiaohongshu.com/publish/publish",
        verification_required: false,
        captcha_visible: false,
        page_is_404: false,
        risk_block_visible: false,
        page_markers: ["禁止发笔记"],
        access_error_visible: false,
        fingerprint_issues: [],
      };
    }
    return {};
  };
  const report = await context.__workerTest.OPERATIONS.check_risk({ probe_urls: [] });
  assert.equal(report.risk_level, "high");
  assert.equal(report.page_scanned, true);
  assert.equal(report.page.page_markers[0], "禁止发笔记");
});

test("read operations execute complete browser orchestration against a fixture", async () => {
  const context = await loadWorker();
  context.setTimeout = (callback) => { callback(); return 0; };
  await context.__workerTest.setNetworkEntries([]);
  context.chrome.__test.scriptHandler = async ({ args: [kind] }) => {
    if (kind === "feeds") {
      return [{ id: "feed-home", xsecToken: "token-home", noteCard: { displayTitle: "首页" } }];
    }
    if (kind === "search") {
      return [{ id: "feed-search", xsecToken: "token-search", noteCard: { displayTitle: "搜索" } }];
    }
    if (kind === "detail") {
      return {
        note: {
          noteId: "feed-search",
          desc: "状态正文 #旧标签",
          tagList: [{ name: "旧标签" }],
          interactInfo: { liked: false, collected: false },
        },
        comments: { list: [{ id: "comment-1", content: "初始评论" }] },
      };
    }
    if (kind === "user") {
      return {
        profile: { basicInfo: { nickname: "用户", redId: "red-1" }, interactions: ["1", "2"] },
        notes: [[{ id: "profile-note", xsecToken: "profile-token", noteCard: { displayTitle: "主页笔记" } }]],
      };
    }
    return null;
  };
  context.chrome.__test.pageHandler = async (_tabId, message) => {
    const responses = {
      ping: { ready: true },
      check_login: { logged_in: true, nickname: "测试账号" },
      apply_filters: { applied: [] },
      note_access: { accessible: true, verification_required: false },
      load_comments: { loaded: true, rounds: 3, visible_comments: 2 },
      dom_note_content: { body: "干净正文", tags: ["#新标签"] },
      dom_detail: {
        note: { body: "干净正文", tags: ["#新标签"] },
        comments: [
          { comment_id: "comment-1", content: "DOM 评论", author: {}, replies: [] },
          { comment_id: "comment-2", content: "滚动评论", author: {}, replies: [] },
        ],
      },
      action_readiness: {
        comment_available: true,
        like_available: true,
        favorite_available: true,
        reply: null,
      },
      interaction_state: {
        liked: false,
        favorited: false,
        like_known: true,
        favorite_known: true,
      },
    };
    return responses[message.operation] ?? {};
  };

  const operations = context.__workerTest.OPERATIONS;
  assert.equal((await operations.check_login({})).logged_in, true);
  assert.equal((await operations.list_feeds({ limit: 2 })).feeds[0].feed_id, "feed-home");
  const search = await operations.search_feeds({ keyword: "咖啡", filters: {}, limit: 2 });
  assert.equal(search.feeds[0].feed_id, "feed-search");
  const detail = plain(await operations.get_feed_detail({
    feed_id: "feed-search",
    xsec_token: "token-search",
    load_all_comments: true,
    click_more_replies: true,
    max_replies_threshold: 10,
    max_comment_items: 0,
    scroll_speed: "normal",
  }));
  assert.equal(detail.note.body, "干净正文");
  assert.deepEqual(detail.note.tags, ["#新标签"]);
  assert.deepEqual(detail.comments.map((item) => item.comment_id), ["comment-1", "comment-2"]);
  assert.equal(detail.comment_loading.visible_comments, 2);
  const profile = await operations.user_profile({
    user_id: "user-12345678",
    xsec_token: "profile-token",
    limit: 2,
  });
  assert.equal(profile.profile.nickname, "用户");
  assert.equal(profile.feeds[0].feed_id, "profile-note");
  const inspection = await operations.inspect_actions({
    feed_id: "feed-search",
    xsec_token: "token-search",
  });
  assert.equal(inspection.interaction_state_known, true);
  assert.equal(inspection.comment_available, true);
});

test("inaccessible note errors retain the caller's recovery keyword without auto-bypass", async () => {
  const context = await loadWorker();
  await context.__workerTest.setNetworkEntries([]);
  context.chrome.__test.pageHandler = async (_tabId, message) => {
    if (message.operation === "ping") return { ready: true };
    if (message.operation === "check_login") return { logged_in: true };
    if (message.operation === "note_access") {
      return {
        accessible: false,
        verification_required: true,
        reason: "扫码查看",
        url: "https://www.xiaohongshu.com/explore/feed-1",
      };
    }
    return {};
  };
  await assert.rejects(
    () => context.__workerTest.OPERATIONS.get_feed_detail({
      feed_id: "feed-1",
      xsec_token: "token-1",
      keyword: "咖啡",
    }),
    (error) => (
      error?.code === "verification_required"
      && error?.details?.suggested_search_keyword === "咖啡"
      && /用户/.test(error?.details?.recovery || "")
    ),
  );
});

test("worker rejects redirected note and profile routes before reading page state", async () => {
  const context = await loadWorker();
  const create = context.chrome.tabs.create.bind(context.chrome.tabs);
  const update = context.chrome.tabs.update.bind(context.chrome.tabs);
  const redirect = (url) => url
    .replace("/explore/feed-1", "/explore/feed-other")
    .replace("/user/profile/user-1", "/user/profile/user-other");
  context.chrome.tabs.create = ({ url, active }) => create({
    url: redirect(url),
    active,
  });
  context.chrome.tabs.update = (tabId, values) => update(tabId, {
    ...values,
    ...(values.url ? { url: redirect(values.url) } : {}),
  });
  context.chrome.__test.pageHandler = async (_tabId, message) => (
    message.operation === "ping" ? { ready: true } : { logged_in: true }
  );
  await assert.rejects(
    () => context.__workerTest.OPERATIONS.get_feed_detail({
      feed_id: "feed-1",
      xsec_token: "token-1",
    }),
    (error) => error?.code === "target_route_mismatch",
  );
  await assert.rejects(
    () => context.__workerTest.OPERATIONS.user_profile({
      user_id: "user-1",
      xsec_token: "token-1",
    }),
    (error) => error?.code === "target_route_mismatch",
  );
});

test("confirmed auth, comment, publishing, draft, and long-form routes complete in fixture", async () => {
  const context = await loadWorker();
  context.setTimeout = (callback) => { callback(); return 0; };
  await context.__workerTest.setNetworkEntries([]);
  let logoutCheckPending = false;
  let selectedLongTemplate = "";
  context.chrome.cookies.remove = async (details) => {
    logoutCheckPending = true;
    return details;
  };
  context.chrome.__test.scriptHandler = async ({ args: [kind] }) => {
    if (kind === "detail") {
      return { note: { noteId: "feed-1", interactInfo: { liked: false, collected: false } } };
    }
    return null;
  };
  context.chrome.__test.pageHandler = async (_tabId, message) => {
    if (message.operation === "check_login" && logoutCheckPending) {
      logoutCheckPending = false;
      return { logged_in: false, login_visible: true };
    }
    if (message.operation === "select_template") {
      const before = fixtureLongDraftSnapshot(selectedLongTemplate);
      selectedLongTemplate = message.params.name;
      return {
        selected: true,
        name: selectedLongTemplate,
        draft_snapshot_before: before,
        draft_snapshot: fixtureLongDraftSnapshot(selectedLongTemplate),
      };
    }
    const responses = {
      ping: { ready: true },
      check_login: { logged_in: true },
      get_qrcode: {
        logged_in: false,
        data_url: "data:image/png;base64,AA==",
        status: "qrcode_ready",
      },
      prepare_phone: { logged_in: false, skip: true },
      send_code_target: fixtureTarget("login-send-code"),
      wait_code_sent: { status: "code_sent" },
      prepare_verify_code: fixtureTarget("login-verify"),
      wait_verify_code: { logged_in: true },
      note_access: { accessible: true },
      comment_open_target: { skip: true, editor_ready: true },
      reply_target: fixtureTarget("comment-reply"),
      prepare_comment: {
        selector: fixtureSelector("comment-submit"),
        before_matches: 0,
      },
      wait_comment_sent: { success: true, status: "comment_sent" },
      prepare_publish_tab: {
        ready: true,
        input_selector: "input[data-hongshuskill-upload='fixture']",
      },
      wait_upload: { uploaded: true },
      fill_publish_form: { status: "filled" },
      publish_setting_rect: { skip: true },
      wait_publish_settings: fixturePublishSettings(message),
      target_rect: fixtureTarget("submit-publish"),
      observe_submission: { success: true, status: "submitted", url: "https://creator.xiaohongshu.com/success" },
      prepare_long_article: { status: "long_article_filled" },
      format_long_article: {
        status: "templates_ready",
        templates: ["理性现代"],
        draft_snapshot: fixtureLongDraftSnapshot(""),
      },
      long_draft_snapshot: fixtureLongDraftSnapshot(selectedLongTemplate),
      long_next: {
        status: "description_filled",
        length: 4,
        draft_snapshot_before: fixtureLongDraftSnapshot(selectedLongTemplate),
      },
    };
    if (message.operation === "target_rect" && message.params.target === "draft") {
      return fixtureTarget("submit-draft");
    }
    return responses[message.operation] ?? {};
  };
  const operations = context.__workerTest.OPERATIONS;
  assert.match((await operations.get_qrcode({})).data_url, /^data:image\/png/);
  assert.equal((await operations.wait_login({ timeout_seconds: 1 })).logged_in, true);
  assert.equal((await operations.send_code({ confirmed: true, phone: "13800138000" })).status, "code_sent");
  assert.equal((await operations.verify_code({ code: "123456" })).logged_in, true);
  assert.equal((await operations.delete_cookies({ confirmed: true })).logged_in, false);
  assert.equal((await operations.post_comment({
    confirmed: true,
    feed_id: "feed-1",
    xsec_token: "token-1",
    content: "评论",
  })).success, true);
  assert.equal((await operations.reply_comment({
    confirmed: true,
    feed_id: "feed-1",
    xsec_token: "token-1",
    comment_id: "comment-1",
    content: "回复",
  })).success, true);

  const common = {
    confirmed: true,
    title: "标题",
    content: "正文",
    tags: [],
    visibility: "公开可见",
    original: false,
    schedule_at: null,
  };
  assert.equal((await operations.fill_image({ ...common, images: ["/tmp/a.png"] })).preview_only, true);
  const compatibilityImage = await operations.publish_image({ ...common, images: ["/tmp/a.png"] });
  assert.equal(compatibilityImage.preview_only, true);
  assert.equal(compatibilityImage.requires_separate_submit, true);
  assert.equal((await operations.fill_video({ ...common, video: "/tmp/a.mp4" })).preview_only, true);
  const compatibilityVideo = await operations.publish_video({ ...common, video: "/tmp/a.mp4" });
  assert.equal(compatibilityVideo.preview_only, true);
  assert.equal(compatibilityVideo.requires_separate_submit, true);
  const publishPreview = await operations.fill_image({ ...common, images: ["/tmp/a.png"] });
  assert.equal((await operations.click_publish({
    confirmed: true,
    preview_id: publishPreview.preview_id,
  })).success, true);
  await assert.rejects(
    () => operations.click_publish({ confirmed: true, preview_id: publishPreview.preview_id }),
    (error) => error?.code === "draft_tab_missing",
  );
  const draftPreview = await operations.fill_image({ ...common, images: ["/tmp/a.png"] });
  assert.equal((await operations.save_draft({
    confirmed: true,
    preview_id: draftPreview.preview_id,
  })).action, "draft");
  await assert.rejects(
    () => operations.save_draft({ confirmed: true, preview_id: draftPreview.preview_id }),
    (error) => error?.code === "draft_tab_missing",
  );
  const long = await operations.fill_long_article({
    confirmed: true,
    title: "长文标题",
    content: "长文正文",
    images: [],
  });
  assert.deepEqual(plain(long.templates), ["理性现代"]);
  await assert.rejects(
    () => operations.long_article_next({
      confirmed: true,
      preview_id: long.preview_id,
      content: "描述",
    }),
    (error) => error?.code === "draft_state_not_ready",
  );
  assert.equal((await operations.select_template({
    confirmed: true,
    preview_id: long.preview_id,
    name: "理性现代",
  })).selected, true);
  assert.equal((await operations.long_article_next({
    confirmed: true,
    preview_id: long.preview_id,
    content: "描述",
  })).status, "description_filled");
});

test("an unconfirmed submission cannot be clicked a second time automatically", async () => {
  const context = await loadWorker();
  await context.__workerTest.setNetworkEntries([]);
  context.chrome.__test.pageHandler = async (_tabId, message) => {
    const responses = {
      ping: { ready: true },
      risk_signals: {},
      prepare_publish_tab: {
        ready: true,
        input_selector: "input[data-hongshuskill-upload='fixture']",
      },
      wait_upload: { uploaded: true },
      fill_publish_form: { status: "filled" },
      publish_setting_rect: { skip: true },
      wait_publish_settings: fixturePublishSettings(message),
      target_rect: fixtureTarget("submit-publish"),
      observe_submission: { success: false, status: "unconfirmed", message: "结果未知" },
    };
    return responses[message.operation] ?? {};
  };
  const common = {
    confirmed: true,
    title: "标题",
    content: "正文",
    tags: [],
    visibility: "公开可见",
    original: false,
    schedule_at: null,
    images: ["/tmp/a.png"],
  };
  const preview = await context.__workerTest.OPERATIONS.fill_image(common);
  await assert.rejects(
    () => context.__workerTest.OPERATIONS.click_publish({
      confirmed: true,
      preview_id: preview.preview_id,
    }),
    (error) => (
      error?.code === "operation_state_uncertain"
      && error?.details?.cause_code === "submission_unconfirmed"
    ),
  );
  await assert.rejects(
    () => context.__workerTest.OPERATIONS.click_publish({
      confirmed: true,
      preview_id: preview.preview_id,
    }),
    (error) => error?.code === "submission_state_uncertain",
  );
});

test("a final publish-button preflight failure does not poison the reusable preview", async () => {
  const context = await loadWorker();
  await context.__workerTest.setNetworkEntries([]);
  installPublishFixture(context);
  const preview = await context.__workerTest.OPERATIONS.fill_image({
    confirmed: true,
    title: "标题",
    content: "正文",
    tags: [],
    visibility: "公开可见",
    original: false,
    schedule_at: null,
    images: ["/tmp/a.png"],
  });
  const base = context.chrome.__test.debuggerHandler;
  context.chrome.__test.debuggerHandler = async (target, method, params) => {
    if (method === "Runtime.callFunctionOn" && /selector_matches/.test(params.functionDeclaration)) {
      return {
        result: {
          value: {
            connected: false,
            selector_matches: true,
            visible: true,
            disabled: false,
            trapped: false,
          },
        },
      };
    }
    return base(target, method, params);
  };
  await assert.rejects(
    () => context.__workerTest.OPERATIONS.click_publish({
      confirmed: true,
      preview_id: preview.preview_id,
    }),
    (error) => error?.code === "click_target_invalid",
  );
  assert.equal(context.chrome.__test.sessionStorage.prepared_creator.stage, "image_preview");

  context.chrome.__test.debuggerHandler = base;
  const result = await context.__workerTest.OPERATIONS.click_publish({
    confirmed: true,
    preview_id: preview.preview_id,
  });
  assert.equal(result.success, true);
});

test("a submission marker write failure after mouse-down is operation-state uncertain", async () => {
  const context = await loadWorker();
  await context.__workerTest.setNetworkEntries([]);
  installPublishFixture(context);
  const preview = await context.__workerTest.OPERATIONS.fill_image({
    confirmed: true,
    title: "标题",
    content: "正文",
    tags: [],
    visibility: "公开可见",
    original: false,
    schedule_at: null,
    images: ["/tmp/a.png"],
  });
  const baseSet = context.chrome.storage.session.set;
  context.chrome.storage.session.set = async (values) => {
    if (/submission_uncertain/.test(values.prepared_creator?.stage || "")) {
      const error = new Error("无法写入提交标记");
      error.code = "storage_write_failed";
      throw error;
    }
    return baseSet(values);
  };
  await assert.rejects(
    () => context.__workerTest.OPERATIONS.click_publish({
      confirmed: true,
      preview_id: preview.preview_id,
    }),
    (error) => (
      error?.code === "operation_state_uncertain"
      && error?.details?.cause_code === "storage_write_failed"
    ),
  );
  assert.equal(context.chrome.__test.sessionStorage.prepared_creator.stage, "image_preview");
});

test("a successful submission stays non-repeatable when session cleanup fails", async () => {
  const context = await loadWorker();
  await context.__workerTest.setNetworkEntries([]);
  context.chrome.__test.pageHandler = async (_tabId, message) => {
    const responses = {
      ping: { ready: true },
      risk_signals: {},
      prepare_publish_tab: {
        ready: true,
        input_selector: "input[data-hongshuskill-upload='fixture']",
      },
      wait_upload: { uploaded: true },
      fill_publish_form: { status: "filled" },
      publish_setting_rect: { skip: true },
      wait_publish_settings: fixturePublishSettings(message),
      target_rect: fixtureTarget("submit-publish"),
      observe_submission: { success: true, status: "submitted" },
    };
    return responses[message.operation] ?? {};
  };
  const preview = await context.__workerTest.OPERATIONS.fill_image({
    confirmed: true,
    title: "标题",
    content: "正文",
    tags: [],
    visibility: "公开可见",
    original: false,
    schedule_at: null,
    images: ["/tmp/a.png"],
  });
  context.chrome.storage.session.remove = async () => {
    throw new Error("fixture storage failure");
  };
  const submitted = await context.__workerTest.OPERATIONS.click_publish({
    confirmed: true,
    preview_id: preview.preview_id,
  });
  assert.equal(submitted.success, true);
  assert.equal(submitted.preview_state_cleared, false);
  await assert.rejects(
    () => context.__workerTest.OPERATIONS.click_publish({
      confirmed: true,
      preview_id: preview.preview_id,
    }),
    (error) => error?.code === "submission_state_uncertain",
  );
});

test("a failed replacement preview invalidates the previously prepared draft", async () => {
  const context = await loadWorker();
  await context.__workerTest.setNetworkEntries([]);
  let uploadAttempts = 0;
  context.chrome.__test.pageHandler = async (_tabId, message) => {
    if (message.operation === "ping") return { ready: true };
    if (message.operation === "risk_signals") return {};
    if (message.operation === "prepare_publish_tab") {
      return { ready: true, input_selector: "input[data-hongshuskill-upload='fixture']" };
    }
    if (message.operation === "wait_upload") {
      uploadAttempts += 1;
      if (uploadAttempts === 2) throw new Error("第二次上传失败");
      return { uploaded: true };
    }
    if (message.operation === "fill_publish_form") return { status: "filled" };
    if (message.operation === "publish_setting_rect") return { skip: true };
    if (message.operation === "wait_publish_settings") {
      return fixturePublishSettings(message);
    }
    return {};
  };
  const common = {
    confirmed: true,
    title: "标题",
    content: "正文",
    tags: [],
    visibility: "公开可见",
    original: false,
    schedule_at: null,
    images: ["/tmp/a.png"],
  };
  const preview = await context.__workerTest.OPERATIONS.fill_image(common);
  await assert.rejects(
    () => context.__workerTest.OPERATIONS.fill_image(common),
    /第二次上传失败/,
  );
  await assert.rejects(
    () => context.__workerTest.OPERATIONS.click_publish({
      confirmed: true,
      preview_id: preview.preview_id,
    }),
    (error) => error?.code === "draft_tab_missing",
  );
});

test("logout invalidates previews and removes partitioned Xiaohongshu cookies", async () => {
  const context = await loadWorker();
  await context.__workerTest.setNetworkEntries([]);
  context.chrome.__test.pageHandler = async (_tabId, message) => {
    const responses = {
      ping: { ready: true },
      check_login: { logged_in: false, login_visible: true },
      risk_signals: {},
      prepare_publish_tab: {
        ready: true,
        input_selector: "input[data-hongshuskill-upload='fixture']",
      },
      wait_upload: { uploaded: true },
      fill_publish_form: { status: "filled" },
      publish_setting_rect: { skip: true },
      wait_publish_settings: fixturePublishSettings(message),
    };
    return responses[message.operation] ?? {};
  };
  const preview = await context.__workerTest.OPERATIONS.fill_image({
    confirmed: true,
    title: "标题",
    content: "正文",
    tags: [],
    visibility: "公开可见",
    original: false,
    schedule_at: null,
    images: ["/tmp/a.png"],
  });
  const removals = [];
  const partitionKey = { topLevelSite: "https://xiaohongshu.com" };
  context.chrome.cookies.getAll = async () => [
    {
      domain: ".xiaohongshu.com",
      name: "regular",
      path: "/",
      secure: true,
      storeId: "0",
    },
    {
      domain: ".xiaohongshu.com",
      name: "partitioned",
      path: "/",
      secure: true,
      storeId: "0",
      partitionKey,
    },
  ];
  context.chrome.cookies.remove = async (details) => {
    removals.push(plain(details));
    return details;
  };
  const result = await context.__workerTest.OPERATIONS.delete_cookies({ confirmed: true });
  assert.equal(result.cookies_removed, 2);
  assert.equal(removals[0].partitionKey, undefined);
  assert.deepEqual(removals[1].partitionKey, partitionKey);
  await assert.rejects(
    () => context.__workerTest.OPERATIONS.click_publish({
      confirmed: true,
      preview_id: preview.preview_id,
    }),
    (error) => error?.code === "draft_tab_missing",
  );
});

test("publish preview explicitly reconciles stale persisted settings", async () => {
  const context = await loadWorker();
  await context.__workerTest.setNetworkEntries([]);
  const settingRequests = [];
  context.chrome.__test.pageHandler = async (_tabId, message) => {
    const responses = {
      ping: { ready: true },
      risk_signals: {},
      prepare_publish_tab: {
        ready: true,
        input_selector: "input[data-hongshuskill-upload='fixture']",
      },
      wait_upload: { uploaded: true },
      fill_publish_form: { status: "filled" },
      wait_publish_settings: fixturePublishSettings(message),
    };
    if (message.operation === "publish_setting_rect") {
      settingRequests.push(plain(message.params));
      return { skip: true };
    }
    return responses[message.operation] ?? {};
  };
  const preview = await context.__workerTest.OPERATIONS.fill_image({
    confirmed: true,
    title: "标题",
    content: "正文",
    tags: [],
    visibility: "公开可见",
    original: false,
    schedule_at: null,
    images: ["/tmp/a.png"],
  });
  assert.deepEqual(plain(settingRequests), [
    { setting: "schedule_switch", enabled: false },
    { setting: "visibility_dropdown", value: "公开可见" },
    { setting: "original_switch", enabled: false },
  ]);
});

test("preview ids bind publish and draft actions before any click target is requested", async () => {
  const context = await loadWorker();
  await context.__workerTest.setNetworkEntries([]);
  const fixture = installPublishFixture(context, {
    settingsForCall(_call, message) {
      const settings = fixturePublishSettings(message);
      settings.snapshot.route += "?credential=must-not-persist";
      settings.snapshot.form.title = "内部标题";
      settings.snapshot.form.content = "不应持久化的正文";
      settings.snapshot.form.tags = ["标签"];
      settings.snapshot.media.descriptors = ["blob:secret-preview"];
      return settings;
    },
  });
  const preview = await context.__workerTest.OPERATIONS.fill_image({
    confirmed: true,
    title: "标题",
    content: "正文",
    tags: [],
    visibility: "公开可见",
    original: false,
    schedule_at: null,
    images: ["/tmp/a.png"],
  });
  for (const operation of ["click_publish", "save_draft"]) {
    await assert.rejects(
      () => context.__workerTest.OPERATIONS[operation]({ confirmed: true }),
      (error) => error?.code === "preview_id_required",
    );
    await assert.rejects(
      () => context.__workerTest.OPERATIONS[operation]({
        confirmed: true,
        preview_id: "f".repeat(32),
      }),
      (error) => error?.code === "preview_id_mismatch",
    );
  }
  assert.equal(fixture.targetRequests, 0);
  const submitted = await context.__workerTest.OPERATIONS.click_publish({
    confirmed: true,
    preview_id: preview.preview_id,
  });
  assert.equal(submitted.success, true);
  assert.equal(fixture.targetRequests, 1);
});

test("compatibility publish operations stop at preview and do not leak the internal snapshot", async () => {
  const context = await loadWorker();
  await context.__workerTest.setNetworkEntries([]);
  const fixture = installPublishFixture(context);
  const result = plain(await context.__workerTest.OPERATIONS.publish_image({
    confirmed: true,
    title: "内部标题",
    content: "不应出现在 settings 里的正文",
    tags: ["标签"],
    visibility: "公开可见",
    original: false,
    schedule_at: null,
    images: ["/tmp/a.png"],
  }));
  assert.equal(result.preview_only, true);
  assert.equal(result.requires_separate_submit, true);
  assert.match(result.preview_id, /^[0-9a-f]{32}$/);
  assert.equal(fixture.targetRequests, 0);
  assert.equal(result.settings.snapshot, undefined);
  assert.equal(JSON.stringify(result.settings).includes("正文"), false);
  assert.equal(JSON.stringify(result).includes("form_snapshot"), false);
  assert.equal(JSON.stringify(result).includes("descriptors"), false);
  const stored = JSON.stringify(context.chrome.__test.sessionStorage.prepared_creator);
  assert.equal(stored.includes("内部标题"), false);
  assert.equal(stored.includes("不应持久化的正文"), false);
  assert.equal(stored.includes("标签"), false);
  assert.equal(stored.includes("blob:secret-preview"), false);
  assert.equal(stored.includes("credential=must-not-persist"), false);
  assert.deepEqual(
    Object.keys(context.chrome.__test.sessionStorage.prepared_creator.form_snapshot.form).sort(),
    ["content_hash", "content_length", "tag_count", "tags_hash", "title_hash", "title_length"],
  );
});

test("manual form or media changes invalidate a bound preview before submission", async () => {
  const context = await loadWorker();
  await context.__workerTest.setNetworkEntries([]);
  const fixture = installPublishFixture(context, {
    settingsForCall(call, message) {
      return call === 1
        ? fixturePublishSettings(message)
        : fixturePublishSettings(message, {
          form: fixturePublishFormSnapshot({
            content_hash: "9".repeat(64),
            content_length: 8,
          }),
        });
    },
  });
  const preview = await context.__workerTest.OPERATIONS.fill_image({
    confirmed: true,
    title: "标题",
    content: "正文",
    tags: [],
    visibility: "公开可见",
    original: false,
    schedule_at: null,
    images: ["/tmp/a.png"],
  });
  await assert.rejects(
    () => context.__workerTest.OPERATIONS.click_publish({
      confirmed: true,
      preview_id: preview.preview_id,
    }),
    (error) => error?.code === "preview_changed",
  );
  assert.equal(fixture.targetRequests, 0);
});

test("changing the local account session invalidates the preview without persisting cookie contents", async () => {
  const context = await loadWorker();
  await context.__workerTest.setNetworkEntries([]);
  installPublishFixture(context);
  let sessionValue = "account-a-secret";
  context.chrome.cookies.getAll = async () => [{
    domain: ".xiaohongshu.com",
    name: "web_session",
    value: sessionValue,
    path: "/",
    storeId: "0",
  }];
  const preview = await context.__workerTest.OPERATIONS.fill_image({
    confirmed: true,
    title: "标题",
    content: "正文",
    tags: [],
    visibility: "公开可见",
    original: false,
    schedule_at: null,
    images: ["/tmp/a.png"],
  });
  const prepared = context.chrome.__test.sessionStorage.prepared_creator;
  assert.match(prepared.account_fingerprint, /^[0-9a-f]{64}$/);
  assert.equal(JSON.stringify(prepared).includes(sessionValue), false);
  sessionValue = "account-b-secret";
  await assert.rejects(
    () => context.__workerTest.OPERATIONS.click_publish({
      confirmed: true,
      preview_id: preview.preview_id,
    }),
    (error) => error?.code === "account_changed",
  );
});

test("long-form stages preserve the original TTL and require the same preview id and source snapshot", async () => {
  const context = await loadWorker();
  await context.__workerTest.setNetworkEntries([]);
  let selected = false;
  let mutateBeforeSelect = false;
  let mutateBeforeNext = false;
  let selectCalls = 0;
  let longNextCalls = 0;
  context.chrome.__test.pageHandler = async (_tabId, message) => {
    if (message.operation === "ping") return { ready: true };
    if (message.operation === "risk_signals") return {};
    if (message.operation === "prepare_long_article") {
      selected = false;
      return { status: "long_article_filled" };
    }
    if (message.operation === "format_long_article") {
      return {
        status: "templates_ready",
        templates: ["理性现代"],
        draft_snapshot: fixtureLongDraftSnapshot(""),
      };
    }
    if (message.operation === "long_draft_snapshot") {
      const snapshot = fixtureLongDraftSnapshot(selected ? "理性现代" : "");
      if (mutateBeforeSelect || mutateBeforeNext) snapshot.content_hash = "9".repeat(64);
      return snapshot;
    }
    if (message.operation === "select_template") {
      selectCalls += 1;
      selected = true;
      return {
        selected: true,
        name: message.params.name,
        draft_snapshot_before: fixtureLongDraftSnapshot(""),
        draft_snapshot: fixtureLongDraftSnapshot(message.params.name),
      };
    }
    if (message.operation === "long_next") {
      longNextCalls += 1;
      const before = fixtureLongDraftSnapshot("理性现代");
      return {
        status: "description_filled",
        length: message.params.content.length,
        draft_snapshot_before: before,
      };
    }
    if (message.operation === "publish_setting_rect") return { skip: true };
    if (message.operation === "wait_publish_settings") return fixturePublishSettings(message);
    return {};
  };
  const initial = await context.__workerTest.OPERATIONS.fill_long_article({
    confirmed: true,
    title: "长文标题",
    content: "长文正文",
    images: [],
  });
  const initialCreatedAt = context.chrome.__test.sessionStorage.prepared_creator.created_at;
  await assert.rejects(
    () => context.__workerTest.OPERATIONS.select_template({
      confirmed: true,
      name: "理性现代",
    }),
    (error) => error?.code === "preview_id_required",
  );
  await assert.rejects(
    () => context.__workerTest.OPERATIONS.select_template({
      confirmed: true,
      preview_id: "f".repeat(32),
      name: "理性现代",
    }),
    (error) => error?.code === "preview_id_mismatch",
  );
  mutateBeforeSelect = true;
  await assert.rejects(
    () => context.__workerTest.OPERATIONS.select_template({
      confirmed: true,
      preview_id: initial.preview_id,
      name: "理性现代",
    }),
    (error) => error?.code === "preview_changed",
  );
  assert.equal(selectCalls, 0);
  assert.equal(selected, false);
  assert.equal(context.chrome.__test.sessionStorage.prepared_creator.created_at, initialCreatedAt);

  mutateBeforeSelect = false;
  const bound = await context.__workerTest.OPERATIONS.fill_long_article({
    confirmed: true,
    title: "重新绑定长文",
    content: "重新绑定正文",
    images: [],
  });
  const createdAt = context.chrome.__test.sessionStorage.prepared_creator.created_at;
  await context.__workerTest.OPERATIONS.select_template({
    confirmed: true,
    preview_id: bound.preview_id,
    name: "理性现代",
  });
  assert.equal(selected, true);
  assert.equal(selectCalls, 1);
  assert.equal(context.chrome.__test.sessionStorage.prepared_creator.created_at, createdAt);
  await assert.rejects(
    () => context.__workerTest.OPERATIONS.long_article_next({
      confirmed: true,
      preview_id: "f".repeat(32),
      content: "描述",
    }),
    (error) => error?.code === "preview_id_mismatch",
  );
  mutateBeforeNext = true;
  await assert.rejects(
    () => context.__workerTest.OPERATIONS.long_article_next({
      confirmed: true,
      preview_id: bound.preview_id,
      content: "描述",
    }),
    (error) => error?.code === "preview_changed",
  );
  assert.equal(longNextCalls, 0);
  assert.equal(context.chrome.__test.sessionStorage.prepared_creator.created_at, createdAt);

  mutateBeforeNext = false;
  const replacement = await context.__workerTest.OPERATIONS.fill_long_article({
    confirmed: true,
    title: "替换长文",
    content: "替换正文",
    images: [],
  });
  const replacementCreatedAt = context.chrome.__test.sessionStorage.prepared_creator.created_at;
  await context.__workerTest.OPERATIONS.select_template({
    confirmed: true,
    preview_id: replacement.preview_id,
    name: "理性现代",
  });
  await context.__workerTest.OPERATIONS.long_article_next({
    confirmed: true,
    preview_id: replacement.preview_id,
    content: "描述",
  });
  assert.equal(
    context.chrome.__test.sessionStorage.prepared_creator.created_at,
    replacementCreatedAt,
  );
});

test("saving a long-form draft rechecks the bound source before requesting a click target", async () => {
  const context = await loadWorker();
  await context.__workerTest.setNetworkEntries([]);
  let mutated = false;
  let targetRequests = 0;
  context.chrome.__test.pageHandler = async (_tabId, message) => {
    if (message.operation === "ping") return { ready: true };
    if (message.operation === "risk_signals") return {};
    if (message.operation === "prepare_long_article") return { status: "long_article_filled" };
    if (message.operation === "format_long_article") {
      return {
        status: "templates_ready",
        templates: ["理性现代"],
        draft_snapshot: fixtureLongDraftSnapshot(""),
      };
    }
    if (message.operation === "long_draft_snapshot") {
      const snapshot = fixtureLongDraftSnapshot("");
      if (mutated) snapshot.title_hash = "8".repeat(64);
      return snapshot;
    }
    if (message.operation === "target_rect") {
      targetRequests += 1;
      return fixtureTarget("submit-draft");
    }
    return {};
  };
  const preview = await context.__workerTest.OPERATIONS.fill_long_article({
    confirmed: true,
    title: "长文标题",
    content: "长文正文",
    images: [],
  });
  mutated = true;
  await assert.rejects(
    () => context.__workerTest.OPERATIONS.save_draft({
      confirmed: true,
      preview_id: preview.preview_id,
    }),
    (error) => error?.code === "preview_changed",
  );
  assert.equal(targetRequests, 0);
});

test("SMS rate limiting returns a QR fallback without retrying the send action", async () => {
  const context = await loadWorker();
  await context.__workerTest.setNetworkEntries([]);
  let sendTargets = 0;
  context.chrome.__test.pageHandler = async (_tabId, message) => {
    if (message.operation === "ping") return { ready: true };
    if (message.operation === "prepare_phone") return { logged_in: false, skip: true };
    if (message.operation === "send_code_target") {
      sendTargets += 1;
      return fixtureTarget("login-send-code");
    }
    if (message.operation === "wait_code_sent") {
      throw new Error("验证码未进入倒计时，可能触发了频率限制");
    }
    if (message.operation === "get_qrcode") {
      return { logged_in: false, data_url: "data:image/png;base64,AA==" };
    }
    return {};
  };
  const result = await context.__workerTest.OPERATIONS.send_code({
    confirmed: true,
    phone: "13800138000",
  });
  assert.equal(sendTargets, 1);
  assert.equal(result.status, "qrcode_fallback");
  assert.match(result.message, /二维码/);
});

test("SMS risk-control errors are never swallowed by the QR fallback", async () => {
  const context = await loadWorker();
  await context.__workerTest.setNetworkEntries([]);
  let qrRequested = false;
  context.chrome.__test.pageHandler = async (_tabId, message) => {
    if (message.operation === "ping") return { ready: true };
    if (message.operation === "prepare_phone") return { logged_in: false, skip: true };
    if (message.operation === "send_code_target") return fixtureTarget("login-send-code");
    if (message.operation === "risk_signals") {
      return { page_markers: ["操作频繁"] };
    }
    if (message.operation === "get_qrcode") {
      qrRequested = true;
      return { data_url: "data:image/png;base64,AA==" };
    }
    return {};
  };
  await assert.rejects(
    () => context.__workerTest.OPERATIONS.send_code({
      confirmed: true,
      phone: "13800138000",
    }),
    (error) => error?.code === "risk_control_active",
  );
  assert.equal(qrRequested, false);
});

test("SMS send wraps only post-dispatch channel failures as uncertain", async () => {
  const context = await loadWorker();
  await context.__workerTest.setNetworkEntries([]);
  context.chrome.__test.pageHandler = async (_tabId, message) => {
    if (message.operation === "ping") return { ready: true };
    if (message.operation === "prepare_phone") return { logged_in: false, skip: true };
    if (message.operation === "send_code_target") return fixtureTarget("login-send-code");
    if (message.operation === "risk_signals") return {};
    if (message.operation === "wait_code_sent") {
      const error = new Error("channel closed at https://example.invalid/?token=secret");
      error.code = "page_channel_disconnected";
      throw error;
    }
    return {};
  };
  await assert.rejects(
    () => context.__workerTest.OPERATIONS.send_code({
      confirmed: true,
      phone: "13800138000",
    }),
    (error) => (
      error?.code === "operation_state_uncertain"
      && error?.details?.cause_code === "page_channel_disconnected"
      && !JSON.stringify(error.details).includes("secret")
    ),
  );

  const beforeContext = await loadWorker();
  await beforeContext.__workerTest.setNetworkEntries([]);
  beforeContext.chrome.__test.pageHandler = async (_tabId, message) => {
    if (message.operation === "ping") return { ready: true };
    if (message.operation === "prepare_phone") return { logged_in: false, skip: true };
    if (message.operation === "send_code_target") {
      const error = new Error("发送按钮尚未准备好");
      error.code = "page_channel_disconnected";
      throw error;
    }
    return {};
  };
  await assert.rejects(
    () => beforeContext.__workerTest.OPERATIONS.send_code({
      confirmed: true,
      phone: "13800138000",
    }),
    (error) => error?.code === "page_channel_disconnected",
  );
});

test("a final send-button dispatch failure is treated as uncertain", async () => {
  const context = await loadWorker();
  await context.__workerTest.setNetworkEntries([]);
  context.chrome.__test.pageHandler = async (_tabId, message) => {
    if (message.operation === "ping") return { ready: true };
    if (message.operation === "prepare_phone") return { logged_in: false, skip: true };
    if (message.operation === "send_code_target") return fixtureTarget("login-send-code");
    if (message.operation === "risk_signals") return {};
    return {};
  };
  const base = context.chrome.__test.debuggerHandler;
  context.chrome.__test.debuggerHandler = async (target, method, params) => {
    if (method === "Input.dispatchMouseEvent" && params.type === "mouseReleased") {
      const error = new Error("调试通道在 release 后断开");
      error.code = "debugger_channel_closed";
      throw error;
    }
    return base(target, method, params);
  };
  await assert.rejects(
    () => context.__workerTest.OPERATIONS.send_code({
      confirmed: true,
      phone: "13800138000",
    }),
    (error) => (
      error?.code === "operation_state_uncertain"
      && error?.details?.cause_code === "debugger_channel_closed"
    ),
  );
});

test("verification-code result loss after submit is operation-state uncertain", async () => {
  const context = await loadWorker();
  await context.__workerTest.setNetworkEntries([]);
  context.chrome.__test.pageHandler = async (_tabId, message) => {
    if (message.operation === "ping") return { ready: true };
    if (message.operation === "prepare_verify_code") return fixtureTarget("login-verify");
    if (message.operation === "risk_signals") return {};
    if (message.operation === "wait_verify_code") {
      const error = new Error("登录结果通道断开");
      error.code = "page_channel_disconnected";
      throw error;
    }
    return {};
  };
  await assert.rejects(
    () => context.__workerTest.OPERATIONS.verify_code({ code: "123456" }),
    (error) => (
      error?.code === "operation_state_uncertain"
      && error?.details?.cause_code === "page_channel_disconnected"
    ),
  );
});

test("logout reports an error when the reloaded page still confirms a logged-in account", async () => {
  const context = await loadWorker();
  await context.__workerTest.setNetworkEntries([]);
  context.chrome.__test.pageHandler = async (_tabId, message) => {
    if (message.operation === "ping") return { ready: true };
    if (message.operation === "check_login") return { logged_in: true };
    return {};
  };
  await assert.rejects(
    () => context.__workerTest.OPERATIONS.delete_cookies({ confirmed: true }),
    (error) => error?.code === "logout_unconfirmed",
  );
});

test("a new risk event during upload blocks one-step publish before submission", async () => {
  const context = await loadWorker();
  await context.__workerTest.setNetworkEntries([]);
  let submitTargetRequested = false;
  context.chrome.__test.pageHandler = async (_tabId, message) => {
    const responses = {
      ping: { ready: true },
      prepare_publish_tab: {
        ready: true,
        input_selector: "input[data-hongshuskill-upload='fixture']",
      },
      wait_upload: { uploaded: true },
      fill_publish_form: { status: "filled" },
      publish_setting_rect: { skip: true },
    };
    if (message.operation === "wait_publish_settings") {
      context.__workerTest.addRiskEvent({
        timestamp: Date.now(),
        status: 461,
        url: "https://creator.xiaohongshu.com/api/publish",
      });
      return fixturePublishSettings(message);
    }
    if (message.operation === "target_rect") submitTargetRequested = true;
    return responses[message.operation] ?? {};
  };
  await assert.rejects(
    () => context.__workerTest.OPERATIONS.publish_image({
      confirmed: true,
      title: "标题",
      content: "正文",
      tags: [],
      visibility: "公开可见",
      original: false,
      schedule_at: null,
      images: ["/tmp/a.png"],
    }),
    (error) => error?.code === "risk_control_active" && error?.details?.status === 461,
  );
  assert.equal(submitTargetRequested, false);
});

test("a visible publish risk warning is preserved as a write gate", async () => {
  const context = await loadWorker();
  await context.__workerTest.setNetworkEntries([]);
  context.chrome.__test.pageHandler = async (_tabId, message) => {
    const responses = {
      ping: { ready: true },
      prepare_publish_tab: {
        ready: true,
        input_selector: "input[data-hongshuskill-upload='fixture']",
      },
      wait_upload: { uploaded: true },
      fill_publish_form: { status: "filled" },
      publish_setting_rect: { skip: true },
      wait_publish_settings: fixturePublishSettings(message),
      target_rect: fixtureTarget("submit-publish"),
      observe_submission: {
        success: false,
        status: "risk_control",
        risk_control: true,
        message: "禁止发笔记",
        url: "https://creator.xiaohongshu.com/publish/publish",
      },
    };
    return responses[message.operation] ?? {};
  };
  const preview = await context.__workerTest.OPERATIONS.fill_image({
    confirmed: true,
    title: "标题",
    content: "正文",
    tags: [],
    visibility: "公开可见",
    original: false,
    schedule_at: null,
    images: ["/tmp/a.png"],
  });
  await assert.rejects(
    () => context.__workerTest.OPERATIONS.click_publish({
      confirmed: true,
      preview_id: preview.preview_id,
    }),
    (error) => (
      error?.code === "risk_control_active"
      && error?.message === "禁止发笔记"
      && error?.details?.status === 999
    ),
  );
  const log = await context.__workerTest.OPERATIONS.get_netlog({});
  assert.equal(log.risk_event_count, 1);
  assert.equal(log.risk_events[0].status, 999);
  await assert.rejects(
    () => context.__workerTest.OPERATIONS.save_draft({
      confirmed: true,
      preview_id: preview.preview_id,
    }),
    (error) => error?.code === "risk_control_active",
  );
});

test("a visible comment risk warning is preserved as a write gate", async () => {
  const context = await loadWorker();
  await context.__workerTest.setNetworkEntries([]);
  context.chrome.__test.pageHandler = async (_tabId, message) => {
    const responses = {
      ping: { ready: true },
      check_login: { logged_in: true },
      note_access: { accessible: true },
      risk_signals: {},
      comment_open_target: { skip: true },
      prepare_comment: {
        selector: fixtureSelector("comment-submit"),
        before_matches: 0,
      },
      wait_comment_sent: {
        success: false,
        status: "risk_control",
        risk_control: true,
        message: "操作频繁",
        url: "https://www.xiaohongshu.com/explore/feed-1?xsec_token=secret",
      },
    };
    return responses[message.operation] ?? {};
  };
  await assert.rejects(
    () => context.__workerTest.OPERATIONS.post_comment({
      confirmed: true,
      feed_id: "feed-1",
      xsec_token: "token-1",
      content: "评论",
    }),
    (error) => error?.code === "risk_control_active" && error?.details?.status === 999,
  );
  const log = await context.__workerTest.OPERATIONS.get_netlog({});
  assert.equal(log.risk_event_count, 1);
  assert.equal(log.risk_events[0].url.includes("xsec_token"), false);
});

test("comment and reply channel failures become uncertain only after final submit", async () => {
  for (const operation of ["post_comment", "reply_comment"]) {
    const context = await loadWorker();
    await context.__workerTest.setNetworkEntries([]);
    let finalTargetPrepared = false;
    let finalDispatches = 0;
    const base = context.chrome.__test.debuggerHandler;
    context.chrome.__test.debuggerHandler = async (target, method, params) => {
      if (
        finalTargetPrepared
        && method === "Input.dispatchMouseEvent"
        && params.type === "mouseReleased"
      ) finalDispatches += 1;
      return base(target, method, params);
    };
    context.chrome.__test.pageHandler = async (_tabId, message) => {
      if (message.operation === "ping") return { ready: true };
      if (message.operation === "check_login") return { logged_in: true };
      if (message.operation === "note_access") return { accessible: true };
      if (message.operation === "risk_signals") return {};
      if (message.operation === "comment_open_target") return { skip: true };
      if (message.operation === "reply_target") return fixtureTarget("comment-reply");
      if (message.operation === "prepare_comment") {
        finalTargetPrepared = true;
        return { ...fixtureTarget("comment-submit"), before_matches: 0 };
      }
      if (message.operation === "wait_comment_sent") {
        const error = new Error("page port closed with token=secret");
        error.code = "page_channel_disconnected";
        throw error;
      }
      return {};
    };
    await assert.rejects(
      () => context.__workerTest.OPERATIONS[operation]({
        confirmed: true,
        feed_id: "feed-1",
        xsec_token: "token-1",
        comment_id: operation === "reply_comment" ? "comment-1" : undefined,
        content: "评论",
      }),
      (error) => (
        error?.code === "operation_state_uncertain"
        && error?.details?.cause_code === "page_channel_disconnected"
        && Object.keys(error.details).sort().join(",") === "action,cause_code"
      ),
    );
    assert.equal(finalDispatches, 1);
  }

  const beforeContext = await loadWorker();
  await beforeContext.__workerTest.setNetworkEntries([]);
  beforeContext.chrome.__test.pageHandler = async (_tabId, message) => {
    if (message.operation === "ping") return { ready: true };
    if (message.operation === "check_login") return { logged_in: true };
    if (message.operation === "note_access") return { accessible: true };
    if (message.operation === "comment_open_target") return { skip: true };
    if (message.operation === "prepare_comment") {
      const error = new Error("评论表单尚未完成");
      error.code = "page_channel_disconnected";
      throw error;
    }
    return {};
  };
  await assert.rejects(
    () => beforeContext.__workerTest.OPERATIONS.post_comment({
      confirmed: true,
      feed_id: "feed-1",
      xsec_token: "token-1",
      content: "评论",
    }),
    (error) => error?.code === "page_channel_disconnected",
  );
});

test("like and favorite operations verify the target state after a trusted click", async () => {
  const context = await loadWorker();
  context.setTimeout = (callback) => { callback(); return 0; };
  await context.__workerTest.setNetworkEntries([]);
  let liked = false;
  let favorited = false;
  let pendingKind = "";
  const baseDebuggerHandler = context.chrome.__test.debuggerHandler;
  context.chrome.__test.debuggerHandler = async (target, method, params) => {
    if (method === "Input.dispatchMouseEvent" && params.type === "mouseReleased") {
      if (pendingKind === "like") liked = true;
      if (pendingKind === "favorite") favorited = true;
    }
    return baseDebuggerHandler(target, method, params);
  };
  context.chrome.__test.scriptHandler = async ({ args: [kind] }) => (
    kind === "detail"
      ? { note: { noteId: "feed-1", interactInfo: { liked, collected: favorited } } }
      : null
  );
  context.chrome.__test.pageHandler = async (_tabId, message) => {
    if (message.operation === "ping") return { ready: true };
    if (message.operation === "check_login") return { logged_in: true };
    if (message.operation === "note_access") return { accessible: true };
    if (message.operation === "interaction_state") {
      return { liked, favorited, like_known: true, favorite_known: true };
    }
    if (message.operation === "interaction_target") {
      pendingKind = message.params.kind;
      return {
        selector: fixtureSelector(`interaction-${pendingKind}`),
      };
    }
    return {};
  };
  const operations = context.__workerTest.OPERATIONS;
  const like = await operations.set_like({
    confirmed: true,
    feed_id: "feed-1",
    xsec_token: "token-1",
    target: true,
  });
  assert.equal(like.changed, true);
  assert.equal(like.liked, true);
  assert.deepEqual(plain(like.verification), {
    method: "reload_initial_state",
    persisted: true,
    transient_observed: true,
  });
  assert.equal((await operations.set_like({
    confirmed: true,
    feed_id: "feed-1",
    xsec_token: "token-1",
    target: true,
  })).changed, false);

  const favorite = await operations.set_favorite({
    confirmed: true,
    feed_id: "feed-1",
    xsec_token: "token-1",
    target: true,
  });
  assert.equal(favorite.changed, true);
  assert.equal(favorite.favorited, true);
  assert.deepEqual(plain(favorite.verification), {
    method: "reload_initial_state",
    persisted: true,
    transient_observed: true,
  });
});

test("an interaction channel failure after dispatch is uncertain while persistence failures stay typed", async () => {
  const context = await loadWorker();
  let fakeNow = 0;
  context.Date = class extends Date {
    static now() {
      fakeNow += 1000;
      return fakeNow;
    }
  };
  context.setTimeout = (callback) => { callback(); return 0; };
  await context.__workerTest.setNetworkEntries([]);
  let clicked = false;
  const baseDebuggerHandler = context.chrome.__test.debuggerHandler;
  context.chrome.__test.debuggerHandler = async (target, method, params) => {
    if (method === "Input.dispatchMouseEvent" && params.type === "mouseReleased") clicked = true;
    return baseDebuggerHandler(target, method, params);
  };
  const baseReload = context.chrome.tabs.reload;
  context.chrome.tabs.reload = async (...args) => {
    if (clicked) {
      const error = new Error("重载时页面通道断开");
      error.code = "page_channel_disconnected";
      throw error;
    }
    return baseReload(...args);
  };
  context.chrome.__test.scriptHandler = async ({ args: [kind] }) => (
    kind === "detail"
      ? { note: { noteId: "feed-1", interactInfo: { liked: false, collected: false } } }
      : null
  );
  context.chrome.__test.pageHandler = async (_tabId, message) => {
    if (message.operation === "ping") return { ready: true };
    if (message.operation === "check_login") return { logged_in: true };
    if (message.operation === "note_access") return { accessible: true };
    if (message.operation === "risk_signals") return {};
    if (message.operation === "interaction_state") {
      return {
        liked: false,
        favorited: false,
        like_known: true,
        favorite_known: true,
        like_evidence: "icon_exact",
        favorite_evidence: "icon_exact",
      };
    }
    if (message.operation === "interaction_target") return fixtureTarget("interaction-like");
    return {};
  };
  await assert.rejects(
    () => context.__workerTest.OPERATIONS.set_like({
      confirmed: true,
      feed_id: "feed-1",
      xsec_token: "token-1",
      target: true,
    }),
    (error) => (
      error?.code === "operation_state_uncertain"
      && error?.details?.cause_code === "page_channel_disconnected"
    ),
  );
});

test("reload verification accepts exact #like/#liked and #collect/#collected DOM evidence", async () => {
  const context = await loadWorker();
  let liked = false;
  let favorited = false;
  let pendingKind = "";
  const baseDebuggerHandler = context.chrome.__test.debuggerHandler;
  context.chrome.__test.debuggerHandler = async (target, method, params) => {
    if (method === "Input.dispatchMouseEvent" && params.type === "mouseReleased") {
      if (pendingKind === "like") liked = true;
      if (pendingKind === "favorite") favorited = true;
    }
    return baseDebuggerHandler(target, method, params);
  };
  context.chrome.__test.scriptHandler = async () => null;
  context.chrome.__test.pageHandler = async (_tabId, message) => {
    if (message.operation === "ping") return { ready: true };
    if (message.operation === "check_login") return { logged_in: true };
    if (message.operation === "note_access") return { accessible: true };
    if (message.operation === "risk_signals") return {};
    if (message.operation === "interaction_state") {
      return {
        liked,
        favorited,
        like_known: true,
        favorite_known: true,
        like_evidence: "icon_exact",
        favorite_evidence: "icon_exact",
      };
    }
    if (message.operation === "interaction_target") {
      pendingKind = message.params.kind;
      return fixtureTarget(`interaction-${pendingKind}`);
    }
    return {};
  };
  const likedResult = await context.__workerTest.OPERATIONS.set_like({
    confirmed: true,
    feed_id: "feed-1",
    xsec_token: "token-1",
    target: true,
  });
  assert.equal(likedResult.verification.method, "reload_dom_exact");
  assert.equal(likedResult.verification.persisted, true);
  const favoriteResult = await context.__workerTest.OPERATIONS.set_favorite({
    confirmed: true,
    feed_id: "feed-1",
    xsec_token: "token-1",
    target: true,
  });
  assert.equal(favoriteResult.verification.method, "reload_dom_exact");
  assert.equal(favoriteResult.verification.persisted, true);
});

test("trusted interaction clicks validate the owner but use the icon geometry", async () => {
  const context = await loadWorker();
  const calls = [];
  context.chrome.__test.debuggerHandler = async (_target, method, params) => {
    calls.push({ method, params });
    if (method === "DOM.getDocument") return { root: { nodeId: 1 } };
    if (method === "DOM.querySelector") {
      return { nodeId: params.selector.includes("anchor") ? 3 : 2 };
    }
    if (method === "DOM.resolveNode") return { object: { objectId: "object-1" } };
    if (method === "Runtime.callFunctionOn") {
      return {
        result: {
          value: {
            connected: true,
            selector_matches: true,
            visible: true,
            disabled: false,
            trapped: false,
          },
        },
      };
    }
    if (method === "DOM.getBoxModel") {
      return { model: { border: [20, 30, 40, 30, 40, 50, 20, 50] } };
    }
    return {};
  };

  const result = await context.__workerTest.debuggerClick({ tabId: 1 }, {
    selector: fixtureSelector("interaction-favorite"),
    anchor_selector: fixtureSelector("interaction-favorite", "anchor"),
  });
  assert.deepEqual(plain(result), { clicked: true });
  const boxModel = calls.find((call) => call.method === "DOM.getBoxModel");
  assert.equal(boxModel.params.nodeId, 3);
  const released = calls.find(
    (call) => call.method === "Input.dispatchMouseEvent" && call.params.type === "mouseReleased",
  );
  assert.equal(released.params.x, 30);
  assert.equal(released.params.y, 40);
});

test("trusted interaction clicks reject a mismatched geometry anchor", async () => {
  const context = await loadWorker();
  assert.throws(
    () => context.__workerTest.validateClickTarget({
      selector: fixtureSelector("interaction-favorite"),
      anchor_selector: fixtureSelector("interaction-like", "anchor"),
    }),
    (error) => error?.code === "click_target_invalid",
  );
  assert.throws(
    () => context.__workerTest.validateClickTarget({
      selector: '[data-hongshuskill-click="interaction-favorite"]',
    }),
    (error) => error?.code === "click_target_invalid",
  );
});

test("trusted clicks revalidate connectivity and visibility immediately before dispatch", async () => {
  const context = await loadWorker();
  const base = context.chrome.__test.debuggerHandler;
  context.chrome.__test.debuggerHandler = async (target, method, params) => {
    if (method === "Runtime.callFunctionOn" && /selector_matches/.test(params.functionDeclaration)) {
      return {
        result: {
          value: {
            connected: false,
            selector_matches: true,
            visible: true,
            disabled: false,
            trapped: false,
          },
        },
      };
    }
    return base(target, method, params);
  };
  await assert.rejects(
    () => context.__workerTest.debuggerClick({ tabId: 1 }, fixtureTarget("interaction-like")),
    (error) => error?.code === "click_target_invalid",
  );
});

test("a stale transient favorite state still reaches reload verification", async () => {
  const context = await loadWorker();
  let fakeNow = 0;
  context.Date = class extends Date {
    static now() {
      fakeNow += 1000;
      return fakeNow;
    }
  };
  context.setTimeout = (callback) => { callback(); return 0; };
  await context.__workerTest.setNetworkEntries([]);
  let clicked = false;
  let reloadedAfterClick = false;
  const baseReload = context.chrome.tabs.reload;
  context.chrome.tabs.reload = async (...args) => {
    if (clicked) reloadedAfterClick = true;
    return baseReload(...args);
  };
  const baseDebuggerHandler = context.chrome.__test.debuggerHandler;
  context.chrome.__test.debuggerHandler = async (target, method, params) => {
    if (method === "Input.dispatchMouseEvent" && params.type === "mouseReleased") clicked = true;
    return baseDebuggerHandler(target, method, params);
  };
  context.chrome.__test.scriptHandler = async ({ args: [kind] }) => (
    kind === "detail"
      ? {
          note: {
            noteId: "feed-1",
            interactInfo: {
              liked: true,
              collected: reloadedAfterClick ? false : true,
            },
          },
        }
      : null
  );
  context.chrome.__test.pageHandler = async (_tabId, message) => {
    if (message.operation === "ping") return { ready: true };
    if (message.operation === "check_login") return { logged_in: true };
    if (message.operation === "note_access") return { accessible: true };
    if (message.operation === "risk_signals") return {};
    if (message.operation === "interaction_state") {
      return {
        liked: true,
        favorited: reloadedAfterClick ? false : true,
        like_known: true,
        favorite_known: true,
        like_evidence: "icon_exact",
        favorite_evidence: "icon_exact",
      };
    }
    if (message.operation === "interaction_target") {
      return fixtureTarget("interaction-favorite");
    }
    return {};
  };

  const result = await context.__workerTest.OPERATIONS.set_favorite({
    confirmed: true,
    feed_id: "feed-1",
    xsec_token: "token-1",
    target: false,
  });
  assert.equal(result.changed, true);
  assert.equal(result.favorited, false);
  assert.deepEqual(plain(result.verification), {
    method: "reload_initial_state",
    persisted: true,
    transient_observed: false,
    transient_error_code: "state_not_changed",
  });
});

test("an optimistic unlike rollback is rejected after a cache-bypassing reload", async () => {
  const context = await loadWorker();
  context.setTimeout = (callback) => { callback(); return 0; };
  await context.__workerTest.setNetworkEntries([]);
  let optimisticLiked = true;
  let reloadedAfterClick = false;
  let clicked = false;
  const baseReload = context.chrome.tabs.reload;
  context.chrome.tabs.reload = async (...args) => {
    if (clicked) reloadedAfterClick = true;
    return baseReload(...args);
  };
  const baseDebuggerHandler = context.chrome.__test.debuggerHandler;
  context.chrome.__test.debuggerHandler = async (target, method, params) => {
    if (method === "Input.dispatchMouseEvent" && params.type === "mouseReleased") {
      clicked = true;
      optimisticLiked = false;
    }
    return baseDebuggerHandler(target, method, params);
  };
  context.chrome.__test.scriptHandler = async ({ args: [kind] }) => (
    kind === "detail"
      ? {
          note: {
            noteId: "feed-1",
            interactInfo: {
              liked: reloadedAfterClick ? true : optimisticLiked,
              collected: false,
            },
          },
        }
      : null
  );
  context.chrome.__test.pageHandler = async (_tabId, message) => {
    if (message.operation === "ping") return { ready: true };
    if (message.operation === "check_login") return { logged_in: true };
    if (message.operation === "note_access") return { accessible: true };
    if (message.operation === "risk_signals") return {};
    if (message.operation === "interaction_state") {
      return {
        liked: optimisticLiked,
        favorited: false,
        like_known: true,
        favorite_known: true,
      };
    }
    if (message.operation === "interaction_target") {
      return fixtureTarget("interaction-like");
    }
    return {};
  };

  await assert.rejects(
    () => context.__workerTest.OPERATIONS.set_like({
      confirmed: true,
      feed_id: "feed-1",
      xsec_token: "token-1",
      target: false,
    }),
    (error) => (
      error?.code === "state_not_persisted"
      && error?.details?.expected === false
      && error?.details?.observed === true
      && error?.details?.verification === "reload_exact_state"
      && error?.details?.evidence?.conflict === true
    ),
  );
});

test("structured interaction state is reported but conflicting DOM evidence fails closed", async () => {
  const context = await loadWorker();
  context.setTimeout = (callback) => { callback(); return 0; };
  await context.__workerTest.setNetworkEntries([]);
  let releasedClicks = 0;
  let structuredLiked = false;
  const baseDebuggerHandler = context.chrome.__test.debuggerHandler;
  context.chrome.__test.debuggerHandler = async (target, method, params) => {
    if (method === "Input.dispatchMouseEvent" && params.type === "mouseReleased") {
      releasedClicks += 1;
      structuredLiked = true;
    }
    return baseDebuggerHandler(target, method, params);
  };
  context.chrome.__test.scriptHandler = async ({ args: [kind] }) => (
    kind === "detail"
      ? { note: { noteId: "feed-1", interactInfo: { liked: structuredLiked, collected: false } } }
      : null
  );
  context.chrome.__test.pageHandler = async (_tabId, message) => {
    if (message.operation === "ping") return { ready: true };
    if (message.operation === "check_login") return { logged_in: true };
    if (message.operation === "note_access") return { accessible: true };
    if (message.operation === "risk_signals") return {};
    if (message.operation === "action_readiness") {
      return { like_available: true, favorite_available: true };
    }
    if (message.operation === "interaction_state") {
      return {
        liked: true,
        favorited: false,
        like_known: true,
        favorite_known: true,
      };
    }
    if (message.operation === "interaction_target") {
      return fixtureTarget("interaction-like");
    }
    return {};
  };

  const inspection = plain(await context.__workerTest.OPERATIONS.inspect_actions({
    feed_id: "feed-1",
    xsec_token: "token-1",
  }));
  assert.equal(inspection.liked, false);
  assert.equal(inspection.state_source, "initial_state");
  assert.deepEqual(inspection.state_evidence.liked, {
    value: false,
    source: "initial_state",
    conflict: true,
    initial_state: false,
    dom: true,
    dom_evidence: "unknown",
  });

  await assert.rejects(
    () => context.__workerTest.OPERATIONS.set_like({
      confirmed: true,
      feed_id: "feed-1",
      xsec_token: "token-1",
      target: false,
    }),
    (error) => (
      error?.code === "interaction_state_unknown"
      && error?.details?.evidence?.conflict === true
    ),
  );
  assert.equal(releasedClicks, 0);

  const changed = await context.__workerTest.OPERATIONS.set_like({
    confirmed: true,
    feed_id: "feed-1",
    xsec_token: "token-1",
    target: true,
  });
  assert.equal(changed.changed, true);
  assert.equal(changed.liked, true);
  assert.equal(releasedClicks, 1);
});

test("liking does not depend on the unrelated favorite state being readable", async () => {
  const context = await loadWorker();
  context.setTimeout = (callback) => { callback(); return 0; };
  await context.__workerTest.setNetworkEntries([]);
  let liked = false;
  const baseDebuggerHandler = context.chrome.__test.debuggerHandler;
  context.chrome.__test.debuggerHandler = async (target, method, params) => {
    if (method === "Input.dispatchMouseEvent" && params.type === "mouseReleased") liked = true;
    return baseDebuggerHandler(target, method, params);
  };
  context.chrome.__test.scriptHandler = async ({ args: [kind] }) => (
    kind === "detail"
      ? { note: { noteId: "feed-1", interactInfo: { liked } } }
      : null
  );
  context.chrome.__test.pageHandler = async (_tabId, message) => {
    if (message.operation === "ping") return { ready: true };
    if (message.operation === "check_login") return { logged_in: true };
    if (message.operation === "note_access") return { accessible: true };
    if (message.operation === "risk_signals") return {};
    if (message.operation === "interaction_state") {
      return { liked, like_known: true, favorite_known: false };
    }
    if (message.operation === "interaction_target") {
      return fixtureTarget("interaction-like");
    }
    return {};
  };
  const result = await context.__workerTest.OPERATIONS.set_like({
    confirmed: true,
    feed_id: "feed-1",
    xsec_token: "token-1",
    target: true,
  });
  assert.equal(result.changed, true);
  assert.equal(result.liked, true);
});

class FakeElement {
  constructor({ text = "", href = "", wrapper = null } = {}) {
    this.textContent = text;
    this.href = href;
    this.wrapper = wrapper;
    this.className = "";
    this.parentElement = null;
    this.attributes = new Map();
    this.dataset = {};
    this.disabled = false;
    this.classList = { contains: (name) => this.className.split(/\s+/).includes(name) };
  }

  getBoundingClientRect() {
    return { width: 20, height: 20, left: 0, top: 0 };
  }

  closest(selector) {
    if (selector.includes("data-hp-kind")) return null;
    if (selector.includes("like-wrapper") || selector.includes("collect-wrapper")) {
      return this.wrapper;
    }
    return null;
  }

  getAttribute(name) {
    if (name === "href" && this.href) return this.href;
    return this.attributes.get(name) ?? null;
  }

  setAttribute(name, value) { this.attributes.set(name, String(value)); }
  removeAttribute(name) { this.attributes.delete(name); }
  scrollIntoView() {}
  focus() {}
  click() {}
  dispatchEvent() {}
  querySelector() { return null; }
  querySelectorAll() { return []; }
  contains(element) { return element === this; }
  matches() { return false; }
}

async function loadPage() {
  const source = await readFile(resolve(ROOT, "extension/page.js"), "utf8");
  const marker = source.lastIndexOf("})();");
  assert.notEqual(marker, -1);
  const injected = `${source.slice(0, marker)}
    globalThis.__pageTest = {
      acceptsPublishMedia,
      activeRiskProbes,
      actionReadiness,
      checkLogin,
      domDetail,
      domProfile,
      domNoteContent,
      editorContentMatches,
      fillPublishForm,
      findReplyComment,
      feedFromCard,
      formatLongArticle,
      getQrCode,
      interactionClickElement,
      interactionState,
      interactionTarget,
      loadComments,
      longEditorIsEmpty,
      longDraftSnapshot,
      longFieldsMatch,
      matchingTopicSuggestion,
      noteAccess,
      normalizedFieldText,
      observeSubmission,
      parseLink,
      preparePhone,
      prepareLongImages,
      publishFieldsMatch,
      publishMediaObservation,
      publishSnapshot,
      publishSettingRect,
      riskSignals,
      safeLocationUrl,
      scheduleSwitch,
      scopedFeedbackText,
      targetRect,
      waitCommentSent,
      waitCodeSent,
      waitPublishSettings,
    };
  ${source.slice(marker)}`;
  let activeRange = null;
  const selection = {
    removeAllRanges() { activeRange = null; },
    addRange(range) { activeRange = range; },
  };
  const document = {
    body: { innerText: "" },
    hidden: false,
    title: "小红书",
    visibilityState: "visible",
    createElement() { return { getContext() { return null; } }; },
    createRange() {
      return {
        collapsed: false,
        element: null,
        collapse() { this.collapsed = true; },
        selectNodeContents(element) { this.element = element; },
      };
    },
    execCommand(command, _showUi, value) {
      if (command !== "insertText" || !activeRange?.element) return false;
      activeRange.element.textContent = activeRange.collapsed
        ? `${activeRange.element.textContent || ""}${value}`
        : value;
      return true;
    },
    getElementById() { return null; },
    querySelector() { return null; },
    querySelectorAll() { return []; },
  };
  const context = vm.createContext({
    chrome: { runtime: { onMessage: eventHook() } },
    crypto: webcrypto,
    document,
    Element: FakeElement,
    Event: class {},
    HTMLInputElement: class extends FakeElement {},
    HTMLTextAreaElement: class extends FakeElement {},
    InputEvent: class {},
    MouseEvent: class {},
    PointerEvent: class {},
    URL,
    clearTimeout,
    console,
    getComputedStyle() {
      return { display: "block", visibility: "visible", opacity: "1" };
    },
    location: {
      href: "https://www.xiaohongshu.com/explore/note-1",
      origin: "https://www.xiaohongshu.com",
      pathname: "/explore/note-1",
      search: "",
    },
    navigator: {
      deviceMemory: 8,
      hardwareConcurrency: 8,
      languages: ["zh-CN"],
      permissions: { async query() { return { state: "prompt" }; } },
      platform: "MacIntel",
      plugins: [{}],
      userAgent: "Mozilla/5.0 Chrome/140.0",
      webdriver: false,
    },
    outerHeight: 900,
    outerWidth: 1440,
    screen: { colorDepth: 24, height: 900, width: 1440 },
    setTimeout,
    TextEncoder,
  });
  context.window = context;
  context.getSelection = () => selection;
  vm.runInContext(injected, context, { filename: "page.js" });
  return context;
}

function setPageFeedback(context, text) {
  const feedback = new FakeElement({ text });
  const previous = context.document.querySelectorAll.bind(context.document);
  context.document.querySelectorAll = (selector) => (
    selector.includes("[role='alert']") ? [feedback] : previous(selector)
  );
  return feedback;
}

test("page helper parses note links and separates body from hashtag anchors", async () => {
  const context = await loadPage();
  const parsed = plain(context.__pageTest.parseLink(
    "/explore/note-123?xsec_token=token-123&xsec_source=pc_search",
  ));
  assert.deepEqual(parsed, {
    feed_id: "note-123",
    xsec_token: "token-123",
    xsec_source: "pc_search",
  });

  const clone = {
    textContent: "正文\n#咖啡 #周末",
    querySelectorAll() {
      return [{ remove() { clone.textContent = "正文"; } }];
    },
  };
  const root = {
    querySelectorAll() {
      return [new FakeElement({ text: "#咖啡" }), new FakeElement({ text: "#周末" })];
    },
    cloneNode() { return clone; },
  };
  context.document.querySelector = () => root;
  assert.deepEqual(plain(context.__pageTest.domNoteContent()), {
    body: "正文",
    tags: ["#咖啡", "#周末"],
  });
});

test("DOM feed cards preserve note and author xsec provenance", async () => {
  const context = await loadPage();
  const noteLink = new FakeElement({
    href: "https://www.xiaohongshu.com/explore/note-1?xsec_token=note-token&xsec_source=pc_search",
  });
  const authorLink = new FakeElement({
    href: "https://www.xiaohongshu.com/user/profile/user-1?xsec_token=author-token&xsec_source=pc_search",
  });
  const title = new FakeElement({ text: "标题" });
  const authorName = new FakeElement({ text: "作者" });
  const image = new FakeElement();
  image.src = "https://sns-img.example/cover.jpg";
  const count = new FakeElement({ text: "12" });
  const card = new FakeElement();
  card.querySelector = (selector) => {
    if (selector.includes("a.cover[href*='xsec_token']")) return noteLink;
    if (selector.includes(".author-wrapper a[href*='/user/profile/']")) return authorLink;
    if (selector === "a.cover img,img[data-xhs-img],img") return image;
    if (selector === "a.title,.title") return title;
    if (selector.includes(".author-wrapper .name")) return authorName;
    return null;
  };
  card.querySelectorAll = (selector) => (
    selector === ".like-wrapper .count" ? [count] : []
  );
  const feed = plain(context.__pageTest.feedFromCard(card, 0, "pc_feed"));
  assert.equal(feed.xsec_token, "note-token");
  assert.equal(feed.xsec_source, "pc_search");
  assert.equal(feed.author.user_id, "user-1");
  assert.equal(feed.author.xsec_token, "author-token");
  assert.equal(feed.author.xsec_source, "pc_search");
});

test("creator upload inputs accept generic image and video MIME declarations", async () => {
  const context = await loadPage();
  assert.equal(context.__pageTest.acceptsPublishMedia("image/*", "上传图文"), true);
  assert.equal(context.__pageTest.acceptsPublishMedia(".jpg,.png", "上传图文"), true);
  assert.equal(context.__pageTest.acceptsPublishMedia(".gif,.bmp,.svg", "上传图文"), true);
  assert.equal(context.__pageTest.acceptsPublishMedia("video/*", "上传视频"), true);
  assert.equal(context.__pageTest.acceptsPublishMedia(".flv,.mp4", "上传视频"), true);
  assert.equal(context.__pageTest.acceptsPublishMedia("image/*", "上传视频"), false);
});

test("topic selection matches the requested tag instead of a stale first suggestion", async () => {
  const context = await loadPage();
  const stale = new FakeElement({ text: "#旅行 120万浏览" });
  const expected = new FakeElement({ text: "#咖啡 80万浏览" });
  context.document.querySelectorAll = () => [stale, expected];
  assert.equal(context.__pageTest.matchingTopicSuggestion("咖啡"), expected);
  assert.equal(context.__pageTest.matchingTopicSuggestion("不存在"), null);
});

test("publish form preserves a plain hashtag when no platform topic suggestion exists", async () => {
  const context = await loadPage();
  const title = new context.HTMLInputElement();
  const editor = new FakeElement();
  context.document.querySelectorAll = (selector) => {
    if (selector === "div.d-input input") return [title];
    if (selector === "div.ql-editor") return [editor];
    return [];
  };
  context.setTimeout = (callback) => { callback(); return 0; };
  vm.runInContext(
    "Date.now = (() => { let value = 0; return () => (value += 1000); })()",
    context,
  );
  const result = plain(await context.__pageTest.fillPublishForm({
    title: "标题",
    content: "正文",
    tags: ["超小众标签"],
    visibility: "公开可见",
  }));
  assert.deepEqual(result.selected_tags, []);
  assert.deepEqual(result.plain_tags, ["超小众标签"]);
  assert.match(editor.textContent, /#超小众标签/);
});

test("publish form verification requires exact title and normalized body content", async () => {
  const context = await loadPage();
  const title = new context.HTMLInputElement();
  title.value = "标题";
  const editor = new FakeElement({ text: "第一段\n\n第二段" });
  assert.equal(context.__pageTest.publishFieldsMatch(title, editor, {
    title: "标题",
    content: "第一段\n\n第二段",
  }), true);
  assert.equal(context.__pageTest.publishFieldsMatch(title, editor, {
    title: "标题",
    content: "第一段\n第二段",
  }), false);
  title.value = "旧标题";
  assert.equal(context.__pageTest.publishFieldsMatch(title, editor, {
    title: "标题",
    content: "第一段\n第二段",
  }), false);
  title.value = "标题";
  editor.textContent = "第一段  第二段";
  assert.equal(context.__pageTest.publishFieldsMatch(title, editor, {
    title: "标题",
    content: "第一段 第二段",
  }), false);
});

test("publish snapshots retain only digests and still distinguish paragraph layout", async () => {
  const context = await loadPage();
  context.location.href = "https://creator.xiaohongshu.com/publish/publish?secret=discard";
  context.location.origin = "https://creator.xiaohongshu.com";
  context.location.pathname = "/publish/publish";
  const title = new context.HTMLInputElement();
  title.value = "私密标题";
  const tag = new FakeElement({ text: "私密标签" });
  const editor = new FakeElement({ text: "第一段\n\n第二段" });
  editor.querySelectorAll = (selector) => (
    selector.includes("/topic/") ? [tag] : []
  );
  const image = new FakeElement();
  image.src = "blob:private-media";
  image.matches = (selector) => selector === "img,video";
  const preview = new FakeElement();
  preview.querySelector = () => image;
  context.document.querySelectorAll = (selector) => {
    if (selector === "div.d-input input") return [title];
    if (selector === "div.ql-editor") return [editor];
    if (selector.includes(".img-preview-area")) return [preview];
    return [];
  };
  const settings = { visibility: "公开可见", original: false, schedule_at: null };
  const first = plain(await context.__pageTest.publishSnapshot(settings, "images", 1));
  const serialized = JSON.stringify(first);
  assert.equal(serialized.includes("私密标题"), false);
  assert.equal(serialized.includes("第一段"), false);
  assert.equal(serialized.includes("私密标签"), false);
  assert.equal(serialized.includes("blob:private-media"), false);
  assert.deepEqual(Object.keys(first.form).sort(), [
    "content_hash",
    "content_length",
    "tag_count",
    "tags_hash",
    "title_hash",
    "title_length",
  ]);
  editor.textContent = "第一\n段\n第二段";
  const second = plain(await context.__pageTest.publishSnapshot(settings, "images", 1));
  assert.notEqual(first.form.content_hash, second.form.content_hash);
  assert.equal(first.form.content_length, second.form.content_length);
});

test("long-form image upload selects a labeled control and never an arbitrary index", async () => {
  const context = await loadPage();
  const unrelated = new FakeElement({ text: "分割线" });
  const imageButton = new FakeElement({ text: "插入图片" });
  context.document.querySelectorAll = (selector) => (
    selector === "button.menu-item" ? [unrelated, imageButton] : []
  );
  const target = plain(await context.__pageTest.prepareLongImages());
  assert.match(target.selector, /^\[data-hongshuskill-click="long-image-[0-9a-f]{24}"\]$/);

  context.document.querySelectorAll = () => Array.from(
    { length: 12 },
    (_, index) => new FakeElement({ text: `无关按钮 ${index}` }),
  );
  await assert.rejects(
    () => context.__pageTest.prepareLongImages(),
    /找不到长文插图按钮/,
  );
});

test("long-form preparation refuses to overwrite an existing editor draft", async () => {
  const context = await loadPage();
  const title = new FakeElement();
  const editor = new FakeElement();
  title.value = "";
  assert.equal(context.__pageTest.longEditorIsEmpty(title, editor), true);
  title.value = "已有标题";
  assert.equal(context.__pageTest.longEditorIsEmpty(title, editor), false);
  title.value = "";
  editor.textContent = "已有正文";
  assert.equal(context.__pageTest.longEditorIsEmpty(title, editor), false);
});

test("long-form verification requires the intended title and body", async () => {
  const context = await loadPage();
  const title = new context.HTMLTextAreaElement();
  title.value = "长文标题";
  const editor = new FakeElement({ text: "第一段\n\n第二段" });
  assert.equal(context.__pageTest.longFieldsMatch(title, editor, {
    title: "长文标题",
    content: "第一段\n\n第二段",
  }), true);
  editor.textContent = "旧正文";
  assert.equal(context.__pageTest.longFieldsMatch(title, editor, {
    title: "长文标题",
    content: "第一段\n第二段",
  }), false);
  assert.equal(context.__pageTest.editorContentMatches(editor, "旧正文"), true);
});

test("long-form snapshots hash actual content, preserve line breaks, and bind inserted media", async () => {
  const context = await loadPage();
  const title = new context.HTMLTextAreaElement();
  title.value = "长文标题";
  const image = new FakeElement();
  image.src = "blob:fixture-image";
  image.matches = (selector) => selector === "img,video";
  const editor = new FakeElement({ text: "甲\n乙" });
  editor.querySelectorAll = (selector) => (selector === "img" ? [image] : []);
  context.document.querySelector = (selector) => {
    if (selector === "textarea[placeholder='输入标题']") return title;
    if (selector === ".tiptap.ProseMirror,.ProseMirror,div.ql-editor") return editor;
    return null;
  };
  context.document.querySelectorAll = () => [];
  const first = plain(await context.__pageTest.longDraftSnapshot());
  editor.textContent = "甲 乙";
  const second = plain(await context.__pageTest.longDraftSnapshot());
  assert.notEqual(first.content_hash, second.content_hash);
  assert.equal(first.content_length, second.content_length);
  assert.equal(first.media.count, 1);
  assert.equal(context.__pageTest.normalizedFieldText("甲\r\n乙"), "甲\n乙");
});

test("video upload readiness requires an observed video or cover preview", async () => {
  const context = await loadPage();
  assert.deepEqual(plain(context.__pageTest.publishMediaObservation("video", 1)), {
    type: "video",
    count: 0,
    ready: false,
    descriptors: [],
  });
});

test("an inaccessible profile and missing long-form templates fail explicitly", async () => {
  const context = await loadPage();
  context.location.pathname = "/user/profile/user-requested";
  context.location.href = "https://www.xiaohongshu.com/user/profile/user-requested";
  const accessAlert = new FakeElement({ text: "该账号包含私密笔记" });
  context.document.querySelectorAll = (selector) => (
    selector.includes("[role='alert']") ? [accessAlert] : []
  );
  await assert.rejects(
    () => context.__pageTest.domProfile({ limit: 2 }),
    /私密笔记/,
  );

  const formatButton = new FakeElement({ text: "一键排版" });
  context.document.querySelectorAll = (selector) => (
    selector === ".template-card" ? [] : [formatButton]
  );
  context.setTimeout = (callback) => { callback(); return 0; };
  vm.runInContext(
    "Date.now = (() => { let value = 0; return () => (value += 20000); })()",
    context,
  );
  await assert.rejects(
    () => context.__pageTest.formatLongArticle(),
    /排版模板加载超时/,
  );
});

test("DOM profile fallback preserves the requested user identity", async () => {
  const context = await loadPage();
  context.location.pathname = "/user/profile/user-requested";
  context.location.href = "https://www.xiaohongshu.com/user/profile/user-requested";
  const root = new FakeElement({ text: "测试用户" });
  const card = new FakeElement();
  context.document.querySelector = (selector) => {
    if (selector === ".user-name,.user-page-box,.user-info") return root;
    if (selector === ".user-name") return root;
    if (selector === "section.note-item,.note-item") return card;
    return null;
  };
  context.document.querySelectorAll = (selector) => {
    if (selector === "section.note-item,.note-item") return [card];
    return [];
  };
  const result = plain(await context.__pageTest.domProfile({
    limit: 1,
    user_id: "user-requested",
  }));
  assert.equal(result.profile.user_id, "user-requested");
  assert.equal(result.profile.nickname, "测试用户");
});

test("comment loader treats a zero reply threshold as unlimited and reaches the end", async () => {
  const context = await loadPage();
  context.setTimeout = (callback) => { callback(); return 0; };
  let visibleComments = 0;
  let replyClicks = 0;
  const commentsRoot = new FakeElement({ text: "评论" });
  const scroller = new FakeElement();
  scroller.scrollHeight = 5000;
  scroller.clientHeight = 500;
  let scrollTop = 0;
  Object.defineProperty(scroller, "scrollTop", {
    get() { return scrollTop; },
    set(value) {
      scrollTop = value;
      visibleComments = Math.min(3, visibleComments + 1);
    },
  });
  scroller.dispatchEvent = () => {};
  context.scrollBy = (_x, y) => {
    scroller.scrollTop = scroller.scrollTop + y;
    context.scrollY = scroller.scrollTop;
    context.pageYOffset = scroller.scrollTop;
  };
  const showMore = new FakeElement({ text: "展开 99 条回复" });
  showMore.click = () => { replyClicks += 1; };
  const end = new FakeElement({ text: "THE END" });
  context.document.scrollingElement = scroller;
  context.document.documentElement = scroller;
  context.document.querySelectorAll = (selector) => {
    if (selector === ".comments-container") return [commentsRoot];
    if (selector === ".note-scroller") return [scroller];
    if (selector === ".parent-comment") {
      return Array.from({ length: visibleComments }, () => new FakeElement());
    }
    if (selector === ".show-more") return [showMore];
    if (selector === ".end-container" && visibleComments >= 3) return [end];
    return [];
  };
  const result = plain(await context.__pageTest.loadComments({
    load_all_comments: true,
    click_more_replies: true,
    max_replies_threshold: 0,
    max_comment_items: 0,
    scroll_speed: "fast",
  }));
  assert.equal(result.reached_end, true);
  assert.equal(result.visible_comments, 3);
  assert.equal(result.skipped_replies, 0);
  assert.ok(result.expanded_replies >= 1);
  assert.ok(replyClicks >= 1);
});

test("publish setting target can turn off a stale schedule switch", async () => {
  const context = await loadPage();
  const switcher = new FakeElement();
  switcher.setAttribute("aria-checked", "true");
  const card = new FakeElement({ text: "定时发布" });
  card.querySelectorAll = (selector) => (selector === ".d-switch" ? [switcher] : []);
  context.document.querySelectorAll = (selector) => {
    if (selector === ".post-time-wrapper,.custom-switch-card") return [card];
    return [];
  };
  const disable = plain(await context.__pageTest.publishSettingRect({
    setting: "schedule_switch",
    enabled: false,
  }));
  assert.equal(disable.skip, false);
  assert.equal(disable.checked, true);
  assert.equal(disable.target_checked, false);
  assert.match(disable.selector, /^\[data-hongshuskill-click="schedule-switch-[0-9a-f]{24}"\]$/);

  const unchanged = plain(await context.__pageTest.publishSettingRect({
    setting: "schedule_switch",
    enabled: true,
  }));
  assert.equal(unchanged.skip, true);
  assert.equal(unchanged.checked, true);
});

test("missing schedule controls never fall back to an unrelated creator switch", async () => {
  const context = await loadPage();
  const unrelated = new FakeElement();
  unrelated.setAttribute("aria-checked", "true");
  const originalityCard = new FakeElement({ text: "原创声明" });
  originalityCard.querySelectorAll = (selector) => (
    selector === ".d-switch" ? [unrelated] : []
  );
  context.document.querySelectorAll = (selector) => {
    if (selector === ".post-time-wrapper,.custom-switch-card") return [originalityCard];
    if (selector === ".d-switch") return [unrelated];
    return [];
  };

  assert.equal(context.__pageTest.scheduleSwitch(), null);
  assert.equal(unrelated.getAttribute("data-hongshuskill-click"), null);
});

test("final submission never falls back to an unrelated generic publish button", async () => {
  const context = await loadPage();
  const unrelated = new FakeElement({ text: "发布" });
  context.document.querySelectorAll = (selector) => (
    selector === "button,[role='button']" ? [unrelated] : []
  );
  assert.throws(
    () => context.__pageTest.targetRect({ target: "publish" }),
    /找不到发布按钮/,
  );
  assert.equal(unrelated.getAttribute("data-hongshuskill-click"), null);

  const finalButton = new FakeElement({ text: "发布" });
  context.document.querySelectorAll = (selector) => (
    selector === ".publish-page-publish-btn button.bg-red" ? [finalButton] : []
  );
  const target = plain(context.__pageTest.targetRect({ target: "publish" }));
  assert.match(target.selector, /^\[data-hongshuskill-click="submit-publish-[0-9a-f]{24}"\]$/);
});

test("QR login returns only the local image and never exposes its decoded credential URL", async () => {
  const context = await loadPage();
  const image = new FakeElement();
  image.src = "data:image/png;base64,AA==";
  context.document.querySelectorAll = (selector) => (
    selector === "img.qrcode-img" ? [image] : []
  );
  let detectorConstructed = false;
  context.BarcodeDetector = class {
    constructor() { detectorConstructed = true; }
  };
  const result = plain(await context.__pageTest.getQrCode());
  assert.equal(result.data_url, image.src);
  assert.equal(result.status, "qrcode_ready");
  assert.equal(result.qr_login_url, undefined);
  assert.equal(detectorConstructed, false);
});

test("expired QR codes are refreshed and stale images are never returned", async () => {
  const context = await loadPage();
  const root = new FakeElement({ text: "二维码已过期" });
  const image = new FakeElement();
  image.src = "data:image/png;base64,OLD=";
  image.closest = (selector) => (
    selector.includes("login-container") || selector.includes("[role='dialog']") ? root : null
  );
  const refresh = new FakeElement({ text: "刷新二维码" });
  refresh.click = () => {
    root.textContent = "请扫码登录";
    image.src = "data:image/png;base64,NEW=";
  };
  root.querySelectorAll = (selector) => (
    selector === "button[class*='refresh']" ? [refresh] : []
  );
  context.document.querySelectorAll = (selector) => {
    if (selector === ".login-container") return [root];
    if (selector === "img.qrcode-img") return [image];
    return [];
  };
  const result = plain(await context.__pageTest.getQrCode());
  assert.equal(result.refreshed, true);
  assert.equal(result.data_url, "data:image/png;base64,NEW=");
});

test("expired QR codes fail closed when no refresh control exists", async () => {
  const context = await loadPage();
  const root = new FakeElement({ text: "二维码已失效" });
  const image = new FakeElement();
  image.src = "data:image/png;base64,OLD=";
  image.closest = (selector) => (
    selector.includes("login-container") || selector.includes("[role='dialog']") ? root : null
  );
  context.document.querySelectorAll = (selector) => {
    if (selector === ".login-container") return [root];
    if (selector === "img.qrcode-img") return [image];
    return [];
  };
  await assert.rejects(() => context.__pageTest.getQrCode(), /二维码已过期/);
});

test("login detection waits for and recognizes the visible profile marker", async () => {
  const context = await loadPage();
  const profile = new FakeElement({ text: "测试账号" });
  context.document.querySelectorAll = (selector) => (
    selector === ".main-container .user a[href*='/user/profile/']" ? [profile] : []
  );
  const result = plain(await context.__pageTest.checkLogin());
  assert.equal(result.logged_in, true);
  assert.equal(result.login_visible, false);
  assert.equal(result.nickname, "测试账号");
});

test("phone login never targets an unrelated page checkbox", async () => {
  const context = await loadPage();
  const loginBox = new FakeElement({ text: "登录" });
  const input = new context.HTMLInputElement();
  const unrelated = new context.HTMLInputElement();
  unrelated.checked = true;
  context.document.querySelectorAll = (selector) => {
    if (selector === ".login-container") return [loginBox];
    if (selector === "label.phone input") return [input];
    if (selector === "input[type='checkbox']:checked") return [unrelated];
    return [];
  };
  await assert.rejects(
    () => context.__pageTest.preparePhone({ phone: "13800138000" }),
    /无法安全定位用户协议/,
  );
  assert.equal(unrelated.getAttribute("data-hongshuskill-click"), null);
});

test("submission observer distinguishes platform risk from ordinary failure", async () => {
  const context = await loadPage();
  const feedback = setPageFeedback(context, "当前账号异常，禁止发笔记");
  const risk = plain(await context.__pageTest.observeSubmission({
    before_url: context.location.href,
    timeout_ms: 10,
  }));
  assert.equal(risk.risk_control, true);
  assert.equal(risk.status, "risk_control");

  feedback.textContent = "网络异常，请重试";
  const failure = plain(await context.__pageTest.observeSubmission({
    before_url: context.location.href,
    timeout_ms: 10,
  }));
  assert.equal(failure.risk_control, undefined);
  assert.equal(failure.status, "failed");
});

test("submission observer only accepts success evidence for the requested action", async () => {
  const context = await loadPage();
  setPageFeedback(context, "已保存到草稿箱");
  const draft = plain(await context.__pageTest.observeSubmission({
    before_url: context.location.href,
    timeout_ms: 1,
    target: "draft",
  }));
  assert.equal(draft.success, true);
  assert.equal(draft.status, "draft_saved");
  assert.equal(draft.action, "draft");

  context.setTimeout = (callback) => { callback(); return 0; };
  const publish = plain(await context.__pageTest.observeSubmission({
    before_url: context.location.href,
    timeout_ms: 1,
    target: "publish",
  }));
  assert.equal(publish.success, false);
  assert.equal(publish.status, "unconfirmed");
});

test("comment observer distinguishes page risk from ordinary failure", async () => {
  const context = await loadPage();
  context.location.href = "https://www.xiaohongshu.com/explore/note-1?xsec_token=secret";
  setPageFeedback(context, "当前操作频繁，请稍后再试");
  const risk = plain(await context.__pageTest.waitCommentSent({
    content: "测试评论",
    before_matches: 0,
  }));
  assert.equal(risk.risk_control, true);
  assert.equal(risk.status, "risk_control");
  assert.equal(risk.url, "https://www.xiaohongshu.com/explore/note-1");
});

test("an editor clearing by itself is not treated as confirmed comment success", async () => {
  const context = await loadPage();
  const editor = new FakeElement({ text: "" });
  context.document.querySelectorAll = (selector) => {
    if (selector === "div.input-box p.content-input") return [editor];
    return [];
  };
  context.setTimeout = (callback) => { callback(); return 0; };
  let clock = 0;
  context.Date = { now: () => { clock += 2000; return clock; } };
  const result = plain(await context.__pageTest.waitCommentSent({
    content: "测试评论",
    before_matches: 0,
  }));
  assert.equal(result.success, false);
  assert.equal(result.status, "unconfirmed");
  assert.equal(result.evidence, "editor_cleared_only");
});

test("正文、评论和编辑器文本 cannot impersonate scoped risk or success feedback", async () => {
  const context = await loadPage();
  context.document.body.innerText = "正文讨论：账号异常、禁止发笔记，但这只是文章内容。";
  context.setTimeout = (callback) => { callback(); return 0; };
  const submission = plain(await context.__pageTest.observeSubmission({
    before_url: context.location.href,
    timeout_ms: 1,
  }));
  assert.equal(submission.status, "unconfirmed");
  const report = plain(await context.__pageTest.riskSignals());
  assert.deepEqual(report.page_markers, []);

  const editorWarning = new FakeElement({ text: "操作频繁 发布成功" });
  editorWarning.closest = (selector) => (
    selector.includes("[contenteditable='true']") ? editorWarning : null
  );
  context.document.querySelectorAll = (selector) => (
    selector.includes("[role='alert']") ? [editorWarning] : []
  );
  assert.equal(context.__pageTest.scopedFeedbackText(), "");
});

test("reply lookup never falls back to a user match when a comment id was supplied", async () => {
  const context = await loadPage();
  let userSearchAttempted = false;
  context.document.getElementById = () => null;
  context.document.querySelectorAll = () => {
    userSearchAttempted = true;
    return [new FakeElement({ href: "/user/profile/user-1" })];
  };
  assert.equal(context.__pageTest.findReplyComment("missing-comment", "user-1"), null);
  assert.equal(userSearchAttempted, false);
});

test("page access detection distinguishes verification from missing content", async () => {
  const context = await loadPage();
  const feedback = setPageFeedback(context, "请使用小红书App扫码后继续");
  const verification = plain(await context.__pageTest.noteAccess());
  assert.equal(verification.accessible, false);
  assert.equal(verification.verification_required, true);

  feedback.textContent = "该笔记已被删除";
  const missing = plain(await context.__pageTest.noteAccess());
  assert.equal(missing.accessible, false);
  assert.equal(missing.verification_required, false);

  feedback.textContent = "该内容已失效";
  const expired = plain(await context.__pageTest.noteAccess());
  assert.equal(expired.accessible, false);
  assert.equal(expired.reason, "已失效");
});

test("DOM detail and profile fallbacks reject mismatched route identities", async () => {
  const context = await loadPage();
  await assert.rejects(
    () => context.__pageTest.domDetail({ feed_id: "another-note" }),
    /不是请求的笔记/,
  );
  context.location.pathname = "/user/profile/user-actual";
  context.location.href = "https://www.xiaohongshu.com/user/profile/user-actual";
  await assert.rejects(
    () => context.__pageTest.domProfile({ user_id: "user-requested" }),
    /不是请求的用户主页/,
  );
});

test("interaction state reads target state from visible icons", async () => {
  const context = await loadPage();
  const use = (href) => ({ getAttribute(name) { return ["href", "xlink:href"].includes(name) ? href : null; } });
  const likeWrapper = { className: "like-wrapper", querySelector() { return use("#liked"); } };
  const favoriteWrapper = { className: "collect-wrapper", querySelector() { return use("#collect"); } };
  const like = new FakeElement({ wrapper: likeWrapper });
  const favorite = new FakeElement({ wrapper: favoriteWrapper });
  const matches = new Map([
    [".interact-container .like-wrapper", [like]],
    [".interact-container .collect-wrapper", [favorite]],
  ]);
  context.document.querySelectorAll = (selector) => matches.get(selector) || [];
  const state = plain(context.__pageTest.interactionState());
  assert.deepEqual(state, {
    liked: true,
    favorited: false,
    like_known: true,
    favorite_known: true,
    like_evidence: "icon_exact",
    favorite_evidence: "icon_exact",
  });
});

test("like-active does not imply liked when the exact icon says inactive", async () => {
  const context = await loadPage();
  const use = { getAttribute() { return "#like"; } };
  const wrapper = new FakeElement();
  wrapper.className = "like-wrapper like-active";
  wrapper.querySelector = () => use;
  const like = new FakeElement({ wrapper });
  context.document.querySelectorAll = (selector) => (
    selector === ".interact-container .like-wrapper" ? [like] : []
  );
  assert.deepEqual(plain(context.__pageTest.interactionState()), {
    liked: false,
    like_known: true,
    favorite_known: false,
    like_evidence: "icon_exact",
    favorite_evidence: "unknown",
  });
});

test("interaction state accepts wrapper and aria state evidence", async () => {
  const context = await loadPage();
  const likeWrapper = new FakeElement();
  likeWrapper.className = "like-wrapper liked";
  likeWrapper.querySelector = () => null;
  const favoriteWrapper = new FakeElement();
  favoriteWrapper.className = "collect-wrapper";
  favoriteWrapper.setAttribute("aria-pressed", "true");
  favoriteWrapper.querySelector = () => null;
  const matches = new Map([
    [".interact-container .like-wrapper", [likeWrapper]],
    [".interact-container .collect-wrapper", [favoriteWrapper]],
  ]);
  context.document.querySelectorAll = (selector) => matches.get(selector) || [];

  assert.deepEqual(plain(context.__pageTest.interactionState()), {
    favorited: true,
    like_known: false,
    favorite_known: true,
    like_evidence: "class_positive",
    favorite_evidence: "aria_pressed",
  });
});

test("interaction clicks mark real wrappers instead of decorative icons", async () => {
  const context = await loadPage();
  const likeWrapper = new FakeElement();
  likeWrapper.className = "like-wrapper";
  const likeIcon = new FakeElement({ wrapper: likeWrapper });
  likeIcon.className = "like-lottie";
  const favoriteWrapper = new FakeElement();
  favoriteWrapper.className = "collect-wrapper";
  const favoriteIcon = new FakeElement({ wrapper: favoriteWrapper });
  favoriteIcon.className = "collect-icon";
  const matches = new Map([
    [".interact-container .left .like-lottie", [likeIcon]],
    [".interact-container .left .collect-icon", [favoriteIcon]],
  ]);
  context.document.querySelectorAll = (selector) => {
    if (selector === "[data-hongshuskill-click]") {
      return [likeWrapper, favoriteWrapper].filter(
        (element) => element.getAttribute("data-hongshuskill-click"),
      );
    }
    if (selector === "[data-hongshuskill-anchor]") {
      return [likeIcon, favoriteIcon].filter(
        (element) => element.getAttribute("data-hongshuskill-anchor"),
      );
    }
    return matches.get(selector) || [];
  };

  const likeTarget = plain(context.__pageTest.interactionTarget({ kind: "like" }));
  const likeMarker = likeWrapper.getAttribute("data-hongshuskill-click");
  assert.match(likeMarker, /^interaction-like-[0-9a-f]{24}$/);
  assert.equal(likeTarget.selector, `[data-hongshuskill-click="${likeMarker}"]`);
  assert.equal(likeTarget.anchor_selector, `[data-hongshuskill-anchor="${likeMarker}"]`);
  assert.equal(likeIcon.getAttribute("data-hongshuskill-click"), null);
  assert.equal(likeIcon.getAttribute("data-hongshuskill-anchor"), likeMarker);

  const favoriteTarget = plain(context.__pageTest.interactionTarget({ kind: "favorite" }));
  const favoriteMarker = favoriteWrapper.getAttribute("data-hongshuskill-click");
  assert.match(favoriteMarker, /^interaction-favorite-[0-9a-f]{24}$/);
  assert.equal(favoriteTarget.selector, `[data-hongshuskill-click="${favoriteMarker}"]`);
  assert.equal(favoriteTarget.anchor_selector, `[data-hongshuskill-anchor="${favoriteMarker}"]`);
  assert.equal(favoriteIcon.getAttribute("data-hongshuskill-click"), null);
  assert.equal(favoriteIcon.getAttribute("data-hongshuskill-anchor"), favoriteMarker);
  assert.equal(likeWrapper.getAttribute("data-hongshuskill-click"), null);
  assert.equal(likeIcon.getAttribute("data-hongshuskill-anchor"), null);

  const readiness = plain(await context.__pageTest.actionReadiness());
  assert.equal(readiness.like_target.resolved_to_ancestor, true);
  assert.equal(readiness.like_target.geometry_anchored, true);
  assert.equal(readiness.favorite_target.resolved_to_ancestor, true);
  assert.equal(readiness.favorite_target.geometry_anchored, true);
});

test("risk scan reports passive browser fingerprint dimensions without probes", async () => {
  const context = await loadPage();
  const report = plain(await context.__pageTest.riskSignals());
  assert.equal(report.fingerprints.webdriver, false);
  assert.equal(report.fingerprints.headless_user_agent, false);
  assert.deepEqual(report.fingerprints.outer_size, { width: 1440, height: 900 });
  assert.equal(report.fingerprints.visibility_state, "visible");
  assert.equal(report.captcha_visible, false);
  assert.equal(report.fingerprint_issues.some((item) => item.severity === "high"), false);

  context.document.visibilityState = "hidden";
  context.document.hidden = true;
  const background = plain(await context.__pageTest.riskSignals());
  const visibility = background.fingerprint_issues.find((item) => item.signal.includes("页面当前位于后台"));
  assert.equal(visibility.severity, "info");
});

test("active risk probes retain only status and numeric code from response bodies", async () => {
  const context = await loadPage();
  context.setTimeout = (callback) => { callback(); return 0; };
  const calls = [];
  context.fetch = async (url, options) => {
    calls.push({ url, options });
    const blocked = url.includes("custom-probe");
    return {
      status: blocked ? 461 : 200,
      ok: !blocked,
      async json() {
        return {
          code: blocked ? -9001 : 0,
          msg: blocked ? "risk fixture" : "ok",
          payload_secret: "must-not-be-retained",
        };
      },
    };
  };
  const report = plain(await context.__pageTest.activeRiskProbes({
    probe_urls: ["https://edith.xiaohongshu.com/api/custom-probe?secret=fixture"],
  }));
  assert.equal(calls.length, 4);
  assert.equal(calls[1].options.method, "POST");
  assert.deepEqual(JSON.parse(calls[1].options.body), {
    cursor_score: "",
    num: 1,
    refresh_type: 1,
    note_index: 1,
  });
  assert.equal(report.results[3].risk_blocked, true);
  assert.equal(report.results[3].xhs_code, -9001);
  assert.equal(Object.hasOwn(report.results[3], "xhs_msg"), false);
  assert.equal(JSON.stringify(report).includes("must-not-be-retained"), false);
});

test("risk scan exposes explicit publishing restrictions to the worker gate", async () => {
  const context = await loadPage();
  setPageFeedback(context, "当前账号禁止发笔记，请稍后再试");
  const report = plain(await context.__pageTest.riskSignals());
  assert.deepEqual(report.page_markers, ["禁止发笔记"]);
});
