from __future__ import annotations

import os
import stat
from pathlib import Path

import pytest

from scripts import cli
from scripts.hongshu import accounts
from scripts.hongshu.errors import InvalidInput


def identity(instance: str = "12" * 16, user_id: str = "user_123") -> dict:
    return {
        "instance_id": instance,
        "user_id": user_id,
        "nickname": "测试账号",
        "session_fingerprint": "ab" * 32,
    }


def test_registry_binds_routes_verifies_and_unbinds_without_cookie_data(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    config_dir = tmp_path / "private-config"
    monkeypatch.setenv("HONGSHUSKILL_CONFIG_DIR", str(config_dir))

    bound = accounts.bind_account("工作号", identity())
    assert bound["name"] == "工作号"
    assert accounts.resolve_routing(None)["instance_id"] == "12" * 16

    path = config_dir / "accounts.json"
    if os.name != "nt":
        assert stat.S_IMODE(path.stat().st_mode) == 0o600
    text = path.read_text(encoding="utf-8")
    assert "cookies" not in text.casefold()
    assert "phone" not in text.casefold()

    refreshed = identity()
    refreshed["session_fingerprint"] = "cd" * 32
    verified = accounts.verify_account("工作号", refreshed)
    assert verified["session_fingerprint"] == "cd" * 32

    removed = accounts.unbind_account("工作号")
    assert removed == {
        "name": "工作号",
        "unbound": True,
        "cookies_deleted": False,
        "profile_deleted": False,
    }


def test_multiple_accounts_require_explicit_routing(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setenv("HONGSHUSKILL_CONFIG_DIR", str(tmp_path / "config"))
    accounts.bind_account("A", identity("12" * 16, "user_a"))
    accounts.bind_account("B", identity("34" * 16, "user_b"))

    with pytest.raises(InvalidInput, match="--account"):
        accounts.resolve_routing(None)
    assert accounts.resolve_routing("B")["user_id"] == "user_b"


def test_profile_instance_cannot_be_bound_to_two_aliases(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setenv("HONGSHUSKILL_CONFIG_DIR", str(tmp_path / "config"))
    accounts.bind_account("A", identity())
    with pytest.raises(InvalidInput, match="Chrome Profile"):
        accounts.bind_account("B", identity())


def test_verify_rejects_different_platform_user(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setenv("HONGSHUSKILL_CONFIG_DIR", str(tmp_path / "config"))
    accounts.bind_account("A", identity())
    with pytest.raises(InvalidInput, match="不同"):
        accounts.verify_account("A", identity(user_id="other_user"))


def test_registry_refuses_symlink_target(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    config_dir = tmp_path / "config"
    config_dir.mkdir()
    target = tmp_path / "outside.json"
    target.write_text("{}", encoding="utf-8")
    try:
        (config_dir / "accounts.json").symlink_to(target)
    except OSError as exc:
        if os.name == "nt" and getattr(exc, "winerror", None) == 1314:
            pytest.skip("Windows symlink privilege is unavailable")
        raise
    monkeypatch.setenv("HONGSHUSKILL_CONFIG_DIR", str(config_dir))

    with pytest.raises(InvalidInput, match="符号链接"):
        accounts.load_registry()


def test_account_name_rejects_path_components() -> None:
    for value in ("../A", "A/B", "A\\B", "A\0B"):
        with pytest.raises(InvalidInput):
            accounts.require_account_name(value)


def test_cli_routes_registered_account_with_session_guard(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setenv("HONGSHUSKILL_CONFIG_DIR", str(tmp_path / "config"))
    accounts.bind_account("A", identity())
    captured: dict = {}

    def fake_call(operation, params, **kwargs):
        captured.update(operation=operation, params=params, **kwargs)
        return {"ok": True}

    monkeypatch.setattr(cli, "call", fake_call)
    args = type("Args", (), {"account": "A", "bridge_url": "ws://127.0.0.1:9345"})()
    assert cli._rpc(args, "fill_image", {"confirmed": True}) == {"ok": True}
    assert captured["target_instance_id"] == "12" * 16
    assert captured["account_guard"] == {
        "user_id": "user_123",
        "session_fingerprint": "ab" * 32,
    }


def test_cli_login_check_routes_without_stale_session_guard(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setenv("HONGSHUSKILL_CONFIG_DIR", str(tmp_path / "config"))
    accounts.bind_account("A", identity())
    captured: dict = {}

    def fake_call(operation, params, **kwargs):
        captured.update(operation=operation, params=params, **kwargs)
        return {"logged_in": True}

    monkeypatch.setattr(cli, "call", fake_call)
    args = type("Args", (), {"account": "A", "bridge_url": "ws://127.0.0.1:9345"})()
    cli._rpc(args, "check_login")
    assert captured["target_instance_id"] == "12" * 16
    assert captured["account_guard"] is None
