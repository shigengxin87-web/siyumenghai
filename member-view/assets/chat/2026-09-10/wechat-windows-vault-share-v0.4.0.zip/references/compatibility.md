# Windows WeChat Compatibility

## Support Matrix

| Component | Verified support |
|---|---|
| Operating system | Windows 10/11 x64 |
| Account scope | Current user's own logged-in desktop account |
| Database capture | WeChat `4.1.10.53`, `4.1.12.26`, `4.1.13.7` (modern hook); `4.1.13.x` series attempted with signature trial + adaptive locate |
| Voice | SILK V3 decode plus local faster-whisper `small` CPU transcription, with simplified-Chinese normalization |
| Images | legacy XOR, V1 fixed AES, V2 AES/XOR, and WXGF/HEVC full-resolution decode when the image key is present in WeChat memory |
| Agent surfaces | WorkBuddy MCP (stdio); compatible with any MCP client that supports `command` + `args` + `env` registration |

## Verified Database Profile

| WeChat | Weixin.dll SHA-256 | PBKDF2 RVA | Status |
|---|---|---:|---|
| 4.1.10.53 | `AB35CFBD7AA9514EC0530747CFC59CAE9DEB0DD46D953548D3CF01919C62A577` | `0x68831B0` | Hook boundary identified; every captured key must pass database page HMAC verification |
| 4.1.12.26 | `4914A621A810ECBC0A132B6FF8F612658CFCE323D3989B3E5FE32D4FF343BA46` | `0x561D730` | SQLCipher wrapper matched uniquely against 4.1.10.53; 20/20 local databases passed page-1 HMAC verification |
| 4.1.13.7 | `F4C4118D85EE743A0832C301288EDF77B041E02F84B73D7905FFE10090206D01` | n/a (modern) | Key passed via `call [rax+0x38]` at RVA `0x35DD332`; runtime-protected site, hook the preceding instruction at RVA `0x35DD32F` (`44 89 fa`); 19/19 local databases passed page-1 HMAC verification |

## Modern Capture Method (WeChat 4.1.13.x)

Legacy PBKDF2 prologue profiling does not work on 4.1.13.x. Instead
`capture_keys_modern.py`:

1. Tries the known hook site for the verified fingerprint, or a guarded
   series-trial site (`0x35DD32F`, byte guard `44 89`) for any 4.1.13.x build.
2. If the guard fails (recompiled build), scans the running process memory for
   the signature `44 89 fa ff 50 38` (mov edx,r15d ; call [rax+0x38]) and/or
   decodes surrounding instructions to locate candidate hook points.
3. Hooks the instruction **before** the key call (the call site itself is
   under runtime byte-rotation protection and cannot be intercepted).
4. Captures `r8`/`r9` (key pointer / length 32) as each database opens during
   login, then requires SQLCipher page-1 HMAC verification before saving.

Verified on `4.1.13.7`: 19/19 databases, including `chatbot\chatbot_message.db`.

## Observed Unsupported Builds

| WeChat | Weixin.dll SHA-256 | Status |
|---|---|---|
| 4.1.12.25 | `2E5348D7AEDB911D90B34925CD1CA753EF4833F619B14E739F357789F6A7FFC2` | Detected on Windows x64; PBKDF2 profile not validated, so key capture must hard-stop |

## Unsupported Builds

Do not reuse the RVA from another build. For each new `Weixin.dll`:

1. Record its SHA-256 fingerprint.
2. Locate the exact embedded `PKCS5_PBKDF2_HMAC` function boundary.
3. Record and validate a stable prologue.
4. Capture candidates only on the current user's process.
5. Accept a candidate only after SQLCipher page-1 HMAC verification.
6. Add a separate profile and regression fixture.

An unknown fingerprint is a hard stop, not a warning.

## Coverage Limits

Local coverage includes databases and cached media present under the current account's `xwechat_files` directory. It may exclude deleted, expired, server-only, not-yet-synchronized, or evicted media.

V2 images require a verified image key from the running desktop process. Opening the target image, including “view original” when available, usually loads the required key and file variant into memory/cache. Once decoded, the private cached output can be reused.
