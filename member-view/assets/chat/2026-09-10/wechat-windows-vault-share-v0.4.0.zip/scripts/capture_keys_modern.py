"""微信 4.1.13.x 新版密钥捕获器（供 4.1.13.7 / 4.1.13.12 及后续 4.1.13.x 小版本使用）。

背景
----
4.1.13.x 起微信改用自研封装层，老版(PBKDF2 prologue)捕获路线失效，报
`unknown Weixin.dll fingerprint`。实测（4.1.13.7）发现：数据库打开时，一段
固定代码序列装载 r8=密钥指针、r9=密钥长度(32)，随后在 0x35DD332 执行
`call [rax+0x38]` 把密钥传给解密层。

注意：
- 0x35DD332 的 call 位于微信"运行时保护"区域，字节会被周期性轮换，
  Frida 无法原地重定位；但其**前一条指令**（4.1.13.7 上为 0x35DD32F，
  `mov edx,r15d`）可以稳定挂载，且该点 r8/r9 已就位、与 call 之间无分支，
  语义等价。
- 不同小版本（如 4.1.13.12）若重新编译，RVA 可能漂移 → 本工具先试已知点
  （带字节校验，防止误挂），不匹配则自动在运行内存里扫描定位（learn），
  再按定位结果抓取。

用法（均由 WorkBuddy/用户按提示操作）:
    python capture_keys_modern.py auto                 # 一条龙：诊断+抓取
    python capture_keys_modern.py diag                 # 只看诊断与缺库情况
    python capture_keys_modern.py learn                # 自适应：扫描定位 hook 点
    python capture_keys_modern.py capture --site RVA   # 用指定 hook 点抓取
    python capture_keys_modern.py capture --site 0x35DD32F --no-kill

抓取流程（关键）:
    工具结束微信 → 用户手动双击启动并登录 → 全部数据库开库瞬间自动抓密钥。
"""
from __future__ import annotations

import argparse
import json
import re
import subprocess
import sys
import threading
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

import frida

from vault_common import (
    KEYS_FILE,
    collect_databases,
    discover_db_roots,
    file_sha256,
    load_keys,
    save_keys,
    verify_key,
    weixin_pids,
)

# ---------------------------------------------------------------------------
# 已知调用点表（fingerprint -> hook 点）。guard 为 hook 点处的期望前 2 字节，
# 用于防止因版本重编译把 hook 挂到错误位置。
# ---------------------------------------------------------------------------
KNOWN_SITES: dict[str, dict] = {
    # 4.1.13.7 —— 本机实测 19/19 全部验证通过
    "F4C4118D85EE743A0832C301288EDF77B041E02F84B73D7905FFE10090206D01": {
        "version": "4.1.13.7",
        "sites": [0x35DD32F],
        "guard": "4489",          # mov edx,r15d (44 89 fa)
        "note": "call [rax+0x38] @0x35DD332 有运行时保护，hook 其前一条指令",
    },
}

# 4.1.13.x 系列的"尝试点"：即使指纹未知也先试（同系列大概率同布局），带字节校验。
SERIES_TRIAL_SITES = [
    {"site": 0x35DD32F, "guard": "4489"},
]

WATCH_DEFAULT = 600        # 巡逻总秒数
POST_FIRST_SEEN = 240      # 微信出现后再等的秒数（覆盖全部库打开）
SITE_CACHE_NAME = "modern_sites_cache.json"

HOOK_JS = """
var SITES = %s;   // [{site: rva(number), guard: 'hex2'|null}]
var RETRY_MS = 100;
var MAX_TRY = 400;   // 400*100ms = 40s，覆盖运行时代码轮换
var state = {};

function hexOf(p, n) {
  try { return Array.from(new Uint8Array(p.readByteArray(n)))
    .map(x => x.toString(16).padStart(2, '0')).join(''); } catch (e) { return null; }
}

function tryInstall() {
  var mod = Process.findModuleByName('Weixin.dll');
  if (mod === null) { return false; }
  var remaining = 0;
  SITES.forEach(function (s) {
    if (state[s.site]) return;
    var p = mod.base.add(s.site);
    try {
      if (s.guard) {
        var g = Array.from(new Uint8Array(p.readByteArray(2)))
          .map(x => x.toString(16).padStart(2, '0')).join('');
        if (g.toLowerCase() !== s.guard.toLowerCase()) {
          send({type: 'guard-skip', site: s.site, got: g});
          state[s.site] = 'skip';
          return;
        }
      }
      Interceptor.attach(p, {
        onEnter: function () {
          // 此点 r8=密钥指针、r9=长度；下一指令即 call [rax+0x38]
          var len = this.context.r9.toInt32();
          if (len !== 32) return;
          var key = hexOf(this.context.r8, 32);
          if (key) send({type: 'key', key: key});
        }
      });
      state[s.site] = 'ok';
      send({type: 'hooked', site: s.site});
    } catch (e) {
      state[s.site] = 'retry';   // 运行时代码轮换中，稍后再试
      remaining++;
    }
  });
  SITES.forEach(function (s) { if (!state[s.site]) remaining++; });
  return remaining === 0;
}

var tries = 0;
(function retry() {
  tries++;
  var done = tryInstall();
  if (done || tries >= MAX_TRY) {
    if (!state.readySent) {
      state.readySent = true;
      send({type: 'ready'});
    }
    return;
  }
  setTimeout(retry, RETRY_MS);
})();
"""

# ---------------------------------------------------------------------------
# 辅助
# ---------------------------------------------------------------------------

def _latest_dll() -> Path | None:
    roots: list[Path] = []
    import winreg
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER,
                            r"Software\Microsoft\Windows\CurrentVersion\App Paths\Weixin.exe") as key:
            app_path = Path(winreg.QueryValue(key, None))
        if app_path.exists():
            roots.extend(app_path.parent.glob("*/Weixin.dll"))
            roots.append(app_path.parent / "Weixin.dll")
    except OSError:
        pass
    for base in (Path("C:/Program Files/Tencent/Weixin"),
                 Path("C:/Program Files (x86)/Tencent/Weixin")):
        if base.exists():
            roots.extend(base.glob("*/Weixin.dll"))
    files = sorted({p.resolve() for p in roots if p.is_file()})
    if not files:
        return None
    # 取版本号最高者
    def ver_key(p: Path) -> tuple:
        m = re.search(r"(\d+)\.(\d+)\.(\d+)\.(\d+)", str(p))
        return tuple(int(x) for x in m.groups()) if m else (0, 0, 0, 0)
    return max(files, key=ver_key)


def fingerprint(dll: Path | None) -> tuple[str, str] | None:
    if dll is None or not dll.is_file():
        return None
    return file_sha256(dll), dll.parent.name


def _find_main_pid() -> int | None:
    """返回加载了 Weixin.dll 的 Weixin.exe pid（主进程）。"""
    device = frida.get_local_device()
    JS = (
        "var mod = Process.findModuleByName('Weixin.dll');"
        "send({ok: mod !== null, base: mod ? mod.base.toString() : null});"
    )
    for pid in weixin_pids():
        try:
            session = device.attach(pid)
            script = session.create_script(JS)
            result = {}
            script.on("message", lambda m, d, r=result: r.update(m.get("payload", {})))
            script.load()
            session.detach()
            if result.get("ok"):
                return pid
        except Exception:
            continue
    return None


def _scan_sites_on_running(limit=5000) -> list[dict]:
    """自适应扫描：在运行中微信的内存里定位 `call [rax+0x38]` 前一条可挂指令。

    返回按匹配度排序的候选: [{site, score, desc}]。需微信已登录运行。
    """
    pid = _find_main_pid()
    if pid is None:
        print("[learn] 未发现正在运行的微信主进程 —— 请先双击打开微信并完成登录，再重试", flush=True)
        return []

    SCAN_JS = """
var LIMIT = %d;
var mod = Process.findModuleByName('Weixin.dll');
if (!mod) { send({type: 'no-mod'}); }
else {
  send({type: 'mod', base: mod.base.toString(), size: mod.size.toString()});
  var hits = [];
  try {
    Memory.scanSync(mod.base, mod.size, 'ff 50 38').forEach(function (m) {
      if (hits.length >= LIMIT) return;
      hits.push(m.address.sub(mod.base).toString());
    });
    send({type: 'hits', count: hits.length, list: hits});
  } catch (e) {
    send({type: 'scan-err', msg: '' + e});
  }
}
""" % limit

    # 4.1.13.x 实测特征：mov edx,r15d (44 89 fa) + call [rax+0x38] (ff 50 38)
    SIG = "4489faff5038"
    SIG_JS = """
var mod = Process.findModuleByName('Weixin.dll');
if (!mod) { send({type: 'no-mod'}); }
else {
  var out = [];
  try {
    Memory.scanSync(mod.base, mod.size, '%s').forEach(function (m) {
      out.push(m.address.sub(mod.base).toString());
    });
  } catch (e) {}
  send({type: 'sig', list: out});
}
""" % SIG

    device = frida.get_local_device()
    hits: list[int] = []
    sig_sites: list[int] = []
    mod_info = {}

    def on_msg(message, _data):
        if message.get("type") != "send":
            return
        p = message["payload"]
        if p.get("type") == "mod":
            mod_info.update(p)
        elif p.get("type") == "hits":
            hits.extend(int(x, 16) for x in p["list"])
        elif p.get("type") == "sig":
            sig_sites.extend(int(x, 16) for x in p["list"])
        elif p.get("type") == "scan-err":
            print(f"[learn] 扫描出错: {p['msg']}", flush=True)

    # 代码区有运行时轮换保护 → 多轮扫描，提高命中真实字节的几率
    for _round in range(4):
        for js in (SCAN_JS, SIG_JS):
            session = device.attach(pid)
            script = session.create_script(js)
            script.on("message", on_msg)
            script.load()
            time.sleep(0.8)
            session.detach()
        time.sleep(0.4)
    base = int(mod_info.get("base", "0x0"), 16)
    if not base or (not hits and not sig_sites):
        print(f"[learn] 未扫到候选。微信代码保护可能不同，无法自动定位。", flush=True)
        return []

    # 用 capstone 反汇编每个候选前的一小段，找真正的前一条指令
    try:
        from capstone import Cs, CS_ARCH_X86, CS_MODE_64
    except ImportError:
        print("[learn] 缺少 capstone，尝试安装...", flush=True)
        subprocess.run([sys.executable, "-m", "pip", "install", "capstone", "-q"], check=False)
        from capstone import Cs, CS_ARCH_X86, CS_MODE_64  # noqa

    DUMP_JS = r"""
rpc.exports = { dump: function (rva, n) {
  var mod = Process.findModuleByName('Weixin.dll');
  if (!mod) return null;
  try {
    var p = mod.base.add(parseInt(rva, 16));
    return Array.from(new Uint8Array(p.readByteArray(n)));
  } catch (e) { return null; }
} };
"""

    session = device.attach(pid)
    script = session.create_script(DUMP_JS)
    script.load()
    md = Cs(CS_ARCH_X86, CS_MODE_64)
    dump = script.exports_sync.dump

    candidates: list[dict] = []
    seen_sites: set[int] = set()
    # 最高优先级：特征字节序列命中（对应 4.1.13.7 实测传密钥点，同系列大概率一致）
    for s in sig_sites:
        if s in seen_sites:
            continue
        seen_sites.add(s)
        candidates.append({
            "site": s, "call": s + 3, "score": 0, "guard": "4489",
            "desc": "signature mov edx,r15d + call [rax+0x38]",
        })
        if len(candidates) >= 200:
            break
    total_scanned = 0
    for hit in hits:
        if len(candidates) >= 200:
            break
        total_scanned += 1
        # 从 hit-1..hit-16 由近到远找：优先取紧贴 call 的那条（最可能是真前一条）
        for back in range(1, 17):
            start = hit - back
            if start <= 0:
                continue
            try:
                raw = dump(hex(start), back + 3)
            except Exception:
                continue
            if not raw:
                break
            buf = bytes(raw)
            insns = list(md.disasm(buf, start))
            prev = None
            call_insn = None
            for insn in insns:
                if insn.address == hit and insn.mnemonic == "call":
                    call_insn = insn
                if insn.address + insn.size == hit:
                    prev = insn  # 恰好结束于 call 起始处的指令 = 前一条
            if call_insn is None:
                continue
            if prev is None or prev.mnemonic not in ("mov", "lea", "nop"):
                break
            # 粗过滤：call 目标为 vtable 偏移 [reg+0x28..0x48]
            if not re.search(r"\[[a-z0-9]+ \+ 0x(2[89a-f]|3[0-9a-f]|4[0-9a-f])\]", call_insn.op_str):
                break
            site = prev.address
            if site in seen_sites:
                break
            seen_sites.add(site)
            candidates.append({
                "site": site,
                "call": hit,
                "score": back,
                "desc": f"prev={prev.mnemonic} {prev.op_str} | call {call_insn.op_str}",
            })
            break
    session.detach()

    candidates.sort(key=lambda c: c["score"])
    print(f"[learn] 扫描到候选 hook 点 {len(candidates)} 个（扫描命中 {total_scanned} 处）", flush=True)
    for c in candidates[:12]:
        print(f"    site=0x{c['site']:x}  call@0x{c['call']:x}  {c['desc']}", flush=True)
    return candidates


# ---------------------------------------------------------------------------
# 抓取循环
# ---------------------------------------------------------------------------

def _run_capture(sites: list[dict], databases, verified: dict, watch: int, no_kill: bool,
                 captured_new: dict, hook_log: list[str]) -> tuple[int, list[str]]:
    """sites: [{'site':int,'guard':str|None}]；杀微信→武装→等用户启动→抓密钥。"""
    import os
    device = frida.get_local_device()
    lock = threading.Lock()
    sessions: list = []
    hooked_pids: set[int] = set()
    first_seen = None

    if not no_kill:
        subprocess.run(["taskkill", "/IM", "Weixin.exe", "/F"],
                       capture_output=True, encoding="gbk", errors="replace")
        print("[工具] 已结束微信 —— 请现在手动双击启动微信并完成登录", flush=True)
        time.sleep(2)

    sites_js = json.dumps([{"site": s["site"], "guard": s.get("guard")} for s in sites])

    def make_handler(pid):
        def on_message(message, _data):
            if message.get("type") != "send":
                return
            p = message["payload"]
            t = p.get("type")
            if t == "ready":
                hook_log.append(f"[pid{pid}] hook 就绪（等待开库）")
                print(f"[pid{pid}] hook 就绪（等待开库）", flush=True)
            elif t == "hooked":
                pass
            elif t == "guard-skip":
                hook_log.append(f"[pid{pid}] 字节校验不符，跳过 site=0x{p['site']:x} (got {p['got']})")
            elif t == "retry-site":
                hook_log.append(f"[pid{pid}] site=0x{p['site']:x} 轮换中，稍后重试")
            elif t == "key":
                try:
                    key = bytes.fromhex(p["key"])
                except ValueError:
                    return
                if len(key) != 32:
                    return
                with lock:
                    for rel, path, page in databases:
                        if rel in verified:
                            continue
                        if verify_key(key, page):
                            verified[rel] = {
                                "enc_key": key.hex(),
                                "salt": page[:16].hex(),
                                "size_mb": round(path.stat().st_size / 1024 / 1024, 1),
                            }
                            captured_new[rel] = verified[rel]
                            print(f"  [捕获] {rel}", flush=True)
        return on_message

    deadline = time.monotonic() + watch
    while time.monotonic() < deadline:
        for pid in weixin_pids():
            if pid in hooked_pids:
                continue
            hooked_pids.add(pid)
            if first_seen is None:
                first_seen = time.monotonic()
            try:
                session = device.attach(pid)
                script = session.create_script(HOOK_JS % sites_js)
                script.on("message", make_handler(pid))
                script.load()
                sessions.append(session)
            except Exception:
                pass
        if first_seen and time.monotonic() - first_seen > POST_FIRST_SEEN:
            break
        time.sleep(2)

    for s in sessions:
        try:
            s.detach()
        except Exception:
            pass
    return 0, hook_log


def _cache_sites(fingerprint_short: str, sites: list[dict]) -> None:
    cache = Path(KEYS_FILE).parent / SITE_CACHE_NAME
    data = {}
    if cache.is_file():
        try:
            data = json.loads(cache.read_text(encoding="utf-8"))
        except Exception:
            data = {}
    data[fingerprint_short] = [{"site": s["site"], "guard": s.get("guard"),
                                "desc": s.get("desc", "")} for s in sites]
    cache.write_text(json.dumps(data, indent=1, ensure_ascii=False), encoding="utf-8")


def _load_cached_sites(fingerprint_short: str) -> list[dict]:
    cache = Path(KEYS_FILE).parent / SITE_CACHE_NAME
    if not cache.is_file():
        return []
    try:
        data = json.loads(cache.read_text(encoding="utf-8"))
    except Exception:
        return []
    return [{"site": s["site"], "guard": s.get("guard"), "desc": s.get("desc", "")}
            for s in data.get(fingerprint_short, [])]


# ---------------------------------------------------------------------------
# 主流程
# ---------------------------------------------------------------------------

def cmd_diag() -> int:
    roots = discover_db_roots()
    if not roots:
        print("未找到微信数据目录（Documents\\xwechat_files\\*/db_storage）。")
        print("请确认微信已登录过，或用 --db-root 指定。")
        return 1
    root = roots[0]
    databases = collect_databases(root)
    existing = load_keys()
    verified = {k: v for k, v in existing.items() if not k.startswith("_")}
    print(f"数据目录: {root}")
    print(f"数据库 {len(databases)} 个 | 已有可用密钥 {len(verified)} 个")
    missing = [rel for rel, _p, _pg in databases if rel not in verified]
    print(f"缺密钥的库: {missing if missing else '无——全部可读'}")
    dll = _latest_dll()
    info = fingerprint(dll) if dll else None
    if info:
        fp, ver = info
        print(f"微信版本目录: {ver}")
        print(f"DLL 指纹: {fp[:16]}...")
        known = KNOWN_SITES.get(fp)
        if known:
            print(f"  该指纹在已知表中（{known['version']}），可直接抓取。")
        else:
            print("  该指纹未知 → 将尝试 4.1.13.x 试抓点，失败则自动扫描定位。")
    else:
        print("未找到 Weixin.dll（微信是否已安装？）")
    return 0 if not missing else 2


def cmd_auto(args) -> int:
    dll = _latest_dll()
    info = fingerprint(dll) if dll else None
    fp = info[0] if info else None
    root = discover_db_roots()[0] if discover_db_roots() else None
    if root is None:
        print("未找到微信数据目录，先确认微信登录过。")
        return 1
    databases = collect_databases(root)
    existing = load_keys()
    verified = {k: v for k, v in existing.items() if not k.startswith("_")}
    missing = [rel for rel, _p, _pg in databases if rel not in verified]
    print(f"数据库 {len(databases)} 个 | 已有 {len(verified)} | 缺 {len(missing)}", flush=True)
    if not missing:
        print("全部数据库均可读，无需抓取。", flush=True)
        return 0
    if fp is None:
        print("未找到 Weixin.dll，无法继续。", flush=True)
        return 1
    ver = info[1]

    sites: list[dict] = []
    known = KNOWN_SITES.get(fp)
    if known:
        print(f"[{ver}] 命中已知表: {known['version']}", flush=True)
        sites = [{"site": s, "guard": known["guard"]} for s in known["sites"]]
    else:
        # 未知版本：先试 4.1.13.x 系列试抓点（带字节校验，防误挂）
        trial = [{"site": s["site"], "guard": s["guard"]} for s in SERIES_TRIAL_SITES]
        print(f"[{ver}] 指纹未知，先用 4.1.13.x 试抓点(带字节校验)快速尝试…", flush=True)
        # 快速探测：当前运行中的微信若代码特征匹配 → 直接可用
        pid = _find_main_pid()
        if pid is not None:
            match = _probe_series_trial(pid, trial)
            if match:
                print(f"  特征匹配! 使用 site=0x{match['site']:x}", flush=True)
                sites = [match]
            else:
                print("  试抓点特征不匹配（版本重编译），转入自动扫描定位…", flush=True)
        else:
            sites = trial  # 微信没开，先进巡逻，靠 guard 拦截误挂

    if not sites:
        # 自适应 learn（需要微信在运行）
        cands = _scan_sites_on_running()
        if not cands:
            print("\n无法自动定位 hook 点。微信可能未运行或代码保护差异。", flush=True)
            print("处理建议：", flush=True)
            print("  1) 确认微信已打开并登录后重试本命令；", flush=True)
            print("  2) 若仍失败：降级微信到 4.1.11.25（旧版本工具完全支持）→ 抓密钥 → 再升回新版。", flush=True)
            print("     （密钥跨版本有效，升级后旧密钥仍能解开原有数据库）", flush=True)
            return 2
        sites = [{"site": c["site"], "guard": c.get("guard"), "desc": c["desc"]} for c in cands]
        _cache_sites(fp[:16], sites)

    # 若存在带字节校验的精确点位(signature/已知)，只保留它们，避免 200 个冗余 hook
    guarded = [s for s in sites if s.get("guard")]
    if guarded and len(guarded) < len(sites):
        print(f"  命中精确特征点位 {len(guarded)} 个，仅使用精确点位", flush=True)
        sites = guarded

    # 若仍无 site 且巡逻态 → 上面已设 trial
    captured_new: dict[str, dict] = {}
    hook_log: list[str] = []
    _run_capture(sites, databases, verified, args.watch, args.no_kill, captured_new, hook_log)

    print("\n=== 结果 ===", flush=True)
    print(f"新捕获 {len(captured_new)} 个: {sorted(captured_new) if captured_new else '无'}", flush=True)
    still = [rel for rel, _p, _pg in databases if rel not in verified]
    print(f"仍缺密钥: {still if still else '无——全部搞定!'}", flush=True)

    if captured_new:
        result = dict(sorted(verified.items()))
        result["_db_dir"] = str(root)
        result["_capture_profile"] = {
            "method": "callsite-hook(modern)",
            "fingerprint": fp,
            "sites": [{"site": hex(s["site"]), "guard": s.get("guard")} for s in sites],
        }
        save_keys(result)
        print(f"已合并写入密钥库: {KEYS_FILE}", flush=True)
    if still:
        print("\n提示: 仍缺的库多为本版本新增库。可降级到 4.1.11.25 抓密钥后升回，或联系工具维护者。", flush=True)
        return 2
    return 0


def _probe_series_trial(pid: int, trial: list[dict]) -> dict | None:
    """探测运行中的微信：试抓点字节校验是否匹配。"""
    JS = """
var TRIAL = %s;
var mod = Process.findModuleByName('Weixin.dll');
if (!mod) { send({type: 'no-mod'}); }
else {
  TRIAL.forEach(function (t) {
    try {
      var g = Array.from(new Uint8Array(mod.base.add(t.site).readByteArray(2)))
        .map(x => x.toString(16).padStart(2, '0')).join('');
      send({type: 'byte', site: t.site, got: g, want: t.guard});
    } catch (e) {}
  });
}
""" % json.dumps(trial)
    device = frida.get_local_device()
    try:
        session = device.attach(pid)
        script = session.create_script(JS)
        result = {}
        script.on("message", lambda m, d, r=result: r.update({m["payload"]["site"]: m["payload"]})
                  if m.get("type") == "send" and m["payload"].get("type") == "byte" else None)
        script.load()
        session.detach()
    except Exception:
        return None
    for t in trial:
        p = result.get(t["site"])
        if p and p.get("got", "").lower() == t.get("guard", "").lower():
            return {"site": t["site"], "guard": t["guard"]}
    return None


def main() -> int:
    parser = argparse.ArgumentParser(description="微信 4.1.13.x 新版密钥捕获")
    parser.add_argument("mode", nargs="?", default="auto",
                        choices=["auto", "diag", "learn", "capture"])
    parser.add_argument("--site", help="capture 模式指定 hook RVA，如 0x35DD32F")
    parser.add_argument("--watch", type=int, default=WATCH_DEFAULT)
    parser.add_argument("--no-kill", action="store_true")
    parser.add_argument("--db-root")
    args = parser.parse_args()

    if args.mode == "diag":
        return cmd_diag()
    if args.mode == "learn":
        cands = _scan_sites_on_running()
        if cands:
            fp = fingerprint(_latest_dll())
            short = fp[0][:16] if fp else "unknown"
            _cache_sites(short, [{"site": c["site"], "guard": c.get("guard"), "desc": c["desc"]} for c in cands])
            print(f"已缓存 {len(cands)} 个候选。接着运行: python capture_keys_modern.py auto")
        return 0 if cands else 2
    if args.mode == "capture":
        if not args.site:
            print("capture 模式需要 --site 0xRVA")
            return 2
        try:
            site = int(args.site, 16)
        except ValueError:
            print("--site 需为十六进制，如 0x35DD32F")
            return 2
        root = args.db_root or (discover_db_roots() or [None])[0]
        if root is None:
            print("未找到微信数据目录")
            return 1
        from pathlib import Path as _P
        root = _P(root)
        databases = collect_databases(root)
        existing = load_keys()
        verified = {k: v for k, v in existing.items() if not k.startswith("_")}
        captured_new: dict[str, dict] = {}
        hook_log: list[str] = []
        _run_capture([{"site": site, "guard": None}], databases, verified,
                     args.watch, args.no_kill, captured_new, hook_log)
        print(f"\n新捕获 {len(captured_new)} 个", flush=True)
        if captured_new:
            result = dict(sorted(verified.items()))
            result["_db_dir"] = str(root)
            result["_capture_profile"] = {"method": "callsite-hook(manual)", "site": hex(site)}
            save_keys(result)
        return 0 if captured_new else 2
    return cmd_auto(args)


if __name__ == "__main__":
    raise SystemExit(main())
