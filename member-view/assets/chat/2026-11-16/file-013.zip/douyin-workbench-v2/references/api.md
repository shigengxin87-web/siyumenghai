# 公网接口（2026-10-29 对照网页脚本）

根地址 https://siyumenghai.cn/api/douyin 。JSON POST，120秒超时，无客户端密钥。

| 路径 | 请求 | 响应 |
|---|---|---|
| parse | url：单条分享链接/文案 | id, description, author, created_at, stats, cover, video, images, web_url |
| profile | target：主页/短链/sec_uid | nickname, signature, stats, web_url 等 |
| posts | target, count 1–50, cursor | items, cursor, has_more |
| mix | target：合集/作品链接/数字ID, count, cursor | items, cursor, has_more |
| comments | id：作品ID, count, cursor | items, cursor, has_more |
| health（GET） | 无 | configured, verified, cooldown_seconds, last_success |
| media/{ticket}（GET） | 临时票据 | 支持 Range 的媒体文件，过期410 |

仅接收本站 HTTPS 媒体路径，禁止外域/内网下载地址与重定向。服务返回字段仍需校验，不能只凭 HTTP 200 判断成功。素材默认512MB上限。

分页每页保存，拒绝未推进或循环游标；连续页间隔15秒；最多100页/次，可手动继续。has_more 为真时不能称为完整提取。

服务端 Cookie 和后台维护由服务所有者负责，客户端不读取用户浏览器 Cookie。遇到鉴权、风控、验证码、限流直接报告，不尝试绕过。

数据中的 video/cover/images 为临时票据，并非永久资源。data.json 留存它们供本次排障，分享成果时优先分享实际下载文件与清理后的资料。
