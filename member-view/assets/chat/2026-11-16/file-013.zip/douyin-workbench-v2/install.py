#!/usr/bin/env python3
"""Install the entire folder; never overwrite an existing installation."""
import argparse
import os
from pathlib import Path
import shutil
import sys

def main():
    p = argparse.ArgumentParser(description=__doc__)
    group = p.add_mutually_exclusive_group(required=True)
    group.add_argument("--client", choices=["codex","claude"])
    group.add_argument("--target",help="Confirmed skill parent directory, e.g. WorkBuddy's actual directory")
    a = p.parse_args()
    if sys.version_info < (3,9):
        p.error("需要 Python 3.9+")
    source = Path(__file__).resolve().parent
    if a.target:
        parent = Path(a.target).expanduser().resolve()
    elif a.client == "codex":
        parent = Path(os.environ.get("CODEX_HOME", str(Path.home()/".codex"))).expanduser()/"skills"
    else:
        parent = Path.home()/".claude"/"skills"
    dest = parent.resolve()/"download-douyin-workbench"
    if dest == source:
        print("已在目标目录："+str(dest))
        return
    if source in dest.parents:
        p.error("目标不能在源文件夹内部")
    if dest.exists():
        p.error("已有同名技能，未覆盖。请备份到 skills 目录之外后再安装。")
    if not (source/"scripts"/"workbench.py").is_file():
        p.error("压缩包不完整，不能只复制 SKILL.md")
    parent.mkdir(parents=True, exist_ok=True)
    shutil.copytree(source,dest,ignore=shutil.ignore_patterns("__pycache__","*.pyc",".DS_Store"))
    print("安装完成："+str(dest))
    print("重新打开会话，并确认客户端可发现此技能；下载视频前须检测 ffprobe。")
if __name__ == "__main__":
    main()
