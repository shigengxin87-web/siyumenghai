# 抖音下载工作台 Skill

石更新分享。把抖音链接发给 AI，保存视频、封面、图集与资料，也可查询博主、作品列表、合集和公开评论。

## 安装：使用完整 ZIP

**WorkBuddy：** 打开「专家·技能·连接器 → 技能 → 添加技能 → 上传技能」，选择 ZIP，再让 AI 检查依赖。[官方安装说明](https://www.codebuddy.cn/docs/workbuddy/From-Beginner-to-Expert-Guide/Function-Description/Skills-Market)明确区分市场技能的对话安装与自定义包上传。

**Claude 网页/桌面版：** 在 Customize → Skills → + Create skill → Upload a skill 上传 ZIP 并启用；需允许代码执行及访问 siyumenghai.cn。输出是会话里的下载文件，不会自动写进电脑。参见[官方说明](https://support.claude.com/en/articles/12512180-use-skills-in-claude)。组织禁用相关权限时，需管理员放行或改用本地 Agent。

**Codex、Claude Code 或可操作本地文件的其他 Agent：** 把 ZIP 发给 AI，复制这段话：
> 请解压这个技能包，先阅读 SKILL.md，检测并补齐需要的依赖，安装到你当前客户端实际使用的 Skill 目录。已有同名技能先备份，不要覆盖。安装后回读文件并告诉我是否需要重开会话；然后用我提供的抖音链接验证。

适用于具备本地文件和命令执行能力的 Codex、Claude Code、WorkBuddy 等 Agent 模式。附件上传、原生导入、自动发现能力随客户端而异；只有上传成功不代表安装成功。不能读取 ZIP 时，手动解压并让 Agent 打开里面的 download-douyin-workbench 文件夹。无法执行命令时，切到具有本地执行能力的模式。

安装器不自动选客户端。Codex：`python3 install.py --client codex`；Claude Code：`python3 install.py --client claude`。其他客户端确认实际目录后：`python3 install.py --target "Skill父目录"`。Windows 把 python3 替换成已验证的 py -3 或 python。安装器尊重 CODEX_HOME，不覆盖同名文件夹，也不会修改其他客户端配置。

## 依赖

Python 3.9+，无需 pip 包。下载视频另需 FFmpeg（含 ffprobe）；数据/图片不需要。AI 应先检测，只安装缺失项。

| 系统 | 已有包管理器时的命令 |
|---|---|
| macOS | brew install python；brew install ffmpeg |
| Windows | winget install --exact --id Python.Python.3.12；winget install --exact --id Gyan.FFmpeg |
| Ubuntu/Debian | sudo apt-get update；sudo apt-get install -y python3 ffmpeg |

表中是分别执行的命令。系统密码和授权窗口由本人完成。没有包管理器时使用 [Python 官网](https://www.python.org/downloads/) 和 [FFmpeg 官网](https://ffmpeg.org/download.html)，不下载来源不明的安装包。安装后重开终端检查 PATH。不要关闭 TLS 证书校验来处理网络错误。

## 直接发这些话即可

- “帮我解析这个抖音，保存视频、封面和资料：链接”
- “下载这个图集的全部图片：链接”
- “导出这个博主的作品数据，先取20条：主页链接”
- “继续提取全部作品，保留分页进度。”
- “导出这个合集的作品：合集分享链接”
- “取这个作品前20条评论，导出表格：作品链接”

默认存到当前工作目录 downloads/douyin；可指定路径。每次生成独立目录。JSON 保留完整字段，CSV 可用 Excel 打开；点赞等字段缺失不会写成0。运行记录用于恢复和查询，不与网页历史同步。

## 遇到问题

- 找不到技能：重开会话，检查实际安装目录和完整 scripts 文件夹；也可直接让 AI 读取解压目录的 SKILL.md 临时使用。
- 只需数据却缺 FFmpeg：使用 --mode data；无需为此装 FFmpeg。
- 下载不完整：只把通过校验并正式更名的文件算成功，.part 不算。脚本会报告失败项。
- 临时地址过期：程序遇到 HTTP 410 自动重新解析一次；仍失败就重新提交原分享链接。
- 部分成功：已成功文件和数据保留，重新提交失败作品即可；分页续做不会自动重下已记录的失败媒体。
- 提取被打断：提供上次结果目录，让 AI 使用 --resume；不要从零开始反复抓取，也不要同时操作同一目录。
- 403/429：停止重试；429 至少五分钟后再试。502/503：解析服务异常，联系石更新。
- 显示还有下一页：当前不是全部结果。所有作品/评论是否可获取受平台返回和服务限制。
- 无法保存手机相册：本包保存到运行 Agent 的文件目录，可把结果传到手机；手机原生保存可使用网页工作台。

有问题把“所用客户端、系统、报错文字”发给石更新。不发账号密码、Cookie 或完整临时下载地址。

## 服务与交付边界

使用同网页的在线服务 https://siyumenghai.cn/api/douyin ，会发送输入链接。不需要群友自行部署服务，也不需要账号、Cookie 或密钥。包内仅含客户端源码，不含服务器实现或凭据；服务可用性、平台返回和限流会影响结果，不承诺无限量或永久可用。仅保存本人拥有或已获授权的素材。

支持 Windows/macOS/Linux 的跨平台代码；具体客户端的权限与安装能力需在用户机器验证。发布时的实测范围见发布目录中的验收记录。卸载只需删除安装的技能文件夹，下载文件仍保留。
