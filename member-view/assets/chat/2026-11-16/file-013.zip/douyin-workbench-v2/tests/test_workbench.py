import argparse
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

SCRIPT = Path(__file__).resolve().parents[1]/"scripts"/"workbench.py"
spec = importlib.util.spec_from_file_location("workbench", SCRIPT)
w = importlib.util.module_from_spec(spec)
spec.loader.exec_module(w)

class ClientTests(unittest.TestCase):
    def args(self, root, **kw):
        d = dict(command="posts",target="https://www.douyin.com/user/test",
                 input_file=None, output_dir=str(root), mode="data",
                 count=20,pages=1,resume=None,online=False)
        d.update(kw)
        return argparse.Namespace(**d)

    def test_inputs_and_network_boundary(self):
        self.assertEqual(w.check_input("标题 https://v.douyin.com/abc/。","parse"),
                         "https://v.douyin.com/abc/")
        for u in ["https://douyin.com.evil.test/video/1", "https://127.0.0.1/a",
                  "https://u:p@douyin.com/a", "http://douyin.com/a"]:
            with self.assertRaises(w.Failure):
                w.check_input(u,"parse")
        for u in ["https://evil.test/a","http://siyumenghai.cn/api/douyin/media/x",
                  "https://siyumenghai.cn/other"]:
            with self.assertRaises(w.Failure):
                w.media_url(u)

    def test_paging_resume_dedup(self):
        with tempfile.TemporaryDirectory() as root:
            a=self.args(root)
            with patch.object(w,"request_json",return_value={"items":[{"id":"123456"}],"cursor":99,"has_more":True}):
                first,code=w.run(a)
            self.assertEqual(first["status"],"page_complete")
            self.assertEqual(code,0)
            a.resume=first["folder"]
            with patch.object(w,"request_json",return_value={"items":[{"id":"123456"},{"id":"234567"}],"has_more":False}) as api:
                last,code=w.run(a)
            self.assertEqual(api.call_args.args[1]["cursor"],99)
            self.assertEqual(last["count"],2)
            self.assertFalse(last["has_more"])

    def test_cursor_stuck_keeps_data(self):
        with tempfile.TemporaryDirectory() as root:
            with patch.object(w,"request_json",return_value={"items":[{"id":"123456"}],"has_more":True,"cursor":None}):
                result,code=w.run(self.args(root))
            self.assertEqual(code,2)
            self.assertEqual(len(json.loads((Path(result["folder"])/"data.json").read_text())["items"]),1)

    def test_rate_limit_stops(self):
        with tempfile.TemporaryDirectory() as root:
            with patch.object(w,"request_json",side_effect=w.Failure("限流",429)) as api:
                result,code=w.run(self.args(root))
            self.assertEqual(api.call_count,1)
            self.assertEqual(code,2)
            self.assertTrue(Path(result["resume"],"state.json").exists())

    def test_partial_batch_continues(self):
        with tempfile.TemporaryDirectory() as root:
            source=Path(root)/"input.txt"
            source.write_text("https://www.douyin.com/video/123456\nhttps://www.douyin.com/video/234567")
            a=self.args(root,command="parse",input_file=str(source))
            with patch.object(w,"request_json",side_effect=[w.Failure("解析失败",502),{"id":"234567"}]), patch.object(w.time,"sleep"):
                result,code=w.run(a)
            self.assertEqual(result["count"],1)
            self.assertEqual(code,2)
            self.assertEqual(len(result["errors"]),1)

    def test_csv_and_missing(self):
        with tempfile.TemporaryDirectory() as root:
            w.exports(Path(root),[{"description":"=1+1","author":"测试"}],"parse")
            data=(Path(root)/"data.csv").read_text(encoding="utf-8-sig")
            self.assertIn("'=1+1",data)
            self.assertEqual(w.safe_cell(None),"")

    def test_image_validation_and_cleanup(self):
        import io
        from email.message import Message
        class Response(io.BytesIO):
            def __init__(self, data):
                super().__init__(data)
                self.headers=Message()
                self.headers["Content-Type"]="image/png"
                self.headers["Content-Length"]=str(len(data))
        class Opener:
            def __init__(self,data): self.data=data
            def open(self,*args,**kwargs): return Response(self.data)
        with tempfile.TemporaryDirectory() as root:
            stem=Path(root)/"image"
            with patch.object(w.urllib.request,"build_opener",return_value=Opener(b"<html>bad</html>")):
                with self.assertRaises(w.Failure):
                    w.download("/api/douyin/media/x",stem,"image")
            self.assertFalse(Path(str(stem)+".part").exists())
            with patch.object(w.urllib.request,"build_opener",return_value=Opener(b"\x89PNG\r\n\x1a\n"+"test".encode())):
                got=w.download("/api/douyin/media/x",stem,"image")
            self.assertTrue(Path(got["path"]).is_file())

    def test_expired_ticket_refreshes_once(self):
        item={"id":"123456", "cover":"/api/douyin/media/old"}
        with tempfile.TemporaryDirectory() as root:
            with patch.object(w,"download",side_effect=[w.Failure("expired",410),{"path":"ok.jpg"}]) as dl, patch.object(w,"request_json",return_value={"cover":"/api/douyin/media/fresh"}) as api, patch.object(w.time,"sleep"):
                files,errors=w.collect_media(item,Path(root),"cover")
            self.assertEqual(errors,[])
            self.assertEqual(api.call_count,1)
            self.assertEqual(dl.call_args.args[0],"/api/douyin/media/fresh")
            self.assertEqual(len(files),1)

    def test_interrupt_does_not_lose_media_failure(self):
        with tempfile.TemporaryDirectory() as root:
            a=self.args(root,command="parse",target="https://www.douyin.com/video/123456",mode="cover")
            with patch.object(w,"request_json",return_value={"id":"123456","cover":"x"}), patch.object(w,"collect_media",side_effect=KeyboardInterrupt):
                result,code=w.run(a)
            state=json.loads(Path(result["folder"],"state.json").read_text())
            self.assertEqual(code,2)
            self.assertEqual(state["errors"][0]["id"],"123456")

    def test_installer_duplicate_does_not_overwrite(self):
        with tempfile.TemporaryDirectory() as root:
            installer=SCRIPT.parents[1]/"install.py"
            cmd=[sys.executable,str(installer),"--target",str(Path(root)/"skills")]
            first=subprocess.run(cmd,capture_output=True)
            self.assertEqual(first.returncode,0)
            installed=Path(root)/"skills"/"download-douyin-workbench"/"SKILL.md"
            old=installed.read_bytes()
            second=subprocess.run(cmd,capture_output=True)
            self.assertNotEqual(second.returncode,0)
            self.assertEqual(installed.read_bytes(),old)

if __name__=="__main__":
    unittest.main()
