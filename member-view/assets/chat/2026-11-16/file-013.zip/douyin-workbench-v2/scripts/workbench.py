#!/usr/bin/env python3
"""Portable Douyin workbench client. Python 3.9+, standard library only."""
import argparse
import csv
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timezone

BASE = "https://siyumenghai.cn/api/douyin"
MAX_BYTES = 1024 * 1024 * 1024

class Failure(Exception):
    def __init__(self, message, code=0):
        super().__init__(message)
        self.code = code

def stamp():
    return datetime.now(timezone.utc).isoformat()

def save_json(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(path)

def request_json(route, body=None):
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(BASE + "/" + route, data=data,
        headers={"Content-Type": "application/json", "User-Agent": "DouyinWorkbenchSkill/1.0"})
    try:
        with urllib.request.urlopen(req, timeout=120) as r:
            result = json.load(r)
    except urllib.error.HTTPError as e:
        # Do not print bodies: they can contain signed URLs or internal details.
        messages = {400: "输入无效", 401: "服务鉴权异常，请联系石更新",
                    403: "访问受限，停止重试", 429: "服务限流，至少等待五分钟后手动续做",
                    502: "上游解析失败", 503: "解析服务暂不可用", 410: "媒体地址过期"}
        raise Failure(messages.get(e.code, "服务请求失败") + " (HTTP %s)" % e.code, e.code)
    except (OSError, ValueError) as e:
        raise Failure("网络超时、连接失败或服务未返回 JSON；已保留现有文件") from e
    if not isinstance(result, dict):
        raise Failure("服务返回格式异常")
    if result.get("success") is False or result.get("error"):
        raise Failure("服务报告解析失败，请稍后或联系石更新")
    return result

def check_input(value, mode):
    value = value.strip()
    if mode == "comments" and re.fullmatch(r"\d{5,30}", value):
        return value
    if mode in ("posts", "profile") and re.fullmatch(r"MS4wLjAB[\w-]+", value):
        return value
    if mode == "mix" and re.fullmatch(r"\d{5,30}", value):
        return value
    urls = re.findall(r"https://[^\s<>\"\u3000]+", value)
    urls = [u.rstrip("。，；！）】,;!)]") for u in urls]
    if len(urls) != 1:
        raise Failure("每条输入须包含一个 HTTPS 抖音链接；批量请每行一条")
    u = urllib.parse.urlsplit(urls[0])
    if (u.hostname != "douyin.com" and not (u.hostname or "").endswith(".douyin.com")) or u.username or u.password or u.port not in (None, 443):
        raise Failure("仅接受 HTTPS 抖音链接")
    return urls[0]

# 允许直连的抖音 CDN 域名白名单（直连下载，不走中转）
ALLOWED_MEDIA_HOSTS = {
    "siyumenghai.cn",
    "douyinvod.com",
    "douyinpic.com",
    "douyinimg.com",
    "bytedance.com",
    "bytecdn.cn",
    "bytetos.com",
    "byteimg.com",
    "pstatp.com",
    "snssdk.com",
    "douyin.com",
    "iesdouyin.com",
    "ibytedtos.com",
}

# 解析时请求 CDN 直链（本地带 Referer 直连，绕开服务器带宽）；网页端不要使用
PARSE_ROUTE = "parse?direct=1"

def _is_allowed_host(hostname):
    """检查域名是否在白名单内（支持子域名）"""
    hostname = (hostname or "").lower().rstrip(".")
    for allowed in ALLOWED_MEDIA_HOSTS:
        if hostname == allowed or hostname.endswith("." + allowed):
            return True
    return False

def media_url(value):
    """解析媒体 URL，支持两种格式：
    1. 本站代理路径（兼容旧版服务端）：/api/douyin/media/xxx
    2. 抖音 CDN 直链（新版服务端）：https://v26-webf.douyinvod.com/...
    """
    # 如果已经是完整 URL，直接解析
    if value.startswith("https://"):
        u = urllib.parse.urlsplit(value)
        if u.scheme != "https" or not _is_allowed_host(u.netloc):
            raise Failure("服务返回了不受信任的媒体地址，未下载")
        host = (u.hostname or "").lower().rstrip(".")
        # 本站域名必须落在媒体代理路径；CDN 域名按主机白名单放行任意路径
        if host == "siyumenghai.cn" or host.endswith(".siyumenghai.cn"):
            if not u.path.startswith("/api/douyin/media/"):
                raise Failure("服务返回了非本站媒体地址，未下载")
        return urllib.parse.urlunsplit(u)
    # 相对路径，拼到本站 BASE
    u = urllib.parse.urlsplit(urllib.parse.urljoin(BASE + "/", value))
    base = urllib.parse.urlsplit(BASE)
    if u.scheme != "https" or u.netloc != base.netloc or not u.path.startswith("/api/douyin/media/"):
        raise Failure("服务返回了非本站媒体地址，未下载")
    return urllib.parse.urlunsplit(u)

class MediaRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        media_url(newurl)
        return super().redirect_request(req, fp, code, msg, headers, newurl)

def _content_range_total(headers):
    """从 Content-Range 头解析完整文件大小：bytes 0-999/10000 -> 10000"""
    cr = headers.get("Content-Range", "")
    m = re.match(r"bytes \d+-\d+/(\d+|\*)", cr)
    if not m or m.group(1) == "*":
        return None
    try:
        return int(m.group(1))
    except ValueError:
        return None

def download(value, stem, kind):
    url = media_url(value)
    part = Path(str(stem) + ".part")
    resume = part.stat().st_size if part.exists() and part.stat().st_size else 0
    keep_part = False  # True 时保留 .part 供断点续传（网络中断/票据过期）
    try:
        # 抖音 CDN 需要 Referer 才能访问，否则 403
        headers = {
            "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "Referer": "https://www.douyin.com/",
        }
        if resume:
            headers["Range"] = "bytes=%d-" % resume
        req = urllib.request.Request(url, headers=headers)
        with urllib.request.build_opener(MediaRedirect()).open(req, timeout=120) as r:
            status = getattr(r, "status", 200)
            mime = r.headers.get_content_type()
            extensions = {"image/jpeg":".jpg", "image/png":".png", "image/webp":".webp",
                          "image/gif":".gif", "image/avif":".avif", "video/mp4":".mp4"}
            if mime not in extensions or (kind == "video") != mime.startswith("video/"):
                raise Failure("媒体类型不符合预期，未保存为成功文件")
            if status == 206:
                # 服务器支持 Range：从断点继续
                total = _content_range_total(r.headers)
                if total is None:
                    total = resume + int(r.headers.get("Content-Length", "0") or 0)
            else:
                # 服务器从头响应：覆盖旧 .part
                total = int(r.headers.get("Content-Length", "0") or 0)
                resume = 0
            if total > MAX_BYTES:
                raise Failure("媒体超过 1GB 上限")
            size = resume
            with part.open("ab" if resume else "wb") as f:
                while True:
                    chunk = r.read(1024 * 1024)
                    if not chunk:
                        break
                    size += len(chunk)
                    if size > MAX_BYTES:
                        raise Failure("媒体超过 1GB 上限")
                    f.write(chunk)
            if not size or (total and total != size):
                raise Failure("媒体为空或下载不完整")
        head = part.read_bytes()[:32] if size < 64 else None
        if head is None:
            with part.open("rb") as f:
                head = f.read(32)
        valid = (mime == "image/jpeg" and head.startswith(b"\xff\xd8\xff") or
                 mime == "image/png" and head.startswith(b"\x89PNG\r\n\x1a\n") or
                 mime == "image/webp" and head[:4] == b"RIFF" and head[8:12] == b"WEBP" or
                 mime == "image/gif" and head[:6] in (b"GIF87a", b"GIF89a") or
                 mime in ("video/mp4", "image/avif") and head[4:8] == b"ftyp")
        if not valid:
            raise Failure("文件头校验失败")
        meta = {"size": size, "mime": mime}
        if kind == "video":
            p = subprocess.run(["ffprobe", "-v", "error", "-show_streams", "-show_format",
                                "-of", "json", str(part)], capture_output=True, text=True, timeout=60)
            probe = json.loads(p.stdout or "{}")
            streams = probe.get("streams", [])
            video = next((s for s in streams if s.get("codec_type") == "video"), None)
            if p.returncode or not video or float(probe.get("format", {}).get("duration", 0)) <= 0:
                raise Failure("视频流或时长校验失败")
            meta.update(duration=probe["format"]["duration"], width=video.get("width"),
                        height=video.get("height"), codec=video.get("codec_name"),
                        has_audio=any(s.get("codec_type") == "audio" for s in streams))
        dest = Path(str(stem) + extensions[mime])
        if dest.exists():
            raise Failure("目标文件已存在，未覆盖")
        part.replace(dest)
        meta["path"] = str(dest.resolve())
        return meta
    except urllib.error.HTTPError as e:
        # 媒体票据过期：保留 .part，collect_media 会重新解析后从断点续传
        keep_part = e.code == 410
        if e.code == 416:
            # Range 起点超出文件总长（罕见）：丢弃旧 .part 从头下载
            part.unlink(missing_ok=True)
            keep_part = False
        raise Failure("媒体读取失败 (HTTP %s)" % e.code, e.code)
    except (OSError, subprocess.SubprocessError) as e:
        # 网络中断/超时：保留已下载字节，重新提交同链接可断点续传
        keep_part = True
        raise Failure("媒体下载或校验失败") from e
    except ValueError as e:
        raise Failure("媒体下载或校验失败") from e
    finally:
        if not keep_part:
            part.unlink(missing_ok=True)

def safe_cell(value):
    value = "" if value is None else str(value)
    return "'" + value if value.lstrip().startswith(("=", "+", "-", "@")) else value

def exports(folder, records, mode):
    save_json(folder / "data.json", {"collected_at": stamp(), "mode": mode, "items": records})
    # 中文表头
    headers = ["作品ID", "作者", "作品描述", "发布时间", "点赞数", "评论数",
               "分享数", "收藏数", "作品链接", "评论内容", "博主昵称", "博主简介",
               "粉丝数", "作品数", "总获赞数"]
    # 对应的英文 key（用来取数据）
    keys = ["id", "author", "description", "created_at", "digg_count", "comment_count",
            "share_count", "collect_count", "web_url", "text", "nickname", "signature",
            "follower_count", "content_count", "total_digg"]

    rows = []
    for item in records:
        stats = item.get("stats") or {}
        row = dict(item)
        row.update({k:stats.get(k) for k in keys if k.endswith("_count") or k == "total_digg"})
        if mode == "comments":
            row["author"] = (item.get("user") or item.get("author") or {}).get("nickname", "") if isinstance(item.get("user") or item.get("author"), dict) else item.get("author", "")
            row["id"] = item.get("id", item.get("cid"))
            row["text"] = item.get("text", item.get("content"))
            row["digg_count"] = item.get("digg_count")
        rows.append([safe_cell(row.get(k)) for k in keys])

    # 优先导出 Excel（有 openpyxl 就用，没有就降级 CSV）
    def write_excel(path, sheet_name, hds, rws):
        from openpyxl import Workbook
        from openpyxl.styles import Font, PatternFill, Alignment
        wb = Workbook()
        ws = wb.active
        ws.title = sheet_name
        header_font = Font(bold=True, color="FFFFFF", size=11)
        header_fill = PatternFill(start_color="4472C4", end_color="4472C4", fill_type="solid")
        for col, h in enumerate(hds, 1):
            cell = ws.cell(row=1, column=col, value=h)
            cell.font = header_font
            cell.fill = header_fill
            cell.alignment = Alignment(horizontal="center", vertical="center")
        for r, row_data in enumerate(rws, 2):
            for c, val in enumerate(row_data, 1):
                ws.cell(row=r, column=c, value=val)
        for col in ws.columns:
            max_len = max(len(str(cell.value or "")) for cell in col)
            ws.column_dimensions[col[0].column_letter].width = min(max_len + 2, 50)
        wb.save(str(path))

    def write_csv(path, hds, rws):
        with path.open("w", encoding="utf-8-sig", newline="") as f:
            w = csv.writer(f)
            w.writerow(hds)
            w.writerows(rws)

    try:
        # 主数据文件
        write_excel(folder / "data.xlsx", "抖音数据", headers, rows)
        # 评论模式下单独导出评论表
        if mode == "comments":
            comment_headers = ["评论ID", "评论作者", "评论内容", "评论点赞数", "评论时间"]
            comment_keys = ["id", "author", "text", "digg_count", "created_at"]
            comment_rows = []
            for item in records:
                row = dict(item)
                row["author"] = (item.get("user") or item.get("author") or {}).get("nickname", "") if isinstance(item.get("user") or item.get("author"), dict) else item.get("author", "")
                row["id"] = item.get("id", item.get("cid"))
                row["text"] = item.get("text", item.get("content"))
                comment_rows.append([safe_cell(row.get(k)) for k in comment_keys])
            write_excel(folder / "评论列表.xlsx", "评论列表", comment_headers, comment_rows)
    except ImportError:
        # 降级 CSV
        write_csv(folder / "data.csv", headers, rows)
        if mode == "comments":
            comment_headers = ["评论ID", "评论作者", "评论内容", "评论点赞数", "评论时间"]
            comment_keys = ["id", "author", "text", "digg_count", "created_at"]
            comment_rows = []
            for item in records:
                row = dict(item)
                row["author"] = (item.get("user") or item.get("author") or {}).get("nickname", "") if isinstance(item.get("user") or item.get("author"), dict) else item.get("author", "")
                row["id"] = item.get("id", item.get("cid"))
                row["text"] = item.get("text", item.get("content"))
                comment_rows.append([safe_cell(row.get(k)) for k in comment_keys])
            write_csv(folder / "评论列表.csv", comment_headers, comment_rows)

def collect_media(item, folder, mode):
    results, errors = [], []
    ident = str(item.get("id") or "")
    if not re.fullmatch(r"\d{5,30}", ident):
        return [], ["作品 ID 缺失或无效"]
    jobs = []
    if mode in ("all", "cover") and item.get("cover"):
        jobs.append(("cover", item["cover"], "image"))
    if mode in ("all", "video") and item.get("video"):
        jobs.append(("video", item["video"], "video"))
    if mode in ("all", "images"):
        jobs.extend(("image-%03d" % (i+1), u, "image") for i,u in enumerate(item.get("images") or []))
    if not jobs:
        return [], ["未返回所请求的媒体资源"]
    refreshed = None
    for name, url, kind in jobs:
        try:
            try:
                result = download(url, folder / (ident + "-" + name), kind)
            except Failure as e:
                if e.code != 410:
                    raise
                if refreshed is None:
                    time.sleep(3)
                    refreshed = request_json(PARSE_ROUTE, {"url": "https://www.douyin.com/video/" + ident})
                fresh = refreshed.get(name) if name in ("cover","video") else (refreshed.get("images") or [])[int(name.split("-")[1])-1]
                result = download(fresh, folder / (ident + "-" + name), kind)
            results.append(result)
        except (Failure, IndexError) as e:
            errors.append(name + ": " + str(e))
            if isinstance(e, Failure) and e.code in (401,403,429,503):
                break
    return results, errors

def run(a):
    if a.command == "check":
        result = {"python":sys.version.split()[0], "ffprobe":shutil.which("ffprobe")}
        if result["ffprobe"]:
            result["ffprobe_works"] = subprocess.run(["ffprobe","-version"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).returncode == 0
        if a.online:
            h = request_json("health")
            result["service"] = {k:h.get(k) for k in ("configured","verified","cooldown_seconds","last_success")}
        return result, 0
    root = Path(a.output_dir).expanduser().resolve()
    if a.command == "history":
        f = root / "history.json"
        if a.clear_history:
            save_json(f, [])
        return {"path":str(f),"items":json.loads(f.read_text(encoding="utf-8")) if f.exists() else []}, 0
    mode = a.mode or ("all" if a.command == "parse" else "data")
    if mode in ("all","video") and a.command in ("parse","posts","mix") and not shutil.which("ffprobe"):
        raise Failure("下载视频需要 FFmpeg/ffprobe；先安装，或明确选择 --mode data/images/cover")
    if a.command in ("profile","comments") and mode != "data":
        raise Failure("profile/comments 仅支持 --mode data")
    if a.resume:
        folder = Path(a.resume).expanduser().resolve()
        state = json.loads((folder / "state.json").read_text(encoding="utf-8"))
        if state["command"] != a.command or state["mode"] != mode:
            raise Failure("续做命令与原记录 command/mode 不一致")
        if state.get("complete"):
            return {"status":"complete","folder":str(folder),"note":"此记录已经完成"}, 0
    else:
        inputs = Path(a.input_file).read_text(encoding="utf-8-sig").splitlines() if a.input_file else [a.target or ""]
        inputs = [check_input(x,a.command) for x in inputs if x.strip()]
        inputs = list(dict.fromkeys(inputs))
        if not inputs or len(inputs)>20 or (a.command != "parse" and len(inputs)!=1):
            raise Failure("作品批量支持 1–20 条；其他查询每次一个目标")
        folder = root / (datetime.now().strftime("%Y%m%d-%H%M%S") + "-" + a.command + "-" + os.urandom(3).hex())
        folder.mkdir(parents=True, exist_ok=False)
        state = dict(command=a.command, mode=mode, targets=inputs, index=0, cursor=None,
                     records=[], files=[], errors=[], complete=False, seen_cursors=[])
    def persist():
        save_json(folder/"state.json", state)
        exports(folder,state["records"],a.command)
    pages = 0
    try:
        while state["index"] < len(state["targets"]):
            target = state["targets"][state["index"]]
            body = {"url":target} if a.command == "parse" else {"target":target,"count":a.count,"cursor":state["cursor"]}
            if a.command == "comments":
                body = {"id":target,"count":a.count,"cursor":state["cursor"] or 0}
            if a.command == "profile":
                body = {"target":target}
            try:
                data = request_json(PARSE_ROUTE if a.command == "parse" else a.command, body)
            except Failure as e:
                if a.command == "parse" and e.code not in (401,403,429,503):
                    state["errors"].append({"input":target,"error":str(e)})
                    state["index"] += 1
                    persist()
                    if state["index"] < len(state["targets"]):
                        time.sleep(3)
                    continue
                raise
            items = [data] if a.command in ("parse","profile") else data.get("items")
            if not isinstance(items,list) or any(not isinstance(x,dict) for x in items):
                raise Failure("服务返回项目格式异常")
            known = {str(x.get("id") or x.get("cid") or json.dumps(x,sort_keys=True)) for x in state["records"]}
            for item in items:
                key = str(item.get("id") or item.get("cid") or json.dumps(item,sort_keys=True))
                if key in known:
                    continue
                state["records"].append(item)
                known.add(key)
                if mode != "data":
                    try:
                        files, errors = collect_media(item,folder,mode)
                    except KeyboardInterrupt:
                        state["errors"].append({"id":item.get("id"),"error":"媒体保存被中断；请重新提交此作品补齐"})
                        raise
                    state["files"].extend(files)
                    state["errors"].extend({"id":item.get("id"),"error":e} for e in errors)
                persist()
            pages += 1
            more = bool(data.get("has_more")) if a.command in ("posts","mix","comments") else False
            next_cursor = data.get("cursor")
            if more:
                key = str(next_cursor)
                if next_cursor is None or key == str(state["cursor"]) or key in state["seen_cursors"]:
                    raise Failure("分页游标未推进或重复，已停止，未声称提取全部")
                state["seen_cursors"].append(key)
                state["cursor"] = next_cursor
            else:
                state["index"] += 1
                state["cursor"] = None
                state["seen_cursors"] = []
            state["complete"] = state["index"] >= len(state["targets"])
            persist()
            if state["complete"] or (a.command != "parse" and pages >= a.pages):
                break
            time.sleep(15 if a.command in ("posts","mix","comments") else 3)
    except (Failure, KeyboardInterrupt) as e:
        state["last_error"] = str(e) or "用户停止"
        persist()
        return {"status":"partial","folder":str(folder),"count":len(state["records"]),"error":state["last_error"],"resume":str(folder)}, 2
    state.pop("last_error",None)
    persist()
    history_path = root/"history.json"
    try:
        history = json.loads(history_path.read_text(encoding="utf-8")) if history_path.exists() else []
    except (ValueError,OSError):
        history = []
    history.append({"at":stamp(),"command":a.command,"folder":str(folder),"count":len(state["records"])})
    save_json(history_path,history[-100:])
    status = "partial" if state["errors"] else ("complete" if state["complete"] else "page_complete")
    return {"status":status,"folder":str(folder),"count":len(state["records"]),
            "files":state["files"],"errors":state["errors"],"has_more":not state["complete"],
            "resume":str(folder) if not state["complete"] else None}, 2 if state["errors"] else 0

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("command",choices=["check","parse","profile","posts","mix","comments","history"])
    p.add_argument("target",nargs="?")
    p.add_argument("--input-file")
    p.add_argument("--output-dir",default="downloads/douyin")
    p.add_argument("--mode",choices=["all","video","cover","images","data"])
    p.add_argument("--count",type=int,default=20)
    p.add_argument("--pages",type=int,default=1)
    p.add_argument("--resume",help="Previously returned run folder; preserves pagination")
    p.add_argument("--online",action="store_true")
    p.add_argument("--clear-history",action="store_true",help="Clear local history only; retain downloads")
    a = p.parse_args()
    if sys.version_info < (3,9):
        p.error("需要 Python 3.9+")
    if not 1<=a.count<=50 or not 1<=a.pages<=100:
        p.error("count 为 1–50，pages 为 1–100")
    try:
        result, code = run(a)
    except (Failure,OSError,ValueError) as e:
        result,code = {"status":"failed","error":str(e)},1
    print("RESULT_JSON="+json.dumps(result,ensure_ascii=False))
    return code
if __name__ == "__main__":
    sys.exit(main())
